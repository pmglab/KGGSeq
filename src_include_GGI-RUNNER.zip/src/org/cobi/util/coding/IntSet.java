/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.coding;

import cern.colt.map.OpenIntIntHashMap;
import cern.colt.map.OpenLongObjectHashMap;
import java.util.HashSet;
import java.util.Set;
import org.cobi.kggseq.GlobalManager;

/**
 * Fast set class for ints, loosely based java.util.HashTable, HashSet, and the
 * discussion of hashtables from "Data Structures & Algorithms in Java" by
 * Robert Lafore.
 *
 * @author Tom Ball
 */
final class IntSet {

    static class Entry {

        int value;
        int hash;
        Entry next;

        Entry(int v, int h, Entry n) {
            value = v;
            hash = h;
            next = n;
        }
    }

    private Entry[] table;
    private int size;

    private static final int LOAD_FACTOR = 2;
    private static final int GROWTH_FACTOR = 2;

    public IntSet() {
        // 2048 is the max used by all of the JDK sources.
        // Use fewer only if the set is referenced longer than
        // the body of makeIndexes() above.
        this(2048);
    }

    public IntSet(int capacity) {
        table = new Entry[capacity];
    }

    public static void main(String[] args) {
        //test perofrmance
        int n = 30000000;
        long start = System.nanoTime();
        int a = 3233323;
        byte b = 124;
        for (int i = 0; i < n; i++) {
          //  a = a | GlobalManager.intOpers[4];
        }

        System.out.println((System.nanoTime() - start) / 1000);
        start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            b = (byte) (b | GlobalManager.byte1Opers[4]);
        }
        System.out.println((System.nanoTime() - start) / 1000);

        /*
        IntSet is = new IntSet();
        for (int i = 0; i < n; i++) {
            is.add(i);
        }
        for (int i = 0; i < n; i++) {
            is.contains(i);
        }
        System.out.println((System.nanoTime() - start) / 1000);
        is.resize();
        Set<Integer> it = new HashSet<Integer>();
        start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            it.add(55);
            it.add(2);
        }
        for (int i = 0; i < n; i++) {
            it.contains(i);
        }
        System.out.println((System.nanoTime() - start) / 1000);
        it.clear();

        /*
        IntOpenHashSet ih = new IntOpenHashSet();
        start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            ih.add(i);
        }
        for (int i = 0; i < n; i++) {
            ih.contains(i);
        }
        System.out.println((System.nanoTime() - start) / 1000);
        ih.clear();
        

 
        Int2IntOpenHashMap iom = new Int2IntOpenHashMap();
        start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            iom.put(i, 0);
        }
        for (int i = 0; i < n; i++) {
            iom.containsKey(i);                                                                                                                              b
        }
        System.out.println((System.nanoTime() - start) / 1000);
        iom.clear();
        
        OpenIntIntHashMap posIndexMap = new OpenIntIntHashMap();
        start = System.nanoTime();
        for (int i = 0; i < n; i++) {
            posIndexMap.put(i, 0);
        }
        for (int i = 0; i < n; i++) {
            posIndexMap.containsKey(i);
        }
        System.out.println((System.nanoTime() - start) / 1000);
        posIndexMap.clear();

        OpenLongObjectHashMap posIndexMapL = new OpenLongObjectHashMap();
        start = System.nanoTime();
        for (long i = 0; i < Long.MAX_VALUE; i++) {
            posIndexMapL.put(i, 0);
            if (i >>> 2 > Integer.MAX_VALUE) {
                break;
            }
        }
        for (long i = 0; i < Long.MAX_VALUE; i++) {
            posIndexMapL.containsKey(i);
        }
        System.out.println((System.nanoTime() - start) / 1000);
        posIndexMapL.clear();
*/
    }

    public boolean add(int x) {
        if (contains(x)) {
            return false;
        }

        if (size > table.length / LOAD_FACTOR) {
            resize();
        }

        int h = hash(x);
        int idx = indexFor(h, table.length);
        Entry e = new Entry(x, h, table[idx]);
        table[idx] = e;
        size++;
        return true;
    }

    public boolean contains(int x) {
        int h = hash(x);
        Entry e = table[indexFor(h, table.length)];
        while (e != null) {
            if (e.value == x) {
                return true;
            }
            e = e.next;
        }
        return false;
    }

    public int[] toArray() {
        int[] arr = new int[size];
        int n = 0;
        Entry eNext;
        for (int i = 0; i < table.length; i++) {
            for (Entry e = table[i]; e != null; e = e.next) {
                arr[n++] = e.value;
            }
        }
        assert n == size;
        return arr;
    }

    private void resize() {
        Entry[] newt = new Entry[table.length * GROWTH_FACTOR];

        Entry eNext;
        for (int i = 0; i < table.length; i++) {
            for (Entry e = table[i]; e != null; e = eNext) {
                int idx = indexFor(e.hash, newt.length);
                eNext = e.next;
                e.next = newt[idx];
                newt[idx] = e;
            }
        }
        table = newt;

    }

    // hash(), forIndex() from java.util.HashMap
    /**
     * Returns a hash value for the specified object. In addition to the
     * object's own hashCode, this method applies a "supplemental hash
     * function," which defends against poor quality hash functions. This is
     * critical because HashMap uses power-of two length hash tables.
     *
     *
     * The shift distances in this function were chosen as the result of an
     * automated search over the entire four-dimensional search space.
     */
    private static int hash(int h) {
        h += ~(h << 9);
        h ^= (h >>> 14);
        h += (h << 4);
        h ^= (h >>> 10);
        return h;
    }

    /**
     * Returns index for hash code h.
     */
    private static int indexFor(int h, int length) {
        return h & (length - 1);
    }
}
