/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.file;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.apache.log4j.Logger;

/**
 *
 * @author mxli
 */
public class ExecuteShellUtils {

    private static final Logger LOG = Logger.getLogger(ExecuteShellUtils.class);

    /**
     * @descrption 执行外部exe公用方法
     * @author xdwang
     * @create 2012-7-20下午22:24:32
     * @param cmdStr 命令字符串
     */
    public static void execProcess(String cmdStr, String errorMsg) {
        Process process = null;
        try {
            //System.out.println(cmdStr);
            process = Runtime.getRuntime().exec(cmdStr);
            new ProcessClearStream(process.getInputStream(), "INFO").start();
            new ProcessClearStream(process.getErrorStream(), "ERROR").start();
            int status = process.waitFor();
            //System.out.println("Process exitValue: " + status);
            if (status != 0) {
                LOG.info(errorMsg);
            }
        } catch (Exception e) {
            LOG.error("Failed to run:执" + cmdStr + ";错" + e.toString());
        } finally {
            if (process == null) {
                process.destroy();
            }
            process = null;
        }
    }

    /**
     * 执行脚本
     *
     * @param shell
     * @return
     * @throws Exception
     */
    public static Integer executeTimeLimit(String shell, int minut) throws Exception {
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec(shell);
        ProcessClearStream error = new ProcessClearStream(process.getErrorStream(), "Error");
        ProcessClearStream output = new ProcessClearStream(process.getInputStream(), "OutPut");
        error.start();
        output.start();
        Integer result = null;
        ExecutorService executor = Executors.newSingleThreadExecutor();
        FutureTask<Integer> futureTask = null;

        futureTask = new FutureTask<Integer>(() -> {
            Integer status = process.waitFor();
            return status;
        });
        executor.execute(futureTask);
//在这里可以做别的任何事情  
        try {
            result = futureTask.get(minut, TimeUnit.MINUTES); //取得结果，同时设置超时执行时间为5秒。同样可以用future.get()，不设置执行超时时间取得结果  
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            futureTask.cancel(true);
        } finally {
            executor.shutdown();
        }

        return result;
    }

    /**
     * 清空脚本缓存流类，防止线程阻塞
     *
     * @author shi
     *
     */
    static class ProcessClearStream extends Thread {

        private InputStream inputStream;
        private String type;

        public ProcessClearStream(InputStream inputStream, String type) {
            this.inputStream = inputStream;
            this.type = type;
        }

        public void run() {
            try {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "GBK");
                BufferedReader br = new BufferedReader(inputStreamReader);
                // 打印信息
                String line = null;
                while ((line = br.readLine()) != null) {
                    //LogUtils.debug(line);
                    // System.out.println(line);
                }
                br.close();
                // 不打印信息
//                 while (br.readLine() != null);
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }
    }
}
