/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.util.file;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.ConsoleAppender;
import ch.qos.logback.core.FileAppender;
import ch.qos.logback.core.rolling.RollingFileAppender;
import ch.qos.logback.core.rolling.TimeBasedRollingPolicy;
import ch.qos.logback.core.util.FileSize;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;

import static ch.qos.logback.core.util.FileSize.GB_COEFFICIENT;

/**
 * 根日志管理器
 */
public class RootLoggerOptions {
    // 根日志对象
    private static final Logger logger = (Logger) LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME);

    // 获取日志上下文信息
    private static final LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

    /**
     * 初始化日志参数
     */
    public static void init() {
        // 重设
        reset();

        // 设置为 debug 级别
        setLevel(Level.DEBUG);

        // 初始化终端追加器
        addConsoleAppender();
    }

    /**
     * 重设日志系统
     */
    public static void reset() {
        context.reset();
    }

    /**
     * 停止日志系统
     */
    public static void stop() {
        context.stop();
    }

    /**
     * 开启日志系统
     */
    public static void start() {
        context.start();
    }

    /**
     * 重设日志系统
     */
    public static void setLevel() {
        logger.setLevel(Level.DEBUG);
    }

    /**
     * 重设日志系统
     */
    public static void setLevel(Level level) {
        logger.setLevel(level);
    }

    /**
     * 获取根日志对象
     *
     * @return 根日志对象
     */
    public static Logger getRootLogger() {
        return logger;
    }

    /**
     * 获取日志上下文
     *
     * @return 日志上下文
     */
    public static LoggerContext getContext() {
        return context;
    }

    /**
     * 添加终端日志规则
     */
    public static void addConsoleAppender() {
        addConsoleAppender("%red(%date{yyyy-MM-dd HH:mm:ss}) %highlight(%-5level) %red([%thread]) %boldMagenta(%logger{50}) %cyan(%msg%n)");
    }

    /**
     * 添加终端日志规则
     *
     * @param pattern 日志格式化模式
     */
    public static void addConsoleAppender(String pattern) {
        // 创建日志编码
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setCharset(StandardCharsets.UTF_8);
        encoder.setPattern(pattern);
        encoder.setImmediateFlush(true);

        // 追加日志模式
        ConsoleAppender<ILoggingEvent> appender = new ConsoleAppender<>();
        appender.setContext(context);
        appender.setEncoder(encoder);
        appender.setName("STDOUT");

        // 启动 encoder 和 appender
        encoder.start();
        appender.start();

        // 向根日志添加终端格式化工具
        logger.addAppender(appender);
    }

    /**
     * 添加基于时间的文件日志规则
     *
     * @param outputDir 日志输出文件夹
     */
    public static void addTimeBasedFileAppender(String outputDir) {
        // 创建日志编码
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setCharset(StandardCharsets.UTF_8);
        encoder.setPattern("%date{yyyy-MM-dd HH:mm:ss} %-5level [%thread] %logger{50} - %msg%n");
        encoder.setImmediateFlush(true);

        // 追加日志模式
        RollingFileAppender<ILoggingEvent> appender = new RollingFileAppender<>();
        appender.setContext(context);

        // 文件规则
        TimeBasedRollingPolicy<ILoggingEvent> policy = new TimeBasedRollingPolicy<>();
        policy.setContext(context);
        policy.setParent(appender);
        // 自动文件命名方式
        policy.setFileNamePattern(outputDir.endsWith("/") ? outputDir + "%d{yyyy-MM-dd}.log" : outputDir + "/%d{yyyy-MM-dd}.log");
        // 最长保留时间 30 天
        policy.setMaxHistory(30);
        // 超过 1 GB 自动清除
        policy.setTotalSizeCap(new FileSize(GB_COEFFICIENT));

        appender.setRollingPolicy(policy);
        appender.setAppend(true);
        appender.setEncoder(encoder);
        appender.setName("FILE");

        // 启动 encoder 和 appender
        policy.start();
        encoder.start();
        appender.start();

        // 向根日志添加终端格式化工具
        logger.addAppender(appender);
    }

    /**
     * 添加基于时间的文件日志规则
     * 默认输出到当前运行路径的 ./log 文件夹下
     */
    public static void addTimeBasedFileAppender() {
        addTimeBasedFileAppender("./log");
    }

    /**
     * 添加输出到指定日志文件
     *
     * @param fileName 日志文件名
     */
    public static void addFileAppender(String fileName) {
        // 创建日志编码
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setCharset(StandardCharsets.UTF_8);
        encoder.setPattern("%date{yyyy-MM-dd HH:mm:ss} %-5level [%thread] %logger{50} - %msg%n");
        encoder.setImmediateFlush(true);

        // 追加日志模式
        FileAppender<ILoggingEvent> appender = new FileAppender<>();
        appender.setContext(context);
        appender.setFile(fileName);
        appender.setAppend(true);
        appender.setEncoder(encoder);
        appender.setName("FILE");

        // 启动 encoder 和 appender
        encoder.start();
        appender.start();

        // 向根日志添加终端格式化工具
        logger.addAppender(appender);
    }

    /**
     * 私有构造器方法
     */
    private RootLoggerOptions() {
    }
}
