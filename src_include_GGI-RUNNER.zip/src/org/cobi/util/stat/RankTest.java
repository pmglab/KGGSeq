/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import cern.colt.list.IntArrayList;
import cern.jet.random.Uniform;
import cern.jet.random.engine.RandomEngine;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.cobi.kggseq.entity.ArrayListComparatorDouble;
import org.cobi.util.text.LocalFile;
import org.cobi.util.thread.Task;
import org.cobi.util.thread.TaskListener;

/**
 *
 * @author mxli
 */
public class RankTest {
//there is a fast version https://academic.oup.com/bioinformatics/article/33/17/2774/3803441
    //but maybe it is not suitable for consequetively eqaul data

    public Map<String, String[]> permutationTest(List<String[]> geneScores, int threadNum, int maxSimuTimes) throws Exception {
        int valueNum = geneScores.get(0).length;
        int[] indexes = new int[]{1, 2};
        Map<String, int[]> geneOrderMap = new HashMap<String, int[]>();
        List<String[]> geneScoresTmp = geneScores.subList(1, geneScores.size());
        int size = geneScoresTmp.size();
        int orgSize = size + 1;
        int order;
        double v0, v1;
        IntArrayList[] orderValues = new IntArrayList[indexes.length];
        int[] orderTmp;

        for (int i = 0; i < indexes.length; i++) {
            orderValues[i] = new IntArrayList();
            ArrayListComparatorDouble acd = new ArrayListComparatorDouble(indexes[i]);
            Collections.sort(geneScoresTmp, acd);
            order = 0;

            v0 = Double.MAX_VALUE;
            for (int j = 0; j < size; j++) {
                v1 = Double.parseDouble(geneScoresTmp.get(j)[indexes[i]]);
                if (v0 > v1) {
                    order++;
                    v0 = v1;
                }

                orderTmp = geneOrderMap.get(geneScoresTmp.get(j)[0]);
                if (orderTmp == null) {
                    orderTmp = new int[indexes.length];
                    geneOrderMap.put(geneScoresTmp.get(j)[0], orderTmp);
                }
                orderTmp[i] = order;
                orderValues[i].add(order);
            }
        }
        //geneScoresTmp.clear();

        int[][] obsValue = new int[2][size];
        int[] sortObsValue0 = new int[size];
        int[] sortObsValue1 = new int[size];
        // List<int[]> obsValueOrders = new ArrayList<int[]>();
        int add, mul;
        for (int i = 1; i < orgSize; i++) {
            orderTmp = geneOrderMap.get(geneScores.get(i)[0]);
            add = 0;
            mul = 1;
            for (int j = 0; j < indexes.length; j++) {
                add += orderTmp[j];
                mul *= orderTmp[j];
            }
            obsValue[0][i - 1] = add;
            obsValue[1][i - 1] = mul;
            sortObsValue0[i - 1] = add;
            sortObsValue1[i - 1] = mul;
             
        }
        Arrays.sort(sortObsValue0);
        Arrays.sort(sortObsValue1);
        int topNum = 100;
        int[] sortObsValue0T = new int[topNum];
        System.arraycopy(sortObsValue0, 0, sortObsValue0T, 0, topNum);
        int[] sortObsValue1T = new int[topNum];
        System.arraycopy(sortObsValue1, 0, sortObsValue1T, 0, topNum);
        int[][] overallRandCounts = new int[2][topNum];
        Arrays.fill(overallRandCounts[0], 0);
        Arrays.fill(overallRandCounts[1], 0);
        double overallSimu = 0;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        int runningThread = 0;
        final IntArrayList allSims = new IntArrayList();
        for (int s = 0; s < threadNum; s++) {
            final OrderSimulationTask task = new OrderSimulationTask(maxSimuTimes / threadNum, sortObsValue0T, sortObsValue1T, orderValues);
            task.addTaskListener(new TaskListener() {
                @Override
                public void taskCompleted() throws Exception {
                    synchronized (overallRandCounts) {
                        int[] tmpOverCount = task.getRandCount0();
                        for (int j = 0; j < tmpOverCount.length; j++) {
                            overallRandCounts[0][j] += tmpOverCount[j];
                        }
                        tmpOverCount = task.getRandCount1();
                        for (int j = 0; j < tmpOverCount.length; j++) {
                            overallRandCounts[1][j] += tmpOverCount[j];
                        }
                        allSims.add((int) task.getRealSimTimes());
                    }
                }
            });
            serv.submit(task);
            runningThread++;
        }
        for (int index = 0; index < runningThread; index++) {
            Future task = serv.take();
            String infor = (String) task.get();
            // System.out.println(infor);
        }
        exec.shutdown();
        for (int i = 0; i < allSims.size(); i++) {
            overallSimu += allSims.getQuick(i);
        }
       // System.out.println(overallSimu);
        Map<String, String[]> geneScoresNew = new HashMap<String,String[]>();
          String[] item0,item1;
        /*
        String[] item0 = geneScores.get(0);
        String[] item1 = new String[item0.length + 2];
        System.arraycopy(item0, 0, item1, 0, item0.length);
        item1[item0.length] = "RS";
        item1[item0.length + 1] = "RSp";
        item1[item0.length + 2] = "RP";
        item1[item0.length + 3] = "RPp";
        geneScoresNew.add(item1);
        */
        int index, indexS;
        for (int i = 1; i < orgSize; i++) {
            item0 = geneScores.get(i);
            item1 = new String[item0.length + 2];
            System.arraycopy(item0, 0, item1, 0, item0.length);
            index = i - 1;
            
            /*
            item1[item0.length] = String.valueOf(obsValue[0][index]);
            indexS = Arrays.binarySearch(sortObsValue0T, obsValue[0][index]);
            if (indexS >= 0) {
                item1[item0.length + 1] = String.valueOf(overallRandCounts[0][indexS] / overallSimu);
            } else {
                item1[item0.length + 1] = "-";
            }
            */
            
            item1[item0.length ] = String.valueOf(obsValue[1][index]);
            indexS = Arrays.binarySearch(sortObsValue1T, obsValue[1][index]);
            if (indexS >= 0) {
                item1[item0.length + 1] = String.valueOf(overallRandCounts[1][indexS] / overallSimu);
            } else {
                item1[item0.length + 1] = "-";
            }
            geneScoresNew.put(item0[0],item1);            
        }
        
        return geneScoresNew;
    }

    public class OrderSimulationTask extends Task implements Callable<String> {

        int maxSimuTimes;
        int[] sortedOvsValue0;
        int[] sortedOvsValue1;
        int[] randCount0;
        int[] randCount1;
        IntArrayList[] orders;
        double realSimTimes;
        //also very slow

        public OrderSimulationTask(int maxSimuTimes, int[] sortedOvsValue0, int[] sortedOvsValue1, IntArrayList[] orders) {
            this.maxSimuTimes = maxSimuTimes;
            this.sortedOvsValue0 = sortedOvsValue0;
            this.sortedOvsValue1 = sortedOvsValue1;
            this.randCount0 = new int[sortedOvsValue0.length];
            this.randCount1 = new int[sortedOvsValue1.length];
            this.orders = new IntArrayList[orders.length];
            for (int i = 0; i < orders.length; i++) {
                this.orders[i] = orders[i].copy();
            }
        }

        public int[] getRandCount0() {
            return randCount0;
        }

        public int[] getRandCount1() {
            return randCount1;
        }

        public double getRealSimTimes() {
            return realSimTimes;
        }

        @Override
        public String call() throws Exception {
            shuffleInteractionPairs();

            //  GlobalManager.logger.info(info);
            fireTaskComplete();
            String info = "  Varaince vas estimated on block  seconds.";
            //  System.out.println(info);
            //return info;
            return info;
            // 

        }

        public void shuffleInteractionPairs() throws Exception {
            RandomEngine tm = new cern.jet.random.engine.MersenneTwister(new java.util.Date());
            Uniform um = new Uniform(tm);

            int ringNum = -1;
            double prob;
            Arrays.fill(randCount0, 0);
            Arrays.fill(randCount1, 0);

            int len = orders[0].size();
            int index1;
            int[] containIds = new int[len];
            int[] minRandomOrders = new int[2];
            int[] tmpRandomOrders = new int[2];
            for (int i = 0; i < len; i++) {
                containIds[i] = i;
            }

            for (int t = 0; t < maxSimuTimes; t++) {
                //Collections.shuffle(Arrays.asList(list2));

                ringNum++;
                if (ringNum > len) {
                    ringNum = ringNum % len;
                }

                if (ringNum == 0) {
                    //System.out.println("Running shuffle!");
                    //shuffle the connection     Fisher–Yates shuffle Algorithm
                    for (int i = 0; i < orders.length; i++) {
                        orders[i].shuffle();
                    }
                    ///it does not shuffle it
                    //Collections.shuffle(Arrays.asList(list2));
                }

                //check the connection
                minRandomOrders[0] = Integer.MAX_VALUE;
                minRandomOrders[1] = Integer.MAX_VALUE;
                for (int i = 0; i < len; i++) {
                    index1 = (containIds[i] + ringNum);
                    if (index1 >= len) {
                        index1 = index1 % len;
                    }

                    tmpRandomOrders[0] = 0;
                    tmpRandomOrders[1] = 1;

                    for (int j = 0; j < orders.length; j += 2) {
                        tmpRandomOrders[0] += orders[j].getQuick(index1);
                        tmpRandomOrders[1] *= orders[j].getQuick(index1);
                    }
                    for (int j = 1; j < orders.length; j += 2) {
                        tmpRandomOrders[0] += orders[j].getQuick(i);
                        tmpRandomOrders[1] *= orders[j].getQuick(i);
                    }
                    if (tmpRandomOrders[0] < minRandomOrders[0]) {
                        minRandomOrders[0] = tmpRandomOrders[0];
                    }
                    if (tmpRandomOrders[1] < minRandomOrders[1]) {
                        minRandomOrders[1] = tmpRandomOrders[1];
                    }
                }

                for (int i = 0; i < sortedOvsValue0.length; i++) {
                    if (minRandomOrders[0] <= sortedOvsValue0[i]) {
                        randCount0[i]++;
                    }
                }
                for (int i = 0; i < sortedOvsValue1.length; i++) {
                    if (minRandomOrders[1] <= sortedOvsValue1[i]) {
                        randCount1[i]++;
                    }
                }


                /*
      if (t % 1000 == 0) {
        double mean = Descriptive.mean(randomCounts);
        double sd = Descriptive.sampleVariance(randomCounts, mean);
        System.out.println(mean + "\t" + sd);
      }
                 */
                realSimTimes++;

                if (t > 1000) {
                    prob = randCount1[0] / realSimTimes;
                    if (prob > 0.1) {
                        break;
                    } else if (prob > 0.01 && t > 1000) {
                        break;
                    } else if (prob > 0.001 && t > 10000) {
                        break;
                    } else if (prob > 0.0001 && t > 100000) {
                        break;
                    } else if (prob > 0.00001 && t > 1000000) {
                        break;
                    } else if (prob > 0.000001 && t > 10000000) {
                        break;
                    } else if (prob > 0.0000001 && t > 100000000) {
                        break;
                    } else if (prob > 0.00000001 && t > 1000000000) {
                        break;
                    } else if (prob > 0.000000001 && t > 2000000000) {
                        break;
                    }
                }

            }
        }
    }

    public static void main(String[] args) {
        try {
            RankTest rt = new RankTest();
            String fileName = "ASD_forebrain_selectHP.values.txt";
            String delimiter = "\t";
            List<String[]> arry = new ArrayList<>();
            int[] indexes = new int[]{0, 1, 2};
            LocalFile.retrieveData(fileName, arry, indexes, delimiter);
            Map<String, String[]> arry1 = rt.permutationTest(arry, 8, 1000000);
            fileName = "outvalues.txt";
           // LocalFile.writeData(fileName, arry1, delimiter, false);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
