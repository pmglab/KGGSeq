/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.graph;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.list.ShortArrayList;
import cern.jet.stat.Descriptive;
import cern.jet.stat.Probability;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import org.apache.log4j.Logger;
import org.cobi.kggseq.phenotyping.DownScore;
import static org.cobi.util.file.LocalFileFunc.getBufferedReader;
import static org.cobi.util.file.LocalFileFunc.getBufferedWriter;

import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.text.LocalFile;
import org.cobi.util.thread.TaskListener;

/**
 *
 * @author mxli
 */
public class GeneGraphShort {
     private static final Logger LOG = Logger.getLogger(GeneGraphShort.class);
    Map<Integer, Short> uniuqeGeneIndexMap;
    Map<Short, Integer> uniuqeIndexGeneMap;
    static short base = 10000;
    short[] geneIndex = new short[3];
    ShortArrayShortComparator cmp0 = new ShortArrayShortComparator(0);
    ShortArrayShortComparator cmp1 = new ShortArrayShortComparator(1);

    //format 1
    short[] interactionItems0_0;
    short[] interactionItems0_1;
    short[] interactionItems0_2;
    short[] interactionItems1_0;
    short[] interactionItems1_1;
    short[] interactionItems1_2;
    //format 2
    Map<Short, ShortArrayList> neighberGraph;
    
    public void clean() {
        uniuqeGeneIndexMap.clear();
        uniuqeIndexGeneMap.clear();
        interactionItems0_0 = null;
        interactionItems0_1 = null;
        interactionItems0_2 = null;
        interactionItems1_0 = null;
        interactionItems1_1 = null;
        interactionItems1_2 = null;
        neighberGraph.clear();
    }
    
    public Map<Integer, Short> getUniuqeGeneIndexMap() {
        return uniuqeGeneIndexMap;
    }
    
    public short[] getInteractionItems0_2() {
        return interactionItems0_2;
    }
    
    public short[] getInteractionItems0_0() {
        return interactionItems0_0;
    }
    
    public short[] getInteractionItems0_1() {
        return interactionItems0_1;
    }
    
    public short[] getInteractionItems1_0() {
        return interactionItems1_0;
    }
    
    public short[] getInteractionItems1_1() {
        return interactionItems1_1;
    }
    
    public GeneGraphShort() {
        uniuqeGeneIndexMap = new HashMap<Integer, Short>();
        uniuqeIndexGeneMap = new HashMap<Short, Integer>();
        neighberGraph = new HashMap<Short, ShortArrayList>();
    }
    
    public int getConectivity(Set<Short> selectedGenes) {
        int len = interactionItems0_0.length;
        int count = 0;
        for (int i = 0; i < len; i++) {
            if (selectedGenes.contains(interactionItems0_0[i]) && selectedGenes.contains(interactionItems0_1[i])) {
                count++;
            }
        }
        return count;
    }
    
    public List<String[]> binaryArraySearchNeighbors(int geneID, Map<Integer, String> idGeneMap) throws Exception {
        int index0, index1, index01 = 0, index02 = 0, index11 = 0, index12 = 0;
        int size = interactionItems0_1.length;
        geneIndex[0] = uniuqeGeneIndexMap.get(geneID);
        index0 = Arrays.binarySearch(interactionItems0_0, geneIndex[0]);
        index01 = index0;
        List<String[]> neighbers = new ArrayList<String[]>();
        geneIndex[1] = geneIndex[0];
        index1 = Arrays.binarySearch(interactionItems1_1, geneIndex[1]);;
        index11 = index1;
        if (index01 < 0 && index11 < 0) {
            return neighbers;
        }
        
        if (index01 >= 0) {
            index01--;
            while (index01 >= 0) {
                if (interactionItems0_0[index01] != geneIndex[0]) {
                    break;
                }
                index01--;
            }
            index01++;
            index02 = index0;
            index02++;
            
            while (index02 < size) {
                if (interactionItems0_0[index02] != geneIndex[0]) {
                    break;
                }
                index02++;
            }
            
            for (int i = index01; i < index02; i++) {
                int symb1 = uniuqeIndexGeneMap.get(interactionItems0_1[i]);
                
                String[] items = new String[2];
                items[0] = idGeneMap.get(symb1);
                items[1] = String.valueOf(interactionItems0_2[i]);
                neighbers.add(items);
            }
        }
        
        if (index11 >= 0) {
            index11--;
            while (index11 >= 0) {
                if (interactionItems1_1[index11] != geneIndex[1]) {
                    break;
                }
                index11--;
            }
            index11++;
            
            index12 = index1;
            index12++;
            
            while (index12 < size) {
                if (interactionItems1_1[index12] != geneIndex[1]) {
                    break;
                }
                index12++;
            }
            
            for (int i = index11; i < index12; i++) {
                int symb1 = uniuqeIndexGeneMap.get(interactionItems1_0[i]);
                String[] items = new String[2];
                items[0] = idGeneMap.get(symb1);
                items[1] = String.valueOf(interactionItems1_2[i]);
                neighbers.add(items);
            }
        }
        
        return neighbers;
    }
    
    public Set<Short> getIDsInShort(Set<String> geneOffIDs) {
        Set<Short> ids = new HashSet<Short>();
        Short id;
        for (String str : geneOffIDs) {
            id = uniuqeGeneIndexMap.get(Integer.parseInt(str));
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }
    
    public Set<Short> getIDsInShort(String[] geneOffIDs) {
        Set<Short> ids = new HashSet<Short>();
        Short id;
        for (String str : geneOffIDs) {
            id = uniuqeGeneIndexMap.get(Integer.parseInt(str));
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }
    
    public int getConnectivityNum(Set<String> testSet) throws Exception {
        // pagerank.showResults(10);

        Set<Short> sigIDs = getIDsInShort(testSet);
        return getConectivity(sigIDs);
    }
    
    public int getConnectivityNum(Set<String> testSet, Map<Integer, String> idSymbolMap) throws Exception {
        // pagerank.showResults(10);
        Set<Short> sigIDs = getEncodedIDS(testSet, idSymbolMap);
        
        return getConectivity(sigIDs);
    }
    
    public Set<Short> getEncodedIDS(Set<String> testSet, Map<Integer, String> idSymbolMap) {
        Map<String, Integer> symbolIDMap = new HashMap<String, Integer>();
        for (Map.Entry<Integer, String> item : idSymbolMap.entrySet()) {
            symbolIDMap.put(item.getValue(), item.getKey());
        }
        Set<Short> ids = new HashSet<Short>();
        Short id;
        Integer geneID;
        for (String str : testSet) {
            geneID = symbolIDMap.get(str);
            id = uniuqeGeneIndexMap.get(geneID);
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }
    
    public double connectivityEvaluate(Set<String> testSet, Map<Integer, String> idSymbolMap, int maxSimuTimes, int threadNum) throws Exception {
        Set<Short> ids = getEncodedIDS(testSet, idSymbolMap);
        return connectivityEvaluateShort(ids, maxSimuTimes, threadNum);
    }
    
    public double connectivityEvaluate(Set<String> testSet, int maxSimuTimes, int threadNum) throws Exception {
        // pagerank.showResults(10);

        Set<Short> sigIDs = getIDsInShort(testSet);
        return connectivityEvaluateShort(sigIDs, maxSimuTimes, threadNum);
    }
    
    public double connectivityEvaluateShort(Set<Short> sigIDs, int maxSimuTimes, int threadNum) throws Exception {
        // pagerank.showResults(10);
        int runningThread = 0;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        
        final double[] counts = new double[2];
        Arrays.fill(counts, 0);
        int obsValue = getConectivity(sigIDs);
        //System.out.println("Observed Num: " + obsValue);
        final DoubleArrayList randomCounts = new DoubleArrayList();
        IntArrayList containIds = new IntArrayList();
        int len = interactionItems0_0.length;
        for (int i = 0; i < len; i++) {
            if (sigIDs.contains(interactionItems0_0[i])) {
                containIds.add(i);
            }
        }
        int[] containIdIndexes = new int[containIds.size()];
        len = containIds.size();
        for (int i = 0; i < len; i++) {
            containIdIndexes[i] = containIds.getQuick(i);
        }
        
        int j;
        int containIdsLen = containIds.size();
        //System.out.println("Searched rows " + containIdsLen);
        for (int s = 0; s < threadNum; s++) {
            final NetShortSimulationTask task = new NetShortSimulationTask(maxSimuTimes / threadNum, obsValue, sigIDs, containIdIndexes, Arrays.copyOf(interactionItems0_1, interactionItems0_1.length));
            task.addTaskListener(new TaskListener() {
                @Override
                public void taskCompleted() throws Exception {
                    synchronized (counts) {
                        double[] tmpOverCount = task.getOverCounts();
                        counts[0] += tmpOverCount[0];
                        counts[1] += tmpOverCount[1];
                        randomCounts.addAllOf(task.getRandomCounts());
                    }
                }
            });
            serv.submit(task);
            runningThread++;
        }
        for (int index = 0; index < runningThread; index++) {
            Future task = serv.take();
            String infor = (String) task.get();
            // System.out.println(infor);
        }
        exec.shutdown();
        
        double mean = Descriptive.mean(randomCounts);
        //double sd = Descriptive.sampleVariance(randomCounts, mean);

        // System.out.println(counts[0] + "\t" + counts[1] + "\t" + Probability.normal(mean, sd, mean + mean - obsValue) + "\t" + Probability.poissonComplemented(obsValue, mean) + "\t" + sigIDs.size());
        // System.out.print("\t" + obsNums[0]);
        counts[0] = counts[0] / counts[1];
        double p = Probability.poissonComplemented(obsValue, mean);
        return p;
    }
    
    public int readInteractionsFast(String ppiFilePath, Map<Integer, String> geneEntryIDMap, double minScore,
            int maxThreadNum, boolean encodeList, boolean convert2List) throws Exception {

        //the encodeList cannot be used to merge network. but the encodeMap facilitates
        int runningThread = 0;
        
        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        File fileFolder = new File(ppiFilePath);
        if (!fileFolder.exists()) {
            throw new Exception("File " + ppiFilePath + " doese not exists!");
        }
        BGZFInputStream bf = new BGZFInputStream(fileFolder.getCanonicalPath(), maxThreadNum);
        //  bf = new BZIP2InputStream(dataFile.getCanonicalPath(), maxThreadNum);

        bf.adjustPos();
        bf.creatSpider();
        int ioThreadNum = bf.getThreadNum();
        // System.out.println(ioThreadNum + " " + (ioThreadNum == 1 ? "thread is" : "threads are") + " created to parse a file!");
        if (maxThreadNum > ioThreadNum) {
            String info = null;
            String fileName = fileFolder.getCanonicalPath();
            if (fileName.endsWith(".gz")) {
                info = "The file is gzip-format, not bgzip-format! You can create a file with Blocked GNU Zip Format by \'zcat " + fileName + " | bgzip > " + fileName.substring(0, fileName.lastIndexOf(".")) + ".b.gz\', See more  http://www.htslib.org/doc/tabix.html";
            } else {
                info = "You can create a file with Blocked GNU Zip Format by \'bgzip " + fileName + "\', See more  http://www.htslib.org/doc/tabix.html";
            }
            //Note BZ2 is very slow
            /*
                     if (fileName.endsWith(".gz")) {
                     info = "You can create a file with bzip2 by zcat " + fileName + " | bzip2 -9 -c  " + fileName.substring(0, fileName.lastIndexOf(".")) + ".bz2, See more  http://www.htslib.org/doc/tabix.html";
                     } else {
                     info = "You can create a file with Blocked GNU Zip Format by bgzip " + fileName + ", See more  http://www.htslib.org/doc/tabix.html";
                     }*/
            System.out.println(info);
        }
        maxThreadNum = ioThreadNum;
        runningThread = 0;
        //I spend 2 days to write a new VCFParseTask which I expected to be faster by modifying the Uitl.tokenize function
        //Unfortunately, the new Task is much slower than
        //VCFParseTask[] parsTaskArray = new VCFParseTask[maxThreadNum];

        final List<int[]> pairs = new ArrayList<int[]>();
        final Set<Integer> geneIDs = new HashSet<Integer>();
        for (int s = 0; s < maxThreadNum; s++) {
            NetworkParseTask parsTask = new NetworkParseTask(bf.spider[s], geneEntryIDMap, minScore, base);
            parsTask.addTaskListener(new TaskListener() {
                @Override
                public void taskCompleted() throws Exception {
                    synchronized (pairs) {
                        pairs.addAll(parsTask.getItemList());
                        geneIDs.addAll(parsTask.getGeneIDs());
                    }
                }
            });
            serv.submit(parsTask);
            runningThread++;
        }
        
        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            //  System.out.println(infor);
        }
        exec.shutdown();
        if (encodeList) {
            encodePairList(pairs, geneIDs, convert2List);
        } else {
            encodePairMap(pairs, geneIDs);
        }
        return pairs.size();
    }
    
    private void encodePairList(List<int[]> itemList, Set<Integer> geneIDs, boolean convert2Array) {
        short index1, index2;
        int num = 0;
        List<Integer> geneIDList = new ArrayList<>(geneIDs);
        int len = geneIDList.size();
        
        List<short[]> interactionItems0 = new ArrayList<short[]>();
        List<short[]> interactionItems1 = new ArrayList<short[]>();
        int inc = uniuqeGeneIndexMap.size();
        for (int i = 0; i < len; i++) {
            if (!uniuqeGeneIndexMap.containsKey(geneIDList.get(i))) {
                uniuqeGeneIndexMap.put(geneIDList.get(i), (short) inc);
                uniuqeIndexGeneMap.put((short) inc, geneIDList.get(i));
                inc++;
            }
        }
        
        for (int[] items : itemList) {
            //System.out.println(items[0]);
            index1 = uniuqeGeneIndexMap.get(items[0]);
            index2 = uniuqeGeneIndexMap.get(items[1]);
            interactionItems0.add(new short[]{index1, index2, (short) (items[2])});
            num++;
            if (num % 100000 == 0) {
                // System.out.println(num);
            }
        }
        itemList.clear();
        Collections.sort(interactionItems0, new ShortArrayShortComparator(0));
        int size = interactionItems0.size();
        interactionItems0_0 = new short[size];
        interactionItems0_1 = new short[size];
        interactionItems0_2 = new short[size];
        short[] tmpItem;
        for (int i = 0; i < size; i++) {
            tmpItem = interactionItems0.get(i);
            interactionItems0_0[i] = tmpItem[0];
            interactionItems0_1[i] = tmpItem[1];
            interactionItems0_2[i] = tmpItem[2];
        }

        // System.out.println(size + " interaction terms have been loaded and encoded!");
        if (convert2Array) {
            interactionItems1.addAll(interactionItems0);
            interactionItems0.clear();
            Collections.sort(interactionItems1, new ShortArrayShortComparator(1));
            interactionItems1_0 = new short[size];
            interactionItems1_1 = new short[size];
            interactionItems1_2 = new short[size];
            
            for (int i = 0; i < size; i++) {
                tmpItem = interactionItems1.get(i);
                interactionItems1_0[i] = tmpItem[0];
                interactionItems1_1[i] = tmpItem[1];
                interactionItems1_2[i] = tmpItem[2];
            }
        }
        interactionItems0.clear();
        interactionItems1.clear();
    }
    
    private void encodePairMap(List<int[]> itemList, Set<Integer> geneIDs) {
        short index1, index2;
        int num = 0;
        List<Integer> geneIDList = new ArrayList<>(geneIDs);
        int len = geneIDList.size();
        
        List<short[]> interactionItems0 = new ArrayList<short[]>();
        List<short[]> interactionItems1 = new ArrayList<short[]>();
        
        int inc = uniuqeGeneIndexMap.size();
        for (int i = 0; i < len; i++) {
            if (!uniuqeGeneIndexMap.containsKey(geneIDList.get(i))) {
                uniuqeGeneIndexMap.put(geneIDList.get(i), (short) inc);
                uniuqeIndexGeneMap.put((short) inc, geneIDList.get(i));
                inc++;
            }
        }
        
        for (int[] items : itemList) {
            //System.out.println(items[0]);
            index1 = uniuqeGeneIndexMap.get(items[0]);
            index2 = uniuqeGeneIndexMap.get(items[1]);
            interactionItems0.add(new short[]{index1, index2, (short) (items[2])});
            num++;
            if (num % 100000 == 0) {
                // System.out.println(num);
            }
        }
        itemList.clear();
        Collections.sort(interactionItems0, new ShortArrayShortComparator(0));
        
        int size = interactionItems0.size();
        
        int index0 = 0;
        int index11 = 0;
        short curID = interactionItems0.get(index0)[0];
        ShortArrayList curArray;
        curArray = neighberGraph.get(curID);
        if (curArray == null) {
            curArray = new ShortArrayList();
            neighberGraph.put(curID, curArray);
        }
        
        do {
            if (curID < interactionItems0.get(index0)[0]) {
                curID = interactionItems0.get(index0)[0];
                curArray = neighberGraph.get(curID);
                if (curArray == null) {
                    curArray = new ShortArrayList();
                    neighberGraph.put(curID, curArray);
                }
                
                curArray.add(interactionItems0.get(index0)[1]);
                curArray.add(interactionItems0.get(index0)[2]);
                
            } else {
                curArray.add(interactionItems0.get(index0)[1]);
                curArray.add(interactionItems0.get(index0)[2]);
            }
            index0++;
        } while (index0 < size);
        
       // System.out.println(size + " interaction terms have been loaded and encoded!");
        
        interactionItems1.addAll(interactionItems0);
        interactionItems0.clear();
        Collections.sort(interactionItems1, new ShortArrayShortComparator(1));
        
        curID = interactionItems1.get(index11)[1];
        curArray = neighberGraph.get(curID);
        if (curArray == null) {
            curArray = new ShortArrayList();
            neighberGraph.put(curID, curArray);
        }
        
        do {
            if (curID < interactionItems1.get(index11)[1]) {
                curID = interactionItems1.get(index11)[1];
                curArray = neighberGraph.get(curID);
                if (curArray == null) {
                    curArray = new ShortArrayList();
                    neighberGraph.put(curID, curArray);
                }
                curArray.add(interactionItems1.get(index11)[0]);
                curArray.add(interactionItems1.get(index11)[2]);
            } else {
                curArray.add(interactionItems1.get(index11)[0]);
                curArray.add(interactionItems1.get(index11)[2]);
            }
            index11++;
        } while (index11 < size);
        
        interactionItems0.clear();
        interactionItems1.clear();
    }

    /*
    public int readInteractions(String ppiFilePath, Map<String, String> geneEntryIDMap, double minScore, boolean convert2Array) throws Exception {
        //read PPI genes
        File fileFolder = new File(ppiFilePath);
        if (!fileFolder.exists()) {
            throw new Exception("File " + ppiFilePath + " doese not exists!");
        }

        Set<Integer> uniuqeGeneSet = new HashSet<Integer>();
        Set<String> uniuqePairs = new HashSet<String>();
        String tmpStr, currentLine;
        boolean needCheck = minScore > 0;
        double score;
        int num = 0;
        short index1, index2;
        String symb1, symb2;
        BufferedReader br = LocalFileFunc.getBufferedReader(ppiFilePath);
        int reduantNum = 0;
        List<String[]> itemList = new ArrayList<>();
        while ((currentLine = br.readLine()) != null) {
            if (currentLine.trim().length() == 0) {
                continue;
            }
            String cells[] = currentLine.trim().split("\t");
            //remove self loop
            if (cells[0].equals(cells[1])) {
                continue;
            }
            symb1 = geneEntryIDMap.get(cells[0]);
            if (symb1 == null) {
                continue;
            }
            symb2 = geneEntryIDMap.get(cells[1]);
            if (symb2 == null) {
                continue;
            }
            String[] items = new String[3];
            if (cells[0].compareTo(cells[1]) < 0) {
                items[0] = cells[0];
                items[1] = cells[1];
            } else {
                items[0] = cells[1];
                items[1] = cells[0];
            }

            tmpStr = items[0] + ":" + items[1];
            if (uniuqePairs.contains(tmpStr)) {
                reduantNum++;
                continue;
            }
            score = Double.parseDouble(cells[2]);
            if (needCheck && score < minScore) {
                continue;
            }
            uniuqePairs.add(tmpStr);
            uniuqeGeneSet.add(Integer.parseInt(items[0]));
            uniuqeGeneSet.add(Integer.parseInt(items[1]));

            items[2] = cells[2];

            num++;
            if (num % 100000 == 0) {
                System.out.println(num);
            }
            itemList.add(items);
        }
        br.close();
        // if (reduantNum > 0)
        {
            System.err.println(reduantNum + " redundant gene pairs!");
        }
        uniuqePairs.clear();

        List<Integer> geneList = new ArrayList<Integer>(uniuqeGeneSet);
        Collections.sort(geneList);
        uniuqeGeneSet.clear();
        int geneNum = geneList.size();
        if (geneNum >= 2 * Short.MAX_VALUE) {
            System.err.println("The number of genes is over " + Short.MAX_VALUE);
        }
        for (short i = 0; i < geneNum; i++) {
            uniuqeGeneIndexMap.put(geneList.get(i), i);
            uniuqeIndexGeneMap.put(i, geneList.get(i));
        }
        geneList.clear();

        for (String[] items : itemList) {
            score = Double.parseDouble(items[2]);

            //System.out.println(items[0]);
            index1 = uniuqeGeneIndexMap.get(items[0]);
            index2 = uniuqeGeneIndexMap.get(items[1]);
            interactionItems0.add(new short[]{index1, index2, (short) (score * base)});
            num++;
            if (num % 100000 == 0) {
                // System.out.println(num);
            }
        }
        itemList.clear();
        Collections.sort(interactionItems0, new ShortArrayShortComparator(0));

        interactionItems1.addAll(interactionItems0);
        Collections.sort(interactionItems1, new ShortArrayShortComparator(1));
        System.out.println(interactionItems1.size() + " interaction terms have been loaded and encoded!");
        if (convert2Array) {
            int size = interactionItems1.size();
            interactionItems0_0 = new short[size];
            interactionItems0_1 = new short[size];
            interactionItems1_0 = new short[size];
            interactionItems1_1 = new short[size];
            short[] tmpItem;
            for (int i = 0; i < size; i++) {
                tmpItem = interactionItems0.get(i);
                interactionItems0_0[i] = tmpItem[0];
                interactionItems0_1[i] = tmpItem[1];

                tmpItem = interactionItems1.get(i);
                interactionItems1_0[i] = tmpItem[0];
                interactionItems1_1[i] = tmpItem[1];
            }
            interactionItems0.clear();
            interactionItems1.clear();
        }
        return interactionItems1.size();
    }

    public int readInteractions(String ppiFilePath, double minScore, boolean convert2Array) throws Exception {
        //read PPI genes
        File fileFolder = new File(ppiFilePath);
        if (!fileFolder.exists()) {
            throw new Exception("File " + ppiFilePath + " doese not exists!");
        }

        Set<Integer> uniuqeGeneSet = new HashSet<Integer>();
        Set<String> uniuqePairs = new HashSet<String>();
        String tmpStr, currentLine;
        boolean needCheck = minScore > 0;
        double score;
        int num = 0;
        short index1, index2;

        BufferedReader br = LocalFileFunc.getBufferedReader(ppiFilePath);
        while ((currentLine = br.readLine()) != null) {
            if (currentLine.trim().length() == 0) {
                continue;
            }
            String cells[] = currentLine.trim().split("\t");

            String[] items = new String[3];
            if (cells[0].compareTo(cells[1]) < 0) {
                items[0] = cells[0];
                items[1] = cells[1];
            } else {
                items[0] = cells[1];
                items[1] = cells[0];
            }
            //remove self loop
            if (items[0].equals(items[1])) {
                continue;
            }
            tmpStr = items[0] + ":" + items[1];
            if (uniuqePairs.contains(tmpStr)) {
                continue;
            }
            score = Double.parseDouble(cells[2]);
            if (needCheck && score < minScore) {
                continue;
            }
            uniuqePairs.add(tmpStr);
            uniuqeGeneSet.add(Integer.parseInt(items[0]));
            uniuqeGeneSet.add(Integer.parseInt(items[1]));

            items[2] = cells[2];

            num++;
            if (num % 100000 == 0) {
                // System.out.println(num);
            }
        }
        br.close();

        uniuqePairs.clear();

        List<Integer> geneList = new ArrayList<Integer>(uniuqeGeneSet);
        Collections.sort(geneList);
        uniuqeGeneSet.clear();
        int geneNum = geneList.size();
        if (geneNum >= 2 * Short.MAX_VALUE) {
            System.err.println("The number of genes is over " + Short.MAX_VALUE);
        }
        for (short i = 0; i < geneNum; i++) {
            uniuqeGeneIndexMap.put(geneList.get(i), i);
            uniuqeIndexGeneMap.put(i, geneList.get(i));
        }
        geneList.clear();

        br = LocalFileFunc.getBufferedReader(ppiFilePath);
        while ((currentLine = br.readLine()) != null) {
            if (currentLine.trim().length() == 0) {
                continue;
            }
            String cells[] = currentLine.trim().split("\t");

            String[] items = new String[3];
            if (cells[0].compareTo(cells[1]) < 0) {
                items[0] = cells[0];
                items[1] = cells[1];
            } else {
                items[0] = cells[1];
                items[1] = cells[0];
            }
            //remove self loop
            if (items[0].equals(items[1])) {
                continue;
            }
            tmpStr = items[0] + ":" + items[1];
            if (uniuqePairs.contains(tmpStr)) {
                continue;
            }
            uniuqePairs.add(tmpStr);

            score = Double.parseDouble(cells[2]);
            if (needCheck && score < minScore) {
                continue;
            }
            //System.out.println(items[0]);
            index1 = uniuqeGeneIndexMap.get(items[0]);
            index2 = uniuqeGeneIndexMap.get(items[1]);
            interactionItems0.add(new short[]{index1, index2, (short) (score * base)});
            num++;
            if (num % 100000 == 0) {
                // System.out.println(num);
            }
        }
        br.close();
        uniuqePairs.clear();
        Collections.sort(interactionItems0, new ShortArrayShortComparator(0));

        interactionItems1.addAll(interactionItems0);
        Collections.sort(interactionItems1, new ShortArrayShortComparator(1));
        System.out.println(interactionItems1.size() + " interaction terms have been loaded and encoded!");
        if (convert2Array) {
            int size = interactionItems1.size();
            interactionItems0_0 = new short[size];
            interactionItems0_1 = new short[size];
            interactionItems1_0 = new short[size];
            interactionItems1_1 = new short[size];
            short[] tmpItem;
            for (int i = 0; i < size; i++) {
                tmpItem = interactionItems0.get(i);
                interactionItems0_0[i] = tmpItem[0];
                interactionItems0_1[i] = tmpItem[1];

                tmpItem = interactionItems1.get(i);
                interactionItems1_0[i] = tmpItem[0];
                interactionItems1_1[i] = tmpItem[1];
            }
            interactionItems0.clear();
            interactionItems1.clear();
        }
        return interactionItems1.size();
    }
     */
    public Map<String, String> readHGNCGeneSymbolID(String path) throws Exception {
        File geneSymbols1 = new File(path + "/HgncGene.txt");
        BufferedReader br = new BufferedReader(new FileReader(geneSymbols1));
        String strLine;
        Map<String, String> geneEtrIDSymbMap = new HashMap<String, String>();

//                    int t=1;
        while ((strLine = br.readLine()) != null) {
//                        System.out.println(t++);
            String[] strItems = strLine.split("\t", -1);
            if (strItems[9] != null) {
                strItems[9] = strItems[9].trim();
                if (strItems[9].length() > 0) {
                    geneEtrIDSymbMap.put(strItems[1], strItems[9]);
                }
            }
        }
        br.close();
        return geneEtrIDSymbMap;
    }
    
    public Map<Integer, String> readHGNCGeneIDSymbol(String path) throws Exception {
        File geneSymbols1 = new File(path + "/HgncGene.txt");
        BufferedReader br = new BufferedReader(new FileReader(geneSymbols1));
        String strLine;
        Map<Integer, String> geneEtrIDSymbMap = new HashMap<Integer, String>();

//                    int t=1;
//skip head
        br.readLine();
        while ((strLine = br.readLine()) != null) {
//                        System.out.println(t++);
            String[] strItems = strLine.split("\t", -1);
            if (strItems[9] != null) {
                strItems[9] = strItems[9].trim();
                if (strItems[9].length() > 0) {
                    geneEtrIDSymbMap.put(Integer.parseInt(strItems[9]), strItems[1]);
                }
            }
        }
        br.close();
        return geneEtrIDSymbMap;
    }
    
    public List<String[]> mappingSearchNeighbors(int geneID, Map<Integer, String> idGeneMap, Map<Short, ShortArrayList> neighberMap) throws Exception {
        geneIndex[0] = uniuqeGeneIndexMap.get(geneID);
        List<String[]> neighbers = new ArrayList<>();
        ShortArrayList arrays = neighberMap.get(geneIndex[0]);
        if (arrays == null || arrays.isEmpty()) {
            return neighbers;
        }
        int size = arrays.size();
        
        for (int i = 0; i < size; i += 2) {
            int symb1 = uniuqeIndexGeneMap.get(arrays.getQuick(i));
            
            String[] items = new String[2];
            items[0] = idGeneMap.get(symb1);
            items[1] = String.valueOf(arrays.getQuick(i + 1));
            neighbers.add(items);
            //System.out.println(geneID + "\t" + symb1 + "\t" + (Double.parseDouble(items[1]) / base));
        }
        return neighbers;
    }
    
    public void mergeReduantInteractions() {
        Map<Short, Integer> avaiMap = new HashMap<Short, Integer>();
        ShortArrayList sal;
        ShortArrayList salT = new ShortArrayList();
        int size;
        
        Integer index;
        short score;
        for (Map.Entry<Short, ShortArrayList> item : neighberGraph.entrySet()) {
            sal = item.getValue();
            size = sal.size();
            salT.clear();
            avaiMap.clear();
            for (int i = 0; i < size; i += 2) {
                index = avaiMap.get(sal.getQuick(i));
                if (index == null) {
                    avaiMap.put(sal.getQuick(i), salT.size());
                    salT.add(sal.getQuick(i));
                    salT.add(sal.getQuick(i + 1));
                } else {
                    score = sal.getQuick(i + 1);
                    if (score > salT.getQuick(index + 1)) {
                        salT.setQuick(index + 1, score);
                    }
                }
            }
            sal.clear();
            size = salT.size();
            for (int i = 0; i < size; i++) {
                sal.add(salT.getQuick(i));
            }
        }
    }
    
    public void converMap2List(boolean need2List) {
        if (neighberGraph == null || neighberGraph.isEmpty()) {
            return;
        }
        List<short[]> interactionItems0 = new ArrayList<short[]>();
        ShortArrayList sal;
        int size;
        short s1;
        for (Map.Entry<Short, ShortArrayList> item : neighberGraph.entrySet()) {
            sal = item.getValue();
            size = sal.size();
            s1 = item.getKey();
            //as neighberGraph contains double-interactions acturally
            for (int i = 0; i < size; i += 2) {
                if (s1 > sal.getQuick(i)) {
                    continue;
                }
                interactionItems0.add(new short[]{s1, sal.getQuick(i), sal.getQuick(i + 1)});
            }
            // System.out.println(interactionItems0.size());
        }
        
        Collections.sort(interactionItems0, new ShortArrayShortComparator(0));
        size = interactionItems0.size();
        interactionItems0_0 = new short[size];
        interactionItems0_1 = new short[size];
        interactionItems0_2 = new short[size];
        short[] tmpItem;
        for (int i = 0; i < size; i++) {
            tmpItem = interactionItems0.get(i);
            interactionItems0_0[i] = tmpItem[0];
            interactionItems0_1[i] = tmpItem[1];
            interactionItems0_2[i] = tmpItem[2];
        }
        List<short[]> interactionItems1 = new ArrayList<short[]>();
        if (need2List) {
            interactionItems1.addAll(interactionItems0);
            interactionItems0.clear();
            Collections.sort(interactionItems1, new ShortArrayShortComparator(1));
            interactionItems1_0 = new short[size];
            interactionItems1_1 = new short[size];
            interactionItems1_2 = new short[size];
            
            for (int i = 0; i < size; i++) {
                tmpItem = interactionItems1.get(i);
                interactionItems1_0[i] = tmpItem[0];
                interactionItems1_1[i] = tmpItem[1];
                interactionItems1_2[i] = tmpItem[2];
            }
        }
        interactionItems0.clear();
        interactionItems1.clear();
    }
//
//    public Map<Short, ShortArrayList> enumerateNeighbors() {
//        int size = interactionItems0_1.length;
//        Map<Short, ShortArrayList> neighberGraph = new HashMap<Short, ShortArrayList>();
//        int index0 = 0, index1 = 0;
//        short curID = interactionItems0_0[index0];
//        ShortArrayList curArray = new ShortArrayList();
//        neighberGraph.put(curID, curArray);
//
//        do {
//            if (curID < interactionItems0_0[index0]) {
//                curID = interactionItems0_0[index0];
//                curArray = new ShortArrayList();
//                curArray.add(interactionItems0_1[index0]);
//                curArray.add(interactionItems0_2[index0]);
//                neighberGraph.put(curID, curArray);
//
//            } else {
//                curArray.add(interactionItems0_1[index0]);
//                curArray.add(interactionItems0_2[index0]);
//
//            }
//            if (interactionItems0_0[index0] == 8860 && interactionItems0_1[index0] == 1016) {
//                int sss = 0;
//            }
//            index0++;
//        } while (index0 < size);
//        curID = interactionItems1_1[index1];
//        curArray = neighberGraph.get(curID);
//        if (curArray == null) {
//            curArray = new ShortArrayList();
//            neighberGraph.put(curID, curArray);
//        }
//
//        do {
//            if (curID < interactionItems1_1[index1]) {
//                curID = interactionItems1_1[index1];
//                curArray = neighberGraph.get(curID);
//                if (curArray == null) {
//                    curArray = new ShortArrayList();
//                    curArray.add(interactionItems1_0[index1]);
//                    curArray.add(interactionItems1_2[index1]);
//                    neighberGraph.put(curID, curArray);
//                } else {
//                    curArray.add(interactionItems1_0[index1]);
//                    curArray.add(interactionItems1_2[index1]);
//                }
//
//            } else {
//                curArray.add(interactionItems1_0[index1]);
//                curArray.add(interactionItems1_2[index1]);
//
//            }
//            if (interactionItems1_1[index1] == 8860 && interactionItems1_0[index1] == 1016) {
//                int sss = 0;
//            }
//            if (curID == 8860) {
//                int sss = 0;
//                if (curArray.size() == 354) {
//                    sss = 0;
//                }
//            }
//            index1++;
//        } while (index1 < size);
//
//        // to save RAM
//        interactionItems0_0 = null;
//        interactionItems0_1 = null;
//        interactionItems0_2 = null;
//        interactionItems1_0 = null;
//        interactionItems1_1 = null;
//        interactionItems1_2 = null;
//
//        return neighberGraph;
//    }

    public static void main(String[] args) {
        String disTerm = "autism,autistic";
        String outDir = "/home/jh/projects/RENER_Extend/ASDtest";
        //scz sig genes
        //String[] cadGenes = new String[]{"SLC45A1", "KDM4A", "LINC01360", "MIR2682", "PLEKHO1", "TMEM81", "SDCCAG8", "DNMT3A", "EML6", "VRK2", "LINC01122", "ALMS1", "RMND5A", "FAM168B", "ZEB2", "FMNL2", "ZNF804A", "MOB4", "TYW5", "CREB1", "NGEF", "RBMS3", "ITIH1", "FHIT", "FOXP1", "STAG1", "MIR548AY", "FXR1", "GABRA2", "SLC39A8", "NEK1", "GPM6A", "TENM3", "ZSWIM6", "MEF2C-AS1", "REEP2", "LINC01470", "POLH", "EYS", "SNAP91", "QKI", "MAD1L1", "MPP6", "CALN1", "ABCB1", "SRPK2", "IMMP2L", "LOC101928782", "CSMD1", "SGCZ", "WHSC1L1", "LOC102724623", "MMP16", "TSNARE1", "KDM4C", "KLHL9", "CCBL1", "CACNB2", "PRKG1", "ZNF365", "GRID1", "CNNM2", "NT5C2", "SORCS3", "FSHB", "MIR3160-1", "TMX2", "PPP2R5B", "PPP6R3", "MIR4301", "ESAM", "SNX19", "IGSF9B", "CACNA2D4", "CACNA1C", "GRIN2B", "SOX5", "DIP2B", "MIR1228", "HMGA2", "ATP2A2", "MLXIP", "PITPNM2", "KLF12", "RBM26", "MIR548AI", "KIAA0391", "RGS6", "BCL11B", "PPP1R13B", "PAK6", "UNC13C", "FAM63B", "CHRNA5", "CPEB1", "LOC440300", "FES", "DNAJA3", "RBFOX1", "PDXDC1", "TMEM219", "SLC38A7", "PLA2G15", "CDH13", "RPL13", "PAFAH1B1", "DRC3", "MFAP4", "MGC57346-CRHR1", "SKA2", "RPTOR", "TCF4", "KCNG2", "DIRAS1", "TSSK6", "SNORD35B", "BCL2L12", "SLC32A1", "KCNB1", "PPDPF", "DOPEY2", "MGAT3", "CACNA1I", "TOB2", "ACO2", "MEI1", "BRD1", "PJA1", "COL4A6", "COL4A5"};
        // String[] cadGenes = new String[]{"PLCH2", "LINC01672", "OPRD1", "MAP7D1", "PTPRF", "KRT8P21", "LINC01360", "MIR137HG", "NFU1P2", "CSDE1", "VPS45", "BRINP2", "KIF21B", "GALNT2", "SDCCAG8", "MYT1L-AS1", "LINC01884", "AGBL5", "QPCT", "FOXN2", "ACTG1P22", "VRK2", "SFXN5", "FAM178B", "ZEB2", "RNU6-1001P", "DPP4", "DLX1", "ZNF804A", "RNU6-1029P", "SNORA105A", "HSPD1", "RNU7-147P", "SPATS2L", "ERBB4", "RNU6-107P", "SNORC", "NGEF", "TBC1D5", "RBMS3", "LINC02033", "ZKSCAN7", "GLYCTK-AS1", "PBRM1", "GNL3", "SNORD19C", "NEK4", "ITIH4", "ITIH4-AS1", "SFMBT1", "SERBP1P3", "THOC7", "FOXP1", "LINC02050", "SEC61A1", "RNU6-823P", "PCCB", "RNU6-1284P", "SOX2-OT", "PCGF3", "PCDH7", "GSX2", "SLC39A8", "MAP9", "YWHAEP4", "GPM6A", "HCN1", "PDE4D", "MEF2C-AS1", "SLCO6A1", "HSPA9", "CXXC5-AS1", "LINC01470", "MFAP3", "CARMIL1", "TRIM38", "HIST1H4A", "HIST1H4B", "HIST1H2APS5", "HFE", "HIST1H2BE", "HIST1H1PS1", "HIST1H2AD", "HIST1H3G", "HIST1H3PS1", "BTN3A2", "BTN3A3", "BTN2A1", "BTN1A1", "ABT1", "ZNF322", "GUSBP2", "HIST1H2BJ", "HIST1H4I", "PRSS16", "POM121L2", "ZNF184", "CUL9", "ADGRB3", "RIMS1", "PGM3", "MFSD4B", "MAD1L1", "SNORA114", "MPP6", "SUMO2P14", "GRM3", "KMT2E", "SND1", "EXOC4", "MSRA", "ZDHHC2", "CLU", "CYP7B1", "MTCO1P47", "TRPS1", "TSNARE1", "PUF60", "RNF38", "MIGA2", "KLF6", "CACNB2", "PRKG1", "ZNF365", "LINC00502", "NT5C2", "RPS15AP29", "ABCC8", "HARBI1", "ATG13", "CTNND1", "MACROD1", "TTC12", "MIR4301", "SIAE", "IGSF9B", "B3GAT1", "CACNA1C", "R3HDM2", "TBC1D15", "KRT19P2", "RNA5SP366", "ATP2A2", "ARL6IP4", "TRPC4", "NDFIP2", "NPAS3", "TRIM9", "RGS6", "KLC1", "LPCAT4", "FRMD5", "CCNB2", "PSMA4", "CPEB1", "WDR73", "FES", "MAN2A2", "ALDOA", "SETD6", "CPNE7", "SMG6-IT1", "ARHGAP44", "EPN2", "CDK5R1", "MAPT", "RPL32P31", "PPIAP14", "TCF4", "TCF4-AS2", "PQLC1", "ZNF491", "NCAN", "MIR640", "ZNF536", "IRF3", "PPP1R16B", "KCNB1", "EEF1A2", "NRIP1", "CACNA1I", "SEPT3", "OGFRP1"};
        String[] cadGenes = new String[]{"PLCH2", "DNAJC11", "LINC01672", "OPRD1", "MAP7D1", "MPL", "PTPRF", "PDE4B", "KRT8P21", "LINC01360", "MIR137HG", "NFU1P2", "CSDE1", "NGF", "VPS45", "BRINP2", "LINC00862", "KIF21B", "GALNT2", "SDCCAG8", "FABP7P1", "MYT1L-AS1", "LINC01884", "AGBL5", "QPCT", "PPP1R21", "EML6", "ACTG1P22", "VRK2", "SFXN5", "FAM178B", "ZEB2", "RNU6-1001P", "DPP4", "DLX1", "ZNF804A", "SF3B1", "RNU6-1029P", "HSPD1", "HSPE1-MOB4", "RNU7-147P", "SATB2", "C2orf69", "MAIP1", "SPATS2L", "ERBB4", "SNORC", "NGEF", "PLCL2", "TBC1D5", "RBMS3", "LINC02033", "CAMKV", "ACTBP13", "PBRM1", "RNU6-856P", "SNORD19B", "SNORD19C", "SNORD69", "NEK4", "ITIH3", "ITIH4", "SERBP1P3", "C3orf49", "THOC7-AS1", "PSMD6", "FOXP1", "LINC02050", "RNU6-823P", "EEFSEC", "PCCB", "RNU6-1284P", "LINC02067", "SOX2-OT", "PCGF3", "PCDH7", "GSX2", "SLC39A8", "LINC02264", "MAP9", "YWHAEP4", "KLHL2", "GPM6A", "HCN1", "PLK2", "PDE4D", "ZSWIM6", "MEF2C-AS1", "SLCO6A1", "EFNA5", "HSPA9", "CXXC5", "CXXC5-AS1", "VTRNA1-3", "LINC01470", "MFAP3", "CMAHP", "TRIM38", "HIST1H1PS2", "HFE", "HIST1H1E", "HIST1H2BE", "HIST1H3G", "BTN3A2", "BTN2A1", "BTN1A1", "ABT1", "GUSBP2", "HIST1H2BJ", "HIST1H4I", "PRSS16", "ZNF184", "CUL9", "ADGRB3", "RIMS1", "PGM3", "BACH2", "MFSD4B", "DCBLD1", "MAD1L1", "MPP6", "SUMO2P14", "GRM3", "KMT2E-AS1", "SRPK2", "IMMP2L", "SND1", "LRRC4", "EXOC4", "DGKI", "MSRA", "ZDHHC2", "CLU", "PLPP5", "CYP7B1", "RNA5SP272", "MTCO1P47", "TRPS1", "TSNARE1", "PUF60", "RNF38", "MIGA2", "KLF6", "CACNB2", "PRKG1", "ANK3", "ZNF365", "LINC00502", "NT5C2", "RPS15AP29", "BRSK2", "ABCC8", "ATG13", "CTNND1", "MACROD1", "OVOL1", "TTC12", "DRD2", "SIAE", "IGSF9B", "B3GAT1", "CACNA1C", "CACNA1C-IT3", "MCRS1", "PCBP2-OT1", "STAT6", "LRP1", "R3HDM2", "TBC1D15", "KRT19P2", "RNA5SP366", "TRPV4", "ATP2A2", "RPL31P49", "ARL6IP4", "TRPC4", "NDFIP2", "NPAS3", "TRIM9", "RGS6", "BCL11B", "KLC1", "PAK6", "PLCB2", "CCNB2", "IREB2", "PSMA4", "CPEB1", "WDR73", "FURIN", "FES", "MAN2A2", "RBFOX1", "GRIN2A", "DOC2A", "C16orf92", "ALDOA", "PPP4C", "SETD6", "DEF8", "SMG6", "SMG6-IT1", "ARHGAP44", "EPN2", "MAPK7", "CDK5R1", "MAPT", "WNT3", "SPHK1", "RPL32P31", "PPIAP14", "TCF4", "TCF4-AS2", "LINC01539", "PQLC1", "APC2", "ZNF823", "ZNF491", "NCAN", "MIR640", "ZNF536", "IRF3", "SLC32A1", "PPP1R16B", "KCNS1", "KCNB1", "EEF1A2", "NRIP1", "CACNA1I", "SLC25A17", "SEPT3"};
        
        try {
            // Set<String> cadGenesIDSet = new HashSet<String>(Arrays.asList(cadGenes));
            Set<String> cadGenesIDSet = new HashSet<String>();
            LocalFile.retrieveData("./SCZdiseaseKnownGenes.txt", cadGenesIDSet, 0);
            GeneGraphShort gg = new GeneGraphShort();
            Map<String, String> symbolIDMap = gg.readHGNCGeneSymbolID("./resources");
            Map<Integer, String> idSymbolMap = gg.readHGNCGeneIDSymbol("./resources");
            // File path = new File("/public1/data/resources/open_db/gene_network/GIANT_bgz/");
            File path = new File("/home/mxli/data/work/data/giant/");
            int threadNum = 10;
            if (args != null && args.length > 0) {
                threadNum = Integer.parseInt(args[0]);
                System.out.println(threadNum);
            }
            
            File[] files = path.listFiles();
            boolean createList = true;
            double minScore = 0.1;
            long time0 = System.nanoTime();
            List<String> sigNetPaths = new ArrayList<String>();
            for (int i = 0; i < files.length; i++) {
                long time = System.nanoTime();
                if (files[i].length() > 1000000000) {
                    //  continue;
                }
                String filePath = files[i].getCanonicalPath();
                System.out.print(files[i].getName());
                gg.readInteractionsFast(filePath, idSymbolMap, minScore, 10, createList, false);
                int obsNum = gg.getConnectivityNum(cadGenesIDSet, idSymbolMap);
                double p = gg.connectivityEvaluate(cadGenesIDSet, idSymbolMap, 10000, 10);
                System.out.println("\t" + obsNum + "\t" + p);
                if (p < 1E-4) {
                    sigNetPaths.add(filePath);
                }
                gg.clean();
                time = System.nanoTime() - time;
                time = time / 1000000000;
                long min = time / 60;
                long sec = time % 60;
                //System.out.printf("Elapsed time: " + min + " min. " + sec + " sec.");
            }

            //merge networks
            if (!sigNetPaths.isEmpty()) {
                int size = sigNetPaths.size();
                gg.readInteractionsFast(sigNetPaths.get(0), idSymbolMap, minScore, 10, false, true);
                for (int s = 1; s < size; s++) {
                    String fs = sigNetPaths.get(s);
                    gg.readInteractionsFast(fs, idSymbolMap, minScore, 6, false, true);
                    gg.mergeReduantInteractions();
                }
                //gg.converMap2List(false);
                Map<Short, ShortArrayList> nodeConnectMap = gg.neighberGraph;
            }
            
            long time = System.nanoTime() - time0;
            time = time / 1000000000;
            long min = time / 60;
            long sec = time % 60;
            System.out.printf("Elapsed time: " + min + " min. " + sec + " sec.");
            //path = "/home/mxli/data/work/java/networksim/resources/giant/liver_top.b.gz";
            //gg.readInteractionsFast(path, idSymbolMap, minScore, 6, createList, true);
            //gg.mergeReduantInteractions();
            //    gg.converMap2List(false);
//            Map<Short, ShortArrayList> nodeConnectMap = null;
//            if (!createList) {
//                nodeConnectMap = gg.neighberGraph;
//            }
//
//            int key = 9882;
//
//            List<String[]> neighberGraph = gg.mappingSearchNeighbors(key, idSymbolMap, nodeConnectMap);
//            for (String[] item : neighberGraph) {
//                System.out.println(key + "\t" + item[0] + "\t" + (Double.parseDouble(item[1]) / base));
//            }
            // double p = gg.connectivityEvaluate(cadGenesIDSet, 200000, 10);
            // System.out.println(p);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void extendERICscore(String ericFile, String codingGeneFile, ArrayList<DownScore> selectHP, HashSet<String> giantPaths,
            Map<String, String> symbolIDMap, Map<Integer, String> idSymbolMap, String outDir) throws Exception {

        //construct ericMap and geneIndex
        HashMap<String, Integer> geneIndexMap = new HashMap<String, Integer>();
        HashMap<String, ArrayList<Double>> ericMap = new HashMap<String, ArrayList<Double>>();
        
        BufferedReader brEric = getBufferedReader(ericFile);
        int geneIdx = 0;
        for (String g : brEric.readLine().split("\t", -1)) {
            geneIndexMap.put(g, geneIdx);
            geneIdx++;
        }
        String line = null;
        while ((line = brEric.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String hp = cell[0];
            ArrayList<Double> scores = new ArrayList<Double>();
            for (int i = 1; i < cell.length; i++) {
                scores.add(Double.valueOf(cell[i]));
            }
            ericMap.put(hp, scores);
        }
        brEric.close();
        //  System.out.println("eric map has been constructed!");

        //get disease-related HP and its weight
        ArrayList<String> hpList = new ArrayList<String>();
        ArrayList<Double> hpWeight = new ArrayList<Double>();
        double totalWeight = 0;
        String hpoNames = "";
        for (DownScore ds : selectHP) {
            if (ericMap.containsKey(ds.getName())) {
                hpList.add(ds.getName());
                hpoNames += "\t" + ds.getName();
                hpWeight.add(ds.getScore());
                totalWeight += ds.getScore();
            }
        }
        System.out.println(hpList.size() + " hp term(s) are avaliable.");
        
        for (String giantFile : giantPaths) {
            readInteractionsFast(giantFile, idSymbolMap, 0.1, 2, false, true);
            
            Map<Short, ShortArrayList> nodeConnectMap = this.neighberGraph;
            
            File gfile = new File(giantFile);
            String tmpResultName = gfile.getName().split("\\.")[0];
            String resultFile = outDir + File.separator + tmpResultName + ".ericScore_on_GIANT.txt";
            //write titleLine
            BufferedWriter bw = getBufferedWriter(resultFile, false);
            bw.write("GeneSymbol" + hpoNames + "\tRelatednessScore\n");
            //read gene file
            BufferedReader br = getBufferedReader(codingGeneFile);
            br.readLine();//title
            while ((line = br.readLine()) != null) {
                String geneSymbol = line.split("\t", -1)[0];
                int geneID = symbolIDMap.containsKey(geneSymbol) ? Integer.parseInt(symbolIDMap.get(geneSymbol)) : -1;
                bw.write(geneSymbol);
                int geneIndex = geneIndexMap.containsKey(geneSymbol) ? geneIndexMap.get(geneSymbol) : -1;
                // System.out.println(geneSymbol + "\t" + geneID + "\t" + geneIndex);
                List<String[]> neighbers = this.uniuqeGeneIndexMap.containsKey(geneID) ? this.mappingSearchNeighbors(geneID, idSymbolMap, nodeConnectMap) : null;
                List<Double> GeneScores = new ArrayList<Double>();
                for (String hp : hpList) {
                    ArrayList<Double> scores = new ArrayList<Double>();
                    if (geneIndex != -1) {
                        scores.add(ericMap.get(hp).get(geneIndex));
                    } else {
                        scores.add(0.0);
                    }
                    if (neighbers != null && !neighbers.isEmpty()) {
                        for (String[] item : neighbers) {
                            String neighborGene = item[0];
                            double similarityGeneScore = Double.parseDouble(item[1]) / base;
                            int neighGeneIndex = geneIndexMap.containsKey(neighborGene) ? geneIndexMap.get(neighborGene) : -1;
                            if (neighGeneIndex != -1) {
                                scores.add(similarityGeneScore * (ericMap.get(hp).get(neighGeneIndex)));
                            }
                            
                        }
                    }
                    double maxScore = scores != null && !scores.isEmpty() ? Collections.max(scores) : 0;
                    GeneScores.add(maxScore);
                    bw.write("\t" + maxScore);
                }
                double max = Collections.max(GeneScores);
                double sum = 0;
                double weightedSum = 0;
                for (int i = 0; i < GeneScores.size(); i++) {
                    sum += GeneScores.get(i);
                    weightedSum += GeneScores.get(i) * hpWeight.get(i);
                }
                double avg = sum / hpList.size();
                double weightedAvg = weightedSum / totalWeight;
                bw.write("\t" + weightedAvg + "\n");
                bw.flush();
            }
            br.close();
            bw.close();
            System.out.println("Finished!");
        }
    }
    
    public void extendERICscore(String ericFile, List<String> geneList, ArrayList<DownScore> selectHP, List<String> giantPathList,
            Map<String, String> symbolIDMap, Map<Integer, String> idSymbolMap,int threadNum, Map<String, double[]> geneScoreMap) throws Exception {

        //construct ericMap and geneIndex
        HashMap<String, Integer> geneIndexMap = new HashMap<String, Integer>();
        HashMap<String, ArrayList<Double>> ericMap = new HashMap<String, ArrayList<Double>>();
        
        BufferedReader brEric = getBufferedReader(ericFile);
        int geneIdx = 0;
        for (String g : brEric.readLine().split("\t", -1)) {
            geneIndexMap.put(g, geneIdx);
            geneIdx++;
        }
        String line = null;
        while ((line = brEric.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String hp = cell[0];
            ArrayList<Double> scores = new ArrayList<Double>();
            for (int i = 1; i < cell.length; i++) {
                scores.add(Double.valueOf(cell[i]));
            }
            ericMap.put(hp, scores);
        }
        brEric.close();
        //  System.out.println("eric map has been constructed!");

        //get disease-related HP and its weight
        ArrayList<String> hpList = new ArrayList<String>();
        ArrayList<Double> hpWeight = new ArrayList<Double>();
        double totalWeight = 0;
        String hpoNames = "";
        for (DownScore ds : selectHP) {
            if (ericMap.containsKey(ds.getName())) {
                hpList.add(ds.getName());
                hpoNames += "\t" + ds.getName();
                hpWeight.add(ds.getScore());
                totalWeight += ds.getScore();
            }
        }
        LOG.info(hpList.size() + " hp term(s) are avaliable and used for phenotype relatedness analysis: "+hpList.toString());
        
        int giantNetNum = giantPathList.size();
        int geneNum = geneList.size();
        for (int g = 0; g < giantNetNum; g++) {
            String giantFile = giantPathList.get(g);
            this.clean();
            readInteractionsFast(giantFile, idSymbolMap, 0.1, threadNum, false, true);
            
            Map<Short, ShortArrayList> nodeConnectMap = this.neighberGraph;
            
            
            for (int n = 0; n < geneNum; n++) {
                String geneSymbol = geneList.get(n);
                int geneID = symbolIDMap.containsKey(geneSymbol) ? Integer.parseInt(symbolIDMap.get(geneSymbol)) : -1;
                double[] scores1 = geneScoreMap.get(geneSymbol);
                if (scores1 == null) {
                    scores1 = new double[giantNetNum];
                    Arrays.fill(scores1, Double.NaN);
                    geneScoreMap.put(geneSymbol, scores1);
                }
                
                int geneIndex = geneIndexMap.containsKey(geneSymbol) ? geneIndexMap.get(geneSymbol) : -1;
                // System.out.println(geneSymbol + "\t" + geneID + "\t" + geneIndex);
                List<String[]> neighbers = this.uniuqeGeneIndexMap.containsKey(geneID) ? this.mappingSearchNeighbors(geneID, idSymbolMap, nodeConnectMap) : null;
                List<Double> GeneScores = new ArrayList<Double>();
                for (String hp : hpList) {
                    ArrayList<Double> scores = new ArrayList<Double>();
                    if (geneIndex != -1) {
                        scores.add(ericMap.get(hp).get(geneIndex));
                    } else {
                        scores.add(0.0);
                    }
                    if (neighbers != null && !neighbers.isEmpty()) {
                        for (String[] item : neighbers) {
                            String neighborGene = item[0];
                            double similarityGeneScore = Double.parseDouble(item[1]) / base;
                            int neighGeneIndex = geneIndexMap.containsKey(neighborGene) ? geneIndexMap.get(neighborGene) : -1;
                            if (neighGeneIndex != -1) {
                                scores.add(similarityGeneScore * (ericMap.get(hp).get(neighGeneIndex)));
                            }
                            
                        }
                    }
                    double maxScore = scores != null && !scores.isEmpty() ? Collections.max(scores) : 0;
                    GeneScores.add(maxScore);
                    // bw.write("\t" + maxScore);
                }
                double max = Collections.max(GeneScores);
                double sum = 0;
                double weightedSum = 0;
                for (int i = 0; i < GeneScores.size(); i++) {
                    sum += GeneScores.get(i);
                    weightedSum += GeneScores.get(i) * hpWeight.get(i);
                }
                double avg = sum / hpList.size();
                double weightedAvg = weightedSum / totalWeight;
                scores1[g] = weightedAvg;
                //bw.write("\t" + weightedAvg + "\n");
                //bw.flush();
            }            
            
        }
    }
    
}
