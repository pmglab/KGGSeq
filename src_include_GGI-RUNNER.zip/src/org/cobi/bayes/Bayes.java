package org.cobi.bayes;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.cobi.kggseq.Constants;

import org.cobi.util.file.LocalFileFunc;

public class Bayes implements Constants {

    String resourcePath;
    private static final Logger LOG = Logger.getLogger(Bayes.class);

    /**
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
/*
        The population mean score for imputation of missing value.
        GWAVA_Region	0.153309
GWAVA_TSS	0.205698
GWAVA_Unmatched	0.33259
CADD_CScore	-0.0784622
DANN	0.291601
FATHMM-MKL	0.00403947
FunSeq	1
FunSeq2	0.287838
GWAS3D	2.80186
SuRFR	9.44965        
         */

        double[] annotationScoreDouble = new double[]{0.153309, 0.205698, 0.33259, -0.0784622, 0.291601, 0.00403947, 1, -0.540851872, 2.80186, 9.44965};

        Bayes bayesScoreGenerator = new Bayes("resources", "hg19");

        bayesScoreGenerator.readResource(false);
        double causalscore, neutralscore;
        for (int i = 0; i < annotationScoreDouble.length; i++) {
            causalscore = bayesScoreGenerator.getCausalscore(annotationScoreDouble[i], i);
            neutralscore = bayesScoreGenerator.getNeutralscore(annotationScoreDouble[i], i);
            System.out.println(causalscore + "\t" + neutralscore + "\t" + (causalscore / neutralscore) + "\t" + (causalscore / (causalscore + neutralscore)));
        }
        // double cell_p = bayesScoreGenerator.getCellSpecificScore("6", 127663116);
        //System.out.println(bayesScoreGenerator.getBayesScore(annotationScore, cell_p));
    }

    public void readResource(boolean cellTypeSpec) {
        causalScores = getDistributionProbability(resourcePath + "/" + causalFilePath + "/");
        neutralScores = getDistributionProbability(resourcePath + "/" + neutralFilePath + "/");
        cellTypeScores = new HashMap<String, List<ArrayList<double[]>>>();
        cellSpecificScoresPostions = new HashMap<String, List<int[]>>();
        if (cellTypeSpec) {
            getCellSpecificityElements1(cellTypeScores, cellSpecificScoresPostions);
        }
    }

    public String causalFilePath = "all_causal_distribution";
    public String neutralFilePath = "all_neutral_distribution";
    public String cellLineName = "GM12878";
    public String cellEncodeInfoName[] = {"H3K4me1", "H3K36me3", "DNase", "H3K79me2", "H3K9me3", "H3K27me3", "H3K4me2", "H3K4me3", "H3K36me3"};

    public ArrayList<double[]> causalScores = new ArrayList<double[]>();
    public ArrayList<double[]> neutralScores = new ArrayList<double[]>();
    public HashMap<String, List< ArrayList<double[]>>> cellTypeScores;
    public HashMap<String, List< int[]>> cellSpecificScoresPostions;

    public StringBuffer sb;
    public String refGenomeVersion;

    public Bayes(String resourcePath, String refGenomeVersion) {
        this.resourcePath = resourcePath;
        this.refGenomeVersion = refGenomeVersion;
    }

    /*
    public void changeFeatureNum(String[] inputList) {
        if (inputList != null) {
            featureNum = new String[inputList.length];
            for (int i = 0; i < inputList.length; i++) {
                featureNum[i] = inputList[i];
            }
        }
    }
     */
    public void changeCellLineName(String inputName) {
        if (inputName != null) {
            cellLineName = inputName;
        }
    }

    public float getCellSpecificScore(List<int[]> poses, List<ArrayList<double[]>> scores, int posIndex, int[] intervalIndexes) {
        float score = 0;
        double[] List_Hit = new double[6];
        double H3K79me2_centrality = -1;
        Arrays.fill(List_Hit, 0);
        // System.out.println(posIndex);
        /*
        if (posIndex == 235844) {
            int sss = 0;
        }
         */
        for (int ii = 0; ii < List_Hit.length; ii++) {
            int[] annotationPosition = poses.get(ii);
            if (annotationPosition == null) {
                List_Hit[ii] = 0;
                continue;
            }
            //int searchIndex = getBinarySearchRegion(annotationPosition, posIndex, 0, annotationPosition.length / 2);
            int searchIndex = getSortMergeSearchRegion(annotationPosition, posIndex, intervalIndexes, ii);
            if (searchIndex >= 0) {
                List_Hit[ii] = 1;
                if (ii == 3) {
                    H3K79me2_centrality = Math.abs(scores.get(ii).get(searchIndex)[1]
                            - (posIndex - annotationPosition[searchIndex]));
                }
            } else {
                if (ii == 3) {
                    List_Hit[ii] = -1;
                }else{
                     List_Hit[ii] = 0;
                }
            }

        }

        double H3K4me1_hit = List_Hit[0];
        double H3K36me3_hit = List_Hit[1];
        double DNase_hit = List_Hit[2];
        double H3K79me2_hit = List_Hit[3];
        double H3K9me3_hit = List_Hit[4];
        double H3K27me3_hit = List_Hit[5];

        double[] scoreList = new double[3];
        Arrays.fill(scoreList, 0);
        int ii;
        for (int a = 0; a < scoreList.length; a++) {
            ii = a + 6;
            int[] annotationPosition = poses.get(ii);
            if (annotationPosition == null) {
                scoreList[a] = 0;
                continue;
            }
            //int searchIndex = getBinarySearchRegion(annotationPosition, posIndex, 0, annotationPosition.length / 2);
            int searchIndex = getSortMergeSearchRegion(annotationPosition, posIndex, intervalIndexes, ii);
            if (searchIndex > 0) {
                scoreList[a] = scores.get(ii).get(searchIndex)[0];
            } else {
                scoreList[a] = 0;
            }

        }
        double H3K4me2_score = scoreList[0];
        double H3K4me3_score = scoreList[1];
        double H3K36me3_score = scoreList[2];
        score = (float) (1 / (1 + Math
                .exp(-(-0.5339527052 + 1.0513562209 * H3K4me1_hit + 1.5659681399 * H3K36me3_hit + 1.2131942069 * DNase_hit + 0.9750312605 * H3K79me2_hit + -0.4843821400 * H3K9me3_hit
                        + 1.5150317212 * H3K27me3_hit + 0.0008691201 * H3K4me2_score + 0.0003089830 * H3K4me3_score + 0.0043517819 * H3K36me3_score + -0.0001497833 * H3K79me2_centrality))));
        if (score < 0.3696304) {
            score = (float) 0.3696304;
        }
        
        return score;
    }

    public int getBinarySearchRegion(int[] posList, int posIndex, int start, int end) {
        int mid = start + (end - start) / 2;
        if (end < start || posIndex > posList[posList.length - 1] || posIndex < posList[0]) {
            return -1;
        }
        if (posList[2 * mid] > posIndex) {
            return getBinarySearchRegion(posList, posIndex, start, mid - 1);
        } else if (posList[2 * mid + 1] < posIndex) {
            return getBinarySearchRegion(posList, posIndex, mid + 1, end);
        } else {
            return mid;
        }
    }

    //new binary search function by MXLi
    public int getBinarySearchRegion1(int[] sortedStartPosList, int target, int lastIndex) {
        int start = lastIndex, end = lastIndex;
        //a special position array
        int halfLen = sortedStartPosList.length / 2;
        if (lastIndex < 0) {
            start = 0;
            end = halfLen;
        } else if (lastIndex >= halfLen) {
            if (target <= sortedStartPosList[sortedStartPosList.length - 1]) {
                return (halfLen - 1);
            } else {
                return -1;
            }
        } else {
            while (start > 0 && target < sortedStartPosList[start]) {
                start--;
            }
            int len = halfLen - 1;
            while (end < len && target > sortedStartPosList[end]) {
                end++;
            }
        }
        int index = Arrays.binarySearch(sortedStartPosList, start, end, target);
        if (index < 0) {
            index = -index - 1;
            if (index == start) {
                //even less than the first postions
                return -1;
            } else {
                //must be larger than a start position
                index = index - 1;
                if (target <= sortedStartPosList[halfLen + index]) {
                    return index;
                } else {
                    return -1;
                }
            }
        } else {
            return index;
        }

    }

    //sorted merging by MXLi; assume no overlapped regions
    public int getSortMergeSearchRegion(int[] sortedStartPosList, int target, int[] intervalIndex, int colI) {
        //a special position array
        int halfLen = sortedStartPosList.length / 2;
        while (intervalIndex[colI] < halfLen && target > sortedStartPosList[intervalIndex[colI]]) {
            intervalIndex[colI]++;
        }

        if (intervalIndex[colI] > halfLen) {
            intervalIndex[colI] = halfLen;
        }

        if (target <= sortedStartPosList[intervalIndex[colI] - 1 + halfLen]) {
            return intervalIndex[colI] - 1;
        } else {
            return -1;
        }

    }

    public double getCausalscore(double s, int index) {
        double causalscore = causalScores.get(2 * index + 1)[getBinarySearch(causalScores.get(2 * index), s, 0, causalScores.get(2 * index).length - 1)];
        return causalscore;
    }

    public double getNeutralscore(double s, int index) {
        double causalscore = neutralScores.get(2 * index + 1)[getBinarySearch(neutralScores.get(2 * index), s, 0, neutralScores.get(2 * index).length - 1)];
        return causalscore;
    }

    public double[] getBayesScoreCompsit(float[] annotationScore, int[] effecIndex, double[] baye1NonCodingPredic, double[] baye2NonCodingPredic) {
        double composite_p = 1;
        double bfFactor = 1;
        double[] result = new double[2];
        Arrays.fill(result, Double.NaN);
        double causalscore;
        double neutralscore;
        int index;

        //StringBuilder sbTest1 = new StringBuilder();
        //StringBuilder sbTest2 = new StringBuilder();
        for (int i = 0; i < effecIndex.length; i++) {
            causalscore = 1;
            neutralscore = 1;
            index = effecIndex[i];
            if (Double.isNaN(annotationScore[index])) {
                //tmpScore = baye1NonCodingPredic[effecIndex[i]];
                //causalscore = causalScores.get(2 * i + 1)[getBinarySearch(causalScores.get(2 * i), tmpScore, 0, causalScores.get(2 * i).length - 1)];
                //neutralscore = neutralScores.get(2 * i + 1)[getBinarySearch(neutralScores.get(2 * i), tmpScore, 0, neutralScores.get(2 * i).length - 1)];
                bfFactor *= baye1NonCodingPredic[index];
                composite_p *= baye2NonCodingPredic[index];
            } else {
                causalscore = causalScores.get(2 * index + 1)[getBinarySearch(causalScores.get(2 * index), annotationScore[index], 0, causalScores.get(2 * index).length - 1)];
                neutralscore = neutralScores.get(2 * index + 1)[getBinarySearch(neutralScores.get(2 * index), annotationScore[index], 0, neutralScores.get(2 * index).length - 1)];
                bfFactor *= (causalscore / neutralscore);
                composite_p *= (causalscore / (causalscore + neutralscore));
            }
            // System.out.println(i+" "+(causalscore / neutralscore)+" "+(causalscore / (causalscore + neutralscore)));
        }

        result[0] = bfFactor;
        result[1] = composite_p;
        return result;

    }

    public void getCellSpecificityElements(List<HashMap<String, ArrayList<double[]>>> cellSpecificScores, List<HashMap<String, int[]>> cellSpecificScoresPostions) {
        for (int i = 0; i < cellEncodeInfoName.length; i++) {
            File rsFile = new File(resourcePath + refGenomeVersion + "/all_cell_signal/" + cellLineName + "-" + cellEncodeInfoName[i] + ".narrowPeak.sorted.gz");
            //File rsFile = new File("C:\\Users\\mulin0424\\Desktop\\PRVCS\\resources\\" + genomeVersion + "\\all_cell_signal\\" + cellLineName + "-" + cellEncodeInfoName[i] + ".narrowPeak.sorted.gz");
            try {
                HashMap<String, ArrayList<double[]>> thisHashMapScores = new HashMap<String, ArrayList<double[]>>();
                HashMap<String, IntArrayList> thisHashMapPoses = new HashMap<String, IntArrayList>();
                BufferedReader br = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                String currentLine;
                while ((currentLine = br.readLine()) != null) {
                    if (currentLine.trim().length() == 0) {
                        continue;
                    }
                    String sp[] = currentLine.trim().split("\t");
                    String key = "";
                    if (sp[0].startsWith("chr") || sp[0].startsWith("Chr")) {
                        key = sp[0].trim().substring(3, sp[0].trim().length());
                    } else {
                        key = sp[0].trim();
                    }
                    double[] element = new double[]{Double.parseDouble(sp[4].trim()), Double.parseDouble(sp[9].trim())};
                    if (thisHashMapScores.containsKey(key)) {
                        thisHashMapScores.get(key).add(element);
                    } else {
                        ArrayList<double[]> thisScore = new ArrayList<double[]>();
                        thisScore.add(element);
                        thisHashMapScores.put(key, thisScore);
                    }

                    IntArrayList posList = thisHashMapPoses.get(key);
                    if (posList == null) {
                        posList = new IntArrayList();
                        thisHashMapPoses.put(key, posList);
                    }
                    posList.add(Integer.parseInt(sp[1].trim()));
                    posList.add(Integer.parseInt(sp[2].trim()));

                }
                cellSpecificScores.add(thisHashMapScores);
                HashMap<String, int[]> thisHashMapPosesArray = new HashMap<String, int[]>();
                int len;
                int lastI1, lastI2;
                for (Map.Entry<String, IntArrayList> item : thisHashMapPoses.entrySet()) {
                    int[] poss = new int[item.getValue().size()];
                    len = poss.length / 2;
                    lastI1 = -1;
                    lastI2 = -1;
                    for (int ii = 0; ii < len; ii++) {
                        poss[ii] = item.getValue().getQuick(ii * 2);
                        poss[ii + len] = item.getValue().getQuick(ii * 2 + 1);
                        if (lastI1 >= poss[ii] || lastI2 >= poss[ii + len]) {
                            System.out.println(lastI1 + "\t" + lastI2 + "\n");
                            System.out.println(poss[ii] + "\t" + poss[ii + len] + "\n");
                        }
                    }
                    thisHashMapPosesArray.put(item.getKey(), poss);
                }
                cellSpecificScoresPostions.add(thisHashMapPosesArray);
                br.close();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                LOG.error(rsFile.toString() + " doesn't exist!");
            }
        }

    }

    public void getCellSpecificityElements1(HashMap<String, List<ArrayList<double[]>>> cellSpecificScores, HashMap<String, List< int[]>> cellSpecificScoresPostions) {
        for (int i = 0; i < cellEncodeInfoName.length; i++) {
            File rsFile = new File(resourcePath + refGenomeVersion + "/all_cell_signal/" + cellLineName + "-" + cellEncodeInfoName[i] + ".narrowPeak.sorted.gz");
            //File rsFile = new File("C:\\Users\\mulin0424\\Desktop\\PRVCS\\resources\\" + genomeVersion + "\\all_cell_signal\\" + cellLineName + "-" + cellEncodeInfoName[i] + ".narrowPeak.sorted.gz");
            try {
                HashMap<String, ArrayList<double[]>> thisHashMapScores = new HashMap<String, ArrayList<double[]>>();
                HashMap<String, IntArrayList> thisHashMapPoses = new HashMap<String, IntArrayList>();
                BufferedReader br = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                String currentLine;
                while ((currentLine = br.readLine()) != null) {
                    if (currentLine.trim().length() == 0) {
                        continue;
                    }
                    String sp[] = currentLine.trim().split("\t");
                    String key = "";
                    if (sp[0].startsWith("chr") || sp[0].startsWith("Chr")) {
                        key = sp[0].trim().substring(3, sp[0].trim().length());
                    } else {
                        key = sp[0].trim();
                    }
                    double[] element = new double[]{Double.parseDouble(sp[4].trim()), Double.parseDouble(sp[9].trim())};
                    if (thisHashMapScores.containsKey(key)) {
                        thisHashMapScores.get(key).add(element);
                    } else {
                        ArrayList<double[]> thisScore = new ArrayList<double[]>();
                        thisScore.add(element);
                        thisHashMapScores.put(key, thisScore);
                    }

                    IntArrayList posList = thisHashMapPoses.get(key);
                    if (posList == null) {
                        posList = new IntArrayList();
                        thisHashMapPoses.put(key, posList);
                    }
                    posList.add(Integer.parseInt(sp[1].trim()));
                    posList.add(Integer.parseInt(sp[2].trim()));

                }

                br.close();

                for (Map.Entry<String, ArrayList<double[]>> item : thisHashMapScores.entrySet()) {
                    List<ArrayList<double[]>> arrayList = cellSpecificScores.get(item.getKey());
                    if (arrayList == null) {
                        arrayList = new ArrayList<ArrayList<double[]>>();
                        cellSpecificScores.put(item.getKey(), arrayList);
                        for (int t = 0; t < cellEncodeInfoName.length; t++) {
                            arrayList.add(new ArrayList<double[]>());
                        }
                    }
                    arrayList.get(i).addAll(item.getValue());
                }
                HashMap<String, int[]> thisHashMapPosesArray = new HashMap<String, int[]>();
                int len;
                int lastI1, lastI2;
                for (Map.Entry<String, IntArrayList> item : thisHashMapPoses.entrySet()) {
                    int[] poss = new int[item.getValue().size()];
                    len = poss.length / 2;
                    lastI1 = -1;
                    lastI2 = -1;
                    for (int ii = 0; ii < len; ii++) {
                        poss[ii] = item.getValue().getQuick(ii * 2);
                        poss[ii + len] = item.getValue().getQuick(ii * 2 + 1);
                        /*
                        //check whether there are overlapped intervals
                        if (lastI1 >= poss[ii] || lastI2 >= poss[ii + len]) {
                            System.out.println(lastI1 + "\t" + lastI2 + "\n");
                            System.out.println(poss[ii] + "\t" + poss[ii + len] + "\n");
                        }
                         */
                    }
                    thisHashMapPosesArray.put(item.getKey(), poss);
                    List< int[]> posList = cellSpecificScoresPostions.get(item.getKey());
                    if (posList == null) {
                        posList = new ArrayList< int[]>();
                        cellSpecificScoresPostions.put(item.getKey(), posList);
                        for (int t = 0; t < cellEncodeInfoName.length; t++) {
                            posList.add(null);
                        }

                    }
                    posList.set(i, poss);
                }

            } catch (Exception e) {
                e.printStackTrace();
                // TODO Auto-generated catch block
                LOG.error(rsFile.toString() + " doesn't exist!");
            }
        }

    }

    public int getBinarySearch(final double[] scoreList, double key, int start, int end) {
        if (key >= scoreList[scoreList.length - 1]) {
            return scoreList.length - 1;
        } else if (key <= scoreList[0]) {
            return 0;
        }
        if (end < start) {
            double mid = (scoreList[end] + scoreList[start]) / 2;
            if (key >= mid) {
                return start;
            }
            return end;
        }
        int mid = start + (end - start) / 2;
        if (key > scoreList[mid]) {
            return getBinarySearch(scoreList, key, mid + 1, end);
        } else if (key < scoreList[mid]) {
            return getBinarySearch(scoreList, key, start, mid - 1);
        }
        return mid;

    }

    public ArrayList<double[]> getDistributionProbability(String filePath) {
        ArrayList<double[]> scores = new ArrayList<double[]>();
        DoubleArrayList thisScore = new DoubleArrayList();
        DoubleArrayList thisProbability = new DoubleArrayList();
        File resourceFile = null;
        for (int i = 0; i < ReguPredicNames.length; i++) {
            thisScore.clear();
            thisProbability.clear();
            try {
                resourceFile = new File(filePath + ReguPredicNames[i] + ".dis");
                if (!resourceFile.exists()) {
                    LOG.error(resourceFile.getCanonicalPath() + " does not exist!");
                    continue;
                }
                BufferedReader br = new BufferedReader(new FileReader(resourceFile));
                while (br.ready()) {
                    String str = br.readLine();
                    String[] splitStr = str.trim().split(" ");
                    if (splitStr.length == 3) {
                        /*
                        if (ReguPredicNames[i].equals("FunSeq2_score")) {
                            thisScore.add(Math.pow(10, Double.parseDouble(splitStr[0])));
                        } else {
                            thisScore.add((double) Double.parseDouble(splitStr[0]));
                        }
                         */
                        thisScore.add((double) Double.parseDouble(splitStr[0]));
                        thisProbability.add((double) Double.parseDouble(splitStr[2]));
                    }
                }
                double[] floatThisScore = new double[thisScore.size()];
                double[] floatThisProability = new double[thisProbability.size()];
                for (int t = 0; t < floatThisScore.length; t++) {
                    floatThisScore[t] = thisScore.getQuick(t);
                }
                for (int t = 0; t < floatThisScore.length; t++) {
                    floatThisProability[t] = thisProbability.getQuick(t);
                }

                scores.add(floatThisScore);
                scores.add(floatThisProability);
                br.close();
            } catch (Exception e) {
                LOG.error(e);
            }
        }
        return scores;
    }

}
