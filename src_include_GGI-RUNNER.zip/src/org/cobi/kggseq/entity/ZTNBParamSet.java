/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author user
 */
public class ZTNBParamSet {

    public int order = -1;
    public int sigGeneNum;
    public double scoreBinCut;
    public double MLFC;
    public double freqCut;
    public int truncationPoint;

    public ZTNBParamSet(double binCut, int sigGeneNum, double MLFC) {
        this.sigGeneNum = sigGeneNum;
        this.scoreBinCut = binCut;
        this.MLFC = MLFC;
    }

    public ZTNBParamSet(double binCut, int sigGeneNum, double MLFC, int truncationPoint) {
        this.sigGeneNum = sigGeneNum;
        this.scoreBinCut = binCut;
        this.MLFC = MLFC;
        this.truncationPoint = truncationPoint;
    }

    public ZTNBParamSet(double binCut, int sigGeneNum, double MLFC, double freqCut, int truncationPoint) {
        this.sigGeneNum = sigGeneNum;
        this.scoreBinCut = binCut;
        this.MLFC = MLFC;
        this.freqCut = freqCut;
        this.truncationPoint = truncationPoint;
    }

}
