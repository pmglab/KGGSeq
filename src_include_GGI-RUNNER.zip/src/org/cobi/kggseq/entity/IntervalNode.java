/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;
 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 区间树维护的节点, 包含中心点、左右节点、此节点收纳的区间列表
 */
class IntervalNode<T> {
    /**
     * 此节点收纳的区间列表
     */
    final List<Interval<T>> intervals = new ArrayList<>();

    /**
     * 中心点
     */
    final long center;

    /**
     * 左节点
     */
    final IntervalNode<T> left;

    /**
     * 右节点
     */
    final IntervalNode<T> right;

    /**
     * 此节点收纳的区间的最大端点值
     */
    final long maxPos;

    /**
     * 此节点收纳的区间的最小端点值
     */
    final long minPos;

    /**
     * 空构造器
     */
    public IntervalNode() {
        this.center = 0;
        this.left = null;
        this.right = null;
        this.minPos = Long.MAX_VALUE;
        this.maxPos = Long.MIN_VALUE;
    }

    /**
     * 构造器方法
     */
    public IntervalNode(List<Interval<T>> intervalList) {
        if (intervalList.size() == 0) {
            this.center = 0;
            this.left = null;
            this.right = null;
            this.minPos = Long.MAX_VALUE;
            this.maxPos = Long.MIN_VALUE;
        } else {
            // 将区间的左、右端点取出, 并构造有序树表
            long[] endpoints=new long[intervalList.size()*2];
            int i=0;
            for (Interval<T> interval : intervalList) {
                endpoints[i]=(interval.getStart());
                endpoints[i+1]=(interval.getEnd());
                i+=2;
            }
            Arrays.sort(endpoints);
            this.center = endpoints[endpoints.length / 2];

            // 构造左右叶的区间列表
            List<Interval<T>> left = new ArrayList<>();
            List<Interval<T>> right = new ArrayList<>();
            long minPos = Long.MAX_VALUE;
            long maxPos = Long.MIN_VALUE;

            for (Interval<T> interval : intervalList) {
                // 将区间分为三类
                if (interval.getEnd() < this.center) {
                    // [start, end] center
                    left.add(interval);
                } else if (interval.getStart() > this.center) {
                    // center [start, end]
                    right.add(interval);
                } else {
                    // [start, center, end]
                    this.intervals.add(interval);
                    if (interval.getStart() <= minPos) {
                        minPos = interval.getStart();
                    }

                    if (interval.getEnd() >= maxPos) {
                        maxPos = interval.getEnd();
                    }
                }
            }

            this.minPos = minPos;
            this.maxPos = maxPos;
            this.intervals.sort(Interval::compareTo);

            this.left = left.size() > 0 ? new IntervalNode<>(left) : null;
            this.right = right.size() > 0 ? new IntervalNode<>(right) : null;
        }
    }

    /**
     * 单点查询, 获得包含指定坐标的区间对象
     */
    public void getContainsIntervals(long pos, List<Interval<T>> returns) {
        if (pos >= this.minPos && pos <= this.maxPos) {
            for (Interval<T> interval : this.intervals) {
                if (interval.contains(pos)) {
                    returns.add(interval);
                } else if (interval.getStart() > pos) {
                    break;
                }
            }
        }

        if (pos < this.center && this.left != null) {
            this.left.getContainsIntervals(pos, returns);
        } else if (pos > this.center && this.right != null) {
            this.right.getContainsIntervals(pos, returns);
        }
    }

    /**
     * 重叠查询, 获得与指定范围区间有交集的区间对象
     */
    public void getOverlapsIntervals(long start, long end, List<Interval<T>> returns) {
        if (Math.max(this.minPos, start) <= Math.min(this.maxPos, end)) {
            for (Interval<T> interval : this.intervals) {
                if (interval.overlapsWith(start, end)) {
                    returns.add(interval);
                } else if (interval.getStart() > end) {
                    break;
                }
            }
        }

        if (start < this.center && this.left != null) {
            this.left.getOverlapsIntervals(start, end, returns);
        }

        if (end > this.center && this.right != null) {
            this.right.getOverlapsIntervals(start, end, returns);
        }
    }

    /**
     * 子集查询, 获得包含了指定范围区间的区间对象
     */
    public void getContainsIntervals(long start, long end, List<Interval<T>> returns) {
        if (this.minPos <= start && this.maxPos >= end) {
            for (Interval<T> interval : this.intervals) {
                if (interval.contains(start, end)) {
                    returns.add(interval);
                } else if (interval.getStart() > end) {
                    break;
                }
            }
        }

        if (start < this.center && this.left != null) {
            this.left.getContainsIntervals(start, end, returns);
        }

        if (end > this.center && this.right != null) {
            this.right.getContainsIntervals(start, end, returns);
        }
    }
}
