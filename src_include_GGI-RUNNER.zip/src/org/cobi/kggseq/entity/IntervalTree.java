/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

import java.util.ArrayList;
import java.util.List;

/**
 * 区间树
 */
public class IntervalTree<T> {

    /*
    
212985592

[1:1:212965168, 212965329]
[1:2:212968435, 212968469]
[1:3:212969857, 212969932]
[1:4:212970452, 212970538]
[1:5:212976041, 212976105]
[1:6:212977660, 212977771]
[1:7:212977936, 212977993]
[1:8:212985591, 212985670]
[1:9:212988353, 212990167]
[2:1:212965329, 212968436]
[2:2:212968469, 212969858]
[2:3:212969932, 212970453]
[2:4:212970538, 212976042]
[2:5:212976105, 212977661]
[2:6:212977771, 212977937]
[2:7:212977993, 212985592]
[2:8:212985670, 212988354]
     */
    public static void main(String[] args) {
        IntervalTree tree = new IntervalTree<>();

//        tree.addInterval(0, 7, null);
//        tree.addInterval(1, 5, null);
//        tree.addInterval(0, 4, null);
//        tree.addInterval(3, 9, null);
//        tree.addInterval(1, 2, null);
//        tree.addInterval(1, 2, null);
//        tree.flush();
//
//        System.out.println(tree.getOverlapsIntervals(2, 3));
//
//        tree.addInterval(212965168, 212965329, null);
//        tree.addInterval(212968435, 212968469, null);
//        tree.addInterval(212969857, 212969932, null);
//        tree.addInterval(212970452, 212970538, null);
//        tree.addInterval(212976041, 212976105, null);
//        tree.addInterval(212977660, 212977771, null);
//        tree.addInterval(212977936, 212977993, null);
//        tree.addInterval(212985591, 212985670, null);
//        tree.addInterval(212988353, 212990167, null);
//        tree.addInterval(212965329, 212968436, null);
//        tree.addInterval(212968469, 212969858, null);
//        tree.addInterval(212969932, 212970453, null);
//        tree.addInterval(212970538, 212976042, null);
//        tree.addInterval(212976105, 212977661, null);
//        tree.addInterval(212977771, 212977937, null);
//        tree.addInterval(212977993, 212985592, null);
//        tree.addInterval(212985670, 212988354, null);
//        tree.flush();
//        System.out.println(tree.getContainsIntervals(212985592));

        tree.addInterval(242751490, 242759739, null);
        tree.addInterval(242751490, 242759739, null);
        tree.addInterval(242751490, 242759739, null);
        tree.addInterval(242791035, 242802046, null);
        tree.addInterval(242810880, 242816975, null);
        tree.addInterval(242822513, 243021873, null);
        tree.addInterval(242835138, 242842291, null);
        tree.addInterval(242835138, 242843615, null);
        tree.addInterval(242835138, 242845736, null);
        tree.addInterval(242911833, 242920427, null);
        tree.addInterval(242942359, 242949162, null);
        tree.addInterval(242988834, 243027289, null);
        tree.addInterval(243029783, 243103476, null);
        tree.addInterval(243029783, 243103476, null);
        tree.addInterval(243029783, 243103476, null);
        tree.addInterval(243029783, 243103476, null);
        tree.flush();

        System.out.println(tree.getContainsIntervals(242988828));
        int sss = 0;
    }

    /**
     * 根节点
     */
    IntervalNode<T> root;

    /**
     * 区间列表
     */
    List<Interval<T>> intervals = new ArrayList<>();

    /**
     * 构造器方法, 创建一个空区间树
     */
    public IntervalTree() {
        flush();
    }

    /**
     * 构造器方法, 将指定的数据源包装为区间树对象
     */
    public IntervalTree(List<Interval<T>> intervals) {
        if (intervals != null && intervals.size() != 0) {
            this.intervals.addAll(intervals);
        }

        flush();
    }

    /**
     * 构造器方法, 将指定的数据源包装为区间树对象
     */
    public IntervalTree(Iterable<Interval<T>> intervals) {
        for (Interval<T> interval : intervals) {
            this.intervals.add(interval);
        }

        this.root = new IntervalNode<T>(this.intervals);
    }

    /**
     * 单点查询, 获得包含指定坐标的区间对象
     */
    public List<Interval<T>> getContainsIntervals(long pos) {
        List<Interval<T>> returns = new ArrayList<>();
        root.getContainsIntervals(pos, returns);
        return returns;
    }

    /**
     * 子集查询, 获得包含了指定范围区间的区间对象
     */
    public List<Interval<T>> getContainsIntervals(long start, long end) {
        if (start > end) {
            return new ArrayList<>();
        }

        List<Interval<T>> returns = new ArrayList<>();
        root.getContainsIntervals(start, end, returns);
        return returns;
    }

    /**
     * 子集查询, 获得包含了指定范围区间的区间对象
     */
    public List<Interval<T>> getContainsIntervals(Interval<?> interval) {
        List<Interval<T>> returns = new ArrayList<>();
        root.getContainsIntervals(interval.getStart(), interval.getEnd(), returns);
        return returns;
    }

    /**
     * 重叠查询, 获得与指定范围区间有交集的区间对象
     */
    public List<Interval<T>> getOverlapsIntervals(long start, long end) {
        if (start > end) {
            return new ArrayList<>();
        }

        List<Interval<T>> returns = new ArrayList<>();
        root.getOverlapsIntervals(start, end, returns);
        return returns;
    }

    /**
     * 重叠查询, 获得与指定范围区间有交集的区间对象
     */
    public List<Interval<T>> getOverlapsIntervals(Interval<?> interval) {
        List<Interval<T>> returns = new ArrayList<>();
        root.getOverlapsIntervals(interval.getStart(), interval.getEnd(), returns);
        return returns;
    }

    /**
     * 添加区间
     *
     * @param interval 区间
     */
    public void addInterval(Interval<T> interval) {
        this.intervals.add(interval);
    }

    /**
     * 添加区间
     *
     * @param begin 区间起点
     * @param end 区间终点
     * @param data 数据对象
     */
    public void addInterval(long begin, long end, T data) {
        this.intervals.add(new Interval<>(begin, end, data));
    }

    /**
     * 刷新缓冲区, 将当前 intervals 的数据构建区间树
     */
    public void flush() {
        this.root = new IntervalNode<>(this.intervals);
    }

    /**
     * 清除所有数据
     */
    public void clear() {
        this.root = new IntervalNode<>();
        this.intervals.clear();
    }
}
