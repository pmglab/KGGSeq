/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
public class RNABoundary {

    int mRNAIndex;
    int start;
    int end;

    public RNABoundary(int mRNAIndex, int start, int end) {
        this.mRNAIndex = mRNAIndex;
        this.start = start;
        this.end = end;
    }

    public int start() {
        return this.start;
    }

    public int end() {
        return this.end;
    }

    @Override
    public String toString() {
        return "[" + this.mRNAIndex + ":" + this.start + ", " + this.end + "]";
    }
}
