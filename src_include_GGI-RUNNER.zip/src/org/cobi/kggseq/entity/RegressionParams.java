/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
public class RegressionParams {

    public double[] coef;
    public double sampleCase2CtrRatio;
    public double optimalCutoff;
    public double truePositiveRate;
    public double trueNegativeRate;
}
