/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

import java.util.Comparator;

/**
 *
 * @author mxli
 */
public class IntSetComparator1 implements Comparator<IntSet> {

    @Override
    public int compare(final IntSet arg0, final IntSet arg1) {
        return (arg0.index1 - arg1.index1);
    }
}
