/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

import cern.colt.list.DoubleArrayList;
import java.util.ArrayList;
import java.util.List;

/**
 * this class is used to store the gene-based association analysis
 *
 * @author mxli
 */
public class Gene extends SeqSegment {

    public String geneSymb;
    public List<Double> testValues;
    public List<String> featureValues;
    public List<String> transcripts;
    protected DoubleArrayList depMutScore;
    protected DoubleArrayList indepMutScores;
    public double caseMutScore = Double.NaN;
    public double controlMutScore = Double.NaN;
    public double refMutScore = Double.NaN;
    protected int[] varTypeCouts;

    public Gene(String refID, int start, int end) {
        super(start, end);
        geneSymb = refID;
        featureValues = new ArrayList<String>();
        testValues = new ArrayList<Double>();
        transcripts = new ArrayList<String>();
    }

    public Gene(String refID) {
        geneSymb = refID;
        featureValues = new ArrayList<String>();
        testValues = new ArrayList<Double>();
        transcripts = new ArrayList<String>();
    }

    public void addFeatureValue(String val) {
        featureValues.add(val);
    }

    public DoubleArrayList getOrgDepMutScore() {
        if (depMutScore == null || depMutScore.isEmpty()) {
            DoubleArrayList scores = new DoubleArrayList();
            return scores;
        } else {
            return depMutScore;
        }
    }

    public String getVarTypeCouts() {
        return varTypeCouts[0] + "(InFrameIndel)" + varTypeCouts[1] + "(LOF)" + varTypeCouts[2] + "(Mis)";
    }

    public void setVarTypeCouts(int[] varTypeCouts) {
        this.varTypeCouts = varTypeCouts;
    }

    public DoubleArrayList getDepMutScore() {
        if (depMutScore == null || depMutScore.isEmpty()) {
            return null;
        }
        DoubleArrayList scores = new DoubleArrayList();
        int size = depMutScore.size() / 2;
        double score;
        for (int i = 0; i < size; i++) {
            score = depMutScore.getQuick(i + i + 1);
            if (!Double.isNaN(score)) {
                scores.add(score);
            }
        }
        return scores;
    }

    public DoubleArrayList getDepMutScore(int unit) {
        if (depMutScore == null) {
            return null;
        }
        DoubleArrayList scores = new DoubleArrayList();
        int size = depMutScore.size() / unit;
        double score;
        for (int i = 0; i < size; i++) {
            score = depMutScore.getQuick(i * unit + unit - 1);
            if (!Double.isNaN(score)) {
                scores.add(score);
            }
        }
        return scores;
    }

    public String getVarScoreStrs() {
        StringBuilder sb = new StringBuilder();
        if (depMutScore == null || depMutScore.isEmpty()) {
            sb.append('.');
        } else {
            int size = depMutScore.size();
            for (int i = 0; i < size; i++) {
                if (!Double.isNaN(depMutScore.getQuick(i))) {
                    sb.append(depMutScore.getQuick(i));
                } else {
                    sb.append('.');
                }
                sb.append(',');
            }
            sb.setCharAt(sb.length() - 1, ';');
        }

        if (indepMutScores == null || indepMutScores.isEmpty()) {
            sb.append('.');
        } else {
            int size = indepMutScores.size();
            for (int i = 0; i < size; i++) {
                if (!Double.isNaN(indepMutScores.getQuick(i))) {
                    sb.append(indepMutScores.getQuick(i));
                } else {
                    sb.append('.');
                }
                sb.append(',');
            }
            sb.deleteCharAt(sb.length() - 1);
        }

        return sb.toString();
    }

    //the formate has been fixed
    public void appendVarScore(String values) {
        if (values == null) {
            return;
        }
        int index1 = values.indexOf(';');
        if (index1 <= 0) {
            return;
        }
        String[] cells = values.substring(0, index1).split(",");
        //no values
        if (cells.length > 1) {
            if (depMutScore == null) {
                depMutScore = new DoubleArrayList();
            }
            for (int i = 0; i < cells.length; i++) {
                if (cells[i].equals(".")) {
                    depMutScore.add(Double.NaN);
                } else {
                    depMutScore.add(Double.parseDouble(cells[i]));
                }
            }
        }
        cells = values.substring(index1 + 1).split(",");
        if (cells.length > 1) {
            if (indepMutScores == null) {
                indepMutScores = new DoubleArrayList();
            }
            for (int i = 0; i < cells.length; i++) {
                if (cells[i].equals(".")) {
                    indepMutScores.add(Double.NaN);
                } else {
                    indepMutScores.add(Double.parseDouble(cells[i]));
                }
            }
        }
    }

    public void rescaleVarScores(DoubleArrayList distr) {
        if (depMutScore == null || depMutScore.isEmpty()) {
            return;
        }
        int size = depMutScore.size() / 2;
        double s;
        int pos;
        double allScoreNum = distr.size();
        for (int i = 0; i < size; i++) {
            s = (depMutScore.getQuick(i + i + 1));
            if (!Double.isNaN(s)) {
                pos = distr.binarySearch(s);
                if (pos < 0) {
                    pos = -pos - 1;
                }
                depMutScore.setQuick(i + i + 1, pos / allScoreNum);
            }
        }
    }

    public void rescaleVarScores(DoubleArrayList distr, int unitSize) {
        if (depMutScore == null || depMutScore.isEmpty()) {
            return;
        }
        int size = depMutScore.size() / unitSize;
        double s;
        int pos;
        double allScoreNum = distr.size();
        int naNum = 0;
        for (int i = 0; i < size; i++) {
            s = (depMutScore.getQuick(i * unitSize + unitSize - 1));
            if (!Double.isNaN(s)) {
                pos = distr.binarySearch(s);
                if (pos < 0) {
                    pos = -pos - 1;
                }
                depMutScore.setQuick(i * unitSize + unitSize - 1, pos / allScoreNum);
            } else {
                naNum++;
            }
        }
        //remove genes with too many missing scores 
        if (naNum >= size * 8 / 10) {
            for (int i = 0; i < size; i++) {
                s = (depMutScore.getQuick(i * unitSize + unitSize - 1));
                if (Double.isNaN(s)) {
                    depMutScore.setQuick(i * unitSize + unitSize - 1, 0);
                }  
            }
        }
    }

    //this is simpler but less powerful than the above in most cancers
    public void rescaleVarScores0(DoubleArrayList distr) {
        if (depMutScore == null || depMutScore.isEmpty()) {
            return;
        }
        int size = depMutScore.size() / 2;
        double s;

        double maxScore = distr.getQuick(distr.size() - 1);
        double minScore = distr.getQuick(0);

        for (int i = 0; i < size; i++) {
            s = (depMutScore.getQuick(i + i + 1));
            if (!Double.isNaN(s)) {
                s = (s - minScore) / (maxScore - minScore);
                depMutScore.setQuick(i + i + 1, s);
            }
        }
    }

    public int getDepVarMutNum(double bin) {
        if (depMutScore == null || depMutScore.isEmpty()) {
            return 0;
        }
        int size = depMutScore.size() / 2;
        int num = 0;
        if (bin <= 0) {
            for (int i = 0; i < size; i++) {
                num += depMutScore.getQuick(i + i);
            }
        } else {
            int missingNum = 0;
            double avgScore = 0;
            int intScore = 0;
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(depMutScore.getQuick(i + i + 1))) {
                    missingNum++;
                } else {
                    avgScore += depMutScore.getQuick(i + i + 1);
                }
            }
            //all missing
            if (size - missingNum == 0) {
                for (int i = 0; i < size; i++) {
                    num += depMutScore.getQuick(i + i);
                }
            } else {
                avgScore = avgScore / (size - missingNum);
                for (int i = 0; i < size; i++) {
                    if (Double.isNaN(depMutScore.getQuick(i + i + 1))) {
                        intScore = (int) (avgScore / bin);
                    } else {
                        intScore = (int) (depMutScore.getQuick(i + i + 1) / bin);
                    }
                    intScore++;
                    num += (depMutScore.getQuick(i + i) * intScore);
                }
            }
        }
        return num;
    }

    // a more complex design; a unit may have three values: case mut; control mut and score
    //later this function has been a consideration of using summary counts for digene mutation burden analysis
    public int getDepVarMutNum(double bin, int uindex, int unit) {
        if (depMutScore == null || depMutScore.isEmpty()) {
            //this is for digene analysis 
            int intScore = 0;
            if (bin <= 0) {
                return (int) (caseMutScore);
            }
            if (!Double.isNaN(caseMutScore)) {
                intScore = Math.round((float) (caseMutScore / (bin)));
                return intScore;
            }
            return 0;
        }
        int size = depMutScore.size() / unit;
        int num = 0;
        if (bin <= 0) {
            for (int i = 0; i < size; i++) {
                num += depMutScore.getQuick(unit * i + uindex);
            }
        } else {
            int missingNum = 0;
            double avgScore = 0;
            int intScore = 0;
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(depMutScore.getQuick(unit + unit * i - 1))) {
                    missingNum++;
                } else {
                    avgScore += depMutScore.getQuick(unit + unit * i - 1);
                }
            }
            //all missing
            if (size - missingNum == 0) {
                for (int i = 0; i < size; i++) {
                    num += depMutScore.getQuick(unit * i + uindex);
                }
            } else {
                avgScore = avgScore / (size - missingNum);
                for (int i = 0; i < size; i++) {
                    if (Double.isNaN(depMutScore.getQuick(unit + unit * i - 1))) {
                        intScore = (int) (avgScore / bin);
                    } else {
                        intScore = (int) (depMutScore.getQuick(unit + unit * i - 1) / bin);
                    }
                    intScore++;
                    num += (depMutScore.getQuick(unit * i + uindex) * intScore);
                }
            }
        }
        return num;
    }

    public int getIndepVarMutNum(double bin) {
        if (indepMutScores == null || indepMutScores.isEmpty()) {
            return 0;
        }
        int size = indepMutScores.size() / 2;
        int num = 0;
        if (bin <= 0) {
            for (int i = 0; i < size; i++) {
                num += indepMutScores.getQuick(i + i);
            }
        } else {
            int missingNum = 0;
            double avgScore = 0;
            int intScore = 0;
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(indepMutScores.getQuick(i + i + 1))) {
                    missingNum++;
                } else {
                    avgScore += indepMutScores.getQuick(i + i + 1);
                }
            }
            //all missing
            if (size - missingNum == 0) {
                for (int i = 0; i < size; i++) {
                    num += indepMutScores.getQuick(i + i);
                }
            } else {
                avgScore = avgScore / (size - missingNum);
                for (int i = 0; i < size; i++) {
                    if (Double.isNaN(indepMutScores.getQuick(i + i + 1))) {
                        intScore = (int) (avgScore / bin);
                    } else {
                        intScore = (int) (indepMutScores.getQuick(i + i + 1) / bin);
                    }
                    intScore++;
                    num += (indepMutScores.getQuick(i + i) * intScore);
                }
            }
        }
        return num;
    }

    public double getIndepVarMutNum(double bin, int uindex, int unit) {
        if (indepMutScores == null || indepMutScores.isEmpty()) {
            //this is for digene analysis 
            if (bin <= 0) {
                return (controlMutScore);
            }
            if (!Double.isNaN(controlMutScore)) {
                double intScore = (controlMutScore / (bin));
                return intScore;
            }
            return 0;
        }
        int size = indepMutScores.size() / unit;
        double num = 0;
        if (bin <= 0) {
            for (int i = 0; i < size; i++) {
                num += indepMutScores.getQuick(i * unit + uindex);
            }
        } else {
            int missingNum = 0;
            double avgScore = 0;
            double intScore = 0;
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(indepMutScores.getQuick(unit + i * unit - 1))) {
                    missingNum++;
                } else {
                    avgScore += indepMutScores.getQuick(unit + i * unit - 1);
                }
            }
            //all missing
            if (size - missingNum == 0) {
                for (int i = 0; i < size; i++) {
                    num += indepMutScores.getQuick(i * unit + uindex);
                }
            } else {
                avgScore = avgScore / (size - missingNum);
                for (int i = 0; i < size; i++) {
                    if (Double.isNaN(indepMutScores.getQuick(unit + i * unit - 1))) {
                        intScore = (avgScore / bin);
                    } else {
                        intScore = (indepMutScores.getQuick(unit + i * unit - 1) / bin);
                    }
                    intScore++;
                    num += (indepMutScores.getQuick(i * unit + uindex) * intScore);
                }
            }
        }
        return num;
    }

    public void setDepMutScore(DoubleArrayList depMutScore) {
        this.depMutScore = depMutScore;
    }

    public void addDepMutScores(DoubleArrayList depMutScore) {
        if (this.depMutScore == null) {
            this.depMutScore = new DoubleArrayList();
        }
        this.depMutScore.addAllOf(depMutScore);
    }

    public DoubleArrayList getIndepMutScores() {
        DoubleArrayList scores = new DoubleArrayList();
        int size = indepMutScores.size() / 2;
        double score;
        for (int i = 0; i < size; i++) {
            score = indepMutScores.getQuick(i + i + 1);
            if (!Double.isNaN(score)) {
                scores.add(score);
            }
        }
        return scores;
    }

    public DoubleArrayList getIndepMutScores(int unit) {
        DoubleArrayList scores = new DoubleArrayList();
        int size = indepMutScores.size() / unit;
        double score;
        for (int i = 0; i < size; i++) {
            score = indepMutScores.getQuick(i * unit + unit - 1);
            if (!Double.isNaN(score)) {
                scores.add(score);
            }
        }
        return scores;
    }

    public void setIndepMutScores(DoubleArrayList indepMutScores) {
        this.indepMutScores = indepMutScores;
    }

    public void addFeatureValueAt(int pos, String val) {
        if (pos >= featureValues.size()) {
            for (int i = featureValues.size(); i <= pos; i++) {
                featureValues.add(null);
            }
        }
        featureValues.set(pos, val);
    }

    public void addTestValue(double val) {
        testValues.add(val);
    }

    public void addTestValueAt(int pos, double val) {
        if (pos >= testValues.size()) {
            for (int i = testValues.size(); i <= pos; i++) {
                testValues.add(null);
            }
        }
        testValues.set(pos, val);
    }

    public String getSymbol() {
        return geneSymb;
    }

    public void setGeneSymb(String stringID) {
        this.geneSymb = stringID;
    }
}
