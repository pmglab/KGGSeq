/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.cobi.kggseq.Constants;
import org.cobi.kggseq.GlobalManager;
import org.cobi.util.file.LocalFileFunc;

/**
 *
 * @author mxli
 */
public class ReferenceGenome implements Constants {

    private static final Logger LOG = Logger.getLogger(ReferenceGenome.class);
    Map<String, Byte> fullchromNameIndexMap = new HashMap<String, Byte>();
    Map<String, Byte> chromNameIndexMap = new HashMap<String, Byte>();
    private List[] chromosomes = null;
    private IntervalTree<RNABoundary>[] chromosomemRNABoundaryIndexTrees = null;

    private Map<String, int[]> geneChromPosMap = new HashMap<String, int[]>();
    boolean hasNotSorted = true;
    int upstreamDis = 1000;
    int donwstreamDis = 1000;
    int splicingDis = 2;
    private String name;

    public ReferenceGenome() {
        chromosomes = new ArrayList[STAND_CHROM_NAMES.length];
        chromosomemRNABoundaryIndexTrees = new IntervalTree[STAND_CHROM_NAMES.length];

        for (byte i = 0; i < STAND_CHROM_NAMES.length; i++) {
            fullchromNameIndexMap.put("chr" + STAND_CHROM_NAMES[i], i);
            chromNameIndexMap.put(STAND_CHROM_NAMES[i], i);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ReferenceGenome(int spd, int usd, int dsd) {
        splicingDis = spd;
        upstreamDis = usd;
        donwstreamDis = dsd;
        chromosomes = new ArrayList[STAND_CHROM_NAMES.length];
        chromosomemRNABoundaryIndexTrees = new IntervalTree[STAND_CHROM_NAMES.length];

        for (byte i = 0; i < STAND_CHROM_NAMES.length; i++) {
            fullchromNameIndexMap.put("chr" + STAND_CHROM_NAMES[i], i);
            chromNameIndexMap.put(STAND_CHROM_NAMES[i], i);
        }
    }

    //a function to read the dataset refGeneMrna.fa.gz prepared by UCSC
    public void readRefGeneSequence(String sequenceFile) throws Exception {
        //Note: a transcipt ID can be mapped onto multiple regions
        Map<String, String> transciptSequence = new HashMap<String, String>();
        File dataFile = new File(sequenceFile);
        BufferedReader br = LocalFileFunc.getBufferedReader(sequenceFile);
        String currentLine;
        int lineCounter = 0;
        String lastTranscripID = null;
        String chromIDPostion;
        int index = 0;
        int index1 = 0;
        int strLen = 0;
        StringBuilder sb = new StringBuilder();

        while ((currentLine = br.readLine()) != null) {
            lineCounter++;

            if (currentLine.startsWith(">")) {

                //System.out.println(lastTranscripID);
                // >NM_001101330 1
//atggtttccgctagtgggacatcattttttaagggtatgttgcttgggag
//catttcctgggttttgataactatgtttggccaaattcacattcgacaca
//gaggtcagactcaagaccacgagcaccatcaccttcgtccacctaacagg
                if (lastTranscripID != null) {
                    String mrnaSeq = transciptSequence.get(lastTranscripID);
                    if (mrnaSeq == null) {
                        transciptSequence.put(lastTranscripID, sb.toString().toUpperCase());
                    } else {
                        System.out.println(lastTranscripID + " has more than 1 sequence");
                    }
                    sb.delete(0, sb.length());
                }
                index = currentLine.indexOf(' ');
                lastTranscripID = currentLine.substring(1, index);

            } else {
                sb.append(currentLine);
            }
        }
        //the last transcript
        if (sb.length() > 0) {
            String mrnaSeq = transciptSequence.get(lastTranscripID);
            sb.delete(0, sb.length());
            if (mrnaSeq == null) {
                transciptSequence.put(lastTranscripID, sb.toString().toUpperCase());
            } else {
                System.out.println(lastTranscripID + " has more than 1 sequence");
            }
        }
        br.close();
        String info = "Read sequence of " + transciptSequence.size() + " transcripts.";
        System.out.println(info);
        int noSequenceRNA = 0;
        StringBuilder noSequenceRNAIDs = new StringBuilder();

        //assign the sequence to genes
        for (int iChrom = 0; iChrom < chromosomes.length; iChrom++) {
            List<Transcript> chrom = chromosomes[iChrom];
            if (chrom == null) {
                continue;
            }
            for (int imRNA = 0; imRNA < chrom.size(); imRNA++) {
                Transcript mrna = chrom.get(imRNA);
                if (mrna.codingStart == mrna.codingEnd) {
                    String mixID = mrna.getRefID() + ":@hr" + STAND_CHROM_NAMES[iChrom] + ":" + mrna.getStart();
                    noSequenceRNA++;
                    noSequenceRNAIDs.append(mixID);
                    noSequenceRNAIDs.append(" ");
                    continue;
                }

                //keep all mRNA whether it has sequence or not
                String msqSeq = transciptSequence.get(mrna.getRefID());
                if (msqSeq == null) {
                    String mixID = mrna.getRefID() + "@chr" + STAND_CHROM_NAMES[iChrom] + ":" + mrna.getStart();
                    noSequenceRNA++;
                    noSequenceRNAIDs.append(mixID);
                    noSequenceRNAIDs.append(" ");
                    continue;
                }
                mrna.setmRnaSequenceStart(mrna.getStart());
                mrna.setmRnaSequence(msqSeq);
            }
        }
        transciptSequence.clear();
        if (noSequenceRNA > 0) {
            info = noSequenceRNA + " transcripts have no sequence data.";
            System.out.println(info);
            //System.out.println(noSequenceRNAIDs);
        }
    }

    public Transcript getmRNA(int[] poss) {
        return (Transcript) chromosomes[poss[0]].get(poss[1]);
    }

    public RefCNV getCNV(int[] poss) {
        return (RefCNV) chromosomes[poss[0]].get(poss[1]);
    }

    public RefDup getDup(int[] poss) {
        return (RefDup) chromosomes[poss[0]].get(poss[1]);
    }

    public Transcript getmRNA(String syb) {
        int[] poss = geneChromPosMap.get(syb);
        if (poss == null) {
            return null;
        }
        return (Transcript) chromosomes[poss[0]].get(poss[1]);
    }

    public int[] getmRNAPos(String syb) {
        return geneChromPosMap.get(syb);
    }

    public void exportGeneRegions(String outPath) throws Exception {
        int upstreamExtendLen = 5000;
        int downstreamExtendLen = 5000;
        BufferedWriter bw = new BufferedWriter(new FileWriter(outPath));
        bw.write("--regions  ");
        for (int iChrom = 0; iChrom < STAND_CHROM_NAMES.length; iChrom++) {
            List<Transcript> chrom = chromosomes[iChrom];
            if (chrom == null) {
                continue;
            }
            for (int iGene = 0; iGene < chrom.size(); iGene++) {
                Transcript mrna = chrom.get(iGene);

                if (mrna.codingStart == mrna.codingEnd) {
                    //   continue;
                }
                int start = (mrna.getStart() - upstreamExtendLen);
                if (start < 0) {
                    start = 0;
                }
                String mixID = "chr" + STAND_CHROM_NAMES[iChrom] + ":"
                        + start + "-" + (mrna.getEnd() + downstreamExtendLen) + ",";
                bw.write(mixID);
                // System.out.println(mrna.getRefID() + "\t" + mrna.getStart() + "\t" + mrna.getEnd());

            }
        }
        bw.close();

    }

    //as Transcript can be mappled onto multiple chrosomes so it would be very difficult to use a mrna to orgnaize the Transcript
    public void addRefRNA(Transcript mrna, String chrom) {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            return;
        }
        if (chromosomes[chromID] == null) {
            chromosomes[chromID] = new ArrayList<Transcript>();
            chromosomes[chromID].add(mrna);
        } else {
            chromosomes[chromID].add(mrna);
        }

        geneChromPosMap.put(mrna.getRefID() + ":" + chrom + ":" + mrna.codingStart + ":" + mrna.codingEnd, new int[]{chromID, chromosomes[chromID].size() - 1});
        hasNotSorted = true;
    }

    //as Transcript can be mappled onto multiple chrosomes so it would be very difficult to use a mrna to orgnaize the Transcript
    public void addRefCNV(RefCNV cnv, String chrom) {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            return;
        }
        if (chromosomes[chromID] == null) {
            chromosomes[chromID] = new ArrayList<RefCNV>();
            chromosomes[chromID].add(cnv);
        } else {
            chromosomes[chromID].add(cnv);
        }

        geneChromPosMap.put(cnv.getDescription() + ":" + chrom + ":" + cnv.getStart() + ":" + cnv.getEnd(), new int[]{chromID, chromosomes[chromID].size() - 1});
        hasNotSorted = true;
    }

    //as Transcript can be mappled onto multiple chrosomes so it would be very difficult to use a mrna to orgnaize the Transcript
    public void addRefDup(RefDup cnv, String chrom) {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            return;
        }
        if (chromosomes[chromID] == null) {
            chromosomes[chromID] = new ArrayList<RefCNV>();
            chromosomes[chromID].add(cnv);
        } else {
            chromosomes[chromID].add(cnv);
        }

        geneChromPosMap.put(cnv.getDescription() + ":" + chrom + ":" + cnv.getStart() + ":" + cnv.getEnd(), new int[]{chromID, chromosomes[chromID].size() - 1});
        hasNotSorted = true;
    }

    /*
     * A reference from Annovar
     Feature	Value 	Explanation
     nonsynonymous	1	Variants result in a codon coding for a different amino acid (missense) and an amino acid codon to a stop codon (stopgain) and a stop codon to an amino acid codon (stoplos)
     synonymous	2	
     splicing	3	variant is within 2-bp of a splicing junction (use -splicing_threshold to change this) 
     ncRNA	4	variant overlaps a transcript without coding annotation in the region definition (see Notes below for more explanation) 
     5UTR	5	variant overlaps a 5' untranslated region 
     3UTR	6	variant overlaps a 3' untranslated region 
     intronic	7	variant overlaps an intron 
     upstream	8	variant overlaps 1-kb region upstream of transcription start site 
     downstream	9	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this) 
     intergenic	10	variant is in intergenic region     
     */
    public GeneFeature getVarFeature(String chrom, Variant var, boolean isForwardStrandInput, Set<Byte> priorFeatureSet) throws Exception {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            throw new Exception("Unknown chrosomsome ID " + chrom);
        }

        if (hasNotSorted) {
            throw new Exception("The genome has to been sorted before search the gene-feature of a variant.");
        }

        List<GeneFeature> featureList = new ArrayList<GeneFeature>();
        // System.out.println(chrom + " : " + var.physicalPosition);
        byte intergID = GlobalManager.VarFeatureIDMap.get("intergenic");

        if (chromosomemRNABoundaryIndexTrees[chromID] == null) {
            // String info = "Variant at chr" + chrom + ":" + var.refStartPosition + " cannot be annotated by the specified gene annotation database " + name + "!";
            //System.out.println(info);
            //  LOG.warn(info);
            if (var.smallestFeatureID > GlobalManager.VarFeatureIDMap.get("unknown")) {
                var.smallestFeatureID = GlobalManager.VarFeatureIDMap.get("unknown");
            }
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("unknown"), null);
        }

        /*
         if (chrom.equals("6")){
         var.refStartPosition=	31322303;
         var.setRefAllele('C');
         var.setAltAlleles(new String[]{"G"});
         }
         * 
         */
        //note for forward and reverse strand, the upstream and downsteam could be different
        int pos = var.refStartPosition;

       
        int extLen = 0, len;
        String[] altAlleles = var.getAltAlleles();
        int refAlleleLen = var.getRefAllele().length();
//        for (int i = 0; i < altAlleles.length; i++) {
//            len = Math.abs(refAlleleLen - altAlleles[i].length());
//            if (extLen < len) {
//                extLen = len;
//            }
//        }
        extLen = refAlleleLen - 1;
        try {
            List<Interval<RNABoundary>> locatedRNAIDs = chromosomemRNABoundaryIndexTrees[chromID].getOverlapsIntervals(pos, pos + extLen);
            for (Interval<RNABoundary> t : locatedRNAIDs) {

                Transcript mRNA = (Transcript) chromosomes[chromID].get(t.data.mRNAIndex);
                if (mRNA.getRefID().startsWith("ENST00000494100")) {
                    int sss = 0;
                }
                //GeneFeature gf1 = mRNA.findFeature(chrom, var, isForwardStrandInput, upstreamDis, donwstreamDis, splicingDis);
                GeneFeature gf = mRNA.findFeatureSV(chrom, var, isForwardStrandInput, splicingDis);

                if (gf != null) {
                    //gf.setName(mRNA.geneSymb + ":" + gf.getName());
                    featureList.add(gf);
                }
                //public static String[] VAR_FEATURE_NAMES = new String[]{"frameshift", "nonframeshift", "startloss", "stoploss", "stopgain", "splicing", "missense", "synonymous", "exonic", "5UTR", "3UTR", "intronic", "upstream", "downstream", "ncRNA", "intergenic", "monomorphic", "unknown"};

//                String testLabel="startloss";
//                //!gf.name.equals(gf1.name)&&
//                if( mRNA.noCodingExon&&(gf.name.contains(testLabel)||gf1.name.contains(testLabel))){
//                    if(mRNA.geneSymb.equals("DST"))
//                     System.out.println("chr" + (chromID + 1) + ":" + var.refStartPosition + (new String(var.getRefAllele())) + "-" 
//                             + (new String(var.getAltAllele(0))) + "\n" + gf.name + "\n" + gf1.name);
//
//                }
                //System.out.println("find [1, 1]: " + t);
            }

            if (featureList.isEmpty()) {
                if (var.smallestFeatureID > intergID) {
                    var.smallestFeatureID = intergID;
                }
                return new GeneFeature(intergID, null);
            } else {
                int gfSize = featureList.size();
                if (gfSize == 1) {
                    if (var.smallestFeatureID > featureList.get(0).id) {
                        var.smallestFeatureID = featureList.get(0).id;
                        if (featureList.get(0).id < intergID) {
                            String ftName = featureList.get(0).name;
                            int index = ftName.indexOf(':');
                            if (index >= 0) {
                                var.geneSymb = ftName.substring(0, index);
                            }
                        }
                    }
                    return featureList.get(0);
                } else {
                    Collections.sort(featureList, new GeneFeatureComparator());
                    //by default use the first description 
                    boolean hasAssignSeledtedID = false;
                    GeneFeature selectGf = featureList.get(0);
                    if (priorFeatureSet.contains(selectGf.id)) {
                        hasAssignSeledtedID = true;
                    }

                    if (var.smallestFeatureID > selectGf.id) {
                        var.smallestFeatureID = selectGf.id;
                        if (featureList.get(0).id < intergID) {
                            String ftName = featureList.get(0).name;
                            int index = ftName.indexOf(':');
                            if (index >= 0) {
                                var.geneSymb = ftName.substring(0, index);
                            }
                        }
                    }

                    for (int i = 1; i < gfSize; i++) {
                        GeneFeature gf = featureList.get(i);
                        if (!hasAssignSeledtedID && priorFeatureSet.contains(gf.id)) {
                            selectGf.id = gf.id;
                        }
                        if (!gf.getName().contains("intergenic")) {
                            selectGf.setName(gf.getName() + ";" + selectGf.getName());
                        }
                    }
                    return selectGf;
                }
            }
        } catch (Exception e) {
            // e.printStackTrace();
            LOG.error(e.getMessage() + " at variant in getVarFeature " + var.refStartPosition + " of chromosome " + chrom);
        }
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("unknown"), null);
    }

    //to be donw
    public List<RefCNV> getCNVFeature(String chrom, Variant var, RNABoundaryIndex searchedmRNABoundaryIndex) throws Exception {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            throw new Exception("Unknown chrosomsome ID " + chrom);
        }

        if (hasNotSorted) {
            throw new Exception("The genome has to been sorted before search the gene-feature of a variant.");
        }
        List<RefCNV> cnvList = new ArrayList<RefCNV>();
        // System.out.println(chrom + " : " + var.physicalPosition);

        if (chromosomemRNABoundaryIndexTrees[chromID] == null) {
            //String info = "A variant at " + var.refStartPosition + " of chromosome " + chrom + " cannot be annotated!";
            //System.out.println(info);
            //LOG.warn(info);           
            return cnvList;
        }

        //note for forward and reverse strand, the upstream and downsteam could be different
        int pos = var.refStartPosition;
        List<Interval<RNABoundary>> locatedRNAIDs = chromosomemRNABoundaryIndexTrees[chromID].getOverlapsIntervals(pos, pos);
        for (Interval<RNABoundary> t : locatedRNAIDs) {

            RefCNV cnv = (RefCNV) chromosomes[chromID].get(t.data.mRNAIndex);
            //gf.setName(mRNA.geneSymb + ":" + gf.getName());
            cnvList.add(cnv);
        }

        //System.out.println("find [1, 1]: " + t);
        return cnvList;
    }

    //to be done
    public List<RefDup> getDupFeature(String chrom, Variant var, RNABoundaryIndex searchedmRNABoundaryIndex) throws Exception {
        Byte chromID = chromNameIndexMap.get(chrom);
        if (chromID == null) {
            throw new Exception("Unknown chrosomsome ID " + chrom);
        }

        if (hasNotSorted) {
            throw new Exception("The genome has to been sorted before search the gene-feature of a variant.");
        }
        List<RefDup> cnvList = new ArrayList<RefDup>();
        // System.out.println(chrom + " : " + var.physicalPosition);

        if (chromosomemRNABoundaryIndexTrees[chromID] == null) {
            //String info = "A variant at " + var.refStartPosition + " of chromosome " + chrom + " cannot be annotated!";
            //System.out.println(info);
            //LOG.warn(info);           
            return cnvList;
        }

        //note for forward and reverse strand, the upstream and downsteam could be different
        int pos = var.refStartPosition;
        searchedmRNABoundaryIndex.position = pos;

        List<Interval<RNABoundary>> locatedRNAIDs = chromosomemRNABoundaryIndexTrees[chromID].getOverlapsIntervals(pos, pos);
        for (Interval<RNABoundary> t : locatedRNAIDs) {

            RefDup cnv = (RefDup) chromosomes[chromID].get(t.data.mRNAIndex);

            //gf.setName(mRNA.geneSymb + ":" + gf.getName());
            cnvList.add(cnv);
        }
        //System.out.println("find [1, 1]: " + t);

        return cnvList;
    }

    private int binarySearchStartPos(int pos, int left, int right, List mRNABounds) {
        if (left > right) {
            return -left - 1;
        }
        int middle = (left + right) / 2;
// the search is based on start posistion

        if (((RNASegment) mRNABounds.get(middle)).start == pos) {
            return middle;
        } else if (((RNASegment) mRNABounds.get(middle)).start > pos) {
            return binarySearchStartPos(pos, left, middle - 1, mRNABounds);
        } else {
            return binarySearchStartPos(pos, middle + 1, right, mRNABounds);
        }
    }

    class RNASegment {

        protected int start;
        protected int end;
        protected int mRNAIndex;
        protected char strand;

        public RNASegment(int start, int end, int mRNAIndex, char strand) {
            this.start = start;
            this.end = end;

            this.mRNAIndex = mRNAIndex;
            this.strand = strand;
        }

        public int getEnd() {
            return end;
        }

        public int getmRNAIndex() {
            return mRNAIndex;
        }

        public int getStart() {
            return start;
        }
    }

    class GeneRNASegmentComparator implements Comparator<RNASegment> {

        @Override
        public int compare(RNASegment arg0, RNASegment arg1) {
            int result = -1;
            if (arg0.start == arg1.start) {
                result = arg0.end - arg1.end;
            } else {
                result = arg0.start - arg1.start;
            }
            return result;
        }
    }

    public void sortmRNAMakeIndexonChromosomes() {
        geneChromPosMap.clear();

        int size = 0;

        RNABoundary rb1 = null, rb2;
        for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
            if (chromosomes[i] != null) {
                Collections.sort(chromosomes[i], new SeqSegmentComparator());
                size = chromosomes[i].size();

                if (chromosomemRNABoundaryIndexTrees[i] == null) {
                    chromosomemRNABoundaryIndexTrees[i] = new IntervalTree<>();
                } else {
                    chromosomemRNABoundaryIndexTrees[i].clear();
                }

                for (int j = 0; j < size; j++) {
                    Transcript mrna = (Transcript) chromosomes[i].get(j);
                    if (mrna.getRefID().equals("NR_146651")) {
                        int sss = 0;
                    }
                    geneChromPosMap.put(mrna.getRefID() + ":" + STAND_CHROM_NAMES[i] + ":" + mrna.codingStart + ":" + mrna.codingEnd, new int[]{i, j});
                    if (mrna.getStrand() == '-') {
                        rb1 = new RNABoundary(j, mrna.start - donwstreamDis, mrna.end + upstreamDis);
                        chromosomemRNABoundaryIndexTrees[i].addInterval(mrna.start - donwstreamDis, mrna.end + upstreamDis, rb1);

                    } else {
                        //default is +
                        rb1 = new RNABoundary(j, mrna.start - upstreamDis, mrna.end + donwstreamDis);

                        chromosomemRNABoundaryIndexTrees[i].addInterval(mrna.start - upstreamDis, mrna.end + donwstreamDis, rb1);

                    }
                    //  System.out.println(rb1.toString());
                }

                chromosomemRNABoundaryIndexTrees[i].flush();

            }

        }

        hasNotSorted = false;
    }

    public void sortCNVMakeIndexonChromosomes() {
        geneChromPosMap.clear();

        int size = 0;
        RNABoundary rb1;
        for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
            if (chromosomes[i] != null) {
                Collections.sort(chromosomes[i], new SeqSegmentComparator());
                size = chromosomes[i].size();
                if (chromosomemRNABoundaryIndexTrees[i] == null) {
                    chromosomemRNABoundaryIndexTrees[i] = new IntervalTree();
                } else {
                    chromosomemRNABoundaryIndexTrees[i].clear();
                }
                for (int j = 0; j < size; j++) {
                    RefCNV cnv = (RefCNV) chromosomes[i].get(j);
                    geneChromPosMap.put(cnv.getDescription() + ":" + STAND_CHROM_NAMES[i] + ":" + cnv.getStart() + ":" + cnv.getEnd(), new int[]{i, j});
                    //default is +
                    rb1 = new RNABoundary(j, cnv.getStart() - upstreamDis, cnv.getEnd() + donwstreamDis);

                    chromosomemRNABoundaryIndexTrees[i].addInterval(cnv.getStart() - upstreamDis, cnv.getEnd() + donwstreamDis, rb1);
                    // chromosomemRNABoundaryIndexTrees[i].insert(new RNABoundary(j, cnv.start - upstreamDis, cnv.end + donwstreamDis));
                }
                chromosomemRNABoundaryIndexTrees[i].flush();
            }

        }
        hasNotSorted = false;
    }

    public void sortDupMakeIndexonChromosomes() {
        geneChromPosMap.clear();

        int size = 0;
        RNABoundary rb1;
        for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {

            if (chromosomes[i] != null) {
                Collections.sort(chromosomes[i], new SeqSegmentComparator());
                size = chromosomes[i].size();

                if (chromosomemRNABoundaryIndexTrees[i] == null) {
                    chromosomemRNABoundaryIndexTrees[i] = new IntervalTree();
                } else {
                    chromosomemRNABoundaryIndexTrees[i].clear();
                }
                for (int j = 0; j < size; j++) {
                    RefDup cnv = (RefDup) chromosomes[i].get(j);
                    geneChromPosMap.put(cnv.getDescription() + ":" + STAND_CHROM_NAMES[i] + ":" + cnv.getStart() + ":" + cnv.getEnd(), new int[]{i, j});
                    //default is +
                    rb1 = new RNABoundary(j, cnv.getStart() - upstreamDis, cnv.getEnd() + donwstreamDis);

                    chromosomemRNABoundaryIndexTrees[i].addInterval(cnv.getStart() - upstreamDis, cnv.getEnd() + donwstreamDis, rb1);
                    //chromosomemRNABoundaryIndexTrees[i].(new RNABoundary(j, cnv.start - upstreamDis, cnv.end + donwstreamDis));
                }
                chromosomemRNABoundaryIndexTrees[i].flush();
            }

        }
        hasNotSorted = false;
    }
}
