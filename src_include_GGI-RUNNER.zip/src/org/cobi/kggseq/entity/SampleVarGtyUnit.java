/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

import cern.colt.list.FloatArrayList;
import cern.colt.map.OpenIntIntHashMap;
import java.util.Set;

/**
 *
 * @author mxli
 */
public class SampleVarGtyUnit {

    public FloatArrayList varScores;
    public OpenIntIntHashMap[] subjectMutCount;
    public double[] subjectMutBestScore;
    public Set<String> chrPosStr;

}
