/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
public enum VarGeneFeatureType {

    FRAME_SHIFT((byte) 0, "frameshift"),
    NON_FRAME_SHIFT((byte) 1, "nonframeshift"),
    START_LOSS((byte) 2, "startloss"),
    STOP_LOSS((byte) 3, "stoploss"),
    STOP_GAINED((byte) 4, "stopgain"),
    SPLICING((byte) 5, "splicing"),
    MISSENSE((byte) 6, "missense"),
    SYNONYMOUS((byte) 7, "synonymous"),
    EXONIC((byte) 8, "exonic"),
    FIVE_PRIME_UTR((byte) 9, "5UTR"),
    THREE_PRIME_UTR((byte) 10, "3UTR"),
    INTRONIC((byte) 11, "intronic"),
    UPSTREAM((byte) 12, "upstream"),
    DOWNSTREAM((byte) 13, "downstream"),
    NC_RNA((byte) 14, "ncRNA"),
    INTERGENIC((byte) 15, "intergenic"),
    MONOMORPHIC((byte) 16, "monomorphic"),
    UNKNOWN((byte) 17, "unknown");

    byte index;
    private String msg;

    private VarGeneFeatureType(byte code, String msg) {
        this.index = code;
        this.msg = msg;

    }

    public String getName() {
        return msg;
    }
}
