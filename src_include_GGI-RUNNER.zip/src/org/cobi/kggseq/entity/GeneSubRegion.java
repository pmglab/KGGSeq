/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
class GeneSubRegion {

        //0: upstream; 1: exon; 2; intron; 3: downstream
        int type;
        int index;
        int start;
        int end;
        int relativeCodingStartPos;
        int relativeExonStartPos;

        public GeneSubRegion(int type, int index, int start, int end) {
            this.type = type;
            this.index = index;
            this.start = start;
            this.end = end;
        }

        public void setRelativeCodingStartPos(int relativeCodingStartPos) {
            this.relativeCodingStartPos = relativeCodingStartPos;
        }

        public void setRelativeExonStartPos(int relativeExonStartPos) {
            this.relativeExonStartPos = relativeExonStartPos;
        }

      
        public int start() {
            return this.start;
        }

       
        public int end() {
            return this.end;
        }

        @Override
        public String toString() {
            return "[" + this.type + ":" + this.index + ":" + this.start + ", " + this.end + "]";
        }
    }