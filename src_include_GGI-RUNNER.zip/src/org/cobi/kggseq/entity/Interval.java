/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.cobi.kggseq.entity;

 
/**
 * 区间树包装类 (范围为左闭右闭)
 */
public class Interval<T> implements Comparable<Interval<T>> {
    /**
     * 区间起点
     */
    final long start;

    /**
     * 区间终点
     */
    final long end;

    /**
     * 区间值对象
     */
    final T data;

    /**
     * 构造器方法, 将 data 包装为带有起点、终点的区间对象
     *
     * @param start 区间起点
     * @param end   区间终点
     * @param data  数据对象
     */
    public Interval(long start, long end, T data) {
        this.start = start;
        this.end = end;

        if (this.start > this.end) {
            throw new RuntimeException("start > end is not allowed");
        }

        this.data = data;
    }

    /**
     * @return 区间起点
     */
    public long getStart() {
        return start;
    }

    /**
     * @return 区间终点
     */
    public long getEnd() {
        return end;
    }

    /**
     * @return 数据对象
     */
    public T getData() {
        return data;
    }

    /**
     * @param pos 位置值
     * @return 当 pos 包含在此区间内时, 返回 true
     */
    public boolean contains(long pos) {
        return pos >= this.start && pos <= this.end;
    }

    /**
     * @param start 另一个区间的起点
     * @param end   另一个区间的终点
     * @return 当 [start, end] 是此区间的子集时, 返回 true (它比 overlaps 更严格)
     */
    public boolean contains(long start, long end) {
        return start <= end && start >= this.start && end <= this.end;
    }

    /**
     * @param other 另一个区间
     * @return 当另一个区间是此区间的子集时, 返回 true (它比 overlaps 更严格)
     */
    public boolean contains(Interval<T> other) {
        return other.start >= this.start && other.end <= this.end;
    }

    /**
     * @param other 另一个区间
     * @return 当两个区间存在交集时, 返回 true
     */
    public boolean overlapsWith(Interval<T> other) {
        return Math.max(this.start, other.start) <= Math.min(this.end, other.end);
    }

    /**
     * @param start 另一个区间的起点
     * @param end   另一个区间的终点
     * @return 当两个区间存在交集时, 返回 true
     */
    public boolean overlapsWith(long start, long end) {
        return start <= end && Math.max(this.start, start) <= Math.min(this.end, end);
    }

    @Override
    public String toString() {
        return "[" + this.start + ", " + this.end + "]: " + this.data;
    }

    @Override
    public int compareTo(Interval<T> other) {
        if (this.start < other.getStart()) {
            return -1;
        } else if (this.start > other.getStart()) {
            return 1;
        } else if (this.end < other.getEnd()) {
            return -1;
        } else if (this.end > other.getEnd()) {
            return 1;
        } else {
            return 0;
        }
    }
}
