package org.cobi.kggseq.Tuple;

public class SevenTuple<A, B, C, D, E, F, G> extends SixTuple<A, B, C, D, E, F> {
    private final G seventh;

    public SevenTuple(A a, B b, C c, D d, E e, F f, G g) {
        super(a, b, c, d, e, f);
        this.seventh = g;
    }

    public G getSeventh() {
        return this.seventh;
    }
}
