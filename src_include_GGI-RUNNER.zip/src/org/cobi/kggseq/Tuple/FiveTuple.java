package org.cobi.kggseq.Tuple;

public class FiveTuple<A, B, C, D, E> extends FourTuple<A, B, C, D> {
    private final E fifth;

    public FiveTuple(A a, B b, C c, D d, E e) {
        super(a, b, c, d);
        this.fifth = e;
    }

    public E getFifth() {
        return this.fifth;
    }
}
