package org.cobi.kggseq.Tuple;

public class SixTuple<A, B, C, D, E, F> extends FiveTuple<A, B, C, D, E> {
    private final F sixth;

    public SixTuple(A a, B b, C c, D d, E e, F f) {
        super(a, b, c, d, e);
        this.sixth = f;
    }

    public F getSixth() {
        return this.sixth;
    }
}
