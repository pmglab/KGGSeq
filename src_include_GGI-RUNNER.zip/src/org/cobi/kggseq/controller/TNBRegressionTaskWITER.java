/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.DoubleArrayList;
import cern.jet.stat.Probability;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import org.apache.log4j.Logger;
import org.cobi.kggseq.GlobalManager;
import org.cobi.kggseq.entity.Gene;
import org.cobi.kggseq.entity.ZTNBParamSet;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.stat.SpecifcCalculatorLinear;
import org.cobi.util.stat.StdStats;
import org.cobi.util.thread.Task;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

/**
 *
 * @author limx54
 */
public class TNBRegressionTaskWITER extends Task implements Callable<String> {

    private static final Logger LOG = Logger.getLogger(TNBRegressionTaskWITER.class);

    List<Gene> orderedAllGenes;
    List<double[]> countsRegList;
    List<String> scoreHeads;

    boolean noExplanatoryVar;

    double scoreBinCut;
    int truncPoint;

    boolean usingLog;

    List<ZTNBParamSet> paramSetList;

    RConnection rcon;
    int threadID;
    double looseFDR;
    String rHost;
    int rPort;
    boolean runStepwise;

    public TNBRegressionTaskWITER(String rHost, int rPort, List<Gene> geneOrder, List<double[]> countsRegList,
            List<String> scoreHeads, boolean noExplanatoryVar, double scoreBinCut, int tn, boolean usingLog,
            int threadID, double looseFDR, boolean runStepwise) {
        this.orderedAllGenes = geneOrder;
        this.countsRegList = countsRegList;

        this.scoreHeads = scoreHeads;

        this.noExplanatoryVar = noExplanatoryVar;

        this.scoreBinCut = scoreBinCut;
        this.truncPoint = tn;

        this.usingLog = usingLog;

        this.threadID = threadID;
        this.looseFDR = looseFDR;
        paramSetList = new ArrayList<ZTNBParamSet>();
        this.rHost = rHost;
        this.rPort = rPort;
        this.runStepwise = runStepwise;
    }

    public List<ZTNBParamSet> getParamSetList() {
        return paramSetList;
    }

    @Override
    public String call() throws Exception {
        //countsRegList will be updated in the thread
        int minSampleSize = 500;
        int geneSize = countsRegList.size();
        List<double[]> countsRegListCopied = new ArrayList<>(geneSize);
        double[] eles;
        for (int i = 0; i < geneSize; i++) {
            eles = countsRegList.get(i);
            countsRegListCopied.add(Arrays.copyOf(eles, eles.length));
        }

        int colNum, sigGeneNum = 0;
        double[] countsMatrix, countsMatrixOrg = null, weights, residuual, residueCounter, v;
        double mean, sd, mflc = 1, adjGenePValueCutoff = 0.05;
        DoubleArrayList pValues = new DoubleArrayList();
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();

        geneSize = countsRegListCopied.size();
        for (int j = 0; j < geneSize; j++) {
            v = countsRegListCopied.get(j);
            v[0] = orderedAllGenes.get(j).getDepVarMutNum(scoreBinCut);
        }

        List<String> geneOrderTrunc = new ArrayList<String>();
        List<double[]> scoreListTrunc = new ArrayList<>();

        geneSize = countsRegListCopied.size();
        geneOrderTrunc.clear();
        scoreListTrunc.clear();
        for (int j = 0; j < geneSize; j++) {
            v = countsRegListCopied.get(j);
            if (v[0] > truncPoint) {
                scoreListTrunc.add(v);
                geneOrderTrunc.add(orderedAllGenes.get(j).geneSymb);
            }
        }
        if (geneOrderTrunc.size() < minSampleSize) {
            String info = "The non-zero mutation counts of genes is  " + geneOrderTrunc.size() + " at truncation point " + truncPoint + ". The analysis of RUNNER is stopped.";
            LOG.info(info);
            return "interrupted";
        }

        Set<String> sigGeneSet0 = new HashSet<>();
        Set<String> sigGeneSet1 = new HashSet<>();

        List<double[]> geneScoreListInsig = new ArrayList<>();
        geneScoreListInsig.addAll(scoreListTrunc);
        try {
            rcon = new RConnection(rHost, rPort);
            rcon.eval("library(MASS)");
            //rcon.eval("library(countreg)");
             rcon.eval(NegTruncR.codes);
            //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");
            // rcon.eval("library(missForest)");


            /*
      rcon.eval("pack=\"MASS\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
      rcon.eval("pack=\"countreg\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://R-Forge.R-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
             */
            do {

                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;

                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    v = geneScoreListInsig.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }

                pValues.clear();

                if (countsMatrixOrg == null) {
                    countsMatrixOrg = Arrays.copyOf(countsMatrix, countsMatrix.length);
                }
                residueCounter = caculateResidueByR(scoreHeads, countsMatrix, geneSize,
                        colNum, noExplanatoryVar, truncPoint, countsMatrixOrg);

                // residueCounter = caculateResidueByRSingleVar(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar);
                mean = StdStats.mean(residueCounter);
                sd = StdStats.stddev(residueCounter);

                weights = new double[residueCounter.length];
                residuual = new double[residueCounter.length];
                Arrays.fill(weights, Double.NaN);
                scl.iterativeWeighter(residueCounter, weights, residuual, 100);

                mean = StdStats.mean(residueCounter, weights, true);
                sd = StdStats.stddev(residueCounter, weights);

                int geneNum = residueCounter.length;
                double zSc;

                for (int t = 0; t < geneNum; t++) {
                    zSc = (residueCounter[t] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    pValues.add(zSc);
                }

                pValues.quickSort();
                adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);
                geneScoreListInsig.clear();

                sigGeneSet1.clear();

                for (int i = 0; i < geneNum; i++) {
                    zSc = (residueCounter[i] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    if (zSc <= adjGenePValueCutoff) {
                        sigGeneSet1.add(geneOrderTrunc.get(i));
                        continue;
                    }
                    geneScoreListInsig.add(scoreListTrunc.get(i));

                }
                if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                    mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues);
                    sigGeneNum = sigGeneSet1.size();
                    break;
                }
                sigGeneSet0.clear();
                sigGeneSet0.addAll(sigGeneSet1);
                if (geneScoreListInsig.size() < minSampleSize) {
                    //String info = "The non-zero mutation counts of genes is  " + geneScoreListInsig.size() + " at truncation point " + truncPoint + ". The analysis of RUNNER is stopped.";
                    //LOG.info(info);
                    break;
                }

            } while (true);
            // if (mflc < 0.2)
            {
                paramSetList.add(new ZTNBParamSet(scoreBinCut, sigGeneNum, mflc, truncPoint));
            }

        } catch (Exception e1) {
            LOG.error("Errors at scoreBinCut " + scoreBinCut + ", truncation point " + truncPoint + "!");
            //System.out.println(freqCut + "\t" + scoreBinCut + "\t" + tn);
            e1.printStackTrace();

        }
        if (rcon != null) {
            rcon.close();
        }
        geneScoreListInsig.clear();
        countsRegListCopied.clear();
        fireTaskComplete();
        return "finished";
    }

    public double[] caculateResidueByR(List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum, boolean noExplanatoryVar,
            int trunc, double[] orgCountsMatrix) throws Exception {
        StringBuilder sb = new StringBuilder();

        String strPrefix = "genemutetest" + threadID;
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size();
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        sb.append(")");

        // System.out.println(sb);
        rcon.voidEval(sb.toString());
        String dataFrameNames = sb.toString();
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval("len<-dim(" + strPrefix + ")[2]");
            rcon.voidEval(strPrefix + "[,seq(2,len)] <- log(" + strPrefix + "[,seq(2,len)])");
            // rcon.voidEval(strPrefix + "[,seq(len,len)] <- log(" + strPrefix + "[,seq(len,len)])");
        }

        sb.delete(0, sb.length());
        int orgScoreHeadSize = scoreHeads.size();

        //dist = c("poisson", "negbin", "geometric")
        //zerotrunc  dist
        if (noExplanatoryVar) {
            sb.append("m1 <- zerotrunc(DepVarScore ~ ");
            sb.append(scoreHeads.get(0));
            for (int i = 1; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        } else {
            sb.append("m1 <- zerotrunc(DepVarScore ~ IndepVar ");
            for (int i = 0; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }

        }

        //sb.append("m1 <- glm(DepVarScore ~ IndepVar + AvgRegionLen");
        // sb.append(", data = ").append(strPrefix).append(",family=\"poisson\")");
        // sb.append(", data = ").append(strPrefix).append(", dist=\"negbin\")");
        sb.append(", data = ").append(strPrefix).append(", dist=\"negbin-extended\", truncPoint=" + trunc + ")");
        double[] residueCounter = null;
        try {
            //System.out.println(sb);
            rcon.voidEval(sb.toString());
            //  System.out.println(sb);
            if (runStepwise) {
                rcon.voidEval(" m1 <- stepAIC(m1,direction = \"both\",trace = 0)");
            }
//            String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
//            System.out.println(logTxt);
            // double[] residueCounter = rcon.eval("resid(m1,\"pearson\")").asDoubles();
            // double[] residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles();
            if (orgCountsMatrix != null) {
                geneSize = orgCountsMatrix.length / colNum;
                strPrefix = "genemutetest" + threadID;
                rcon.assign("valMat", orgCountsMatrix);
                rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

                rcon.voidEval(strPrefix + "<-data.frame(valMat);"); 
                rcon.voidEval(dataFrameNames);

                residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + trunc + ")").asDoubles();
            } else {
                residueCounter = rcon.eval("residuals(m1,type = \"deviance\", truncPoint=" + trunc + ")").asDoubles();
            }
        } catch (RserveException ex) {

//            BufferedWriter bw = new BufferedWriter(new FileWriter("testS.txt"));
//            bw.write("DepVarScore\tExplanatoryVar");
//            for (int i = 0; i < scoreHeads.size(); i++) {
//                bw.write("\t" + scoreHeads.get(i));
//            }
//            bw.write("\n");
//            geneSize = countsMatrix.length / colNum;
//            for (int j = 0; j < geneSize; j++) {
//                bw.write(String.valueOf(countsMatrix[j * colNum]));
//                for (int i = 1; i < colNum; i++) {
//                    bw.write("\t");
//                    bw.write(String.valueOf(countsMatrix[j * colNum + i]));
//                }
//                bw.write("\n");
//            }
//            bw.close();
            ex.printStackTrace();
        }
        return residueCounter;
    }

}
