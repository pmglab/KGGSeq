/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.FloatArrayList;
import cern.colt.list.IntArrayList;
import cern.jet.random.engine.MersenneTwister64;
import cern.jet.stat.Probability;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.GZIPInputStream;
import jsc.independentsamples.MannWhitneyTest;
import jsc.tests.H1;
import org.apache.log4j.Logger;
import static org.cobi.kggseq.Constants.STAND_CHROM_NAMES;
import org.cobi.kggseq.GlobalManager;
import org.cobi.kggseq.entity.ArrayListComparatorDouble;
import org.cobi.kggseq.entity.Chromosome;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.Gene;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.GeneSet;
import org.cobi.kggseq.entity.GeneSetWilcoxPValueComparator;
import org.cobi.kggseq.entity.PPIGraph;
import org.cobi.kggseq.entity.ZTNBParamSet;
import org.cobi.kggseq.entity.ZTNBParamSetComparator;
import org.cobi.kggseq.entity.RefGene;
import org.cobi.kggseq.entity.SampleVarGtyUnit;
import org.cobi.kggseq.entity.SeqSegment;
import org.cobi.kggseq.entity.Variant;
import org.cobi.kggseq.entity.ZTNBParamSetComparatorOrder;
import org.cobi.kggseq.entity.ZTNBParamSetComparatorSig;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.net.NCBIRetriever;
import org.cobi.util.plot.PValuePainter;
import org.cobi.util.stat.LinearRegression;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.stat.SpecifcCalculatorLinear;
import org.cobi.util.stat.StdStats;
import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.text.BZPartReader;
import org.cobi.util.text.LocalExcelFile;
import org.cobi.util.text.StringArrayDoubleComparator;
import org.cobi.util.text.StringArrayIntegerComparator;
import org.cobi.util.text.Util;
import org.cobi.util.thread.Task;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

/**
 *
 * @author mxli
 */
public class GeneAnnotator {

    private static final Logger LOG = Logger.getLogger(GeneAnnotator.class);
    List<String> pubMedFilter;

    public GeneAnnotator() {
        pubMedFilter = new ArrayList<String>();
        pubMedFilter.add("gene");
        pubMedFilter.add("genes");
        pubMedFilter.add("mRNA");
        pubMedFilter.add("protein");
        pubMedFilter.add("proteins");
        pubMedFilter.add("transcription");
        pubMedFilter.add("transcript");
        pubMedFilter.add("transcripts");
        pubMedFilter.add("expressed");
        pubMedFilter.add("expression");
        pubMedFilter.add("expressions");
        pubMedFilter.add("locus");
        pubMedFilter.add("loci");
        pubMedFilter.add("SNP");

    }

    public void readZebrafishPhenotype(Map<String, String> xebraP2Phe) throws Exception {
        File geneSymbols1 = new File(GlobalManager.RESOURCE_PATH + "/HgncGene.txt");
        BufferedReader br = new BufferedReader(new FileReader(geneSymbols1));
        String strLine;
        Map<String, String> geneEtrIDSymbMap = new HashMap<String, String>();
//                    int k=1;
        while ((strLine = br.readLine()) != null) {
//                        System.out.println(k++);
            String[] strItems = strLine.split("\t", -1);
            if (strItems[9] != null) {
                strItems[9] = strItems[9].trim();
                if (strItems[9].length() > 0) {
                    geneEtrIDSymbMap.put(strItems[9], strItems[1].toUpperCase());
                }
            }
        }
        br.close();

        File fisher = new File(GlobalManager.RESOURCE_PATH + "/pheno_fish.txt.gz");
        br = LocalFileFunc.getBufferedReader(fisher.getCanonicalPath());
        //skip the headline
        br.readLine();
        br.readLine();
        Map<String, Set> xebraP2Phe0 = new HashMap<String, Set>();

        while ((strLine = br.readLine()) != null) {
            String[] strItems = strLine.split("\t", -1);
            String geneSymb = geneEtrIDSymbMap.get(strItems[2]);
            if (geneSymb == null) {
                continue;
            }
            Set pheno1 = xebraP2Phe0.get(geneSymb);
            if (pheno1 == null) {
                pheno1 = new HashSet<String>();
                xebraP2Phe0.put(geneSymb, pheno1);
            }

            if (strItems[9] != null && strItems[9].length() > 0) {
                pheno1.add(strItems[9]);
            }
            if (strItems[18] != null && strItems[18].length() > 0) {
                pheno1.add(strItems[18]);
            }
        }
        for (Map.Entry<String, Set> mPath : xebraP2Phe0.entrySet()) {
            xebraP2Phe.put(mPath.getKey(), mPath.getValue().toString());
        }
        xebraP2Phe0.clear();
        geneEtrIDSymbMap = null;
        br.close();
    }

    public void retrieveVariants1(RefGene mgeneExons, String chromName, String scorePath, BGZFInputStream bfScoreIndexes, int[] scoreIndexes,
            String[] varaintDBFilterFilesPathes, BGZFInputStream[] bfMAFIndexes, int[][] freqIndexes, IntArrayList positions,
            List<char[]> alleleList, List<float[]> scoreList, DoubleArrayList frequnceList) throws Exception {

        int boundNum = mgeneExons.getMergedSegments().size();
        if (boundNum == 0) {
            return;
        }
        IntArrayList exonBounders = new IntArrayList();
        List<SeqSegment> segs = mgeneExons.getMergedSegments();
        //it should be reversed
        if (segs.get(0).getStart() >= segs.get(boundNum - 1).getStart()) {
            for (int i = boundNum - 1; i >= 0; i--) {
                SeqSegment mgs = segs.get(i);
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        } else {
            for (SeqSegment mgs : segs) {
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        }
        boundNum = exonBounders.size();

        long[] pos = bfScoreIndexes.findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
        if (pos[0] == pos[1]) {
            return;
        }

        File rsFile = new File(scorePath);
        final BGZFInputStream bfScore = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
        bfScore.adjustPos(pos[0], pos[1]);
        bfScore.creatSpider(pos[0] != 0);
        int indexCHROM = -1, indexPOS = 0;
        VarAnnotTask varAnnoTask = new VarAnnotTask(bfScore.spider[0], indexCHROM, indexPOS, scoreIndexes);

        int[] regions = new int[exonBounders.size()];
        for (int i = 0; i < regions.length; i++) {
            regions[i] = exonBounders.getQuick(i);

        }
//because dbNSFP only has resions of exons, it is safe to just use the first and last boundary 
        varAnnoTask.dbNSFPAnnotSimple(positions, alleleList, scoreList, regions);
        bfScore.spider[0].closeInputStream();

        for (int i = positions.size() - 1; i >= 0; i--) {
            frequnceList.add(Double.NaN);
        }

//should define the format of alleles and frequencies
        indexCHROM = 0;
        indexPOS = 1;

        if (varaintDBFilterFilesPathes != null) {
            for (int i = 0; i < varaintDBFilterFilesPathes.length; i++) {
                // varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBFilterFiles6[k], options.needProgressionIndicator);               
                File mapfFile = new File(varaintDBFilterFilesPathes[i]);

                pos = bfMAFIndexes[i].findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
                if (pos[0] == pos[1]) {
                    return;
                }
                final BGZFInputStream bfMAF = new BGZFInputStream(mapfFile.getCanonicalPath(), 1, true);
                bfMAF.adjustPos(pos[0], pos[1]);
                bfMAF.creatSpider(pos[0] != 0);

                varAnnoTask = new VarAnnotTask(bfMAF.spider[0], indexCHROM, indexPOS);

                if (varaintDBFilterFilesPathes[i].endsWith("vcf.gz")) {
                    varAnnoTask.markByVCFFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i]);
                } else {
                    varAnnoTask.markByANNOVARefFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i][0]);
                }
                bfMAF.spider[0].closeInputStream();
            }
        }

    }

    public void retrieveVariants(RefGene mgeneExons, String chromName, String scorePath, BGZFInputStream bfScoreIndexes, int[] scoreIndexes,
            String[] varaintDBFilterFilesPathes, BGZFInputStream[] bfMAFIndexes, int[][] freqIndexes, IntArrayList positions,
            List<char[]> alleleList, List<float[]> scoreList, DoubleArrayList frequnceList) throws Exception {

        int boundNum = mgeneExons.getMergedSegments().size();
        if (boundNum == 0) {
            return;
        }
        IntArrayList exonBounders = new IntArrayList();
        List<SeqSegment> segs = mgeneExons.getMergedSegments();
        //it should be reversed
        if (segs.get(0).getStart() >= segs.get(boundNum - 1).getStart()) {
            for (int i = boundNum - 1; i >= 0; i--) {
                SeqSegment mgs = segs.get(i);
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        } else {
            for (SeqSegment mgs : segs) {
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        }
        boundNum = exonBounders.size();

        long[] pos = bfScoreIndexes.findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
        if (pos[0] == pos[1]) {
            return;
        }

        File rsFile = new File(scorePath);

        final BGZFInputStream bfScore = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
        bfScore.adjustPos(pos[0], pos[1]);
        bfScore.creatSpider(pos[0] != 0);
        int indexCHROM = -1, indexPOS = 0;
        VarAnnotTask varAnnoTask = new VarAnnotTask(bfScore.spider[0], indexCHROM, indexPOS, scoreIndexes);

        int[] regions = new int[exonBounders.size()];
        for (int i = 0; i < regions.length; i++) {
            regions[i] = exonBounders.getQuick(i);

        }
//because dbNSFP only has resions of exons, it is safe to just use the first and last boundary 
        varAnnoTask.dbNSFPAnnotSimple(positions, alleleList, scoreList, regions);
        bfScore.spider[0].closeInputStream();

        for (int i = positions.size() - 1; i >= 0; i--) {
            frequnceList.add(Double.NaN);
        }

//should define the format of alleles and frequencies
        indexCHROM = 0;
        indexPOS = 1;

        if (varaintDBFilterFilesPathes != null) {
            for (int i = 0; i < varaintDBFilterFilesPathes.length; i++) {
                // varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBFilterFiles6[k], options.needProgressionIndicator);               
                File mapfFile = new File(varaintDBFilterFilesPathes[i]);

                pos = bfMAFIndexes[i].findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
                if (pos[0] == pos[1]) {
                    return;
                }
                final BGZFInputStream bfMAF = new BGZFInputStream(mapfFile.getCanonicalPath(), 1, true);
                bfMAF.adjustPos(pos[0], pos[1]);
                bfMAF.creatSpider(pos[0] != 0);

                varAnnoTask = new VarAnnotTask(bfMAF.spider[0], indexCHROM, indexPOS);

                if (varaintDBFilterFilesPathes[i].endsWith("vcf.gz")) {
                    varAnnoTask.markByVCFFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i]);
                } else {
                    varAnnoTask.markByANNOVARefFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i][0]);
                }
                bfMAF.spider[0].closeInputStream();
            }
        }

    }

    public void removeVariantsByAlleleFreq(boolean exclusionMode, double minExFreq, double minAlleleFreq, double maxAlleleFreq, IntArrayList positions, List<char[]> alleleList,
            List<float[]> scoreList, DoubleArrayList frequnceList) {
        IntArrayList positionsTmp = new IntArrayList();
        List<char[]> alleleListTmp = new ArrayList<char[]>(alleleList);
        List<float[]> scoreListTmp = new ArrayList<float[]>(scoreList);
        DoubleArrayList frequnceListTmp = new DoubleArrayList();
        frequnceListTmp.addAllOf(frequnceList);
        positionsTmp.addAllOf(positions);

        positions.clear();
        alleleList.clear();
        scoreList.clear();
        frequnceList.clear();
        double altAF;
        int size = positionsTmp.size();
        boolean shouldAdd = false;
        for (int i = 0; i < size; i++) {
            altAF = frequnceListTmp.getQuick(i);
            shouldAdd = false;
            if (exclusionMode) {
                if (altAF == -1) {
                    //not exist in any database
                    //keep it anyhow
                    shouldAdd = true;
                } else if (Double.isNaN(altAF)) {
                    //exist in a database but have no frequence informaion
                    //not exist in any database
                    shouldAdd = true;

                } else //exist in a database and have freq infor
                if ((altAF >= minExFreq)) {
//                    leftVarNum--;

                } else {
                    shouldAdd = true;
                }
                if (shouldAdd) {
                    positions.add(positionsTmp.getQuick(i));
                    alleleList.add(alleleListTmp.get(i));
                    scoreList.add(scoreListTmp.get(i));
                    frequnceList.add(frequnceListTmp.getQuick(i));
                }

            } else {
                if (altAF == -1) {
                    //remove is anyhow
//                leftVarNum--;

                } else if (Double.isNaN(altAF)) {
                    // exist in a database but have no frequence informaion
                    //remove is anyhow
//                leftVarNum--;

                } else //exist in a database and have freq infor
                if ((altAF < minAlleleFreq || altAF > maxAlleleFreq)) {
//                    leftVarNum--;

                } else {
                    positions.add(positionsTmp.getQuick(i));
                    alleleList.add(alleleListTmp.get(i));
                    scoreList.add(scoreListTmp.get(i));
                    frequnceList.add(frequnceListTmp.getQuick(i));
                }
            }
        }
        positionsTmp.clear();
        alleleListTmp.clear();
        scoreListTmp.clear();
        frequnceListTmp.clear();
    }

    public void geneScoreSimulation(Map<String, double[]> geneScores, String chromName, Map<String, RefGene> mergedGeneExonMap, String dbNSFPFilePath,
            String alleFreqFilePath, int actualThreadNum, int[] scoreIndexes, int[] mafIndex, List<CombOrders> combOrderList, int bestModelNum,
            boolean needFilter, boolean exclusionMode, double minExFreq, double minAF, double maxAF, int datasetNum) {
        try {
            if (geneScores == null || geneScores.isEmpty()) {
                return;
            }
            File rsFile = new File(dbNSFPFilePath + chromName + ".gz");
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            BGZFInputStream bfScoreIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfScoreIndexes.checkIndex()) {
                bfScoreIndexes.adjustPos();
                bfScoreIndexes.buildIndex(rsFile.getCanonicalPath(), -1, 0, true);
            }
            bfScoreIndexes.readIndex(false, null);

            File mafFile = new File(alleFreqFilePath);
            BGZFInputStream bfMAFIndexes = new BGZFInputStream(mafFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfMAFIndexes.checkIndex()) {
                bfMAFIndexes.adjustPos();
                bfMAFIndexes.buildIndex(rsFile.getCanonicalPath(), 0, 1, false);
            }
            bfMAFIndexes.readIndex(false, chromName);
            IntArrayList positions = new IntArrayList();
            List<char[]> alleleList = new ArrayList<char[]>();
            List<float[]> scoreList = new ArrayList<float[]>();
            DoubleArrayList frequnceList = new DoubleArrayList();

            int varNum = positions.size();

            int sampleSize = 45;
            double denovMutationRate = 1.3E-8;

            RiskPredictionLogisticTask task = new RiskPredictionLogisticTask(combOrderList, bestModelNum);
            MersenneTwister64 mt54 = new cern.jet.random.engine.MersenneTwister64(new java.util.Date());
            double actualGeneScore;
            double prob = 0;
            double score = 0, scoreSum = 0;
            double p = 1;
            for (Map.Entry<String, double[]> item : geneScores.entrySet()) {

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public int[] partitionEvenBlock(int totalSnpSize, int blockNum) throws Exception {
        int[] bigBlockIndexes;
        int intervalLen = totalSnpSize / blockNum;
        if (intervalLen == 0) {
            bigBlockIndexes = new int[totalSnpSize + 1];
            for (int i = 0; i < bigBlockIndexes.length; i++) {
                bigBlockIndexes[i] = i;
            }
        } else {
            bigBlockIndexes = new int[blockNum + 1];
            Arrays.fill(bigBlockIndexes, 0);
            for (int s = 1; s < blockNum; s++) {
                bigBlockIndexes[s] = s * intervalLen;
            }
            bigBlockIndexes[blockNum] = totalSnpSize;
        }

        return bigBlockIndexes;
    }

    public void geneScoreSimulationMultiThread(Map<String, double[]> geneScores, String chromName, Map<String, RefGene> mergedGeneExonMap, String dbNSFPFilePath,
            int[] scoreIndexes, String[] varaintDBFilterFilesPathes, int[][] freqCols, int actualThreadNum, List<CombOrders> combOrderList, int bestModelNum,
            boolean exclusionMode, double minExFreq, double minAF, double maxAF, int maxThreadNum, int datasetNum, int sampleSize, boolean ignoreHomo) {
        try {
            if (geneScores == null || geneScores.isEmpty()) {
                return;
            }
            File rsFile = new File(dbNSFPFilePath + chromName + ".gz");
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            BGZFInputStream bfScoreIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfScoreIndexes.checkIndex()) {
                bfScoreIndexes.adjustPos();
                bfScoreIndexes.buildIndex(rsFile.getCanonicalPath(), -1, 0, true);
            }
            bfScoreIndexes.readIndex(false, null);

            BGZFInputStream[] bfMAFIndexes = new BGZFInputStream[varaintDBFilterFilesPathes.length];
            for (int i = 0; i < varaintDBFilterFilesPathes.length; i++) {
                File mafFile = new File(varaintDBFilterFilesPathes[i]);
                bfMAFIndexes[i] = new BGZFInputStream(mafFile.getCanonicalPath(), actualThreadNum, true);
                if (!bfMAFIndexes[i].checkIndex()) {
                    bfMAFIndexes[i].adjustPos();
                    bfMAFIndexes[i].buildIndex(rsFile.getCanonicalPath(), 0, 1, false);
                }
                bfMAFIndexes[i].readIndex(false, chromName);
            }

            // CountDownLatch threadSignal = new CountDownLatch(maxThreadNum);
            ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);

            RiskPredictionLogisticTask task = new RiskPredictionLogisticTask(combOrderList, bestModelNum);
            double actualGeneScore;

            Map<String, Double> geneEmpP = new HashMap<String, Double>();
            int runningThread = 0;
            BufferedWriter bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Freq\tSIFT_score	Polyphen2_HDIV_score	Polyphen2_HVAR_score	LRT_score	MutationTaster_converted_rankscore	MutationAssessor_score	FATHMM_score	VEST3_score	PROVEAN_score	CADD_raw	GERP++_NR	GERP++_RS	phastCons7way_vertebrate	SiPhy_29way_logOdds\n");
//int[][] mafIndex,
            for (Map.Entry<String, double[]> item : geneScores.entrySet()) {
                actualGeneScore = item.getValue()[1];

                if (actualGeneScore <= 0) {
                    item.getValue()[1] = 1;
                    continue;
                }

                SimuDoubleHitAllTask simTask = new SimuDoubleHitAllTask(datasetNum, sampleSize, combOrderList, bestModelNum, chromName,
                        new File(dbNSFPFilePath), scoreIndexes, bfScoreIndexes, varaintDBFilterFilesPathes,
                        freqCols, bfMAFIndexes, exclusionMode, minExFreq, minAF, maxAF, ignoreHomo, bw) {
                    @Override
                    public void fireTaskComplete() throws Exception {
                        synchronized (geneEmpP) {
                            geneEmpP.put(this.mgeneExons.getSymb(), this.empP);
                        }

                    }
                };
                String geneSymbDis = item.getKey();
                RefGene mgeneExons = mergedGeneExonMap.get(geneSymbDis);
                simTask.updateParamters(actualGeneScore, mgeneExons);
                serv.submit(simTask);
                runningThread++;
            }
            // threadSignal.await();

            //if I use this, it seems the CPUs were not fully used
            for (int s = 0; s < runningThread; s++) {
                Future<String> taskTmp = serv.take();
                String infor = taskTmp.get();
                //  System.out.println(infor);
            }

            for (Map.Entry<String, double[]> item : geneScores.entrySet()) {
                Double ep = geneEmpP.get(item.getKey());
                if (ep != null) {
                    item.getValue()[1] = ep;
                }
            }

            exec.shutdown();
            bw.close();
            // System.out.println(chromName +" has been finished!");

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void geneScoreSimulationMultiThread1(Map<String, double[]> geneScores, String chromName, Map<String, RefGene> mergedGeneExonMap, String dbNSFPFilePath,
            int[] scoreIndexes, String[] varaintDBFilterFilesPathes, int[][] freqCols, int actualThreadNum, List<CombOrders> combOrderList, int bestModelNum,
            boolean exclusionMode, double minExFreq, double minAF, double maxAF, int maxThreadNum, int datasetNum, int sampleSize) {
        try {
            if (geneScores == null || geneScores.isEmpty()) {
                return;
            }
            File rsFile = new File(dbNSFPFilePath + chromName + ".gz");
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            BGZFInputStream bfScoreIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfScoreIndexes.checkIndex()) {
                bfScoreIndexes.adjustPos();
                bfScoreIndexes.buildIndex(rsFile.getCanonicalPath(), -1, 0, true);
            }
            bfScoreIndexes.readIndex(false, null);

            BGZFInputStream[] bfMAFIndexes = new BGZFInputStream[varaintDBFilterFilesPathes.length];
            for (int i = 0; i < varaintDBFilterFilesPathes.length; i++) {
                File mafFile = new File(varaintDBFilterFilesPathes[i]);
                bfMAFIndexes[i] = new BGZFInputStream(mafFile.getCanonicalPath(), actualThreadNum, true);
                if (!bfMAFIndexes[i].checkIndex()) {
                    bfMAFIndexes[i].adjustPos();
                    bfMAFIndexes[i].buildIndex(rsFile.getCanonicalPath(), 0, 1, false);
                }
                bfMAFIndexes[i].readIndex(false, chromName);
            }

            IntArrayList positions = new IntArrayList();
            List<char[]> alleleList = new ArrayList<char[]>();
            List<float[]> scoreList = new ArrayList<float[]>();
            DoubleArrayList frequnceList = new DoubleArrayList();

            int varNum = positions.size();
            double denovMutationRate = 1.3E-8;

            ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            RiskPredictionLogisticTask task = new RiskPredictionLogisticTask(combOrderList, bestModelNum);
            double actualGeneScore;
            double prob = 0;

            double p = 1;
            int randSetNum = 0;

            SimuDoubleTask[] simTask = new SimuDoubleTask[maxThreadNum];
            int runningThread = 0;
            int[] numsArray = partitionEvenBlock(datasetNum, maxThreadNum);
            maxThreadNum = numsArray.length - 1;
            for (int s = 1; s < numsArray.length; s++) {
                simTask[s - 1] = new SimuDoubleTask(numsArray[s] - numsArray[s - 1], sampleSize, combOrderList, bestModelNum);
            }
//int[][] mafIndex,
            for (Map.Entry<String, double[]> item : geneScores.entrySet()) {
                actualGeneScore = item.getValue()[1];

                if (actualGeneScore <= 0) {
                    item.getValue()[1] = 1;
                    continue;
                }
                String geneSymbDis = item.getKey();
                RefGene mgeneExons = mergedGeneExonMap.get(geneSymbDis);
                positions.clear();
                alleleList.clear();
                scoreList.clear();
                frequnceList.clear();

                retrieveVariants(mgeneExons, chromName, rsFile.getCanonicalPath(), bfScoreIndexes, scoreIndexes, varaintDBFilterFilesPathes,
                        bfMAFIndexes, freqCols, positions, alleleList, scoreList, frequnceList);

                removeVariantsByAlleleFreq(exclusionMode, minExFreq, minAF, maxAF, positions, alleleList, scoreList, frequnceList);

                varNum = positions.size();
                double[] mutantCounts = new double[2];
                Arrays.fill(mutantCounts, 0);

                double motherAccu = 0, fatherAccu = 0;

                p = 1;
                randSetNum = 0;
                runningThread = 0;
                for (int s = 0; s < maxThreadNum; s++) {
                    simTask[s].updateParamters(actualGeneScore, positions, alleleList, frequnceList, scoreList);
                    serv.submit(simTask[s]);
                    runningThread++;
                }

                for (int s = 0; s < runningThread; s++) {
                    Future<String> taskTmp = serv.take();
                    String infor = taskTmp.get();
                    //  System.out.println(infor);
                }
                for (int s = 0; s < runningThread; s++) {
                    p += simTask[s].getEmpP();
                    randSetNum += simTask[s].getRanSetNum();
                }

                p = p / (randSetNum + 1);
                //save the regressionFactors-value
                item.getValue()[1] = p;
                System.out.println(item.getKey() + "\t" + p);
            }
            exec.shutdown();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    class SimuDoubleTask extends Task implements Callable<String> {

        int datasetNum;
        int sampleSize;

        double actualGeneScore;
        DoubleArrayList frequnceList;
        IntArrayList positions;
        List<char[]> alleleList;
        List<float[]> scoreList;

        List<CombOrders> combOrderList;
        RiskPredictionLogisticTask taskPredic;

        double empP;
        int ranSetNum = 0;
        MersenneTwister64 mt54 = new cern.jet.random.engine.MersenneTwister64(new java.util.Date());

        public SimuDoubleTask(int datasetNum, int sampleSize, List<CombOrders> combOrderList, int bestModelNum) {
            this.datasetNum = datasetNum;
            this.sampleSize = sampleSize;

            this.combOrderList = combOrderList;
            taskPredic = new RiskPredictionLogisticTask(combOrderList, bestModelNum);
        }

        public void updateParamters(double actualGeneScore, IntArrayList positions, List<char[]> alleleList, DoubleArrayList frequnceList, List<float[]> scoreList) {
            this.positions = positions;
            this.alleleList = alleleList;
            this.actualGeneScore = actualGeneScore;
            this.frequnceList = frequnceList;
            this.scoreList = scoreList;
        }

        @Override
        public String call() throws Exception {
            ranSetNum = 0;
            double scoreSum = 0;
            double prob;
            double[] mutantCounts = new double[2];
            double score;
            double denovMutationRate = 1.3E-8;
            empP = 1;
            int varNum = frequnceList.size();
            //random simulation

            int startI = 0, endI = 1;
            //at most three types altration
            double[] probs = new double[3];
            int[] scoreIndex = new int[3];
            boolean allNA = false;
            int nonNAIndex = 0;
            int tempLen;
            double minMutRate;
            Set<Integer> availVars = new HashSet<Integer>();
            int tmpI;
            for (int k = 0; k < datasetNum; k++) {
                scoreSum = 0;
                ranSetNum++;
                for (int j = 0; j < sampleSize; j++) {
                    Arrays.fill(mutantCounts, 0);
                    startI = 0;
                    endI = 1;
                    do {
                        //all variants
                        while (endI < varNum && positions.getQuick(endI - 1) == positions.getQuick(endI)) {
                            endI++;
                        }
                        allNA = false;
                        nonNAIndex = 0;
                        //a variant may have different amino accid annotatins
                        availVars.clear();
                        Arrays.fill(scoreIndex, -1);
                        tempLen = 0;
                        for (int i = startI; i < endI; i++) {
                            tmpI = alleleList.get(i)[0] + alleleList.get(i)[1];
                            //filter out duplicated variant
                            if (availVars.contains(tmpI)) {
                                continue;
                            }
                            availVars.add(tmpI);
                            scoreIndex[tempLen] = i;
                            tempLen++;
                            if (!Double.isNaN(frequnceList.getQuick(i)) && frequnceList.getQuick(i) != 0) {
                                if (nonNAIndex == 0) {
                                    probs[nonNAIndex] = frequnceList.getQuick(i);
                                } else {
                                    //accumulate the probablity
                                    probs[nonNAIndex] = (probs[nonNAIndex - 1] + frequnceList.getQuick(i));
                                }
                                nonNAIndex++;
                            }
                        }

                        if (nonNAIndex < tempLen) {
                            minMutRate = denovMutationRate / (tempLen);
                            while (nonNAIndex < tempLen) {
                                if (nonNAIndex == 0) {
                                    probs[nonNAIndex] = minMutRate;
                                } else {
                                    //accumulate the probablity
                                    probs[nonNAIndex] = (probs[nonNAIndex - 1] + minMutRate);
                                }
                                nonNAIndex++;
                            }
                        }

                        //2 haplod transmitted
                        for (int t = 0; t < 2; t++) {
                            prob = mt54.nextDouble();
                            nonNAIndex = Arrays.binarySearch(probs, 0, tempLen, prob);
                            if (nonNAIndex < 0) {
                                nonNAIndex = -nonNAIndex - 1;
                                if (nonNAIndex < tempLen) {
                                    score = taskPredic.predictByBestModels(combOrderList, scoreList.get(scoreIndex[nonNAIndex]));
                                    mutantCounts[t] += score;
                                }
                            } else {
                                score = taskPredic.predictByBestModels(combOrderList, scoreList.get(scoreIndex[nonNAIndex]));
                                mutantCounts[t] += score;
                            }
                        }
                        startI = endI;
                        endI++;
                    } while (startI < varNum);

                    //under double-hit model, assume mutations occur on both chromosomes
                    scoreSum += (mutantCounts[0] * mutantCounts[1]);
                }

                if (scoreSum >= actualGeneScore) {
                    empP++;
                }
                //Use the adaptive approach here     
                if (ranSetNum > 500000000) {
                    if (empP / ranSetNum > 0.0000005) {
                        break;
                    }
                } else if (ranSetNum > 50000000) {
                    if (empP / ranSetNum > 0.000005) {
                        break;
                    }
                } else if (ranSetNum > 5000000) {
                    if (empP / ranSetNum > 0.00005) {
                        break;
                    }
                } else if (ranSetNum > 500000) {
                    if (empP / ranSetNum > 0.0005) {
                        break;
                    }
                } else if (ranSetNum > 50000) {
                    if (empP / ranSetNum > 0.005) {
                        break;
                    }
                } else if (ranSetNum > 5000) {
                    if (empP / ranSetNum > 0.01) {
                        break;
                    }
                } else if (ranSetNum > 500) {
                    if (empP / ranSetNum > 0.1) {
                        break;
                    }
                } else if (ranSetNum > 100) {
                    if (empP / ranSetNum > 0.3) {
                        break;
                    }
                }
                if (ranSetNum % 300 == 0) {
                    System.out.println("Running " + actualGeneScore);
                }
            }
            return "";
        }

        public double getEmpP() {
            return empP;
        }

        public int getRanSetNum() {
            return ranSetNum;
        }

    }

    public void readMousePhenotype(Map<String, String[]> g2MP) throws Exception {
        File fleMouse1 = new File(GlobalManager.RESOURCE_PATH + "/" + "HMD_HumanPhenotype.rpt.txt");
        File fleMouse2 = new File(GlobalManager.RESOURCE_PATH + "/" + "VOC_MammalianPhenotype.rpt.txt");
        File fleMouse3 = new File(GlobalManager.RESOURCE_PATH + "/" + "ALL_genotype_phenotype.mouse.gz");

        BufferedReader br = new BufferedReader(new FileReader(fleMouse2));
        String strLine;
        Map<String, String> mp2Phe1 = new HashMap<String, String>();
//                    int k=1;
        while ((strLine = br.readLine()) != null) {
//                        System.out.println(k++);
            String[] strItems = strLine.split("\t", -1);
            if (strItems.length > 2) {
                if (strItems[2] != null && strItems[2].length() > 0) {
                    mp2Phe1.put(strItems[0], strItems[1] + "->" + strItems[2]);
                } else {
                    mp2Phe1.put(strItems[0], strItems[1]);
                }
            } else {
                mp2Phe1.put(strItems[0], strItems[1]);
            }
        }
        br.close();

        String strPhe1 = null;

        br = new BufferedReader(new FileReader(fleMouse1));
        while ((strLine = br.readLine()) != null) {
            String[] strItems = strLine.split("\t", -1);
            if (strItems.length < 7 || strItems[6] == null || strItems[6].trim().length() == 0) {
                continue;
            }

            strPhe1 = ".";
            String[] strMP = strItems[6].trim().split(" ");
            for (String temp : strMP) {
                if (mp2Phe1.containsKey(temp)) {
                    if (strPhe1.length() == 1) {
                        strPhe1 = mp2Phe1.get(temp);
                    } else {
                        strPhe1 += ("||" + mp2Phe1.get(temp));
                    }
                }
            }
            g2MP.put(strItems[0], new String[]{strPhe1, "."});
        }
        br.close();

        br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(fleMouse3))));
        String geneSymb = null;
        while ((strLine = br.readLine()) != null) {
            // String[] strItems = strLine.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)", -1);
            String[] strItems = strLine.split("\t", -1);
            geneSymb = strItems[1].toUpperCase().trim();
            String[] values = g2MP.get(geneSymb);

            if (values == null) {
                g2MP.put(geneSymb, new String[]{".", strItems[20].replace("\"", "") + "," + strItems[22].replace("\"", "")});
            } else {
                values[1] = strItems[20].replace("\"", "") + "," + strItems[22].replace("\"", "");
            }
        }
        br.close();
    }

    public Map<String, double[]> readGeneValues(String filePath, String canceLabel) throws Exception {
        String line;
        String[] cells;
        Map<String, double[]> driverGeneScores = new HashMap<String, double[]>();
        BufferedReader brScore = LocalFileFunc.getBufferedReader(filePath);
        line = brScore.readLine();
        cells = line.split("\t");
        int index = -1;
        for (int i = 0; i < cells.length; i++) {
            if (cells[i].startsWith(canceLabel)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            LOG.warn("The cancel label '" + canceLabel + "' is not available in the resource data of " + filePath);
            return null;
        }

        double mean, median;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            cells = line.split("\t", -1);
            if (cells[index].equals(".")) {
                continue;
            }

            mean = Double.parseDouble(cells[index]);

            double[] results = new double[]{mean};
            driverGeneScores.put(cells[0], results);
        }
        brScore.close();
        return driverGeneScores;
    }

    public Map<String, double[]> readGeneCoverages(String filePath, int minCov) throws Exception {
        String line;
        String[] cells;
        Map<String, double[]> driverGeneScores = new HashMap<String, double[]>();
        BufferedReader brScore = LocalFileFunc.getBufferedReader(filePath);
        line = brScore.readLine();
        cells = line.split("\t");
        int index = -1;

        double min, max;

        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            cells = line.split("\t", -1);
            if (cells[1].equals("NA")) {
                cells[1] = "0";
            }
            min = Double.parseDouble(cells[1]);
            max = min;
            for (int t = 2; t < cells.length; t++) {
                if (cells[t].equals("NA")) {
                    cells[t] = "0";
                }
                if (min > Double.parseDouble(cells[t])) {
                    min = Double.parseDouble(cells[t]);
                }
                if (max < Double.parseDouble(cells[t])) {
                    max = Double.parseDouble(cells[t]);
                }
            }
            if (min < minCov) {
                continue;
            }
            double[] results = new double[2];
            results[0] = min;
            results[1] = max;
            driverGeneScores.put(cells[0], results);
        }
        brScore.close();
        return driverGeneScores;
    }

    public Map<String, double[]> readGeneExp(String folderPath, String filePath, String cancerName) throws Exception {
        String line;
        String[] cells;
        Map<String, String> cancerCodeMap = new HashMap<String, String>();
        BufferedReader br = LocalFileFunc.getBufferedReader(folderPath + "/TCGACodes.txt");
        br.readLine();
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");
            cancerCodeMap.put(cells[0], cells[2]);
        }
        br.close();
        Map<String, double[]> driverGeneScores = new HashMap<String, double[]>();
        BufferedReader brScore = LocalFileFunc.getBufferedReader(folderPath + "/" + filePath);
        line = brScore.readLine();
        cells = line.split("\t");
        Map<String, IntArrayList> cancerIndexMap = new HashMap<String, IntArrayList>();
        IntArrayList indexes;
        for (int i = 1; i < cells.length; i++) {
            String[] ids = cells[i].split("-");
            String diseaseName = cancerCodeMap.get(ids[1]);
            indexes = cancerIndexMap.get(diseaseName);
            if (indexes == null) {
                indexes = new IntArrayList();
                cancerIndexMap.put(diseaseName, indexes);
            }
            indexes.add(i);
            //System.out.println( cells[k]);
        }

        indexes = cancerIndexMap.get(cancerName);
        if (indexes == null) {
            return null;
        }

        double[] values = new double[indexes.size()];
        double mean, median;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            Arrays.fill(values, Double.NaN);
            cells = line.split("\t");
            for (int i = 0; i < values.length; i++) {
                if (cells[indexes.getQuick(i)].equals(".")) {
                    continue;
                }
                values[i] = Double.parseDouble(cells[indexes.getQuick(i)]);
            }

            mean = StdStats.mean(values);
            median = StdStats.medianNS(values);

            double[] results = new double[]{mean, median};
            driverGeneScores.put(cells[0], results);
        }
        brScore.close();
        return driverGeneScores;
    }

    public Map<String, double[]> readGeneScore(String geneCoVarFilePath, String[] names, List<String> heads, int extraCol) throws Exception {
        Map<String, double[]> driverGeneScores = new HashMap<String, double[]>();
        String line;
        String[] cells;
        BufferedReader brScore = new BufferedReader(new FileReader(geneCoVarFilePath));

        int[] effecIndex;

        line = brScore.readLine();
        cells = line.split("\t");
        if (names != null) {
            effecIndex = new int[names.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (names[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }
            for (int i = 1; i < effecIndex.length; i++) {
                heads.add(cells[effecIndex[i]]);
            }
        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 1; i < effecIndex.length; i++) {
                effecIndex[i - 1] = i;
                heads.add(cells[effecIndex[i]]);
            }
        }

        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");
            double[] itemCell = new double[effecIndex.length - 1 + extraCol];
            Arrays.fill(itemCell, Double.NaN);
            boolean hasError = false;
            for (int i = 1; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                itemCell[i - 1] = Double.parseDouble(cells[effecIndex[i]]);
            }
            if (hasError) {
                continue;
            }

            driverGeneScores.put(cells[effecIndex[0]], itemCell);
        }
        brScore.close();

        return driverGeneScores;
    }

    public Map<String, double[]> readGeneScore(String geneCoVarFilePath, String[] names, int extraColNum) throws Exception {
        Map<String, double[]> driverGeneScores = new HashMap<String, double[]>();
        String line;
        String[] cells;
        BufferedReader brScore = new BufferedReader(new FileReader(geneCoVarFilePath));

        int[] effecIndex;

        line = brScore.readLine();
        cells = line.split("\t");
        if (names != null) {
            effecIndex = new int[names.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (names[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 1; i < effecIndex.length; i++) {
                effecIndex[i - 1] = i;
            }
        }

        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");
            double[] itemCell = new double[effecIndex.length - 1 + extraColNum];
            Arrays.fill(itemCell, Double.NaN);
            //Assume the frequences are zero 
            /*
            for (int k = 0; k < popuNum; k++) {
                itemCell[effecIndex.length - 1 + k * 2] = 0;
                itemCell[effecIndex.length - 1 + k * 2 + 1] = 0;
            }
             */
            boolean hasError = false;
            for (int i = 1; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                itemCell[i - 1] = Double.parseDouble(cells[effecIndex[i]]);
            }
            if (hasError) {
                continue;
            }

            driverGeneScores.put(cells[effecIndex[0]], itemCell);
        }
        brScore.close();

        return driverGeneScores;
    }

    public void appendGeneVar(String geneCoVarFilePath, String[] popuNames, int mafStartIndex, double mafCutOff, double scoreCutOff,
            Map<String, double[]> driverGeneScores, Set<String> hittedGeneSet) throws Exception {
        String line;
        String[] cells;
        BufferedReader brScore = LocalFileFunc.getBufferedReader(geneCoVarFilePath);

        int[] effecIndex;
        boolean needWeight = false;
        if (scoreCutOff < 1) {
            needWeight = true;
        }
        double baseCount = 1E6;
        line = brScore.readLine();
        cells = line.split("\t");
        if (popuNames != null) {
            effecIndex = new int[popuNames.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (popuNames[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 0; i < effecIndex.length; i++) {
                effecIndex[i] = i;
            }
        }

        double[] itemCell;
        double freq;
        double score;
        int scoreInt = 1;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");
            itemCell = driverGeneScores.get(cells[5]);
            if (itemCell == null) {
                continue;
            }

            boolean hasError = false;
            for (int i = 0; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[effecIndex[i]]);
                if (freq < mafCutOff) {
                    if (cells[4].charAt(0) == 'N') {
                        if (needWeight) {
                            if (cells[cells.length - 2].equals(".")) {
                                scoreInt = 1;
                            } else {
                                score = Double.parseDouble(cells[cells.length - 2]);
                                scoreInt = (int) (score / scoreCutOff);
                                scoreInt += 1;
                            }
                        }
                        itemCell[i * 2 + mafStartIndex] += (freq * scoreInt);
                    } else {
                        itemCell[i * 2 + mafStartIndex + 1] += freq;
                    }
                }
            }
            hittedGeneSet.add(cells[5]);
        }
        brScore.close();
    }

    public void appendGeneVar1KG(String geneCoVarFilePath, String[] popuNames, int mafStartIndex, double mafCutOff, double scoreCutOff,
            Set<Integer>[] featureIDList, boolean[] isWeightFeaure, Map<String, double[]> driverGeneScores, Set<String> hittedGeneSet) throws Exception {
        String line;
        String[] cells;
        BufferedReader brScore = LocalFileFunc.getBufferedReader(geneCoVarFilePath);

        int[] effecIndex;
        boolean needWeight = false;
        if (scoreCutOff < 1) {
            needWeight = true;
        }
        double baseCount = 1E6;
        line = brScore.readLine();
        cells = line.split("\t");
        if (popuNames != null) {
            effecIndex = new int[popuNames.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (popuNames[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 0; i < effecIndex.length; i++) {
                effecIndex[i] = i;
            }
        }

        double[] itemCell;
        double freq;
        double score;
        int scoreInt = 1;
        int index;
        String[] geneList;
        String geneSymb;
        int typeID = -1;
        int featureListSize = featureIDList.length;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");

            boolean hasError = false;
            for (int i = 0; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[effecIndex[i]]);
                if (freq < mafCutOff) {
                    geneList = cells[9].split(";");
                    for (int t = 0; t < geneList.length; t++) {
                        index = geneList[t].lastIndexOf(':');
                        geneSymb = geneList[t].substring(0, index);

                        itemCell = driverGeneScores.get(geneSymb);
                        if (itemCell == null) {
                            continue;
                        }
                        typeID = Integer.parseInt(geneList[t].substring(index + 1));
                        for (int k = 0; k < featureListSize; k++) {
                            if (featureIDList[k].contains(typeID)) {
                                if (isWeightFeaure[k]) {
                                    if (cells[cells.length - 2].equals(".")) {
                                        scoreInt = 1;
                                    } else {
                                        score = Double.parseDouble(cells[cells.length - 2]);
                                        scoreInt = (int) (score / scoreCutOff);
                                        scoreInt += 1;
                                    }
                                    itemCell[mafStartIndex + i * featureListSize + k] += (freq * scoreInt);
                                } else {
                                    itemCell[mafStartIndex + i * featureListSize + k] += freq;
                                }
                                hittedGeneSet.add(geneSymb);
                                //assume the feature list is not overlapped
                                break;
                            }
                        }

                    }

                }
            }

        }
        brScore.close();

    }

    public void appendGeneVarFreq(String geneCoVarFilePath, String[] popuNames, double mafCutOff, double scoreCutOff,
            Set<Byte> featureIDList, boolean isWeightFeaure, Map<String, double[]> driverGeneScores, Set<String> hittedGeneSet) throws Exception {
        String line;
        String[] cells;
        BufferedReader brScore = LocalFileFunc.getBufferedReader(geneCoVarFilePath);

        int[] effecIndex;
        boolean needWeight = false;
        if (scoreCutOff < 1) {
            needWeight = true;
        }
        double baseCount = 1E6;
        line = brScore.readLine();
        cells = line.split("\t");
        if (popuNames != null) {
            effecIndex = new int[popuNames.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (popuNames[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 0; i < effecIndex.length; i++) {
                effecIndex[i] = i;
            }
        }

        double[] itemCell;
        double freq;
        double score;
        int scoreInt = 1;
        int index;
        String[] geneList;
        String geneSymb;
        byte typeID = -1;
        int mafStartIndex = 0;
        Map<String, double[]> driverGeneScoresTmp = new HashMap<String, double[]>(driverGeneScores);
        driverGeneScores.clear();
        double[] tmpArray = null;
        for (Map.Entry<String, double[]> items : driverGeneScoresTmp.entrySet()) {
            tmpArray = new double[items.getValue().length + effecIndex.length];
            Arrays.fill(tmpArray, 0);
            System.arraycopy(items.getValue(), 0, tmpArray, 0, items.getValue().length);
            driverGeneScores.put(items.getKey(), tmpArray);
        }
        mafStartIndex = tmpArray.length - effecIndex.length;

        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");

            boolean hasError = false;
            for (int i = 0; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[effecIndex[i]]);
                if (freq < mafCutOff) {
                    geneList = cells[cells.length - 1].split(";");
                    for (int t = 0; t < geneList.length; t++) {
                        index = geneList[t].lastIndexOf(':');

                        geneSymb = geneList[t].substring(0, index);

                        itemCell = driverGeneScores.get(geneSymb);
                        if (itemCell == null) {
                            continue;
                        }
                        typeID = Byte.parseByte(geneList[t].substring(index + 1));

                        if (featureIDList.contains(typeID)) {
                            if (isWeightFeaure) {
                                if (cells[cells.length - 2].equals(".")) {
                                    scoreInt = 1;
                                } else {
                                    score = Double.parseDouble(cells[cells.length - 2]);
                                    scoreInt = (int) (score / scoreCutOff);
                                    scoreInt += 1;
                                }
                                itemCell[mafStartIndex + i] += (freq * scoreInt);
                            } else {
                                itemCell[mafStartIndex + i] += freq;
                            }
                            hittedGeneSet.add(geneSymb);

                        }

                    }

                }
            }
        }
        brScore.close();

    }

    public void appendGeneVarFreq(String geneCoVarFilePath, String[] popuNames, int mafBins, double scoreCutOff,
            Set<Byte> featureIDList, boolean isWeightFeaure, Map<String, double[]> driverGeneScores, Set<String> hittedGeneSet) throws Exception {
        String line;
        String[] cells;
        BufferedReader brScore = LocalFileFunc.getBufferedReader(geneCoVarFilePath);
        int[] effecIndex;
        line = brScore.readLine();
        cells = line.split("\t");
        if (popuNames != null) {
            effecIndex = new int[popuNames.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (popuNames[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 0; i < effecIndex.length; i++) {
                effecIndex[i] = i;
            }
        }

        double[] itemCell;
        double freq;
        double score;
        int scoreInt = 1;
        int index;
        String[] geneList;
        String geneSymb;
        byte typeID = -1;

        double mafSeg = 0.5 / mafBins;
        double[] mafCutOffs = new double[mafBins];
        for (int k = 0; k < mafBins; k++) {
            mafCutOffs[k] = (k + 1) * mafSeg;
        }

        boolean hasError;
        String idString;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");

            hasError = false;
            for (int i = 0; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[effecIndex[i]]);

                geneList = cells[cells.length - 1].split(";");
                for (int t = 0; t < geneList.length; t++) {
                    index = geneList[t].lastIndexOf(':');

                    geneSymb = geneList[t].substring(0, index);
                    idString = geneList[t].substring(index + 1);

                    typeID = Byte.parseByte(idString);

                    if (featureIDList.contains(typeID)) {
                        itemCell = driverGeneScores.get(geneSymb);
                        if (itemCell == null) {
                            itemCell = new double[mafBins];
                            Arrays.fill(itemCell, 0);
                            driverGeneScores.put(geneSymb, itemCell);
                        }
                        if (isWeightFeaure) {
                            if (cells[cells.length - 2].equals(".")) {
                                scoreInt = 1;
                            } else {
                                score = Double.parseDouble(cells[cells.length - 2]);
                                scoreInt = (int) (score / scoreCutOff);
                                scoreInt += 1;
                            }
                            for (int k = 0; k < mafBins; k++) {
                                if (freq <= mafCutOffs[k]) {
                                    itemCell[k] += (freq * scoreInt);
                                }
                            }
                        } else {
                            for (int k = 0; k < mafBins; k++) {
                                if (freq <= mafCutOffs[k]) {
                                    itemCell[k] += freq;
                                }
                            }
                        }
                        hittedGeneSet.add(geneSymb);

                    }

                }

            }
        }
        brScore.close();

    }

    public void generateGeneVarFreq(Chromosome chr, int mafBins, double centerMaf, double scoreBin, int popuNum, int scoreIndex,
            Set<Byte> featureIDList, int maxIntronIDs, boolean isWeightFeaure, Map<String, double[]> geneFrqScores, Set<String> hittedGeneSet) throws Exception {
        List<Variant> snpList = chr.variantList;
        String[] cells;

        int geneIndex = popuNum;

        double[] itemCell;
        double freq;
        double score;

        int index, index0, intronID;
        String[] geneList;
        String geneSymb;
        int scoreInt;
        byte typeID = -1;

        double minMAD = 0;
        double maxMAF = centerMaf;
        if (maxMAF > 1) {
            maxMAF = 1;
        }
        double mafSeg = (maxMAF - minMAD) / mafBins;
        double[] mafCutOffs = new double[mafBins];
        for (int k = 0; k < mafBins; k++) {
            mafCutOffs[k] = (minMAD + mafSeg * (k + 1));
        }

        boolean hasError;
        String idString;
        Set<String> addedGene = new HashSet<String>();

        for (Variant var : snpList) {
            cells = var.getFeatureValues();

            hasError = false;
            for (int i = 0; i < popuNum; i++) {
                hasError = !Util.isNumeric(cells[i]) || cells[i].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[i]);
                geneList = cells[geneIndex].split(";");
                addedGene.clear();
                scoreInt = 1;
                if (isWeightFeaure) {
                    if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {
                        scoreInt = 1;
                    } else {
                        score = Double.parseDouble(cells[scoreIndex]);
                        scoreInt = (int) (score / scoreBin);
                        scoreInt += 1;
                    }
                }

                for (int t = 0; t < geneList.length; t++) {
                    index = geneList[t].lastIndexOf(':');

                    geneSymb = geneList[t].substring(0, index);
                    index0 = geneList[t].lastIndexOf('-');
                    if (index0 < index) {
                        idString = geneList[t].substring(index + 1);
                    } else {
                        idString = geneList[t].substring(index + 1, index0);
                        intronID = Integer.parseInt(geneList[t].substring(index0 + 1));
                        if (intronID > maxIntronIDs) {
                            continue;
                        }
                    }

                    if (addedGene.contains(geneSymb)) {
                        continue;
                    }
                    typeID = Byte.parseByte(idString);

                    if (featureIDList.contains(typeID)) {
                        itemCell = geneFrqScores.get(geneSymb);
                        if (itemCell == null) {
                            itemCell = new double[mafBins];
                            Arrays.fill(itemCell, 0);
                            geneFrqScores.put(geneSymb, itemCell);
                        }

                        for (int k = 0; k < mafBins; k++) {
                            if (freq <= mafCutOffs[k]) {
                                itemCell[k] += (freq * scoreInt);
                            }
                        }
                        addedGene.add(geneSymb);
                        hittedGeneSet.add(geneSymb);
                    }
                }
            }
        }

    }

    public void generateGeneVarMinIDFreq(Chromosome chr, int mafBins, double centerMaf, double scoreBin, int popuNum, int scoreIndex,
            Set<Byte> featureIDList, int maxIntronIDs, boolean isWeightFeaure, Map<String, double[]> geneFrqScores, Set<String> hittedGeneSet) throws Exception {
        List<Variant> snpList = chr.variantList;
        String[] cells;

        int geneIndex = popuNum;

        double[] itemCell;
        double freq;
        double score;

        int index, index0, intronID;
        String[] geneList;
        String geneSymb;
        int scoreInt;
        byte typeID = -1;
        Map<String, byte[]> geneVarIDMap = new HashMap<String, byte[]>();

        double minMAD = centerMaf;
        double maxMAF = centerMaf;
        if (maxMAF > 1) {
            maxMAF = 1;
        }
        double mafSeg = (maxMAF - minMAD) / mafBins;
        double[] mafCutOffs = new double[mafBins];
        for (int k = 0; k < mafBins; k++) {
            mafCutOffs[k] = (minMAD + mafSeg * k);
        }

        boolean hasError;
        String idString;

        byte[] ids;

        for (Variant var : snpList) {
            cells = var.getFeatureValues();

            hasError = false;
            for (int i = 0; i < popuNum; i++) {
                hasError = !Util.isNumeric(cells[i]) || cells[i].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[i]);
                geneList = cells[geneIndex].split(";");

                scoreInt = 1;

                if (isWeightFeaure) {
                    if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {
                        scoreInt = 1;
                    } else {
                        score = Double.parseDouble(cells[scoreIndex]);
                        scoreInt = (int) (score / scoreBin);
                        scoreInt += 1;
                    }
                }

                geneVarIDMap.clear();
                for (int t = 0; t < geneList.length; t++) {
                    index = geneList[t].lastIndexOf(':');

                    geneSymb = geneList[t].substring(0, index);
                    index0 = geneList[t].lastIndexOf('-');
                    if (index0 < index) {
                        idString = geneList[t].substring(index + 1);
                    } else {
                        idString = geneList[t].substring(index + 1, index0);
                        intronID = Integer.parseInt(geneList[t].substring(index0 + 1));
                        if (intronID > maxIntronIDs) {
                            continue;
                        }
                    }
                    typeID = Byte.parseByte(idString);

                    ids = geneVarIDMap.get(geneSymb);
                    if (ids == null) {
                        ids = new byte[]{typeID};
                        geneVarIDMap.put(geneSymb, ids);
                    } else {
                        if (ids[0] > typeID) {
                            ids[0] = typeID;
                        }
                    }
                }

                for (Map.Entry<String, byte[]> item : geneVarIDMap.entrySet()) {
                    ids = item.getValue();
                    geneSymb = item.getKey();

                    if (featureIDList.contains(ids[0])) {
                        itemCell = geneFrqScores.get(geneSymb);
                        if (itemCell == null) {
                            itemCell = new double[mafBins];
                            Arrays.fill(itemCell, 0);
                            geneFrqScores.put(geneSymb, itemCell);
                        }
                        if (freq == 0) {
                            continue;
                        }

                        for (int k = 0; k < mafBins; k++) {
                            if (freq <= mafCutOffs[k]) {
                                itemCell[k] += (freq * scoreInt);
                            }
                        }
                        hittedGeneSet.add(geneSymb);
                    }

                }

            }
        }

    }

    public void generateGeneAllVarMinIDFreq(Chromosome chr, int popuNum, int scoreIndex, Set<Byte> dependentGeneFeature,
            Set<Byte> independentGeneFeature, int maxIntronIDs, boolean isWeightFeaure, Map<String, DoubleArrayList> geneDepVarFreqScoreMap, Set<String> hittedGeneSet) throws Exception {
        List<Variant> snpList = chr.variantList;
        List<Gene> chrGeneList = chr.geneList;
        String[] cells;

        int geneIndex = popuNum;

        double[] itemCell;
        double freq;
        double score;

        int index, index0, intronID;
        String[] geneList;
        String geneSymb;

        byte typeID = -1;
        Map<String, byte[]> geneVarIDMap = new HashMap<String, byte[]>();

        Map<String, DoubleArrayList> geneIndepMutScoreMap = new HashMap<String, DoubleArrayList>();

        boolean hasError;
        String idString;

        byte[] ids;
        double avgFreq = 0;
        int effectiveNum = 0;
        double amplifier = 1;

        for (Variant var : snpList) {

            cells = var.getFeatureValues();

            hasError = false;
            avgFreq = 0;
            effectiveNum = 0;
            for (int i = 0; i < popuNum; i++) {
                hasError = !Util.isNumeric(cells[i]) || cells[i].equals("NaN");
                if (hasError) {
                    freq = 0;
                    //break;
                } else {
                    freq = Double.parseDouble(cells[i]);
                    freq *= amplifier;
                }
                avgFreq += freq;
                effectiveNum++;
            }
            if (effectiveNum == 0) {
                continue;
            }
            avgFreq = avgFreq / effectiveNum;

            geneList = cells[geneIndex].split(";");
            geneVarIDMap.clear();
            for (int t = 0; t < geneList.length; t++) {
                index = geneList[t].lastIndexOf(':');
                geneSymb = geneList[t].substring(0, index);
                index0 = geneList[t].lastIndexOf('-');
                if (index0 < index) {
                    idString = geneList[t].substring(index + 1);
                } else {
                    idString = geneList[t].substring(index + 1, index0);
                    intronID = Integer.parseInt(geneList[t].substring(index0 + 1));
                    if (intronID > maxIntronIDs) {
                        continue;
                    }
                }
                typeID = Byte.parseByte(idString);

                ids = geneVarIDMap.get(geneSymb);
                if (ids == null) {
                    ids = new byte[]{typeID};
                    geneVarIDMap.put(geneSymb, ids);
                } else {
                    if (ids[0] > typeID) {
                        ids[0] = typeID;
                    }
                }
            }

            score = Double.NaN;

            if (isWeightFeaure) {
                if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {
                } else {
                    score = Double.parseDouble(cells[scoreIndex]);
                }
            }

            for (Map.Entry<String, byte[]> item : geneVarIDMap.entrySet()) {
                ids = item.getValue();
                geneSymb = item.getKey();
                hittedGeneSet.add(geneSymb);

                //give a priority to dependentNum
                if (dependentGeneFeature.contains(ids[0])) {
                    DoubleArrayList alleleNumsScore = geneDepVarFreqScoreMap.get(geneSymb);
                    //as giving a priority to dependentNum may produce bias, we can limit this by 
                    if (alleleNumsScore == null) {
                        alleleNumsScore = new DoubleArrayList();
                        geneDepVarFreqScoreMap.put(geneSymb, alleleNumsScore);
                    }
                    alleleNumsScore.add(avgFreq);
                    alleleNumsScore.add(score);

                } else if (independentGeneFeature.contains(ids[0])) {
                    DoubleArrayList alleleNumsScore = geneIndepMutScoreMap.get(geneSymb);
                    if (alleleNumsScore == null) {
                        alleleNumsScore = new DoubleArrayList();
                        geneIndepMutScoreMap.put(geneSymb, alleleNumsScore);
                    }
                    alleleNumsScore.add(avgFreq);
                    alleleNumsScore.add(score);
                }
            }

        }

        chrGeneList.clear();
        if (isWeightFeaure) {
            Map<String, DoubleArrayList> geneScoreMapTmp = new HashMap<String, DoubleArrayList>();
            int size, naNum;
            //remove genes with all NA scores because it can introduce biases
            for (Map.Entry<String, DoubleArrayList> item : geneDepVarFreqScoreMap.entrySet()) {
                DoubleArrayList alleleNumsScore = item.getValue();

                size = alleleNumsScore.size();
                naNum = 0;

                for (int i = 0; i < size; i += 2) {
                    if (Double.isNaN(alleleNumsScore.getQuick(i + 1))) {
                        naNum++;
                    }
                }
                //ignore genes with too many missing scores at variants
//                if (naNum >= (size * 9 / 20)) {
//                    continue;
//                }
                geneScoreMapTmp.put(item.getKey(), alleleNumsScore);
            }
            geneDepVarFreqScoreMap.clear();
            geneDepVarFreqScoreMap.putAll(geneScoreMapTmp);
            geneScoreMapTmp.clear();

            //remove genes with all NA scores because it can introduce biases
            for (Map.Entry<String, DoubleArrayList> item : geneIndepMutScoreMap.entrySet()) {
                DoubleArrayList alleleNumsScore = item.getValue();
                size = alleleNumsScore.size();
                naNum = 0;
                for (int i = 0; i < size; i += 2) {
                    if (Double.isNaN(alleleNumsScore.getQuick(i + 1))) {
                        naNum++;
                    }
                }
//                if (naNum >= size / 2) {
//                    continue;
//                }
                geneScoreMapTmp.put(item.getKey(), alleleNumsScore);
            }
            geneIndepMutScoreMap.clear();
            geneIndepMutScoreMap.putAll(geneScoreMapTmp);
            geneIndepMutScoreMap.clear();
        }

    }

    public void generateGeneVarFreq(Chromosome chr, int mafBins, double centerMaf, double[] scorePercentiles, double[] scoreCutoffs, boolean updateCutoff, int popuNum,
            int scoreIndex, Set<Byte> featureIDList, boolean isWeightFeaure, Map<String, double[]> geneFrqScores, Set<String> hittedGeneSet) throws Exception {
        List<Variant> snpList = chr.variantList;
        String[] cells;

        int geneIndex = popuNum;

        double[] itemCell;
        double freq;
        double score;

        int index;
        String[] geneList;
        String geneSymb;
        int scoreInt;
        byte typeID = -1;

        double mafSeg = 0.0025;
        double[] mafCutOffs = new double[mafBins];
        for (int k = 0; k < mafBins; k++) {
            mafCutOffs[k] = (centerMaf - mafSeg * mafBins / 2) + k * mafSeg;
        }

        boolean hasError;
        String idString;
        Set<String> addedGene = new HashSet<String>();
        DoubleArrayList scoreList = new DoubleArrayList();

        if (isWeightFeaure && updateCutoff) {
            for (Variant var : snpList) {
                cells = var.getFeatureValues();
                if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {

                } else {
                    score = Double.parseDouble(cells[scoreIndex]);
                    scoreList.add(score);
                }
            }
            scoreList.quickSort();
            int size = scoreList.size();
            for (int i = 0; i < scorePercentiles.length; i++) {
                scoreCutoffs[i] = scoreList.getQuick((int) (size * scorePercentiles[i]));
            }
        }

        for (Variant var : snpList) {
            cells = var.getFeatureValues();

            hasError = false;
            for (int i = 0; i < popuNum; i++) {
                hasError = !Util.isNumeric(cells[i]) || cells[i].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[i]);
                geneList = cells[geneIndex].split(";");
                addedGene.clear();
                scoreInt = 1;
                if (isWeightFeaure) {
                    if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {
                        scoreInt = 1;
                    } else {
                        score = Double.parseDouble(cells[scoreIndex]);

                        scoreInt = Arrays.binarySearch(scoreCutoffs, score);
                        if (scoreInt < 0) {
                            scoreInt = -scoreInt;
                        } else {
                            scoreInt++;
                        }
                    }
                }

                for (int t = 0; t < geneList.length; t++) {
                    index = geneList[t].lastIndexOf(':');

                    geneSymb = geneList[t].substring(0, index);
                    idString = geneList[t].substring(index + 1);
                    if (addedGene.contains(geneSymb)) {
                        continue;
                    }
                    typeID = Byte.parseByte(idString);

                    if (featureIDList.contains(typeID)) {
                        itemCell = geneFrqScores.get(geneSymb);
                        if (itemCell == null) {
                            itemCell = new double[mafBins];
                            Arrays.fill(itemCell, 0);
                            geneFrqScores.put(geneSymb, itemCell);
                        }
                        for (int k = 0; k < mafBins; k++) {
                            if (freq <= mafCutOffs[k]) {
                                itemCell[k] += (freq * scoreInt);
                            }
                        }
                        addedGene.add(geneSymb);
                        hittedGeneSet.add(geneSymb);
                    }
                }
            }
        }

    }

    public void generateGeneVarFreq(Chromosome chr, double centerMaf, double scoreBin, int popuNum, int scoreIndex, Set<Byte> featureIDList, boolean isWeightFeaure, Map<String, double[]> geneFrqScores, Set<String> hittedGeneSet) throws Exception {
        List<Variant> snpList = chr.variantList;
        String[] cells;

        int geneIndex = popuNum;

        double[] itemCell;
        double freq;
        double score;

        int index;
        String[] geneList;
        String geneSymb;
        int scoreInt;
        byte typeID = -1;

        boolean hasError;
        String idString;
        Set<String> addedGene = new HashSet<String>();
        for (Variant var : snpList) {
            cells = var.getFeatureValues();

            hasError = false;
            for (int i = 0; i < popuNum; i++) {
                hasError = !Util.isNumeric(cells[i]) || cells[i].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[i]);
                geneList = cells[geneIndex].split(";");
                addedGene.clear();
                scoreInt = 1;
                if (isWeightFeaure) {
                    if (cells[scoreIndex] == null || cells[scoreIndex].equals(".")) {
                        scoreInt = 1;
                    } else {
                        score = Double.parseDouble(cells[scoreIndex]);
                        scoreInt = (int) (score / scoreBin);
                        scoreInt += 1;
                    }
                }

                for (int t = 0; t < geneList.length; t++) {
                    index = geneList[t].lastIndexOf(':');

                    geneSymb = geneList[t].substring(0, index);
                    idString = geneList[t].substring(index + 1);
                    if (addedGene.contains(geneSymb)) {
                        continue;
                    }
                    typeID = Byte.parseByte(idString);

                    if (featureIDList.contains(typeID)) {
                        itemCell = geneFrqScores.get(geneSymb);
                        if (itemCell == null) {
                            itemCell = new double[popuNum];
                            Arrays.fill(itemCell, 0);
                            geneFrqScores.put(geneSymb, itemCell);
                        }
                        if (freq <= centerMaf) {
                            itemCell[i] += (freq * scoreInt);
                        }
                        addedGene.add(geneSymb);
                        hittedGeneSet.add(geneSymb);
                    }
                }
            }
        }

    }

    private int parseInt(final byte[] s, int start, int end) {
        // Check for a sign.
        int num = 0;
        int sign = -1;
        int i = start;
        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        //' ': 32
        while (s[i] == 32) {
            i++;
        }

        final byte ch = s[i++];
        if (ch == 45) {
            sign = 1;
        } else {
            num = 48 - ch;
        }

        // Build the number. 
        while (i < end) {
            if (s[i] == 46) {
                return sign * num;
            } else if (s[i] < 48 || s[i] > 57) {
                i++;
            } else {
                num = num * 10 + 48 - s[i++];
            }
        }
        return sign * num;
    }

    private boolean equal(byte[] src, int start, int end, byte[] tar) {
        if (end - start != tar.length) {
            return false;
        }
        for (int i = start; i < end; i++) {
            if (src[i] != tar[i - start]) {
                return false;
            }
        }
        return true;
    }

    private int indexof(byte[] src, int start, int end, byte tar) {
        if (end - start < 1) {
            return -1;
        }
        for (int i = end - 1; i >= start; i--) {
            if (tar == src[i]) {
                return i;
            }
        }
        return -1;
    }

    private float parseFloat(byte[] f, int start, int end) {
        double ret = 0f;         // return value
        int pos = start;          // read pointer position
        int part = 0;          // the current part (int, float and sci parts of the number)
        boolean neg = false;      // true if part is a negative number
        // the max long is 2147483647
        final int MAX_INT_BIT = 9;

        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        while (f[pos] == ' ') {
            pos++;
        }
        // find start
        while (pos < end && (f[pos] < 48 || f[pos] > 57) && f[pos] != 45 && f[pos] != 46) {
            pos++;
        }

        // sign
        if (f[pos] == 45) {
            neg = true;
            pos++;
        }

        // integer part
        while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
            part = part * 10 + (f[pos++] - 48);
        }
        ret = neg ? (double) (part * -1) : (double) part;

        // float part
        if (pos < end && f[pos] == 46) {
            pos++;
            int mul = 1;
            part = 0;
            int num = 0;
            while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                num++;
                if (num <= MAX_INT_BIT) {
                    part = part * 10 + (f[pos] - 48);
                    mul *= 10;
                }
                pos++;
            }
            ret = neg ? ret - (double) part / (double) mul : ret + (double) part / (double) mul;
        }

        // scientific part
        if (pos < end && (f[pos] == 101 || f[pos] == 69)) {
            pos++;
            if (pos < end) {
                neg = (f[pos] == 45);
                pos++;
                part = 0;
                while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                    part = part * 10 + (f[pos++] - 48);
                }
                if (neg) {
                    ret = ret / Math.pow(10, part);
                } else {
                    ret = ret * Math.pow(10, part);
                }
            }
        }
        return (float) ret;
    }
    private int[] tempInt;

    private int[] tokenizeDelimiter(byte[] string, int startI, int endI, byte delimiter) {
        int tempLength = ((endI - startI) / 2) + 2;
        if (tempInt == null || tempInt.length < tempLength) {
            tempInt = new int[tempLength];
        }

        int i = startI;
        int j = 0;

        int wordCount = 0;
        int tt = startI;
        tempInt[wordCount] = startI;
        wordCount++;
        if (endI > string.length) {
            endI = string.length;
        }
        j = -1;
        for (; tt < endI; tt++) {
            if (string[tt] == delimiter) {
                j = tt;
                break;
            }
        }

        while (j >= 0 && j <= endI) {
            tempInt[wordCount] = j;
            wordCount++;
            i = j + 1;
            j = -1;
            for (tt = i; tt < endI; tt++) {
                if (string[tt] == delimiter) {
                    j = tt;
                    break;
                }
            }
        }

        if (i <= endI) {
            // tempInt[wordCount++] = k;
            tempInt[wordCount] = endI;
            wordCount++;
        }

        int[] result = new int[wordCount];
        System.arraycopy(tempInt, 0, result, 0, wordCount);
        return result;
    }

    public Chromosome readAnnotGeneVarFreq(String geneCoVarFilePath, int chromNameID, int[] effecIndex, int extraIndex, Set<Byte> featureIDList) throws Exception {
        byte[] currentLine;
        String chromName = STAND_CHROM_NAMES[chromNameID];
        BGZFInputStream bfIndexes = new BGZFInputStream(geneCoVarFilePath, 1, true);
        if (!bfIndexes.checkIndex()) {
            bfIndexes.adjustPos();
            bfIndexes.buildIndex(geneCoVarFilePath, chromNameID, 1, false);
        }
        bfIndexes.readIndex(chromNameID == 0, chromName);

        long[] pos = bfIndexes.findIndex(0, Integer.MAX_VALUE);
        if (pos[0] == pos[1]) {

            return null;
        }
        final BGZFInputStream bf = new BGZFInputStream(geneCoVarFilePath, 1, true);
        bf.adjustPos(pos[0], pos[1]);

        bf.creatSpider(pos[0] != 0);
        //skip the head line
        bf.spider[0].readLine();

        BZPartReader brScore = bf.spider[0];
        int[] cellDelimts = new int[15];

        String[] alleles;
        Chromosome chrom = new Chromosome(chromName, 0);
        List<Variant> variantList = chrom.variantList;
        int index;

        byte typeID = -1;

        byte[] currChr = chromName.getBytes();
        int[] mafIndexInCol;
        int filePosition;
        int indexCHROM = 0;
        int indexPOS = 1;
        int indexAllele = 2;
        String[] freq = new String[effecIndex.length];
        boolean isHit = false;
        while ((currentLine = brScore.readLine(cellDelimts)) != null) {
            if (cellDelimts[0] == 1) {
                continue;
            }

            if (!equal(currentLine, indexCHROM == 0 ? 0 : cellDelimts[indexCHROM] + 1, cellDelimts[indexCHROM + 1], currChr)) {
                continue;
            }
            isHit = false;
            mafIndexInCol = tokenizeDelimiter(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]], (byte) ';');
            for (int t = 1; t < mafIndexInCol.length; t++) {
                index = indexof(currentLine, t == 1 ? mafIndexInCol[t - 1] : mafIndexInCol[t - 1] + 1, mafIndexInCol[t], (byte) ':');
                typeID = (byte) parseInt(currentLine, index + 1, mafIndexInCol[t]);
                if (!featureIDList.contains(typeID)) {
                    continue;
                }
                isHit = true;

                for (int i = 0; i < effecIndex.length; i++) {
                    freq[i] = new String(Arrays.copyOfRange(currentLine, cellDelimts[effecIndex[i]] + 1, cellDelimts[effecIndex[i] + 1]));
                }
            }
            if (isHit) {
                alleles = (new String(Arrays.copyOfRange(currentLine, cellDelimts[indexAllele] + 1, cellDelimts[indexAllele + 1]))).split("/");
                String[] altAlleles = new String[alleles.length - 1];
                System.arraycopy(alleles, 1, altAlleles, 0, alleles.length - 1);
                filePosition = parseInt(currentLine, indexPOS == 0 ? 0 : cellDelimts[indexPOS] + 1, cellDelimts[indexPOS + 1]);

                Variant var = new Variant(filePosition, alleles[0], altAlleles);

                variantList.add(var);
                for (int i = 0; i < effecIndex.length; i++) {
                    var.setFeatureValue(i, freq[i]);
                }
                var.setFeatureValue(effecIndex.length + extraIndex, new String(Arrays.copyOfRange(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]])));
            }
        }
        brScore.closeInputStream();
        return chrom;
    }

    public Chromosome readAnnotGeneVarFreq(String geneCoVarFilePath, int chromNameID, int effecIndex, int insideIndex, int totalMafNum,
            Set<Byte> featureIDList, int maxIntron, boolean useMinID, int ctType) throws Exception {
        byte[] currentLine;
        String chromName = STAND_CHROM_NAMES[chromNameID];
        BGZFInputStream bfIndexes = new BGZFInputStream(geneCoVarFilePath, 1, true);
        if (!bfIndexes.checkIndex()) {
            bfIndexes.adjustPos();
            bfIndexes.buildIndex(geneCoVarFilePath, 0, 1, true);
        }
        bfIndexes.readIndex(false, chromName);

        long[] pos = bfIndexes.findIndex(0, Integer.MAX_VALUE);
        if (pos[0] == pos[1]) {

            return null;
        }
        final BGZFInputStream bf = new BGZFInputStream(geneCoVarFilePath, 1, true);
        bf.adjustPos(pos[0], pos[1]);

        bf.creatSpider(pos[0] != 0);
        //skip the head line
        bf.spider[0].readLine();

        BZPartReader brScore = bf.spider[0];
        int[] cellDelimts = new int[15];

        String[] alleles;
        Chromosome chrom = new Chromosome(chromName, 0);
        List<Variant> variantList = chrom.variantList;
        int index, index0, intronID;

        byte typeID = -1;

        byte[] currChr = chromName.getBytes();
        int[] mafIndexInCol;
        int filePosition;
        int indexCHROM = 0;
        int indexPOS = 1;
        int indexAllele = 2;
        String freq;
        boolean isHit = false;
        byte minTypeID = 0;
        boolean needSubIntron = false;
        int minIntron = Integer.MAX_VALUE;
        if (maxIntron != Integer.MAX_VALUE) {
            needSubIntron = true;
        }

        while ((currentLine = brScore.readLine(cellDelimts)) != null) {
            if (cellDelimts[0] == 1) {
                continue;
            }

            if (!equal(currentLine, indexCHROM == 0 ? 0 : cellDelimts[indexCHROM] + 1, cellDelimts[indexCHROM + 1], currChr)) {
                continue;
            }
            alleles = (new String(Arrays.copyOfRange(currentLine, cellDelimts[indexAllele] + 1, cellDelimts[indexAllele + 1]))).split("/");
            if (ctType == 1) {
                //only ouse ct variants 
                if (!(alleles[0].toUpperCase().equals("C") && alleles[1].toUpperCase().equals("T")) && !(alleles[0].toUpperCase().equals("T") && alleles[1].toUpperCase().equals("C"))) {
                    continue;
                }

            } else if (ctType == 2) {
                //exclude ct variants 
                if ((alleles[0].toUpperCase().equals("C") && alleles[1].toUpperCase().equals("T")) || (alleles[0].toUpperCase().equals("T") && alleles[1].toUpperCase().equals("C"))) {
                    continue;
                }
            }
            isHit = false;
            //assume the last column is gene variant type column
            mafIndexInCol = tokenizeDelimiter(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]], (byte) ';');
            if (useMinID) {
                minTypeID = Byte.MAX_VALUE;
                for (int t = 1; t < mafIndexInCol.length; t++) {
                    index = indexof(currentLine, t == 1 ? mafIndexInCol[t - 1] : mafIndexInCol[t - 1] + 1, mafIndexInCol[t], (byte) ':');
                    index0 = indexof(currentLine, index + 1, mafIndexInCol[t], (byte) '-');
                    if (index0 < 0) {
                        typeID = (byte) parseInt(currentLine, index + 1, mafIndexInCol[t]);
                    } else {
                        typeID = (byte) parseInt(currentLine, index + 1, index0);
                    }

                    if (minTypeID >= typeID) {
                        minTypeID = typeID;
                        if (needSubIntron) {
                            if (typeID == 11 && index0 >= 0) {
                                intronID = parseInt(currentLine, index0 + 1, mafIndexInCol[t]);
                                if (minIntron > intronID) {
                                    minIntron = intronID;
                                }
                            } else if (typeID != 11) {
                                //update it to be the maxima;
                                minIntron = Integer.MAX_VALUE;
                            }
                        }
                    }
                }
                if (featureIDList.contains(minTypeID)) {
                    if (needSubIntron) {
                        if (typeID == 11) {
                            if (minIntron <= maxIntron) {
                                isHit = true;
                            }
                        } else {
                            isHit = true;
                        }
                    } else {
                        isHit = true;
                    }
                }
            } else {
                for (int t = 1; t < mafIndexInCol.length; t++) {
                    index = indexof(currentLine, t == 1 ? mafIndexInCol[t - 1] : mafIndexInCol[t - 1] + 1, mafIndexInCol[t], (byte) ':');
                    index0 = indexof(currentLine, index + 1, mafIndexInCol[t], (byte) '-');
                    if (index0 < 0) {
                        typeID = (byte) parseInt(currentLine, index + 1, mafIndexInCol[t]);
                    } else {
                        typeID = (byte) parseInt(currentLine, index + 1, index0);
                    }

                    if (!featureIDList.contains(typeID)) {
                        continue;
                    }

                    if (needSubIntron) {
                        //the intron is too long, we usually only consider several regions
                        if (typeID == 11 && index0 >= 0) {
                            intronID = parseInt(currentLine, index0 + 1, mafIndexInCol[t]);
                            if (intronID <= maxIntron) {
                                isHit = true;
                                break;
                            }
                        } else {
                            isHit = true;
                            break;
                        }
                    } else {
                        isHit = true;
                        break;
                    }
                }
            }
            if (isHit) {
                alleles = (new String(Arrays.copyOfRange(currentLine, cellDelimts[indexAllele] + 1, cellDelimts[indexAllele + 1]))).split("/");
                String[] altAlleles = new String[alleles.length - 1];
                System.arraycopy(alleles, 1, altAlleles, 0, alleles.length - 1);
                filePosition = parseInt(currentLine, indexPOS == 0 ? 0 : cellDelimts[indexPOS] + 1, cellDelimts[indexPOS + 1]);

                Variant var = new Variant(filePosition, alleles[0], altAlleles);
                var.smallestFeatureID = minTypeID;
                variantList.add(var);
                freq = new String(Arrays.copyOfRange(currentLine, cellDelimts[effecIndex] + 1, cellDelimts[effecIndex + 1]));
                //set frequency and gene feature types
                var.setFeatureValue(insideIndex, freq);
                var.setFeatureValue(totalMafNum, new String(Arrays.copyOfRange(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]])));
            }
        }
        brScore.closeInputStream();
        return chrom;
    }

    public void appendAnnotGeneVarFreq(Chromosome chrom, String geneCoVarFilePath, int chromNameID, int[] effecIndex, int startIndex, Set<Byte> featureIDList) throws Exception {
        byte[] currentLine;
        String chromName = STAND_CHROM_NAMES[chromNameID];
        BGZFInputStream bfIndexes = new BGZFInputStream(geneCoVarFilePath, 1, true);
        if (!bfIndexes.checkIndex()) {
            bfIndexes.adjustPos();
            bfIndexes.buildIndex(geneCoVarFilePath, chromNameID, 1, false);
        }
        bfIndexes.readIndex(chromNameID == 0, chromName);

        long[] pos = bfIndexes.findIndex(0, Integer.MAX_VALUE);
        if (pos[0] == pos[1]) {

            return;
        }
        final BGZFInputStream bf = new BGZFInputStream(geneCoVarFilePath, 1, true);
        bf.adjustPos(pos[0], pos[1]);

        bf.creatSpider(pos[0] != 0);
        //skip the head line
        bf.spider[0].readLine();

        BZPartReader brScore = bf.spider[0];
        int[] cellDelimts = new int[15];

        String[] alleles;

        List<Variant> variantList = chrom.variantList;
        int index;

        byte typeID = -1;

        byte[] currChr = chromName.getBytes();
        int[] mafIndexInCol;
        int filePosition;
        int indexCHROM = 0;
        int indexPOS = 1;
        int indexAllele = 2;
        String[] freq = new String[effecIndex.length];
        boolean isHit = false;
        while ((currentLine = brScore.readLine(cellDelimts)) != null) {
            if (cellDelimts[0] == 1) {
                continue;
            }

            if (!equal(currentLine, indexCHROM == 0 ? 0 : cellDelimts[indexCHROM] + 1, cellDelimts[indexCHROM + 1], currChr)) {
                continue;
            }
            isHit = false;
            mafIndexInCol = tokenizeDelimiter(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]], (byte) ';');
            for (int t = 1; t < mafIndexInCol.length; t++) {
                index = indexof(currentLine, t == 1 ? mafIndexInCol[t - 1] : mafIndexInCol[t - 1] + 1, mafIndexInCol[t], (byte) ':');
                typeID = (byte) parseInt(currentLine, index + 1, mafIndexInCol[t]);
                if (!featureIDList.contains(typeID)) {
                    continue;
                }
                isHit = true;

                for (int i = 0; i < effecIndex.length; i++) {
                    freq[i] = new String(Arrays.copyOfRange(currentLine, cellDelimts[effecIndex[i]] + 1, cellDelimts[effecIndex[i] + 1]));
                }
            }
            if (isHit) {
                alleles = (new String(Arrays.copyOfRange(currentLine, cellDelimts[indexAllele] + 1, cellDelimts[indexAllele + 1]))).split("/");
                String[] altAlleles = new String[alleles.length - 1];
                System.arraycopy(alleles, 1, altAlleles, 0, alleles.length - 1);
                filePosition = parseInt(currentLine, indexPOS == 0 ? 0 : cellDelimts[indexPOS] + 1, cellDelimts[indexPOS + 1]);
                int poss = chrom.lookupVariantByMap(filePosition);
                if (poss >= 0) {
                    Variant var = variantList.get(poss);
                    for (int i = 0; i < effecIndex.length; i++) {
                        var.setFeatureValue(i + startIndex, freq[i]);
                    }
                    continue;
                }
                Variant var = new Variant(filePosition, alleles[0], altAlleles);

                variantList.add(var);
                for (int i = 0; i < effecIndex.length; i++) {
                    var.setFeatureValue(i + startIndex, freq[i]);
                }
                var.setFeatureValue(effecIndex.length, new String(Arrays.copyOfRange(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]])));
            }
        }
        brScore.closeInputStream();
    }

    public void appendAnnotGeneVarFreq(Chromosome chrom, String geneCoVarFilePath, int chromNameID, int effecIndex, int freqIndex, int annotIndex, Set<Byte> featureIDList) throws Exception {
        byte[] currentLine;
        String chromName = STAND_CHROM_NAMES[chromNameID];
        BGZFInputStream bfIndexes = new BGZFInputStream(geneCoVarFilePath, 1, true);
        if (!bfIndexes.checkIndex()) {
            bfIndexes.adjustPos();
            bfIndexes.buildIndex(geneCoVarFilePath, chromNameID, 1, false);
        }
        bfIndexes.readIndex(chromNameID == 0, chromName);

        long[] pos = bfIndexes.findIndex(0, Integer.MAX_VALUE);
        if (pos[0] == pos[1]) {

            return;
        }
        final BGZFInputStream bf = new BGZFInputStream(geneCoVarFilePath, 1, true);
        bf.adjustPos(pos[0], pos[1]);

        bf.creatSpider(pos[0] != 0);
        //skip the head line
        bf.spider[0].readLine();

        BZPartReader brScore = bf.spider[0];
        int[] cellDelimts = new int[15];

        String[] alleles;

        List<Variant> variantList = chrom.variantList;
        int index;

        byte typeID = -1;

        byte[] currChr = chromName.getBytes();
        int[] mafIndexInCol;
        int filePosition;
        int indexCHROM = 0;
        int indexPOS = 1;
        int indexAllele = 2;
        String freq, freq1;
        double freqD1;
        boolean isHit = false;
        while ((currentLine = brScore.readLine(cellDelimts)) != null) {
            if (cellDelimts[0] == 1) {
                continue;
            }

            if (!equal(currentLine, indexCHROM == 0 ? 0 : cellDelimts[indexCHROM] + 1, cellDelimts[indexCHROM + 1], currChr)) {
                continue;
            }
            isHit = false;
            mafIndexInCol = tokenizeDelimiter(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]], (byte) ';');
            for (int t = 1; t < mafIndexInCol.length; t++) {
                index = indexof(currentLine, t == 1 ? mafIndexInCol[t - 1] : mafIndexInCol[t - 1] + 1, mafIndexInCol[t], (byte) ':');
                typeID = (byte) parseInt(currentLine, index + 1, mafIndexInCol[t]);
                if (!featureIDList.contains(typeID)) {
                    continue;
                }
                isHit = true;

            }
            if (isHit) {
                alleles = (new String(Arrays.copyOfRange(currentLine, cellDelimts[indexAllele] + 1, cellDelimts[indexAllele + 1]))).split("/");
                String[] altAlleles = new String[alleles.length - 1];
                System.arraycopy(alleles, 1, altAlleles, 0, alleles.length - 1);
                filePosition = parseInt(currentLine, indexPOS == 0 ? 0 : cellDelimts[indexPOS] + 1, cellDelimts[indexPOS + 1]);
                freq = new String(Arrays.copyOfRange(currentLine, cellDelimts[effecIndex] + 1, cellDelimts[effecIndex + 1]));

                int poss = chrom.lookupVariantByMap(filePosition);
                if (poss >= 0) {
                    Variant var = variantList.get(poss);
                    var.setFeatureValue(freqIndex, freq);

                    // freq1=var.getFeatureValues()[freqIndex];
                    // freqD1=Double.parseDouble(freq1)+Double.parseDouble(freq);
                    // freqD1=freqD1/2;                   
                    //var.setFeatureValue(freqIndex, String.valueOf(freqD1));
                    continue;
                }
                Variant var = new Variant(filePosition, alleles[0], altAlleles);

                variantList.add(var);
                var.setFeatureValue(freqIndex, freq);
                var.setFeatureValue(annotIndex, new String(Arrays.copyOfRange(currentLine, cellDelimts[cellDelimts[0] - 1] + 1, cellDelimts[cellDelimts[0]])));
            }
        }
        brScore.closeInputStream();
    }

    public void appendGeneVar1KG(String geneCoVarFilePath, String[] popuNames, int mafStartIndex, double mafCutOff, double scoreCutOff,
            Map<String, double[]> driverGeneScores, Set<String> hittedGeneSet) throws Exception {
        String line;
        String[] cells;
        BufferedReader brScore = LocalFileFunc.getBufferedReader(geneCoVarFilePath);

        int[] effecIndex;
        boolean needWeight = false;
        if (scoreCutOff < 1) {
            needWeight = true;
        }
        double baseCount = 1E6;
        line = brScore.readLine();
        cells = line.split("\t");
        if (popuNames != null) {
            effecIndex = new int[popuNames.length];
            Arrays.fill(effecIndex, -1);

            for (int i = 0; i < effecIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (popuNames[i].equals(cells[j])) {
                        effecIndex[i] = j;
                        break;
                    }
                }
            }

        } else {
            effecIndex = new int[cells.length - 1];
            for (int i = 0; i < effecIndex.length; i++) {
                effecIndex[i] = i;
            }
        }

        double[] itemCell;
        double freq;
        double score;
        int scoreInt = 1;
        int index;
        String[] geneList;
        String geneSymb;
        int typeID = -1;
        while ((line = brScore.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t");

            boolean hasError = false;
            for (int i = 0; i < effecIndex.length; i++) {
                hasError = !Util.isNumeric(cells[effecIndex[i]]) || cells[effecIndex[i]].equals("NaN");
                if (hasError) {
                    break;
                }
                freq = Double.parseDouble(cells[effecIndex[i]]);
                if (freq < mafCutOff) {
                    geneList = cells[9].split(";");
                    for (int t = 0; t < geneList.length; t++) {
                        index = geneList[t].lastIndexOf(':');
                        geneSymb = geneList[t].substring(0, index);
                        itemCell = driverGeneScores.get(geneSymb);
                        if (itemCell == null) {
                            continue;
                        }
                        typeID = Integer.parseInt(geneList[t].substring(index + 1));
                        if (typeID == 7) {
                            itemCell[i * 2 + mafStartIndex + 1] += freq;
                        } else {
                            if (needWeight) {
                                if (cells[cells.length - 2].equals(".")) {
                                    scoreInt = 1;
                                } else {
                                    score = Double.parseDouble(cells[cells.length - 2]);
                                    scoreInt = (int) (score / scoreCutOff);
                                    scoreInt += 1;
                                }
                            }
                            itemCell[i * 2 + mafStartIndex] += (freq * scoreInt);
                        }
                        hittedGeneSet.add(geneSymb);
                    }

                }
            }

        }
        brScore.close();

    }

    public Map<String, Map<String, Integer>> readCosmicGeneAnnotation(String dbPath) throws Exception {
        int indexChrom = 0;
        int indexref = 3;
        int indexalt = 4;
        int indexaaref = 3;
        int indexaaalt = 4;
        int indexhg19pos = 1;
        int indexCancerInfo = 7;
        int indexGene = 4;

        int maxColNum = indexChrom;

        maxColNum = Math.max(maxColNum, indexCancerInfo);
        maxColNum = Math.max(maxColNum, indexGene);

        String currentLine = null;

        boolean incomplete;

        String geneStr = null;
        String cancerInfo = null;

        StringBuilder tmpBuffer = new StringBuilder();
        int cosmicVarNum = 0;

        File rsFile = new File(dbPath);
        if (!rsFile.exists()) {
            LOG.error(rsFile.getCanonicalPath() + " does not exist!");
            return null;
        }
        // System.out.print(" Chromosome " + Options.REF_CHROM_NAMES[chromID]);

        BufferedReader br = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
        // skip to the head line
        br.readLine();

        Map<String, Map<String, Integer>> cosmicGeneMut = new HashMap<String, Map<String, Integer>>();

        int num = 0;
        Integer num1;

        while ((currentLine = br.readLine()) != null) {
            // System.out.println(currentLine);
            String[] cells = Util.tokenize(currentLine, '\t', maxColNum);
            // initialize varaibles
            incomplete = true;

            geneStr = null;
            cancerInfo = null;
            geneStr = cells[indexGene];
            cancerInfo = cells[indexCancerInfo];;

            Map<String, Integer> canNum = cosmicGeneMut.get(geneStr);
            if (canNum == null) {
                canNum = new HashMap<String, Integer>();
                cosmicGeneMut.put(geneStr, canNum);
            }
            cancerInfo = cancerInfo.substring(1, cancerInfo.length() - 1);
            String[] cells1 = cancerInfo.split(",");
            for (String cell : cells1) {
                cells = Util.tokenize(cell, '=');
                num = Integer.parseInt(cells[1].trim());
                cells[0] = cells[0].trim();
                num1 = canNum.get(cells[0]);
                if (num1 != null) {
                    num += num1;
                }
                canNum.put(cells[0], num);
            }
            cosmicVarNum++;
        }
        br.close();
        StringBuilder info = new StringBuilder();
        info.append(cosmicVarNum).append(" variants in the COSMIC database are read.");
        LOG.info(info);
        return cosmicGeneMut;
    }

    public void enrichmentTestGeneSet(Map<String, GeneSet> dbPathwaySet, List<String[]> geneMutRateSheet, int minSetSize, double genePValueCutoff,
            String geneSumOutFile) throws Exception {
        int zIndex = -1, pIndex = -1;
        int t = 1, len = geneMutRateSheet.size();
        String[] item;
        Map<String, Double> geneZValueMap = new HashMap<String, Double>();
        Map<String, String> genePValueMap = new HashMap<String, String>();
        String[] colNames = geneMutRateSheet.get(0);
        for (int i = 0; i < colNames.length; i++) {
            if (colNames[i].equals("Residual")) {
                zIndex = i;
            }
            if (colNames[i].equals("P")) {
                pIndex = i;
                break;
            }
        }

        double z, p;
        for (t = 1; t < len; t++) {
            item = geneMutRateSheet.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }
            z = Double.parseDouble(item[zIndex]);
            geneZValueMap.put(item[0], z);
            genePValueMap.put(item[0], item[pIndex]);
        }

        DoubleArrayList zValueListOutPathway = new DoubleArrayList();
        DoubleArrayList zValueListInGeneSet = new DoubleArrayList();

        List<String[]> availableGWASGeneList = new ArrayList<String[]>();
        Double p1 = null;
        int subPopulationSize;
        DoubleArrayList geneSetPValuesForQQPlot = new DoubleArrayList();

        List<GeneSet> effectiveGeneSetList = new ArrayList<GeneSet>();

        for (Map.Entry<String, GeneSet> mPath : dbPathwaySet.entrySet()) {
            GeneSet curPath = mPath.getValue();
            String pathID = mPath.getKey();

            Set<String> pGenes = curPath.getGeneSymbols();
            zValueListInGeneSet.clear();
            zValueListOutPathway.clear();
            availableGWASGeneList.clear();

            Set<String> geneSymbolWeightMap = curPath.getGeneSymbols();

            for (String pGeneSymb : geneSymbolWeightMap) {
                //may introduce biase
                if (!geneZValueMap.containsKey(pGeneSymb)) {
                    continue;
                }

                p1 = geneZValueMap.get(pGeneSymb);
                if (p1 == null) {
                    continue;
                }

                availableGWASGeneList.add(new String[]{pGeneSymb, String.valueOf(p1)});
                zValueListInGeneSet.add(p1);
            }
            if (availableGWASGeneList.isEmpty()) {
                continue;
            }
            GeneSet newPathway = new GeneSet(pathID, pathID, curPath.getURL());
            newPathway.getGeneValues().addAll(availableGWASGeneList);
            for (Map.Entry<String, Double> mGene : geneZValueMap.entrySet()) {
                if (!pGenes.contains(mGene.getKey())) {
                    zValueListOutPathway.add(mGene.getValue());
                }
            }

            subPopulationSize = zValueListInGeneSet.size();
            if (subPopulationSize < minSetSize) {
                continue;
            }
            double[] zInGeneSet = new double[subPopulationSize];
            for (int k = 0; k < subPopulationSize; k++) {
                zInGeneSet[k] = zValueListInGeneSet.getQuick(k);
            }

            double[] zOutGeneSet = new double[zValueListOutPathway.size()];
            for (int k = 0; k < zOutGeneSet.length; k++) {
                zOutGeneSet[k] = zValueListOutPathway.getQuick(k);
            }
            /*
             if (pathID.equals("ADENYL_NUCLEOTIDE_BINDING")) {
             BufferedWriter testWriter = new BufferedWriter(new FileWriter("test.txt"));
             testWriter.write("group\tvalue\n");
             for (int t = 0; t < zInGeneSet.length; t++) {
             testWriter.write("1\t" + zInGeneSet[t] + "\n");
             }
             for (int t = 0; t < zOutGeneSet.length; t++) {
             testWriter.write("2\t" + zOutGeneSet[t] + "\n");
             }
             testWriter.close();
             }
             */

            MannWhitneyTest mt = new MannWhitneyTest(zInGeneSet, zOutGeneSet, H1.GREATER_THAN);
            // WilcoxonTest wt = new WilcoxonTest(zInGeneSet, median, H1.LESS_THAN);
            // newPathway.setWilcoxonPValue(mt.getSP());
            // allPValues.add(newPathway.getWilcoxonPValue());
            //outPathwayList.add(newPathway);                
            //  runningResultTopComp.insertText(pathID + 2 + " Time " + (end - start));

            p = mt.getSP();
            newPathway.setWilcoxonPValue(p);

            geneSetPValuesForQQPlot.add(p);
            effectiveGeneSetList.add(newPathway);
        }

        ArrayListComparatorDouble acd = new ArrayListComparatorDouble(1);
        List<String[]> outGeneSetList = new ArrayList<String[]>();
        outGeneSetList.add(new String[]{"GeneSetID", "WilcoxonP", "Gene", "GeneP"});
        Collections.sort(effectiveGeneSetList, new GeneSetWilcoxPValueComparator());
        for (GeneSet pathway : effectiveGeneSetList) {
            List<String[]> geneList = pathway.getGeneValues();

            String[] items = new String[4];
            items[0] = pathway.getID();
            items[1] = String.valueOf(pathway.getWilcoxonPValue());

            Collections.sort(geneList, acd);
            items[2] = geneList.get(0)[0];
            items[3] = genePValueMap.get(geneList.get(0)[0]);
            outGeneSetList.add(items);
            for (int i = 1; i < geneList.size(); i++) {
                items = new String[4];
                items[2] = geneList.get(i)[0];
                items[3] = genePValueMap.get(geneList.get(i)[0]);
                outGeneSetList.add(items);
            }
        }

        LocalExcelFile.writeArray2XLSXFile(geneSumOutFile + ".xlsx", outGeneSetList, true, 0, 2);
        String info = "The results of geneset enrichment test are saved in " + (new File(geneSumOutFile)).getCanonicalPath() + "!";

        LOG.info(info);
        geneSetPValuesForQQPlot.quickSort();
        List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
        List<String> nameList = new ArrayList<String>();
        pvalueLists.add(geneSetPValuesForQQPlot);
        PValuePainter pvPainter = new PValuePainter(400, 400);
        File plotFile = new File(geneSumOutFile + ".qq.png");
        nameList.add("WilcoxonP");
        pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);
        info = "The QQ plot saved in " + plotFile.getCanonicalPath();
        LOG.info(info);

        StringBuilder sumSb = new StringBuilder();
        double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(genePValueCutoff, geneSetPValuesForQQPlot);
        Set<String> wholeSigCandiGeneSet = new HashSet<String>();
        for (GeneSet pathway : effectiveGeneSetList) {
            if (pathway.getWilcoxonPValue() <= adjGenePValueCutoff) {
                wholeSigCandiGeneSet.add(pathway.getID());
            }
        }

        sumSb.append(wholeSigCandiGeneSet.size()).append(" genesets with p-value <= ").append(adjGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());
        wholeSigCandiGeneSet.clear();
    }

    public Map<String, StringBuilder> readTissueSpecficGenes(String specificFilepath) throws Exception {
        File fileFolder = new File(specificFilepath);
        if (!fileFolder.exists()) {
            throw new Exception("File " + specificFilepath + " doese not exists!");
        }
        String strLine;
        BufferedReader br = LocalFileFunc.getBufferedReader(specificFilepath);
        Map<String, StringBuilder> geneTissueMap = new HashMap<String, StringBuilder>();
        Set<String> availableTissues = new HashSet<String>();
        String tissue;
        int index;
        while ((strLine = br.readLine()) != null) {
            String[] items = strLine.split("\t");

            for (int i = 2; i < items.length; i++) {
                tissue = items[i];
                if (tissue.contains("NonSynRe(")) {
                    index = tissue.lastIndexOf("NonSynRe(");
                    tissue = tissue.substring(0, index);
                    index = tissue.lastIndexOf('-');
                    if (index >= 0) {
                        tissue = tissue.substring(0, index);
                    }
                } else {
                    index = tissue.lastIndexOf('(');
                    if (index >= 0) {
                        tissue = tissue.substring(0, index);
                    }
                }
                availableTissues.add(tissue);
            }
            StringBuilder infSB = geneTissueMap.get(items[0]);
            if (infSB == null) {
                infSB = new StringBuilder();
                geneTissueMap.put(items[0], infSB);
            }
            infSB.append(items[1]).append(':');

            String[] stockArr = availableTissues.toArray(new String[0]);
            infSB.append(stockArr[0]);
            for (int t = 1; t < stockArr.length; t++) {
                infSB.append(',');
                infSB.append(stockArr[t]);
            }
            infSB.append(';');
            availableTissues.clear();
        }
        br.close();

        return geneTissueMap;
    }

    public Map<String, String[]> loadGeneScores(String filePathPrefix, double fdr) throws Exception {
//ResponseVar	ResponseVarScore	ExplanatoryVar    
//load assist file
        int responseVarIndex = -1;
        int responseVarScoreIndex = -1;
        int explanatoryVarIndex = -1;
        int detailAlleleIndex = -1;
        int pIndex = -1;

        BufferedReader br = LocalFileFunc.getBufferedReader(filePathPrefix);
        String line = br.readLine();
        String[] row;
        String[] cells = line.split("\t");

        for (int j = 0; j < cells.length; j++) {
            if (cells[j].equals("ResponseVar") || cells[j].equals("DependentVar")) {
                responseVarIndex = j;

            } else if (cells[j].equals("ResponseVarScore") || cells[j].equals("DependentVarScore")) {
                responseVarScoreIndex = j;

            } else if (cells[j].equals("ExplanatoryVar") || cells[j].equals("IndependentVar")) {
                explanatoryVarIndex = j;

            } else if (cells[j].equals("P")) {
                pIndex = j;
            } else if (cells[j].equals("AlleleScore")) {
                detailAlleleIndex = j;
            }
        }

        DoubleArrayList pvalueList = new DoubleArrayList();
        String pStr;
        List<String[]> arryList = new ArrayList<String[]>();
        while ((line = br.readLine()) != null) {
            //line = line.trim();
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t", -1);
            row = new String[6];
            row[0] = cells[0];
            row[1] = cells[responseVarIndex];
            row[2] = cells[responseVarScoreIndex];
            if (explanatoryVarIndex >= 0) {
                row[3] = cells[explanatoryVarIndex];
            }
            row[4] = cells[pIndex];
            if (!row[4].equals(".") && !row[4].equals("NaN")) {
                pvalueList.add(Double.parseDouble(row[4]));
            }
            row[5] = cells[detailAlleleIndex];
            arryList.add(row);
        }
        br.close();
        pvalueList.quickSort();

        Map<String, String[]> otherGeneScoreMap = new HashMap<String, String[]>();
        double pCut = MultipleTestingMethod.benjaminiHochbergFDR(fdr, pvalueList);
        pvalueList.clear();
        double pV;
        for (String[] item : arryList) {
            pStr = item[item.length - 2];
            if (pStr.equals(".") || pStr.equals("NaN")) {
                continue;
            }
            pV = Double.parseDouble(pStr);
            if (pV > pCut) {
                otherGeneScoreMap.put(item[0], item);
            }
        }
        arryList.clear();

        return otherGeneScoreMap;
    }

    public double[] caculateResidueByR(RConnection rcon, List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum,
            boolean noExplanatoryVar, boolean needInteraction, double truncPoint, int addedCovNum,
            boolean usingLog, double[] orgCountsMatrix, boolean runStepwise) throws Exception {
        StringBuilder sb = new StringBuilder();

        int datasetID = (int) (Math.random() * 10000);
        String strPrefix = "genemutetest" + datasetID;
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        sb.delete(0, sb.length());

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }

        sb.append(")");

        rcon.voidEval(sb.toString());
        String dataFrameNames = sb.toString();
        sb.delete(0, sb.length());
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval(strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])] <-log(" + strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])])");
        }

        //dist = c("poisson", "negbin", "geometric")
        //zerotrunc  dist
        if (noExplanatoryVar) {
            sb.append("m1 <- zerotrunc(DepVarScore ~ ");
            sb.append(scoreHeads.get(0));
            for (int i = 1; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        } else {
            sb.append("m1 <- zerotrunc(DepVarScore ~ IndepVar ");
            for (int i = 0; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        }

        //sb.append("m1 <- glm(DepVarScore ~ IndepVar + AvgRegionLen");
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append("+").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            sb.append("+").append(scoreHeads.get(i + orgScoreNum));
        }

        //sb.append(", data = ").append(strPrefix).append(",family=\"poisson\")");
        //sb.append(", data = ").append(strPrefix).append(", dist=\"negbin\")");
        sb.append(", data = ").append(strPrefix).append(", dist=\"negbin-extended\", truncPoint=" + truncPoint + ")");
        //sb.append(", data = ").append(strPrefix).append(")");

        //System.out.println(sb);
        rcon.voidEval(sb.toString());
        if (runStepwise) {
            rcon.voidEval(" m1 <- stepAIC(m1,direction = \"both\",trace = 0)");
        }
        //  double[] residueCounter = rcon.eval("resid(m1,\"deviance\")").asDoubles();
        //double[] residueCounter = rcon.eval("residuals(m1,type = \"response\")").asDoubles();   
        double[] residueCounter;
        if (orgCountsMatrix != null) {
            geneSize = orgCountsMatrix.length / colNum;
            //strPrefix = "genemutetest" + (int) (Math.random() * 10000);
            rcon.assign("valMat", orgCountsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

            rcon.voidEval(strPrefix + "<-data.frame(valMat);");

            rcon.voidEval(dataFrameNames);
            residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + truncPoint + ")").asDoubles();
        } else {
            residueCounter = rcon.eval("residuals(m1,type = \"deviance\", truncPoint=" + truncPoint + ")").asDoubles(); //
        }
        //lr.robustLinearRegression(yy, xx, 5000, 1);
        //residueCounter = lr.getResidual();
        return residueCounter;
    }

    public double[] caculateResidueByR(RConnection rcon, List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum,
            boolean noExplanatoryVar, boolean needInteraction, double truncPoint, int addedCovNum, int geneControlVarScoreIndex, boolean usingLog,
            List<String> marginalHeads, double[] orgCountsMatrix) throws Exception {
        StringBuilder sb = new StringBuilder();

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        sb.delete(0, sb.length());

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }
        if (geneControlVarScoreIndex >= 0) {
            sb.append(",\"CtrlVarScore\"");
        }
        if (marginalHeads != null && !marginalHeads.isEmpty()) {
            for (int i = 0; i < marginalHeads.size(); i++) {
                sb.append(",\"").append(marginalHeads.get(i)).append("\"");
            }
        }
        sb.append(")");

        rcon.voidEval(sb.toString());
        String dataFrameNames = sb.toString();
        sb.delete(0, sb.length());
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval("len<-dim(" + strPrefix + ")[2]");
            rcon.voidEval(strPrefix + "[,seq(2,len)] <- log(" + strPrefix + "[,seq(2,len)])");
            //rcon.voidEval(strPrefix + "[,seq(len,len)] <- log(" + strPrefix + "[,seq(len,len)])");
        }

        //dist = c("poisson", "negbin", "geometric")
        //zerotrunc  dist
        if (noExplanatoryVar) {
            sb.append("m1 <- zerotrunc(DepVarScore ~ ");
            sb.append(scoreHeads.get(0));
            for (int i = 1; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        } else {
            sb.append("m1 <- zerotrunc(DepVarScore ~ IndepVar ");
            for (int i = 0; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        }

        //sb.append("m1 <- glm(DepVarScore ~ IndepVar + AvgRegionLen");
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append("+").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            sb.append("+").append(scoreHeads.get(i + orgScoreNum));
        }

        if (geneControlVarScoreIndex >= 0) {
            sb.append("+CtrlVarScore");
        }

        if (marginalHeads != null && !marginalHeads.isEmpty()) {
            for (int i = 0; i < marginalHeads.size(); i++) {
                sb.append("+").append(marginalHeads.get(i));
            }
        }

        //sb.append(", data = ").append(strPrefix).append(",family=\"poisson\")");
        //sb.append(", data = ").append(strPrefix).append(", dist=\"negbin\")");
        sb.append(", data = ").append(strPrefix).append(", dist=\"negbin-extended\", truncPoint=" + truncPoint + ")");
        //sb.append(", data = ").append(strPrefix).append(")");

        //  System.out.println(sb);
        rcon.voidEval(sb.toString());
        //    String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        //   System.out.println(logTxt);

        // double[] residueCounter = rcon.eval("resid(m1,\"pearson\")").asDoubles();
        //double[] residueCounter = rcon.eval("residuals(m1,type = \"response\")").asDoubles();   
        double[] residueCounter;
        if (orgCountsMatrix != null) {
            geneSize = orgCountsMatrix.length / colNum;

            rcon.assign("valMat", orgCountsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

            rcon.voidEval(strPrefix + "<-data.frame(valMat);");
            rcon.voidEval(dataFrameNames);

            residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + truncPoint + ")").asDoubles();
        } else {
            residueCounter = rcon.eval("residuals(m1,type = \"deviance\", truncPoint=" + truncPoint + ")").asDoubles(); //
        }

        //lr.robustLinearRegression(yy, xx, 5000, 1);
        //residueCounter = lr.getResidual();
        return residueCounter;
    }

    public double[] caculateResidueByRNegBi(RConnection rcon, List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum,
            boolean noExplanatoryVar, boolean needInteraction, double truncPoint, int addedCovNum) throws Exception {
        StringBuilder sb = new StringBuilder();

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        //zerotrunc  dist
        if (noExplanatoryVar) {
            sb.append("m1 <- glm.nb(DepVarScore ~ ");
            sb.append(scoreHeads.get(0));
            for (int i = 1; i < scoreHeads.size(); i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        } else {
            sb.append("m1 <- glm.nb(DepVarScore ~ IndepVar ");
            for (String name : scoreHeads) {
                sb.append("+").append(name);
            }
        }

        if (needInteraction) {
            for (int i = 0; i < scoreHeads.size() - addedCovNum; i++) {
                for (int j = i + 1; j < scoreHeads.size() - addedCovNum; j++) {
                    sb.append("+").append(scoreHeads.get(i)).append("*").append(scoreHeads.get(j));
                }
            }
        }

        sb.append(", data = ").append(strPrefix).append(")");

        //System.out.println(sb);
        rcon.voidEval(sb.toString());

        // double[] residueCounter = rcon.eval("resid(m1,\"pearson\")").asDoubles();
        double[] residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles();
        // double[] residueCounter = rcon.eval("residuals(m1,type = \"deviance\", truncPoint=" + truncPoint + ")").asDoubles(); //

        //lr.robustLinearRegression(yy, xx, 5000, 1);
        //residueCounter = lr.getResidual();
        return residueCounter;
    }

    public double[] caculateResidueByRSingleVar(RConnection rcon, List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum, boolean noExplanatoryVar) throws Exception {
        StringBuilder sb = new StringBuilder();

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        sb.append("m1 <- zerotrunc(DepVarScore ~ IndepVar ");
        sb.append(", data = ").append(strPrefix).append(", dist=\"negbin\")");
        rcon.voidEval(sb.toString());
        String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        LOG.info(logTxt);

        //sb.append("m1 <- glm(DepVarScore ~ IndepVar ");
        // sb.append("m1 <- glm.nb(DepVarScore ~ IndepVar ");
        for (String name : scoreHeads) {
            sb.delete(0, sb.length());
            sb.append("m1 <- zerotrunc(DepVarScore ~  ").append(name);
            sb.append(", data = ").append(strPrefix).append(" , dist=\"negbin\")");
            rcon.voidEval(sb.toString());
            logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
            LOG.info(logTxt);
        }

        double[] residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles(); //

        return residueCounter;
    }

    public double[] caculateResidueByRIterativeNegBi(List<String> geneOrder, List<String> scoreHeads, List<double[]> countsRegList,
            boolean noExplanatoryVar, int truncPoint) throws Exception {
        RConnection rcon = new RConnection();
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        boolean wirteTestFile = true;
        Map<String, double[]> geneCov = null;
        BufferedWriter bw = null;
        int midlleColNum = 2;
        Set<String> availableGeneSymbs = new HashSet<String>();
        if (wirteTestFile) {
            geneCov = readGeneCoverages("LUADCov.txt", 0);
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVarScore\tIndVarScore");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
                midlleColNum++;
            }
            bw.write("\tMinCov\tMaxCov");
            bw.write("\n");
        }
        LinearRegression lr = new LinearRegression();
        double[] yy = new double[countsRegList.size()];
        double[][] xx = new double[countsRegList.size()][scoreHeads.size() + (noExplanatoryVar ? 0 : 1)];
        for (int j = 0; j < countsRegList.size(); j++) {
            double[] v = countsRegList.get(j);
            yy[j] = v[0];
            System.arraycopy(v, 1, xx[j], 0, xx[j].length);

            if (wirteTestFile) {
                bw.write(geneOrder.get(j));
                for (int s = 0; s < v.length; s++) {
                    bw.write("\t" + v[s]);
                }
                double[] cov = geneCov.get(geneOrder.get(j));
                if (cov == null) {
                    bw.write("\t.\t.");
                } else {
                    bw.write("\t" + cov[0] + "\t" + cov[1]);
                }
                bw.write("\n");
                availableGeneSymbs.add(geneOrder.get(j));
            }
        }

        if (wirteTestFile) {
            for (Map.Entry<String, double[]> item : geneCov.entrySet()) {
                if (availableGeneSymbs.contains(item.getKey())) {
                    continue;
                }
                bw.write(item.getKey());
                for (int i = 0; i < midlleColNum; i++) {
                    bw.write("\t.");
                }
                bw.write("\t" + item.getValue()[0] + "\t" + item.getValue()[1]);
                bw.write("\n");
            }
            bw.close();
        }

        List<double[]> remainedList0 = new ArrayList<double[]>();
        remainedList0.addAll(countsRegList);
        List<double[]> remainedList1 = new ArrayList<double[]>();
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null;

        // It sseems no need to use PCA
        boolean needPCA = false;
        if (needPCA) {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            rcon.assign("valMat", countsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
            rcon.voidEval("nc<-" + colNum);
            rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
            rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
            rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
            countsMatrix = rcon.eval("t(valMat)").asDoubles();
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                for (int i = 3; i < v.length; i++) {
                    v[i] = countsMatrix[j * v.length + i];
                }
            }
        }

        //Later I found this make no difference
        boolean needImput = false;
        if (needImput) {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            rcon.assign("valMat", countsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
            rcon.voidEval("tmpD<-missForest(valMat)$ximp");
            countsMatrix = rcon.eval("t(tmpD)").asDoubles();
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                for (int i = 3; i < v.length; i++) {
                    v[i] = countsMatrix[j * v.length + i];
                }
            }
        }
        
        List<double[]> remainedList = new ArrayList<double[]>();

        geneSize = remainedList0.size();
        for (int i = 0; i < geneSize; i++) {
            double[] v = remainedList0.get(i);
            if (v[0] >= truncPoint) {
                remainedList.add(v);

            }
        }
        remainedList0.clear();
        remainedList0.addAll(remainedList);

        do {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;

            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            pValues.clear();

            residueCounter = caculateResidueByRNegBi(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, false, truncPoint, 0);

            mean = StdStats.mean(residueCounter);
            sd = StdStats.stddev(residueCounter);

            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);

            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(0.1, pValues);
            remainedList1.clear();
            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                remainedList1.add(remainedList0.get(i));
            }
            if (remainedList1.size() == remainedList0.size()) {
                break;
            }
            remainedList0.clear();
            remainedList0.addAll(remainedList1);

        } while (true);

        // String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        String logTxt = "AIC: " + rcon.eval("AIC(m1)").asString(); //

        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());

        rcon.close();

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {
            residueCounter[t] = (residueCounter[t] - mean) / sd;
            if (residueCounter[t] < 0) {
                residueCounter[t] = 1 - Probability.normal(residueCounter[t]);
            } else {
                residueCounter[t] = Probability.normal(-residueCounter[t]);
            }
            System.out.println(residueCounter[t]);
        }
        return residueCounter;
    }

    public double[] caculateResidueByRIterative(List<String> geneOrder, List<String> scoreHeads, List<double[]> countsRegList,
            boolean noExplanatoryVar, int truncPoint) throws Exception {
        RConnection rcon = new RConnection();
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        boolean wirteTestFile = false;
        Map<String, double[]> geneCov = null;
        BufferedWriter bw = null;
        int midlleColNum = 2;
        Set<String> availableGeneSymbs = new HashSet<String>();
        if (wirteTestFile) {
            geneCov = readGeneCoverages("LUSCCov.txt", 0);
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVarScore\tIndVarScore");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
                midlleColNum++;
            }
            bw.write("\tMinCov\tMaxCov");
            bw.write("\n");
        }
        LinearRegression lr = new LinearRegression();
        double[] yy = new double[countsRegList.size()];
        double[][] xx = new double[countsRegList.size()][scoreHeads.size() + (noExplanatoryVar ? 0 : 1)];
        for (int j = 0; j < countsRegList.size(); j++) {
            double[] v = countsRegList.get(j);
            yy[j] = v[0];
            System.arraycopy(v, 1, xx[j], 0, xx[j].length);

            if (wirteTestFile) {
                bw.write(geneOrder.get(j));
                for (int s = 0; s < v.length; s++) {
                    bw.write("\t" + v[s]);
                }
                double[] cov = geneCov.get(geneOrder.get(j));
                if (cov == null) {
                    bw.write("\t.\t.");
                } else {
                    bw.write("\t" + cov[0] + "\t" + cov[1]);
                }
                bw.write("\n");
                availableGeneSymbs.add(geneOrder.get(j));
            }
        }

        if (wirteTestFile) {
            for (Map.Entry<String, double[]> item : geneCov.entrySet()) {
                if (availableGeneSymbs.contains(item.getKey())) {
                    continue;
                }
                bw.write(item.getKey());
                for (int i = 0; i < midlleColNum; i++) {
                    bw.write("\t.");
                }
                bw.write("\t" + item.getValue()[0] + "\t" + item.getValue()[1]);
                bw.write("\n");
            }
            bw.close();
        }

        List<double[]> remainedList0 = new ArrayList<double[]>();
        remainedList0.addAll(countsRegList);
        List<double[]> remainedList1 = new ArrayList<double[]>();
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null;

        // It sseems no need to use PCA
        boolean needPCA = false;
        if (needPCA) {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            rcon.assign("valMat", countsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
            rcon.voidEval("nc<-" + colNum);
            rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
            rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
            rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
            countsMatrix = rcon.eval("t(valMat)").asDoubles();
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                for (int i = 3; i < v.length; i++) {
                    v[i] = countsMatrix[j * v.length + i];
                }
            }
        }

        //Later I found this make no difference
        boolean needImput = false;
        if (needImput) {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            rcon.assign("valMat", countsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
            rcon.voidEval("tmpD<-missForest(valMat)$ximp");
            countsMatrix = rcon.eval("t(tmpD)").asDoubles();
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                for (int i = 3; i < v.length; i++) {
                    v[i] = countsMatrix[j * v.length + i];
                }
            }
        }
        List<double[]> remainedList = new ArrayList<double[]>();

        geneSize = remainedList0.size();
        for (int i = 0; i < geneSize; i++) {
            double[] v = remainedList0.get(i);
            if (v[0] >= truncPoint) {
                remainedList.add(v);

            }
        }
        remainedList0.clear();
        remainedList0.addAll(remainedList);

        do {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;

            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            pValues.clear();

            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, false, truncPoint, 0, false, null, false);

            // residueCounter = caculateResidueByRSingleVar(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar);
            mean = StdStats.mean(residueCounter);
            sd = StdStats.stddev(residueCounter);

            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);

            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(0.1, pValues);
            remainedList1.clear();
            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                remainedList1.add(remainedList0.get(i));
            }
            if (remainedList1.size() == remainedList0.size()) {
                break;
            }
            remainedList0.clear();
            remainedList0.addAll(remainedList1);

        } while (true);

        String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // String logTxt = "AIC: " + rcon.eval("AIC(m1)").asString(); //

        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);
            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }

        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + truncPoint + ")").asDoubles();
        rcon.close();

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {
            residueCounter[t] = (residueCounter[t] - mean) / sd;
        }
        return residueCounter;
    }

    public double[] caculateResidueWITERThread(String rHost, int rPort, List<Gene> orderedGenes, List<String> scoreHeads, List<double[]> countsRegList,
            boolean noExplanatoryVar, boolean considerFunVar, double[] optimalBinCut, int threadNum) throws Exception {

        boolean usingLog = false;
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null, orgCountsMatrix = null;

        String logTxt;
        double adjGenePValueCutoff;
        double looseFDR = 0.8;

        int scoreBinNum = 20;
        //int scoreBinNum = 3;
        double scoreBinLen = 0.025;
        if (!considerFunVar) {
            scoreBinLen = 0;
            scoreBinNum = 1;
        }

        int truncatedNum = 4;
        //int truncatedNum = 2;

        boolean runStepwise = true;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0, tn;
        List<ZTNBParamSet> paramSetListAll = new ArrayList<ZTNBParamSet>();
        double scoreBinCut;

        for (int s = 0; s < scoreBinNum; s++) {
            scoreBinCut = scoreBinLen * (s + 1);
            for (tn = 0; tn < truncatedNum; tn++) {

                //the orginal one is too slow in the new iteration procedure
                final TNBRegressionTaskWITER varTaks = new TNBRegressionTaskWITER(rHost, rPort, orderedGenes, countsRegList, scoreHeads,
                        noExplanatoryVar, scoreBinCut, tn, usingLog, runningThread, looseFDR, runStepwise) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            synchronized (exec) {
                                paramSetListAll.addAll(paramSetList);
                            }

                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                serv.submit(varTaks);
                runningThread++;

            }
        }
        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            // System.out.println(infor);
        }
        exec.shutdown();

        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());
        int size = paramSetListAll.size();
        for (int j = 0; j < size; j++) {
            paramSetListAll.get(j).order = j;
        }
//        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorSig());
//        size = paramSetListAll.size();
//        for (int j = 0; j < size; j++) {
//            paramSetListAll.get(j).order += j;
//        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorOrder());

        for (int j = 0; j < size; j++) {
            ZTNBParamSet ap = paramSetListAll.get(j);
            // LOG.info(ap.MLFC + "\t" + ap.scoreBinCut + "\t" + ap.truncationPoint + "\t" + ap.sigGeneNum + "\t" + ap.order);
        }
        int bestRankID = 0;

        int optimalBinTruncatPoint = 0;
        if (!paramSetListAll.isEmpty()) {
            // optimalBinCut[0] = paramSetList.get(bestRankID).scoreBinCut;
            optimalBinCut[0] = paramSetListAll.get(0).scoreBinCut;
            optimalBinTruncatPoint = paramSetListAll.get(0).truncationPoint;
        } else {
            optimalBinCut[0] = 0.1;
        }
        //System.out.print("Bestbin: " + optimalBinCut[0]);
        LOG.info("Best standardized score bin: " + optimalBinCut[0] + "; Optimal truncation point: " + optimalBinTruncatPoint + ";  MLFC:" + paramSetListAll.get(bestRankID).MLFC);

        geneSize = countsRegList.size();
        List<double[]> geneScoreListTrunc = new ArrayList<>();
        List<double[]> geneScoreListInsig = new ArrayList<>();
        List<String> geneOrderTrunc = new ArrayList<>();
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);
            v[0] = orderedGenes.get(j).getDepVarMutNum(optimalBinCut[0]);
            if (v[0] >= optimalBinTruncatPoint) {
                geneScoreListTrunc.add(v);
                geneOrderTrunc.add(orderedGenes.get(j).geneSymb);
            }

        }

        RConnection rcon = new RConnection(rHost, rPort);
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        //difficult to install
        //rcon.eval("library(missForest)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        Set<String> sigGeneSet0 = new HashSet<>();
        Set<String> sigGeneSet1 = new HashSet<>();

        geneScoreListInsig.addAll(geneScoreListTrunc);
        double[] countsMatrixOrg;
        //redo the analysis with the best bin cut
        //if (considerFunVar)
        {
            countsMatrixOrg = null;
            do {
                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;

                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = geneScoreListInsig.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                pValues.clear();
                if (countsMatrixOrg == null) {
                    countsMatrixOrg = Arrays.copyOf(countsMatrix, countsMatrix.length);
                }
                residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, false,
                        optimalBinTruncatPoint, 0, false, countsMatrixOrg, runStepwise);

                // residueCounter = caculateResidueByRSingleVar(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar);
                mean = StdStats.mean(residueCounter);
                sd = StdStats.stddev(residueCounter);

                weights = new double[residueCounter.length];
                residuual = new double[residueCounter.length];
                Arrays.fill(weights, Double.NaN);
                scl.iterativeWeighter(residueCounter, weights, residuual, 100);

                mean = StdStats.mean(residueCounter, weights, true);
                sd = StdStats.stddev(residueCounter, weights);

                int geneNum = residueCounter.length;
                double zSc;

                for (int t = 0; t < geneNum; t++) {
                    zSc = (residueCounter[t] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    pValues.add(zSc);
                }

                pValues.quickSort();
                adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);

                geneScoreListInsig.clear();

                sigGeneSet1.clear();
                for (int i = 0; i < geneNum; i++) {
                    zSc = (residueCounter[i] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    if (zSc <= adjGenePValueCutoff) {
                        sigGeneSet1.add(geneOrderTrunc.get(i));
                        continue;
                    }
                    geneScoreListInsig.add(geneScoreListTrunc.get(i));
                }

                if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                    //mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues);
                    //sigGeneNum = sigGeneSet1.size();
                    break;
                }
                sigGeneSet0.clear();
                sigGeneSet0.addAll(sigGeneSet1);

            } while (true);
        }

        logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // String logTxt = "AIC: " + rcon.eval("AIC(m1)").asString(); //

        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);

            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetestF" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }

        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + optimalBinTruncatPoint + ")").asDoubles();
        rcon.close();

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {

            residueCounter[t] = (residueCounter[t] - mean) / sd;
        }
        return residueCounter;
    }

    public double[] caculateResidueByRIterativeExploreWeight(List<Gene> orderedGenes, List<String> scoreHeads, List<double[]> countsRegList,
            boolean noExplanatoryVar, int truncPoint, boolean considerFunVar, double[] optimalBinCut) throws Exception {
        RConnection rcon = new RConnection();
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        boolean wirteTestFile = false;
        Map<String, double[]> geneCov = null;
        BufferedWriter bw = null;
        int midlleColNum = 2;
        Set<String> availableGeneSymbs = new HashSet<String>();
        if (wirteTestFile) {
            geneCov = readGeneCoverages("LUSCCov.txt", 0);
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVarScore\tIndVarScore");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
                midlleColNum++;
            }
            bw.write("\tMinCov\tMaxCov");
            bw.write("\n");
        }
        LinearRegression lr = new LinearRegression();
        double[] yy = new double[countsRegList.size()];
        double[][] xx = new double[countsRegList.size()][scoreHeads.size() + (noExplanatoryVar ? 0 : 1)];
        for (int j = 0; j < countsRegList.size(); j++) {
            double[] v = countsRegList.get(j);
            v[0] = orderedGenes.get(j).getDepVarMutNum(0.05);
            yy[j] = v[0];
            System.arraycopy(v, 1, xx[j], 0, xx[j].length);

            if (wirteTestFile) {
                bw.write(orderedGenes.get(j).geneSymb);
                for (int s = 0; s < v.length; s++) {
                    bw.write("\t" + v[s]);
                }
                double[] cov = geneCov.get(orderedGenes.get(j));
                if (cov == null) {
                    bw.write("\t.\t.");
                } else {
                    bw.write("\t" + cov[0] + "\t" + cov[1]);
                }
                bw.write("\n");
                availableGeneSymbs.add(orderedGenes.get(j).geneSymb);
            }
        }

        if (wirteTestFile) {
            if (geneCov != null) {
                for (Map.Entry<String, double[]> item : geneCov.entrySet()) {
                    if (availableGeneSymbs.contains(item.getKey())) {
                        continue;
                    }
                    bw.write(item.getKey());
                    for (int i = 0; i < midlleColNum; i++) {
                        bw.write("\t.");
                    }
                    bw.write("\t" + item.getValue()[0] + "\t" + item.getValue()[1]);
                    bw.write("\n");
                }
            }
            bw.close();
        }

        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null;
        double[] countsMatrixOrg = null;

        List<double[]> geneScoreListTrunc = new ArrayList<double[]>();
        List<Gene> geneOrderTrunc = new ArrayList<>();

        geneSize = countsRegList.size();
        for (int i = 0; i < geneSize; i++) {
            double[] v = countsRegList.get(i);
            if (v[0] >= truncPoint) {
                geneScoreListTrunc.add(v);
                geneOrderTrunc.add(orderedGenes.get(i));
            }
        }

        int binNum = 10;
        double binLen = 0.5 / binNum;
        double binCut = 0;

        List<ZTNBParamSet> paramSetList = new ArrayList<ZTNBParamSet>();
        double mflc;
        int sigGeneNum;
        if (!considerFunVar) {
            binNum = 1;
            binLen = 0;
        }
        Set<String> sigGeneSet0 = new HashSet<String>();
        Set<String> sigGeneSet1 = new HashSet<String>();
        List<double[]> geneScoreListInsig = new ArrayList<double[]>();

        double iterativeCut = 0.8;
        for (int s = 0; s < binNum; s++) {
            binCut += binLen;
            geneSize = geneScoreListTrunc.size();
            for (int j = 0; j < geneSize; j++) {
                double[] v = geneScoreListTrunc.get(j);
                v[0] = geneOrderTrunc.get(j).getDepVarMutNum(binCut);
            }
            sigGeneSet0.clear();
            geneScoreListInsig.addAll(geneScoreListTrunc);

            do {

                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;

                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = geneScoreListInsig.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                if (false) {
                    bw = new BufferedWriter(new FileWriter("test.txt"));
                    for (int j = 0; j < geneSize; j++) {
                        double[] v = geneScoreListInsig.get(j);
                        System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                        for (int i = 0; i < v.length; i++) {
                            bw.write(v[i] + "\t");
                        }
                        bw.write("\n");
                    }
                    bw.close();

                }
                pValues.clear();

                if (countsMatrixOrg == null) {
                    countsMatrixOrg = Arrays.copyOf(countsMatrix, countsMatrix.length);
                }
                residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, false, truncPoint,
                        0, false, countsMatrixOrg, false);

                // residueCounter = caculateResidueByRSingleVar(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar);
                mean = StdStats.mean(residueCounter);
                sd = StdStats.stddev(residueCounter);

                weights = new double[residueCounter.length];
                residuual = new double[residueCounter.length];
                Arrays.fill(weights, Double.NaN);
                scl.iterativeWeighter(residueCounter, weights, residuual, 100);

                mean = StdStats.mean(residueCounter, weights, true);
                sd = StdStats.stddev(residueCounter, weights);

                int geneNum = residueCounter.length;
                double zSc;

                for (int t = 0; t < geneNum; t++) {
                    zSc = (residueCounter[t] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    pValues.add(zSc);
                }

                pValues.quickSort();
                double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(iterativeCut, pValues);
                geneScoreListInsig.clear();

                sigGeneSet1.clear();

                for (int i = 0; i < geneNum; i++) {
                    zSc = (residueCounter[i] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    if (zSc <= adjGenePValueCutoff) {
                        sigGeneSet1.add(geneOrderTrunc.get(i).geneSymb);
                        continue;
                    }
                    geneScoreListInsig.add(geneScoreListTrunc.get(i));

                }
                if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                    mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues);
                    sigGeneNum = sigGeneSet1.size();
                    break;
                }
                sigGeneSet0.clear();
                sigGeneSet0.addAll(sigGeneSet1);

            } while (true);
            // if (mflc < 0.2)
            {
                paramSetList.add(new ZTNBParamSet(binCut, sigGeneNum, mflc));
            }
        }

        Collections.sort(paramSetList, new ZTNBParamSetComparator());

        //check the cut off which miniize the MLFC and maxmize the sig geneNum
        int rank = 0;
        int sigGene = 0;
        int bestRankID = 0;
        int bestRank = Integer.MAX_VALUE;
        for (int j = 0; j < paramSetList.size(); j++) {
            rank = j;
            sigGene = paramSetList.get(j).sigGeneNum;
            for (int t = 0; t < paramSetList.size(); t++) {
                if (paramSetList.get(t).sigGeneNum > sigGene) {
                    rank++;
                }
            }
            if (rank < bestRank) {
                bestRank = rank;
                bestRankID = j;
            }
        }
        if (!paramSetList.isEmpty()) {
            // optimalBinCut[0] = paramSetList.get(bestRankID).scoreBinCut;
            optimalBinCut[0] = paramSetList.get(0).scoreBinCut;
        } else {
            optimalBinCut[0] = 0.1;
        }
        //System.out.print("Bestbin: " + optimalBinCut[0]);

        geneSize = geneScoreListTrunc.size();
        for (int j = 0; j < geneSize; j++) {
            double[] v = geneScoreListTrunc.get(j);
            v[0] = orderedGenes.get(j).getDepVarMutNum(optimalBinCut[0]);
        }
        sigGeneSet0.clear();
        geneScoreListInsig.clear();
        geneScoreListInsig.addAll(geneScoreListTrunc);
        //redo the analysis with the best bin cut
        if (considerFunVar) {
            countsMatrixOrg = null;
            do {
                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;

                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = geneScoreListInsig.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                pValues.clear();
                if (countsMatrixOrg == null) {
                    countsMatrixOrg = Arrays.copyOf(countsMatrix, countsMatrix.length);
                }
                residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, false,
                        truncPoint, 0, false, countsMatrixOrg, false);

                // residueCounter = caculateResidueByRSingleVar(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar);
                mean = StdStats.mean(residueCounter);
                sd = StdStats.stddev(residueCounter);

                weights = new double[residueCounter.length];
                residuual = new double[residueCounter.length];
                Arrays.fill(weights, Double.NaN);
                scl.iterativeWeighter(residueCounter, weights, residuual, 100);

                mean = StdStats.mean(residueCounter, weights, true);
                sd = StdStats.stddev(residueCounter, weights);

                int geneNum = residueCounter.length;
                double zSc;

                for (int t = 0; t < geneNum; t++) {
                    zSc = (residueCounter[t] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    pValues.add(zSc);
                }

                pValues.quickSort();
                double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(iterativeCut, pValues);

                geneScoreListInsig.clear();

                sigGeneSet1.clear();
                for (int i = 0; i < geneNum; i++) {
                    zSc = (residueCounter[i] - mean) / sd;
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                    if (zSc <= adjGenePValueCutoff) {
                        sigGeneSet1.add(geneOrderTrunc.get(i).geneSymb);
                        continue;
                    }
                    geneScoreListInsig.add(geneScoreListTrunc.get(i));
                }

                if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                    //mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues);
                    //sigGeneNum = sigGeneSet1.size();
                    break;
                }
                sigGeneSet0.clear();
                sigGeneSet0.addAll(sigGeneSet1);

            } while (true);
        }

        String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // String logTxt = "AIC: " + rcon.eval("AIC(m1)").asString(); //

        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);

            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }

        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + truncPoint + ")").asDoubles();
        rcon.close();

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {

            residueCounter[t] = (residueCounter[t] - mean) / sd;
        }
        return residueCounter;
    }

    double calcGeneRefAlleleScores(DoubleArrayList da, double maxMAF, double binCut) {
        if (da == null || da.isEmpty()) {
            return 0;
        }
        int size = da.size() / 2;
        double score = 0, avgScore = 0;
        int effectNum = 0;

        //only add frequencey
        if (binCut <= 0) {
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(da.getQuick(i + i))) {
                    continue;
                }
                if (da.getQuick(i + i) > maxMAF) {
                    continue;
                }

                if (Double.isNaN(da.getQuick(i + i + 1))) {
                    score += da.getQuick(i + i);
                } else {
                    score += da.getQuick(i + i);
                }
            }
            return score;
        }

        for (int i = 0; i < size; i++) {
            if (Double.isNaN(da.getQuick(i + i))) {
                continue;
            }
            if (da.getQuick(i + i) > maxMAF) {
                continue;
            }
            if (!Double.isNaN(da.getQuick(i + i + 1))) {
                avgScore += da.getQuick(i + i + 1);
                effectNum++;
            }
        }
        if (effectNum > 0) {
            avgScore = avgScore / effectNum;
        } else {
            //as the scores are normalzied to be 0 and 1.  0.5 is the median
            avgScore = 0.5;
        }

        for (int i = 0; i < size; i++) {
            if (Double.isNaN(da.getQuick(i + i))) {
                continue;
            }
            if (da.getQuick(i + i) > maxMAF) {
                continue;
            }

            if (Double.isNaN(da.getQuick(i + i + 1))) {
                score += da.getQuick(i + i) * avgScore / binCut;
            } else {
                score += da.getQuick(i + i) * da.getQuick(i + i + 1) / binCut;
            }

        }
        return score;
    }

    public double[] caculateResidueByRIterativeMultiThread0(String rHost, int rPort, List<Gene> geneOrder, List<String> scoreHeads, List<double[]> countsRegList, double mafCut, boolean noExplanatoryVar,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, int caseControlAlleleCount, int geneFreqScoreIndex, int threadNum, boolean needInteraction,
            int orgScoreColStart, int orgScoreColEnd, int addedCovNum, boolean useFunctionWeight, boolean hasMergeScore,
            IntArrayList mergedDepVarScores, IntArrayList mergedIndpVarScores, boolean isOneGene, boolean usingLog, boolean protectiveEffect) throws Exception {


        /*
    try {
      rcon.eval("pack=\"MASS\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
      rcon.eval("library(MASS)");
    } catch (RserveException ex) {
      LOG.error("KGGSeq failed to install R package MASS! Please report this problem to your administrator.");
    }   
    try {
      rcon.eval("pack=\"countreg\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://R-Forge.R-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
      rcon.eval("library(countreg)");
    } catch (RserveException ex) {
      LOG.error("KGGSeq failed to install R package countreg! Please report this problem to your administrator.");
    }
         */
        boolean wirteTestFile = false;
        BufferedWriter bw = null;
        if (wirteTestFile) {
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVarScore\tIndepVar");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
            }
            bw.write("\n");
        }

        /*
    double[] yy = new double[countsRegListCopied.varSize()];
    double[][] xx = new double[countsRegListCopied.varSize()][scoreHeads.varSize() + (noExplanatoryVar ? 0 : 1)];
    for (int j = 0; j < countsRegListCopied.varSize(); j++) {
      double[] v = countsRegListCopied.get(j);
      yy[j] = v[0];
      System.arraycopy(v, 1, xx[j], 0, xx[j].length);

      if (wirteTestFile) {
        bw.write(geneSymbolOrder.get(j).geneSymb);
        for (int s = 0; s < v.length; s++) {
          bw.write("\t" + v[s]);
        }
        bw.write("\n");
      }
    }

    if (wirteTestFile) {
      bw.close();
    }
         */
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null;

        //select the model with min AIC
        List<String> geneOrderTmp = new ArrayList<String>();
        List<String> geneOrderTmp0 = new ArrayList<String>();
        List<String> geneOrderTmp1 = new ArrayList<String>();
        String logTxt;
        double adjGenePValueCutoff;
        double looseFDR = 0.08;

        int scoreBinNum = 20;
        double scoreBinLen = 0.025;
        if (!useFunctionWeight) {
            scoreBinLen = 0;
            scoreBinNum = 1;
        }
        int[] bounderies = partitionEvenBlock(scoreBinNum, threadNum);
        //int[] bounderies = partitionEvenBlock(20, threadNum);
        int actualThreadNum = bounderies.length - 1;

        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        List<ZTNBParamSet> paramSetListAll = new ArrayList<ZTNBParamSet>();

        for (int f = 1; f < bounderies.length; f++) {
            final TNBRegressionTaskRUNNER0 varTaks = new TNBRegressionTaskRUNNER0(rHost, rPort, refGeneVarFreqScoreMap, geneOrder, countsRegList, scoreHeads,
                    noExplanatoryVar, mafCut, scoreBinLen, bounderies[f - 1] + 1, bounderies[f] + 1, geneFreqScoreIndex, needInteraction, orgScoreColStart,
                    orgScoreColEnd, addedCovNum, caseControlAlleleCount, isOneGene, usingLog, protectiveEffect, f, looseFDR) {
                @Override
                protected void fireTaskComplete() {
                    try {
                        synchronized (bounderies) {
                            paramSetListAll.addAll(paramSetList);
                        }

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            };
            serv.submit(varTaks);
            runningThread++;
        }
        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            // System.out.println(infor);
        }

        exec.shutdown();

        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());

        RConnection rcon = new RConnection(rHost, rPort);
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        //difficult to install
        //rcon.eval("library(missForest)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        //check the cut off which miniize the MLFC and maxmize the sig geneNum
        int rank = 0;
        int sigGene = 0;
        int bestRankID = 0;
        int bestRank = Integer.MAX_VALUE;
        for (int j = 0; j < paramSetListAll.size(); j++) {
            rank = j;
            sigGene = paramSetListAll.get(j).sigGeneNum;
            for (int t = 0; t < paramSetListAll.size(); t++) {
                if (paramSetListAll.get(t).sigGeneNum > sigGene) {
                    rank++;
                }
            }
            if (rank < bestRank) {
                bestRank = rank;
                bestRankID = j;
            }
        }
        double optimalScoreBinCut;
        int optimalTN;
        double optimalFreq;
        if (!paramSetListAll.isEmpty()) {
            optimalScoreBinCut = paramSetListAll.get(bestRankID).scoreBinCut;
            optimalTN = paramSetListAll.get(bestRankID).truncationPoint;
            optimalFreq = paramSetListAll.get(bestRankID).freqCut;
        } else {
            optimalScoreBinCut = 0.1;
            optimalTN = 0;
            optimalFreq = 0.01;
        }
        LOG.info("Best standardized score bin: " + optimalScoreBinCut + "; Best frequency cut:" + optimalFreq + "; MLFC:" + paramSetListAll.get(bestRankID).MLFC);

        //the use the MAF for min AIC scores
        geneOrderTmp0.clear();

        List<double[]> remainedList = new ArrayList<double[]>();
        List<double[]> remainedList0 = new ArrayList<double[]>();
        remainedList0.addAll(countsRegList);
        List<double[]> remainedList1 = new ArrayList<double[]>();

        //recalculate resisdue by the best cutoff
        geneSize = remainedList0.size();
        int inc;
        if (!noExplanatoryVar) {
            orgScoreColStart++;
            orgScoreColEnd++;
        }
        for (int i = 0; i < geneSize; i++) {
            geneOrderTmp0.add(geneOrder.get(i).geneSymb);
            double[] v = remainedList0.get(i);

            v[0] = geneOrder.get(i).getDepVarMutNum(optimalScoreBinCut, caseControlAlleleCount, 3);
            if (v[0] > optimalTN) {
                remainedList.add(v);
                geneOrderTmp.add(geneOrderTmp0.get(i));
            }
            if (isOneGene) {
                v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(geneOrderTmp0.get(i)), optimalFreq, optimalScoreBinCut);
            } else {
                String[] genes = geneOrderTmp0.get(i).split(" ");
                v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[0]), optimalFreq, optimalScoreBinCut);
                for (int j = 1; j < genes.length; j++) {
                    v[orgScoreColEnd - 1] += calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[j]), optimalFreq, optimalScoreBinCut);
                }
            }
            if (needInteraction) {
                inc = 0;
                for (int k = orgScoreColStart; k < orgScoreColEnd; k++) {
                    for (int t = k + 1; t < orgScoreColEnd; t++) {
                        v[orgScoreColEnd + inc] = v[k] * v[t];
                        inc++;
                    }
                }
            }

        }
        remainedList0.clear();
        remainedList0.addAll(remainedList);
        geneOrderTmp0.clear();
        geneOrderTmp0.addAll(geneOrderTmp);

        geneSize = remainedList0.size();
        do {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;

            boolean needImput = false;
            boolean hasNA = false;
            if (needImput) {
                geneSize = remainedList0.size();
                colNum = remainedList0.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = remainedList0.get(j);
                    if (!hasNA) {
                        for (int t = 0; t < v.length; t++) {
                            if (Double.isNaN(v[t])) {
                                hasNA = true;
                            }
                        }
                    }
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                if (hasNA) {
                    rcon.assign("valMat", countsMatrix);
                    rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                    rcon.voidEval("tmpD<-missForest(valMat)$ximp");
                    countsMatrix = rcon.eval("t(tmpD)").asDoubles();
                    for (int j = 0; j < geneSize; j++) {
                        double[] v = remainedList0.get(j);
                        for (int i = 3; i < v.length; i++) {
                            v[i] = countsMatrix[j * v.length + i];
                        }
                    }
                }
            }

            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            pValues.clear();

            if (false) {
                int ssssss = 0;
                bw = new BufferedWriter(new FileWriter("testS.txt"));
                bw.write("Gene\tDepVarScore	RegionLength	EAS	RegionLengthEAS	mu_mis	mu_lof	oe_mis	oe_lof	ExonGC\n");

                for (int j = 0; j < geneSize; j++) {
                    if (geneOrderTmp0.get(j).equals("ABCC1:CDH1")) {
                        int sss = 0;
                    }
                    bw.write(String.valueOf(geneOrderTmp0.get(j)));
                    double[] v = remainedList0.get(j);
                    for (int i = 0; i < v.length; i++) {
                        bw.write("\t");
                        bw.write(String.valueOf(v[i]));
                    }
                    bw.write("\n");
                }

                bw.close();
            }
            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar,
                    needInteraction, optimalTN, addedCovNum, usingLog, null, false);

            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);
            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                if (!protectiveEffect) {
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    //one tailed test
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);
            remainedList1.clear();
            geneOrderTmp1.clear();
            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }

                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                remainedList1.add(remainedList0.get(i));
                geneOrderTmp1.add(geneOrderTmp0.get(i));
            }

            if (remainedList1.size() == remainedList0.size()) {
                break;
            }
            remainedList0.clear();
            remainedList0.addAll(remainedList1);

            geneOrderTmp0.clear();
            geneOrderTmp0.addAll(geneOrderTmp1);

        } while (true);

        logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // logTxt = "AIC(m1) \t" + rcon.eval("AIC(m1)").asString(); //
        logTxt += ("\n  Optimal truncation point: " + optimalTN);
        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);
            if (hasMergeScore) {
                v[0] -= mergedDepVarScores.getQuick(j);
                if (noExplanatoryVar) {
                    v[1] -= mergedIndpVarScores.getQuick(j);
                }
            }
            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }

        sb.append(")");

        rcon.voidEval(sb.toString());
        sb.delete(0, sb.length());
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval(strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])] <-log(" + strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])])");
        }
        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        //  residueCounter = rcon.eval("residuals.zrpNew(m1, " + strPrefix + ")").asDoubles();

        // residueCounter = rcon.eval("residuals.possionFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        if (rcon != null) {
            rcon.close();
        }

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {
            double[] v = countsRegList.get(t);
            if (v[0] > optimalTN) {
                residueCounter[t] = (residueCounter[t] - mean) / sd;
            } else {
                residueCounter[t] = Double.NaN;
            }
        }
        return residueCounter;
    }

    public double[] caculateResidueRUNNERThread(String rHost, int rPort, List<Gene> geneOrder, List<String> scoreHeads, List<double[]> countsRegList, double mafCut, boolean noExplanatoryVar,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, int caseControlAlleleCount, int geneFreqScoreIndex, int threadNum, boolean needInteraction,
            int orgScoreColStart, int orgScoreColEnd, int addedCovNum, boolean useFunctionWeight, boolean hasMergeScore,
            IntArrayList mergedDepVarScores, IntArrayList mergedIndpVarScores, boolean isOneGene, boolean usingLog, boolean protectiveEffect) throws Exception {

        boolean wirteTestFile = false;
        BufferedWriter bw = null;
        if (wirteTestFile) {
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVarScore\tIndepVar");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
            }
            bw.write("\n");
        }

        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null, orgCountsMatrix = null;

        String logTxt;
        double adjGenePValueCutoff;
        double looseFDR = 0.8;

        int scoreBinNum = 20;
        //int scoreBinNum = 3;
        double scoreBinLen = 0.025;
        if (!useFunctionWeight) {
            scoreBinLen = 0;
            scoreBinNum = 1;
        }

        int truncatedNum = 4;
        //int truncatedNum = 2;

        int freqBinNum = 3;
        // int freqBinNum = 3;
        double mafCutRange = mafCut;
        double mafBinlen = (mafCutRange) / freqBinNum;
        double startFreq = mafCut - mafBinlen * freqBinNum / 2;

        //int[] bounderies = partitionEvenBlock(20, threadNum);
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0, tn;
        List<ZTNBParamSet> paramSetListAll = new ArrayList<ZTNBParamSet>();
        double scoreBinCut, freqCut;

        for (int s = 0; s < scoreBinNum; s++) {
            scoreBinCut = scoreBinLen * (s + 1);
            for (tn = 0; tn < truncatedNum; tn++) {
                for (int freqBinID = 0; freqBinID < freqBinNum; freqBinID++) {
                    freqCut = startFreq + mafBinlen * (freqBinID + 1);
                    if (freqCut <= 0) {
                        continue;
                    }
                    //the orginal one is too slow in the new iteration procedure
                    final TNBRegressionTaskRUNNER varTaks = new TNBRegressionTaskRUNNER(rHost, rPort, refGeneVarFreqScoreMap, geneOrder, countsRegList, scoreHeads,
                            noExplanatoryVar, freqCut, scoreBinCut, tn, geneFreqScoreIndex, needInteraction, orgScoreColStart,
                            orgScoreColEnd, addedCovNum, caseControlAlleleCount, isOneGene, usingLog, protectiveEffect, runningThread, looseFDR) {
                        @Override
                        protected void fireTaskComplete() {
                            try {
                                synchronized (exec) {
                                    paramSetListAll.addAll(paramSetList);
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    };
                    serv.submit(varTaks);
                    runningThread++;

                }
            }
        }
        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            // System.out.println(infor);
        }
        exec.shutdown();

//        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());
//        //check the cut off which miniize the MLFC and maxmize the sig geneNum
//        int rank = 0;
//        int sigGene = 0;
//        int bestRankID = 0;
//        int bestRank = Integer.MAX_VALUE;
//        for (int j = 0; j < paramSetListAll.size(); j++) {
//            rank = j;
//            sigGene = paramSetListAll.get(j).sigGeneNum;
//            for (int t = 0; t < paramSetListAll.size(); t++) {
//                if (paramSetListAll.get(t).sigGeneNum > sigGene) {
//                    rank++;
//                }
//            }
//            if (rank < bestRank) {
//                bestRank = rank;
//                bestRankID = j;
//            }
//        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());
        int size = paramSetListAll.size();
        for (int j = 0; j < size; j++) {
            paramSetListAll.get(j).order = j;
        }
//        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorSig());
//        size = paramSetListAll.size();
//        for (int j = 0; j < size; j++) {
//            paramSetListAll.get(j).order += j;
//        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorOrder());

        for (int j = 0; j < size; j++) {
            ZTNBParamSet ap = paramSetListAll.get(j);
            //LOG.info(ap.MLFC + "\t" + ap.freqCut + "\t" + ap.scoreBinCut + "\t" + ap.truncationPoint + "\t" + ap.sigGeneNum + "\t" + ap.order);
        }
        int bestRankID = 0;

        double optimalScoreBinCut;
        int optimalTN;
        double optimalFreq;
        if (!paramSetListAll.isEmpty()) {
            optimalScoreBinCut = paramSetListAll.get(bestRankID).scoreBinCut;
            optimalTN = paramSetListAll.get(bestRankID).truncationPoint;
            optimalFreq = paramSetListAll.get(bestRankID).freqCut;
        } else {
            optimalScoreBinCut = 0.1;
            optimalTN = 0;
            optimalFreq = 0.01;
        }
        LOG.info("Best standardized score bin: " + optimalScoreBinCut + "; Best frequency cut:" + optimalFreq + "; MLFC:" + paramSetListAll.get(bestRankID).MLFC);

        //select the model with min AIC
        List<String> geneOrderInsig = new ArrayList<String>();
        List<String> geneOrderTrunc = new ArrayList<String>();

        List<double[]> geneScoreListTrunc = new ArrayList<double[]>();
        List<double[]> geneScoreListInsig = new ArrayList<double[]>();

        //recalculate resisdue by the best cutoff
        geneSize = countsRegList.size();
        int inc;
        if (!noExplanatoryVar) {
            orgScoreColStart++;
            orgScoreColEnd++;
        }
        Set<Integer> truncedGeneIndexSet = new HashSet<Integer>();

        for (int i = 0; i < geneSize; i++) {
            double[] v = countsRegList.get(i);
            v[0] = geneOrder.get(i).getDepVarMutNum(optimalScoreBinCut, caseControlAlleleCount, 3);
            if (v[0] > optimalTN) {
                geneScoreListTrunc.add(v);
                geneOrderTrunc.add(geneOrder.get(i).geneSymb);
            } else {
                truncedGeneIndexSet.add(i);
                continue;
            }
            if (isOneGene) {
                v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(geneOrder.get(i).geneSymb), optimalFreq, optimalScoreBinCut);
            } else {
                String[] genes = geneOrder.get(i).geneSymb.split(" ");
                v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[0]), optimalFreq, optimalScoreBinCut);
                for (int j = 1; j < genes.length; j++) {
                    v[orgScoreColEnd - 1] += calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[j]), optimalFreq, optimalScoreBinCut);
                }
            }
            if (needInteraction) {
                inc = 0;
                for (int k = orgScoreColStart; k < orgScoreColEnd; k++) {
                    for (int t = k + 1; t < orgScoreColEnd; t++) {
                        v[orgScoreColEnd + inc] = v[k] * v[t];
                        inc++;
                    }
                }
            }

        }

        RConnection rcon = new RConnection(rHost, rPort);
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        //difficult to install
        //rcon.eval("library(missForest)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        Set<String> sigGeneSet0 = new HashSet<String>();
        Set<String> sigGeneSet1 = new HashSet<String>();
        geneScoreListInsig.addAll(geneScoreListTrunc);
        geneOrderInsig.addAll(geneOrderTrunc);
        int iterNum = 0;
        do {

            geneSize = geneScoreListInsig.size();
            colNum = geneScoreListInsig.get(0).length;

            boolean needImput = false;
            boolean hasNA = false;
            if (needImput) {
                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = geneScoreListInsig.get(j);
                    if (!hasNA) {
                        for (int t = 0; t < v.length; t++) {
                            if (Double.isNaN(v[t])) {
                                hasNA = true;
                            }
                        }
                    }
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                if (hasNA) {
                    rcon.assign("valMat", countsMatrix);
                    rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                    rcon.voidEval("tmpD<-missForest(valMat)$ximp");
                    countsMatrix = rcon.eval("t(tmpD)").asDoubles();
                    for (int j = 0; j < geneSize; j++) {
                        double[] v = geneScoreListInsig.get(j);
                        for (int i = 3; i < v.length; i++) {
                            v[i] = countsMatrix[j * v.length + i];
                        }
                    }
                }

            }

            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = geneScoreListInsig.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            pValues.clear();

            if (false) {
                int ssssss = 0;
                bw = new BufferedWriter(new FileWriter("testS.txt"));
                bw.write("Gene\tDepVarScore	RegionLength	EAS	RegionLengthEAS	mu_mis	mu_lof	oe_mis	oe_lof	ExonGC\n");

                for (int j = 0; j < geneSize; j++) {
                    if (geneOrderTrunc.get(j).equals("ABCC1:CDH1")) {
                        int sss = 0;
                    }
                    bw.write(String.valueOf(geneOrderTrunc.get(j)));
                    double[] v = geneScoreListTrunc.get(j);
                    for (int i = 0; i < v.length; i++) {
                        bw.write("\t");
                        bw.write(String.valueOf(v[i]));
                    }
                    bw.write("\n");
                }

                bw.close();
            }
            if (orgCountsMatrix == null) {
                orgCountsMatrix = new double[countsMatrix.length];
                System.arraycopy(countsMatrix, 0, orgCountsMatrix, 0, countsMatrix.length);
            }
            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, needInteraction,
                    optimalTN, addedCovNum, usingLog, orgCountsMatrix, false);

            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);
            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                if (!protectiveEffect) {
                    //one tailed test
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    //one tailed test
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);
            geneScoreListInsig.clear();
            geneOrderInsig.clear();
            sigGeneSet1.clear();

            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }

                if (zSc <= adjGenePValueCutoff) {
                    sigGeneSet1.add(geneOrderTrunc.get(i));
                    continue;
                }
                geneScoreListInsig.add(geneScoreListTrunc.get(i));
                geneOrderInsig.add(geneOrderTrunc.get(i));
            }

            if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                break;
            }
            sigGeneSet0.clear();
            sigGeneSet0.addAll(sigGeneSet1);

            iterNum++;
            if (iterNum > 3) {
                //no need
                // break;
            }
        } while (true);

        logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // logTxt = "AIC(m1) \t" + rcon.eval("AIC(m1)").asString(); //
        logTxt += ("\n  Optimal truncation point: " + optimalTN);
        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
//        geneSize = countsRegListCopied.size();
//        colNum = countsRegListCopied.get(0).length;
//        countsMatrix = new double[geneSize * colNum];
//        for (int j = 0; j < geneSize; j++) {
//            double[] v = countsRegListCopied.get(j);
//            if (hasMergeScore) {
//                v[0] -= mergedDepVarScores.getQuick(j);
//                if (noExplanatoryVar) {
//                    v[1] -= mergedIndpVarScores.getQuick(j);
//                }
//            }
//            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
//        }
//
//        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);

        rcon.assign("valMat", orgCountsMatrix);
        geneSize = orgCountsMatrix.length / colNum;
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }

        sb.append(")");

        rcon.voidEval(sb.toString());
        sb.delete(0, sb.length());
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval(strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])] <-log(" + strPrefix + "[,seq(2,dim(" + strPrefix + ")[2])])");
        }
        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        //  residueCounter = rcon.eval("residuals.zrpNew(m1, " + strPrefix + ")").asDoubles();

        // residueCounter = rcon.eval("residuals.possionFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        rcon.close();

        int geneNum = countsRegList.size();

        inc = 0;
        double[] residueCounterFull = new double[geneNum];
        Arrays.fill(residueCounterFull, Double.NaN);
        for (int t = 0; t < geneNum; t++) {
            if (!truncedGeneIndexSet.contains(t)) {
                residueCounterFull[t] = (residueCounter[inc] - mean) / sd;
                inc++;
            }
        }
        return residueCounterFull;
//        for (int t = 0; t < geneNum; t++) {
//            double[] v = countsRegListCopied.get(t);
//            if (v[0] > optimalTN) {
//                residueCounter[t] = (residueCounter[t] - mean) / sd;
//            } else {
//                residueCounter[t] = Double.NaN;
//            }
//        }
//        return residueCounter;
    }

    public double[] caculateResidueByRIterativeMultiThreadGeneInteraction0(String rHost, int rPort, List<Gene> geneOrder, List<String> scoreHeads, List<double[]> countsRegList, double mafCut, boolean noExplanatoryVar,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, int geneFreqScoreIndex, int threadNum, boolean needLenFreqInteraction,
            int orgScoreColStart, int orgScoreColEnd, int addedCovNum, boolean useFunctionWeight, boolean hasMergeScore, IntArrayList mergedDepVarScores,
            IntArrayList mergedIndpVarScores, boolean useControlFreq, boolean usingLog, boolean protectiveEffect, int interactGeneNum,
            int minRegressionSample, Map<String, double[]> geneScoreMap, boolean adjMarginal, Map<String, Gene> mappedGenes) throws Exception {

        BufferedWriter bw = null;

        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null;

        //select the model with min AIC
        List<String> geneSymbolOrderTmp = new ArrayList<String>();
        List<String> geneSymbolOrderTmp0 = new ArrayList<String>();
        List<String> geneSymbolOrderTmp1 = new ArrayList<String>();
        String logTxt;
        double adjGenePValueCutoff;
        double looseFDR = 0.1;

        int scoreBinNum = 10;
        int truncatedNum = 3;
        int freqBinNum = 6;
        //int scoreBinNum = 1;
        double scoreBinLen = 0.025;
        if (!useFunctionWeight) {
            scoreBinLen = 0;
            scoreBinNum = 1;
        }
        double currentBen;

        int geneControlVarScoreIndex = -1;
        if (useControlFreq) {
            geneControlVarScoreIndex = countsRegList.get(0).length - 1;
        }

        double mafCutRange = mafCut, freqCut;
        double mafBinlen = (mafCutRange) / freqBinNum;
        double startFreq = mafCut - mafBinlen * freqBinNum / 2;

        // threadNum=1; 
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        List<ZTNBParamSet> paramSetListAll = new ArrayList<ZTNBParamSet>();
        int threadID = 0;
        for (int bi = 0; bi < scoreBinNum; bi++) {
            currentBen = scoreBinLen * bi + scoreBinLen;
            for (int ti = 0; ti < truncatedNum; ti++) {
                for (int fi = 0; fi < freqBinNum; fi++) {
                    freqCut = startFreq + mafBinlen * fi + mafBinlen;
                    if (freqCut <= 0) {
                        continue;
                    }
                    threadID++;
                    final TNBRegressionTaskInteraction varTaks = new TNBRegressionTaskInteraction(rHost, rPort, refGeneVarFreqScoreMap, geneOrder, countsRegList, scoreHeads,
                            noExplanatoryVar, freqCut, currentBen, ti, geneFreqScoreIndex, needLenFreqInteraction, orgScoreColStart,
                            orgScoreColEnd, addedCovNum, -1, interactGeneNum, usingLog, protectiveEffect, minRegressionSample, threadID, looseFDR) {
                        @Override
                        protected void fireTaskComplete() {
                            try {
                                synchronized (paramSetListAll) {
                                    if (paramSet != null) {
                                        paramSetListAll.add(paramSet);
                                    }
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    };
                    varTaks.setGeneControlVarScoreIndex(geneControlVarScoreIndex);
                    varTaks.setGeneScoreMap(geneScoreMap);
                    varTaks.setMappedGenes(adjMarginal, mappedGenes);
                    serv.submit(varTaks);
                    runningThread++;
                }
            }

        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            // System.out.println(infor);
        }

        exec.shutdown();

        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());
        //check the cut off which miniize the MLFC and maxmize the sig geneNum
//        int rank = 0;
//        int sigGene = 0;
//        int bestRankID = 0;
//        int bestRank = Integer.MAX_VALUE;
//        for (int j = 0; j < paramSetListAll.size(); j++) {
//            rank = j;
//            sigGene = paramSetListAll.get(j).sigGeneNum;
//            for (int t = 0; t < paramSetListAll.size(); t++) {
//                if (paramSetListAll.get(t).sigGeneNum > sigGene) {
//                    rank++;
//                }
//            }
//            if (rank < bestRank) {
//                bestRank = rank;
//                bestRankID = j;
//            }
//        }

        int size = paramSetListAll.size();
        for (int j = 0; j < size; j++) {
            paramSetListAll.get(j).order = j;
        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorSig());
        size = paramSetListAll.size();
        for (int j = 0; j < size; j++) {
            paramSetListAll.get(j).order += j;
        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorOrder());

        int bestRankID = 0;
        RConnection rcon = new RConnection(rHost, rPort);
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        //difficult to install
        //rcon.eval("library(missForest)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");
        double optimalScoreBinCut;
        int optimalTN;
        double optimalFreq;
        if (!paramSetListAll.isEmpty()) {
            optimalScoreBinCut = paramSetListAll.get(bestRankID).scoreBinCut;
            optimalTN = paramSetListAll.get(bestRankID).truncationPoint;
            optimalFreq = paramSetListAll.get(bestRankID).freqCut;
        } else {
            optimalScoreBinCut = 0.1;
            optimalTN = 0;
            optimalFreq = 0.01;
        }
        LOG.info("Best standardized score bin: " + optimalScoreBinCut + "; Best frequency cut:" + optimalFreq + "; MLFC:" + paramSetListAll.get(bestRankID).MLFC);

        //the use the MAF for min AIC scores
        geneSymbolOrderTmp0.clear();

        List<double[]> remainedList = new ArrayList<double[]>();
        List<double[]> remainedList0 = new ArrayList<double[]>();
        remainedList0.addAll(countsRegList);
        List<double[]> remainedList1 = new ArrayList<double[]>();

        //recalculate resisdue by the best cutoff
        geneSize = remainedList0.size();
        int inc;
        if (!noExplanatoryVar) {
            orgScoreColStart++;
            orgScoreColEnd++;
        }
        boolean outTest = false;
        boolean needPCA = false;

        for (int i = 0; i < geneSize; i++) {
            geneSymbolOrderTmp0.add(geneOrder.get(i).geneSymb);

            double[] v = remainedList0.get(i);

            v[0] = geneOrder.get(i).getDepVarMutNum(optimalScoreBinCut, -1, -1);
            if (v[0] > optimalTN) {
                remainedList.add(v);
                if (geneControlVarScoreIndex >= 0) {
                    // v[geneControlVarScoreIndex] = geneOrder.get(i).getIndepVarMutNum(optimalScoreBinCut, -1, -1);
                    v[geneControlVarScoreIndex] = geneOrder.get(i).getIndepVarMutNum(optimalScoreBinCut, -1, -1);
                }

                geneSymbolOrderTmp.add(geneSymbolOrderTmp0.get(i));
            }

            String[] genes = geneSymbolOrderTmp0.get(i).split(":");
            v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[0]), optimalFreq, optimalScoreBinCut);
            for (int j = 1; j < genes.length; j++) {
                v[orgScoreColEnd - 1] *= calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[j]), optimalFreq, optimalScoreBinCut);
            }

            if (needLenFreqInteraction) {
                inc = 0;
                for (int k = orgScoreColStart; k < orgScoreColEnd; k++) {
                    for (int t = k + 1; t < orgScoreColEnd; t++) {
                        v[orgScoreColEnd + inc] = v[k] * v[t];

                        inc++;
                    }
                }
            }

        }

        remainedList0.clear();
        remainedList0.addAll(remainedList);
        geneSymbolOrderTmp0.clear();
        geneSymbolOrderTmp0.addAll(geneSymbolOrderTmp);

        colNum = remainedList0.get(0).length;

        List<String> marginalHeads = new ArrayList<>();
        if (adjMarginal) {
            //add marginal
            colNum += interactGeneNum;
            for (int i = 0; i < interactGeneNum; i++) {
                //marginalHeads.add("Len" + (i + 1));
                marginalHeads.add("Gene" + (i + 1) + "Mut");
            }
        }

        do {
            geneSize = remainedList0.size();
            countsMatrix = new double[geneSize * colNum];
            boolean needImput = false;
            boolean hasNA = false;
            if (needImput) {
                geneSize = remainedList0.size();
                colNum = remainedList0.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = remainedList0.get(j);
                    if (!hasNA) {
                        for (int t = 0; t < v.length; t++) {
                            if (Double.isNaN(v[t])) {
                                hasNA = true;
                            }
                        }
                    }
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                if (hasNA) {
                    rcon.assign("valMat", countsMatrix);
                    rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                    rcon.voidEval("tmpD<-missForest(valMat)$ximp");
                    countsMatrix = rcon.eval("t(tmpD)").asDoubles();
                    for (int j = 0; j < geneSize; j++) {
                        double[] v = remainedList0.get(j);
                        for (int i = 3; i < v.length; i++) {
                            v[i] = countsMatrix[j * v.length + i];
                        }
                    }
                }
            }

            if (needPCA) {
                double[] v;
                geneSize = remainedList0.size();
                colNum = remainedList0.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    v = remainedList0.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                rcon.assign("valMat", countsMatrix);
                rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                rcon.voidEval("nc<-" + colNum);
                rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
                rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
                rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
                countsMatrix = rcon.eval("t(valMat)").asDoubles();
                for (int j = 0; j < geneSize; j++) {
                    v = remainedList0.get(j);
                    for (int i = 3; i < v.length; i++) {
                        v[i] = countsMatrix[j * v.length + i];
                    }
                }
            }

            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);

                if (adjMarginal) {
                    String[] genes = geneSymbolOrderTmp0.get(j).split(":");
                    double[] v1 = new double[v.length + interactGeneNum];
                    System.arraycopy(v, 0, v1, 0, v.length);
                    for (int i = 0; i < genes.length; i++) {
//                        v1[v.length + i * 2] = geneScoreMap.get(genes[i])[0];
//                        v1[v.length + i * 2 + 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[i]), optimalFreq, optimalScoreBinCut);

                        v1[v.length + i] = mappedGenes.get(genes[i]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                    }
                    //may have no signal
//                    v1[v.length] = mappedGenes.get(genes[0]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
//                    v1[v.length] += mappedGenes.get(genes[1]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                    System.arraycopy(v1, 0, countsMatrix, j * v1.length, v1.length);
                } else {
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
            }
            pValues.clear();

            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, needLenFreqInteraction,
                    optimalTN, addedCovNum, geneControlVarScoreIndex, usingLog, marginalHeads, null);
            if (Double.isNaN(residueCounter[0])) {

                break;
            }
            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);
            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);
            remainedList1.clear();
            geneSymbolOrderTmp1.clear();
            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                remainedList1.add(remainedList0.get(i));
                geneSymbolOrderTmp1.add(geneSymbolOrderTmp0.get(i));
            }
            if (remainedList1.size() == remainedList0.size()) {
                if (outTest) {
                    bw = new BufferedWriter(new FileWriter("testS.txt"));
                    bw.write("Gene\tDepVarScore	RegionLength	EAS	RegionLengthEAS	oe_mis	oe_lof	ExonGC	CtrlVarScore\n");
                }

                if (outTest) {
                    for (int i = 0; i < geneSymbolOrderTmp1.size(); i++) {
                        geneSymbolOrderTmp0.add(geneSymbolOrderTmp1.get(i));
                        double[] v = remainedList1.get(i);

                        if (geneSymbolOrderTmp1.get(i).equals("ABCC1:CDH1")) {
                            int sss = 0;
                        }
                        bw.write(String.valueOf(geneSymbolOrderTmp1.get(i)));
                        for (int s = 0; s < v.length; s++) {
                            bw.write("\t");
                            bw.write(String.valueOf(v[s]));
                        }
                        bw.write("\n");

                    }

                    bw.close();
                }

                break;
            }

            remainedList0.clear();
            remainedList0.addAll(remainedList1);

            geneSymbolOrderTmp0.clear();
            geneSymbolOrderTmp0.addAll(geneSymbolOrderTmp1);

        } while (true);

        logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // logTxt = "AIC(m1) \t" + rcon.eval("AIC(m1)").asString(); //
        logTxt += ("\n  Optimal truncation point: " + optimalTN);
        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());

        if (needPCA) {
            double[] v;
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            rcon.assign("valMat", countsMatrix);
            rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
            rcon.voidEval("nc<-" + colNum);
            rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
            rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
            rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
            countsMatrix = rcon.eval("t(valMat)").asDoubles();
            for (int j = 0; j < geneSize; j++) {
                v = remainedList0.get(j);
                for (int i = 3; i < v.length; i++) {
                    v[i] = countsMatrix[j * v.length + i];
                }
            }
        }
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        if (adjMarginal) {
            //add marginal
            colNum += interactGeneNum;
        }
        countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);
            if (hasMergeScore) {
                v[0] -= mergedDepVarScores.getQuick(j);
                if (noExplanatoryVar) {
                    v[1] -= mergedIndpVarScores.getQuick(j);
                }
            }
            if (adjMarginal) {
                String[] genes = geneOrder.get(j).geneSymb.split(":");
                double[] v1 = new double[v.length + interactGeneNum];
                System.arraycopy(v, 0, v1, 0, v.length);
                for (int i = 0; i < genes.length; i++) {
//                    v1[v.length + i * 2] = geneScoreMap.get(genes[i])[0];
//                    v1[v.length + i * 2 + 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[i]), optimalFreq, optimalScoreBinCut);
                    v1[v.length + i] = mappedGenes.get(genes[i]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                }

                //cannot contol the TTN
//                v1[v.length] = mappedGenes.get(genes[0]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
//                v1[v.length] += mappedGenes.get(genes[1]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                System.arraycopy(v1, 0, countsMatrix, j * v1.length, v1.length);
            } else {
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());

        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval("len<-dim(" + strPrefix + ")[2]");
            rcon.voidEval(strPrefix + "[,seq(2,len)] <- log(" + strPrefix + "[,seq(2,len)])");
            //rcon.voidEval(strPrefix + "[,seq(len,len)] <- log(" + strPrefix + "[,seq(len,len)])");
        }

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needLenFreqInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }

        if (geneControlVarScoreIndex >= 0) {
            sb.append(",\"CtrlVarScore\"");
        }
        if (marginalHeads != null && !marginalHeads.isEmpty()) {
            for (int i = 0; i < marginalHeads.size(); i++) {
                sb.append(",\"").append(marginalHeads.get(i)).append("\"");
            }
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        //  residueCounter = rcon.eval("residuals.zrpNew(m1, " + strPrefix + ")").asDoubles();

        //residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles(); //
        if (rcon != null) {
            rcon.close();
        }

        int geneNum = residueCounter.length;
        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        for (int t = 0; t < geneNum; t++) {
            double[] v = countsRegList.get(t);
            if (v[0] > optimalTN) {
                residueCounter[t] = (residueCounter[t] - mean) / sd;
            } else {
                residueCounter[t] = Double.NaN;
            }
        }
        return residueCounter;
    }

    public double[] caculateResidueRUNERGeneInteractionThread(String rHost, int rPort, List<Gene> geneOrder, List<String> scoreHeads, List<double[]> countsRegList, double mafCut, boolean noExplanatoryVar,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, int geneFreqScoreIndex, int threadNum, boolean needLenFreqInteraction,
            int orgScoreColStart, int orgScoreColEnd, int addedCovNum, boolean useFunctionWeight, boolean hasMergeScore, IntArrayList mergedDepVarScores,
            IntArrayList mergedIndpVarScores, boolean useControlFreq, boolean usingLog, boolean protectiveEffect, int interactGeneNum,
            int minRegressionSample, Map<String, double[]> geneScoreMap, boolean adjMarginal, Map<String, Gene> mappedGenes) throws Exception {

        BufferedWriter bw = null;

        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        double mean = 0;
        double sd = 1;
        double[] countsMatrix = null, orgCountsMatrix = null;

        //select the model with min AIC
        String logTxt;
        double adjGenePValueCutoff;
        double looseFDR = 0.8;

        int scoreBinNum = 20;
        int truncatedNum = 4;
        int freqBinNum = 3;
//         scoreBinNum = 3;
//         freqBinNum = 2;
//         truncatedNum = 1;
        double scoreBinLen = 0.025;
        if (!useFunctionWeight) {
            scoreBinLen = 0;
            scoreBinNum = 1;
        }
        double currentBen;

        int geneControlVarScoreIndex = -1;
        if (useControlFreq) {
            geneControlVarScoreIndex = countsRegList.get(0).length - 1;
        }

        double mafCutRange = mafCut, freqCut;
        double mafBinlen = (mafCutRange) / freqBinNum;
        double startFreq = mafCut - mafBinlen * freqBinNum / 2;

        // threadNum=1; 
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        List<ZTNBParamSet> paramSetListAll = new ArrayList<ZTNBParamSet>();
        int threadID = 0;
        for (int bi = 0; bi < scoreBinNum; bi++) {
            currentBen = scoreBinLen * bi + scoreBinLen;
            for (int ti = 0; ti < truncatedNum; ti++) {
                for (int fi = 0; fi < freqBinNum; fi++) {
                    freqCut = startFreq + mafBinlen * fi + mafBinlen;
                    if (freqCut <= 0) {
                        continue;
                    }
                    threadID++;
                    final TNBRegressionTaskInteraction varTaks = new TNBRegressionTaskInteraction(rHost, rPort, refGeneVarFreqScoreMap, geneOrder, countsRegList, scoreHeads,
                            noExplanatoryVar, freqCut, currentBen, ti, geneFreqScoreIndex, needLenFreqInteraction, orgScoreColStart,
                            orgScoreColEnd, addedCovNum, -1, interactGeneNum, usingLog, protectiveEffect, minRegressionSample, threadID, looseFDR) {
                        @Override
                        protected void fireTaskComplete() {
                            try {
                                synchronized (paramSetListAll) {
                                    if (paramSet != null) {
                                        paramSetListAll.add(paramSet);
                                    }
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    };
                    varTaks.setGeneControlVarScoreIndex(geneControlVarScoreIndex);
                    varTaks.setGeneScoreMap(geneScoreMap);
                    varTaks.setMappedGenes(adjMarginal, mappedGenes);
                    serv.submit(varTaks);
                    runningThread++;
                }
            }

        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            // System.out.println(infor);
        }

        exec.shutdown();

        Collections.sort(paramSetListAll, new ZTNBParamSetComparator());
        int size = paramSetListAll.size();
        for (int j = 0; j < size; j++) {
            paramSetListAll.get(j).order = j;

        }
//        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorSig());
//        size = paramSetListAll.size();
//        for (int j = 0; j < size; j++) {
//            paramSetListAll.get(j).order += j;
//
//        }
        Collections.sort(paramSetListAll, new ZTNBParamSetComparatorOrder());

//        for (int j = 0; j < size; j++) {
//            ZTNBParamSet ap = paramSetListAll.get(j);
//            LOG.info(ap.MLFC + "\t" + ap.freqCut + "\t" + ap.scoreBinCut + "\t" + ap.truncationPoint + "\t" + ap.sigGeneNum + "\t" + ap.order);
//        }
        int bestRankID = 0;
        RConnection rcon = new RConnection(rHost, rPort);
        StringBuilder sb = new StringBuilder();
        rcon.eval("library(MASS)");
        //rcon.eval("library(countreg)");
        //difficult to install
        //rcon.eval("library(missForest)");
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");
        double optimalScoreBinCut;
        int optimalTN;
        double optimalFreq;
        if (!paramSetListAll.isEmpty()) {
            optimalScoreBinCut = paramSetListAll.get(bestRankID).scoreBinCut;
            optimalTN = paramSetListAll.get(bestRankID).truncationPoint;
            optimalFreq = paramSetListAll.get(bestRankID).freqCut;
        } else {
            optimalScoreBinCut = 0.1;
            optimalTN = 0;
            optimalFreq = 0.01;
        }
        LOG.info("Best standardized score bin: " + optimalScoreBinCut + "; Best frequency cut:" + optimalFreq + "; MLFC:" + paramSetListAll.get(bestRankID).MLFC);

//the use the MAF for min AIC scores
        List<String> geneSymblOrderInsig = new ArrayList<String>();
        List<String> geneOrderTrunc = new ArrayList<String>();

        List<double[]> geneScoreListTrunc = new ArrayList<double[]>();
        List<double[]> geneScoreListInsig = new ArrayList<double[]>();

        //recalculate resisdue by the best cutoff
        geneSize = countsRegList.size();

        int inc;
        if (!noExplanatoryVar) {
            orgScoreColStart++;
            orgScoreColEnd++;
        }
        boolean outTest = false;
        boolean needPCA = false;

        Set<Integer> truncedGeneIndexSet = new HashSet<Integer>();
        for (int i = 0; i < geneSize; i++) {
            double[] v = countsRegList.get(i);

            v[0] = geneOrder.get(i).getDepVarMutNum(optimalScoreBinCut, -1, -1);
            if (v[0] > optimalTN) {
                geneScoreListTrunc.add(v);
                if (geneControlVarScoreIndex >= 0) {
                    // v[geneControlVarScoreIndex] = geneOrder.get(i).getIndepVarMutNum(optimalScoreBinCut, -1, -1);
                    v[geneControlVarScoreIndex] = geneOrder.get(i).getIndepVarMutNum(optimalScoreBinCut, -1, -1);
                }

                geneOrderTrunc.add(geneOrder.get(i).geneSymb);
            } else {
                truncedGeneIndexSet.add(i);
                continue;
            }

            String[] genes = geneOrder.get(i).geneSymb.split(":");
            v[orgScoreColEnd - 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[0]), optimalFreq, optimalScoreBinCut);
            for (int j = 1; j < genes.length; j++) {
                v[orgScoreColEnd - 1] *= calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[j]), optimalFreq, optimalScoreBinCut);
            }

            if (needLenFreqInteraction) {
                inc = 0;
                for (int k = orgScoreColStart; k < orgScoreColEnd; k++) {
                    for (int t = k + 1; t < orgScoreColEnd; t++) {
                        v[orgScoreColEnd + inc] = v[k] * v[t];

                        inc++;
                    }
                }
            }

        }

        colNum = geneScoreListTrunc.get(0).length;

        List<String> marginalHeads = new ArrayList<>();
        if (adjMarginal) {
            //add marginal
            colNum += interactGeneNum;
            for (int i = 0; i < interactGeneNum; i++) {
                //marginalHeads.add("Len" + (i + 1));
                marginalHeads.add("Gene" + (i + 1) + "Mut");
            }

        }
        Set<String> sigGeneSet0 = new HashSet<String>();
        Set<String> sigGeneSet1 = new HashSet<String>();
        geneScoreListInsig.addAll(geneScoreListTrunc);
        geneSymblOrderInsig.addAll(geneOrderTrunc);
        int iterNum = 0;

        boolean needImput = false;
        boolean hasNA = false;

        do {
            geneSize = geneScoreListInsig.size();
            countsMatrix = new double[geneSize * colNum];

            if (needImput) {
                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    double[] v = geneScoreListInsig.get(j);
                    if (!hasNA) {
                        for (int t = 0; t < v.length; t++) {
                            if (Double.isNaN(v[t])) {
                                hasNA = true;
                            }
                        }
                    }
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                if (hasNA) {
                    rcon.assign("valMat", countsMatrix);
                    rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                    rcon.voidEval("tmpD<-missForest(valMat)$ximp");
                    countsMatrix = rcon.eval("t(tmpD)").asDoubles();
                    for (int j = 0; j < geneSize; j++) {
                        double[] v = geneScoreListInsig.get(j);
                        for (int i = 3; i < v.length; i++) {
                            v[i] = countsMatrix[j * v.length + i];
                        }
                    }
                }

            }

            if (needPCA) {
                double[] v;
                geneSize = geneScoreListInsig.size();
                colNum = geneScoreListInsig.get(0).length;
                countsMatrix = new double[geneSize * colNum];
                for (int j = 0; j < geneSize; j++) {
                    v = geneScoreListInsig.get(j);
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
                rcon.assign("valMat", countsMatrix);
                rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                rcon.voidEval("nc<-" + colNum);
                rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
                rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
                rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
                countsMatrix = rcon.eval("t(valMat)").asDoubles();
                for (int j = 0; j < geneSize; j++) {
                    v = geneScoreListInsig.get(j);
                    for (int i = 3; i < v.length; i++) {
                        v[i] = countsMatrix[j * v.length + i];
                    }
                }
            }

            for (int j = 0; j < geneSize; j++) {
                double[] v = geneScoreListInsig.get(j);

                if (adjMarginal) {
                    String[] genes = geneSymblOrderInsig.get(j).split(":");
                    double[] v1 = new double[v.length + interactGeneNum];
                    System.arraycopy(v, 0, v1, 0, v.length);
                    for (int i = 0; i < genes.length; i++) {
//                        v1[v.length + i * 2] = geneScoreMap.get(genes[i])[0];
//                        v1[v.length + i * 2 + 1] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[i]), optimalFreq, optimalScoreBinCut);

                        v1[v.length + i] = mappedGenes.get(genes[i]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                    }
                    //may have no signal
//                    v1[v.length] = mappedGenes.get(genes[0]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
//                    v1[v.length] += mappedGenes.get(genes[1]).getDepVarMutNum(optimalScoreBinCut, 0, 3);
                    System.arraycopy(v1, 0, countsMatrix, j * v1.length, v1.length);
                } else {
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                }
            }
            pValues.clear();
            if (orgCountsMatrix == null) {
                orgCountsMatrix = new double[countsMatrix.length];
                System.arraycopy(countsMatrix, 0, orgCountsMatrix, 0, countsMatrix.length);
            }
            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, needLenFreqInteraction,
                    optimalTN, addedCovNum, geneControlVarScoreIndex, usingLog, marginalHeads, orgCountsMatrix);
            if (Double.isNaN(residueCounter[0])) {
                break;
            }
            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);
            mean = StdStats.mean(residueCounter, weights, true);
            sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);

            geneScoreListInsig.clear();
            geneSymblOrderInsig.clear();
            sigGeneSet1.clear();

            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (!protectiveEffect) {
                    if (zSc < 0) {
                        zSc = 1 - Probability.normal(zSc);
                    } else {
                        zSc = Probability.normal(-zSc);
                    }
                } else {
                    if (zSc < 0) {
                        zSc = Probability.normal(zSc);
                    } else {
                        zSc = 1 - Probability.normal(-zSc);
                    }
                }
                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                geneScoreListInsig.add(geneScoreListTrunc.get(i));
                geneSymblOrderInsig.add(geneOrderTrunc.get(i));
            }

            if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                break;
            }

            sigGeneSet0.clear();
            sigGeneSet0.addAll(sigGeneSet1);

            iterNum++;
            if (iterNum > 3) {
                //no need
                //  break;
            }

        } while (true);

        logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        // logTxt = "AIC(m1) \t" + rcon.eval("AIC(m1)").asString(); //
        logTxt += ("\n  Optimal truncation point: " + optimalTN);
        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", orgCountsMatrix);
        geneSize = orgCountsMatrix.length / colNum;
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());

        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval("len<-dim(" + strPrefix + ")[2]");
            rcon.voidEval(strPrefix + "[,seq(2,len)] <- log(" + strPrefix + "[,seq(2,len)])");
            //rcon.voidEval(strPrefix + "[,seq(len,len)] <- log(" + strPrefix + "[,seq(len,len)])");
        }

        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needLenFreqInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }

        if (geneControlVarScoreIndex >= 0) {
            sb.append(",\"CtrlVarScore\"");
        }
        if (marginalHeads != null && !marginalHeads.isEmpty()) {
            for (int i = 0; i < marginalHeads.size(); i++) {
                sb.append(",\"").append(marginalHeads.get(i)).append("\"");
            }
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + optimalTN + ")").asDoubles();
        //  residueCounter = rcon.eval("residuals.zrpNew(m1, " + strPrefix + ")").asDoubles();

        //residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles(); //
        rcon.close();

        int geneNum = countsRegList.size();

        /*
        weights = new double[residueCounter.length];
        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);       
        scl.iterativeWeighter(residueCounter, weights, residuual, 100);
        min = StdStats.min(residueCounter, weights, true);
        sd = StdStats.stddev(residueCounter, weights);
         */
        inc = 0;
        double[] residueCounterFull = new double[geneNum];
        Arrays.fill(residueCounterFull, Double.NaN);
        for (int t = 0; t < geneNum; t++) {
            if (!truncedGeneIndexSet.contains(t)) {
                residueCounterFull[t] = (residueCounter[inc] - mean) / sd;
                inc++;
            }
        }
        return residueCounterFull;
    }

    public double[] caculateResidueByRIterative(List<String> geneOrder, boolean regReads, List<String> scoreHeads, List<double[]> countsRegList, List<double[]> readsRegList,
            boolean noExplanatoryVar) throws Exception {
        RConnection rcon = new RConnection();
        StringBuilder sb = new StringBuilder();
        try {
            rcon.eval("pack=\"MASS\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
            rcon.eval("library(MASS)");
        } catch (RserveException ex) {
            LOG.error("WITER failed to install R package MASS! Please report this problem to your administrator.");
        }
        try {
            rcon.eval("pack=\"countreg\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://R-Forge.R-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
            rcon.eval("library(countreg)");
        } catch (RserveException ex) {
            LOG.error("WITER failed to install R package countreg! Please report this problem to your administrator.");
        }

        if (regReads) {
            rcon.eval("pack=\"mvtnorm\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
            rcon.eval("library(mvtnorm)");
            rcon.eval("pack=\"tmvtnorm\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
            rcon.eval("library(tmvtnorm)");
        }
        rcon.eval(NegTruncR.codes);
        //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");

        boolean wirteTestFile = false;
        BufferedWriter bw = null;
        if (wirteTestFile) {
            bw = new BufferedWriter(new FileWriter("test.txt"));
            bw.write("Gene\tDepVar\tDepVarScore\tIndepVar");
            for (String name : scoreHeads) {
                bw.write("\t" + name);
            }
            bw.write("\n");
        }

        LinearRegression lr = new LinearRegression();
        double[] yy = new double[countsRegList.size()];
        double[][] xx = new double[countsRegList.size()][scoreHeads.size() + (noExplanatoryVar ? 0 : 1)];
        for (int j = 0; j < countsRegList.size(); j++) {
            double[] v = countsRegList.get(j);
            yy[j] = v[0];
            System.arraycopy(v, 1, xx[j], 0, xx[j].length);

            if (wirteTestFile) {
                bw.write(geneOrder.get(j));
                bw.write("\t" + countsRegList.get(j)[1]);
                for (int s = 0; s < v.length; s++) {
                    bw.write("\t" + v[s]);
                }
                bw.write("\n");
            }
        }

        if (wirteTestFile) {
            bw.close();
        }

        double[] readsMatrix = null;
        if (regReads) {
            readsMatrix = new double[readsRegList.size() * readsRegList.get(0).length];
            for (int j = 0; j < readsRegList.size(); j++) {
                double[] v = readsRegList.get(j);
                System.arraycopy(v, 0, readsMatrix, j * v.length, v.length);
            }
        }

        List<double[]> remainedList0 = new ArrayList<double[]>();
        remainedList0.addAll(countsRegList);
        List<double[]> remainedList1 = new ArrayList<double[]>();
        SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();
        double[] residueCounter;
        double[] weights;
        double[] residuual;
        int geneSize, colNum;
        DoubleArrayList pValues = new DoubleArrayList();
        int truncPoint = 0;
        do {
            geneSize = remainedList0.size();
            colNum = remainedList0.get(0).length;
            double[] countsMatrix = new double[geneSize * colNum];
            for (int j = 0; j < geneSize; j++) {
                double[] v = remainedList0.get(j);
                System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
            }
            pValues.clear();
            residueCounter = caculateResidueByR(rcon, scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar,
                    false, truncPoint, 0, false, null, false);
            weights = new double[residueCounter.length];
            residuual = new double[residueCounter.length];
            Arrays.fill(weights, Double.NaN);
            scl.iterativeWeighter(residueCounter, weights, residuual, 100);
            double mean = StdStats.mean(residueCounter, weights, true);
            double sd = StdStats.stddev(residueCounter, weights);

            int geneNum = residueCounter.length;
            double zSc;

            for (int t = 0; t < geneNum; t++) {
                zSc = (residueCounter[t] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                pValues.add(zSc);
            }

            pValues.quickSort();
            double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(0.1, pValues);
            remainedList1.clear();
            for (int i = 0; i < geneNum; i++) {
                zSc = (residueCounter[i] - mean) / sd;
                //one tailed test
                if (zSc < 0) {
                    zSc = 1 - Probability.normal(zSc);
                } else {
                    zSc = Probability.normal(-zSc);
                }
                if (zSc <= adjGenePValueCutoff) {
                    continue;
                }
                remainedList1.add(remainedList0.get(i));
            }
            if (remainedList1.size() == remainedList0.size()) {
                break;
            }
            remainedList0.clear();
            remainedList0.addAll(remainedList1);

        } while (true);

        String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
        //String logTxt = rcon.eval("AIC(m1)").asString(); //

        LOG.info("The zero-truncated negative-binominal regression model fitted for gene-based mutation rate test:\n" + logTxt);

        sb.delete(0, sb.length());
        geneSize = countsRegList.size();
        colNum = countsRegList.get(0).length;
        double[] countsMatrix = new double[geneSize * colNum];
        for (int j = 0; j < geneSize; j++) {
            double[] v = countsRegList.get(j);
            System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
        }

        sb.delete(0, sb.length());

        String strPrefix = "genemutetest" + (int) (Math.random() * 10000);
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }

        for (String name : scoreHeads) {
            sb.append(",\"").append(name).append("\"");
        }
        sb.append(")");

        rcon.voidEval(sb.toString());

        sb.delete(0, sb.length());

        residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + truncPoint + ")").asDoubles();
        //residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles(); //
        if (rcon != null) {
            rcon.close();
        }

        weights = new double[residueCounter.length];

        residuual = new double[residueCounter.length];
        Arrays.fill(weights, Double.NaN);

        int geneNum = residueCounter.length;

        scl.iterativeWeighter(residueCounter, weights, residuual, 100);

        double mean = StdStats.mean(residueCounter, weights, true);
        double sd = StdStats.stddev(residueCounter, weights);
        for (int t = 0; t < geneNum; t++) {
            residueCounter[t] = (residueCounter[t] - mean) / sd;
        }
        return residueCounter;
    }

    public List<String[]> geneSomaticMutationRateTest(Genome genome, String[] indexLabels, Map<String, Map<String, Integer>> cosmicGeneMut, Map<String, double[]> geneScores,
            List<String> scoreHeads, double genePValueCutoff, boolean considerFunVar, Map<String, double[]> geneMutRegPValueAllVar, boolean noExplanatoryVar, String refMutGeneFile) throws Exception {
        Chromosome[] chroms = genome.getChromosomes();
        int responseVarIndex = -1;
        int explanatoryVarIndex = -1;
        int responseVarScoreIndex = -1;

        boolean needPubMedAnno = false;
        boolean needCosmic = false;
        int shiftCol = 0;

        List<String> featureLabels = genome.getGeneFeatureLabels();
        for (int i = 0; i < featureLabels.size(); i++) {
            if (featureLabels.get(i).equals(indexLabels[0])) {
                responseVarIndex = i;
            } else if (featureLabels.get(i).equals(indexLabels[1])) {
                explanatoryVarIndex = i;
            } else if (featureLabels.get(i).equals(indexLabels[2])) {
                responseVarScoreIndex = i;
            }
        }

        if (cosmicGeneMut != null) {
            needCosmic = true;
        }

        String[] basicHeadRow = null;
        int independentVarCol = 0;
        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
        }
        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        if (needCosmic) {
            geneTableHeadRow.add("COSMICCancerInfo");
            shiftCol++;
        }

        for (String name : scoreHeads) {
            geneTableHeadRow.add(name);
        }

        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        if (refMutGeneFile != null) {
            hasRefBackground = true;
            geneTableHeadRow.add("MergedAlleleNum");
        }

        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        List<double[]> countsRegList = new ArrayList<double[]>();

        int colNum = geneTableHeadRow.size();
        String nsVar = null, sVar = null, nsVarScore = null;
        int scoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        if (geneScores != null && !geneScores.isEmpty()) {
            scoreNum = geneScores.get((new ArrayList(geneScores.keySet())).get(0)).length;
            hasGeneScore = true;
        }
        scoreNum += (1 + independentVarCol);
        int nonZeroSynNum = 0;
        double nSNScore = 0;
        String COSMICCancerInfo;
        double[] geneScore = null;
        List<String> geneOrder = new ArrayList<String>();
        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        Map< String, String[]> refGeneScores = null;
        if (refMutGeneFile != null) {
            refGeneScores = loadGeneScores(refMutGeneFile, 0.3);
        }

        //codes to address reviewers' comments
        boolean withCoverage = false;
        //codes to address reviewers' comments
        Map<String, double[]> geneCoverages = null;
        Map<String, double[]> geneVarNums = null;
        if (withCoverage) {
            geneVarNums = new HashMap<String, double[]>();
            geneCoverages = readGeneCoverages("LUADCov.txt", 90);
        }
        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        Set<String> localGeneSet = new HashSet<String>();
        for (int i = 0; i < chroms.length; i++) {
            if (chroms[i] == null) {
                continue;
            }

            for (Gene gene : chroms[i].geneList) {
                if (gene.geneSymb == null) {
                    continue;
                }

                //remove low coverage genes
                if (withCoverage) {
                    if (!geneCoverages.containsKey(gene.geneSymb)) {
                        continue;
                    }
                }

                hasNA = false;
                if (hasGeneScore) {
                    geneScore = geneScores.get(gene.geneSymb);
                    if (geneScore == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScore.length; k++) {
                        if (Double.isNaN(geneScore[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }
                }

                List<String> features = gene.featureValues;
                nsVar = features.get(responseVarIndex);
                if (considerFunVar) {
                    nsVarScore = features.get(responseVarScoreIndex);
                } else {
                    nsVarScore = features.get(responseVarIndex);
                }
                if (!noExplanatoryVar) {
                    sVar = features.get(explanatoryVarIndex);
                }

                if (nsVar.equals(".")) {
                    continue;
                }
                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                nSNScore = Double.parseDouble(nsVarScore);

                if (nSNScore <= 0) {
                    String[] row = new String[colNum];
                    row[0] = gene.geneSymb;
                    row[1] = nsVar;
                    row[2] = nsVarScore;
                    if (!noExplanatoryVar) {
                        row[3] = sVar;
                    }

                    if (hasGeneScore) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                    geneZeroMutRateSheet.add(row);
                    if (withCoverage) {
                        geneVarNums.put(gene.geneSymb, new double[]{0, Double.parseDouble(sVar)});
                    }
                    continue;
                }
                if (!noExplanatoryVar) {
                    if (sVar.equals(".")) {
                        sVar = "0";
                    }
                }

                String[] row = new String[colNum];
                row[0] = gene.geneSymb;
                row[1] = nsVar;
                row[2] = nsVarScore;
                if (!noExplanatoryVar) {
                    row[3] = sVar;
                }

                if (needPubMedAnno) {
                    //  geneTableRow.add(info[2]);
                }
                if (needCosmic) {
                    Map<String, Integer> sb = cosmicGeneMut.get(row[0]);
                    if (sb == null) {
                        COSMICCancerInfo = ".";
                    } else {
                        COSMICCancerInfo = sb.toString();
                    }
                    row[3 + independentVarCol] = COSMICCancerInfo;
                }
                localGeneSet.add(row[0]);

                double[] scoresM = new double[scoreNum];
                scoresM[0] = nSNScore;
                if (!noExplanatoryVar) {
                    scoresM[1] = Double.parseDouble(sVar);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }
                row[row.length - 1] = "0";
                if (refGeneScores != null && !refGeneScores.isEmpty()) {
                    String[] items = refGeneScores.get(row[0]);
                    if (items != null) {
                        scoresM[0] += Double.parseDouble(items[2]);
                        row[1] = String.valueOf(Double.parseDouble(row[1]) + Double.parseDouble(items[1]));
                        row[2] = String.valueOf(scoresM[0]);
                        if (!noExplanatoryVar) {
                            scoresM[1] += Double.parseDouble(items[3]);
                            row[3] = String.valueOf(scoresM[1]);
                        }
                        row[row.length - 1] = items[2];
                    }
                }

                countsRegList.add(scoresM);
                geneMutRateSheet.add(row);
                nonZeroSynNum += scoresM[0];

                geneOrder.add(gene.geneSymb);
            }
        }

        //add socres new genes       
        if (refGeneScores != null && !refGeneScores.isEmpty()) {
            for (Map.Entry<String, String[]> item : refGeneScores.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScore = geneScores.get(item.getKey());
                    if (geneScore == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScore.length; k++) {
                        if (Double.isNaN(geneScore[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }
                }

                double[] scoresM = new double[scoreNum];
                String[] row = new String[colNum];
                scoresM[0] = Double.parseDouble(item.getValue()[2]);
                if (!noExplanatoryVar) {
                    scoresM[1] = Double.parseDouble(item.getValue()[3]);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }
                row[0] = item.getValue()[0];
                row[1] = item.getValue()[1];
                row[2] = item.getValue()[2];
                if (!noExplanatoryVar) {
                    row[3] = item.getValue()[3];
                }
                countsRegList.add(scoresM);
                geneOrder.add(item.getKey());

                row[row.length - 1] = item.getValue()[2];
                geneMutRateSheet.add(row);
            }
        }
//bw.close();

//codes to address the comments reviewers
        if (geneCoverages != null && !geneCoverages.isEmpty()) {
            for (Map.Entry<String, double[]> item : geneCoverages.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScore = geneScores.get(item.getKey());
                    if (geneScore == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScore.length; k++) {
                        if (Double.isNaN(geneScore[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }
                }

                double[] scoresM = new double[scoreNum];
                String[] row = new String[colNum];
                scoresM[0] = 0;
                if (!noExplanatoryVar) {
                    double[] varNums = geneVarNums.get(item.getKey());
                    if (varNums == null) {
                        scoresM[1] = 0;
                    } else {
                        scoresM[1] = varNums[1];
                    }
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }

                countsRegList.add(scoresM);
                geneOrder.add(item.getKey());
                geneMutRateSheet.add(row);
            }
        }

        //end of the testing codes
        if (nonZeroSynNum < 8000) {
            String info = "There seems insufficient number of variants (" + nonZeroSynNum + ") for a stable model, please add option ‘--ref-mut-file path/to/referenceDataset’ to incorporate more background variants.";
            // String info = "There seems no variants in your input data. The mutation burden analysis aborts!";
            LOG.warn(info);
            //return null;
        }

        double[] residueCounter = caculateResidueByRIterative(geneOrder, scoreHeads, countsRegList, noExplanatoryVar, 0);
        // double[] residueCounter = caculateResidueByRIterativeNegBi(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, 0);

        //double[] residueCounter = caculateResidueByRIterative0(orderedAllGenes, false, scoreHeads, countsRegListCopied,null, noExplanatoryVar);
        if (residueCounter == null) {
            return null;
        }
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        Map<String, Double> lmRegGeneP = new HashMap<String, Double>();
        int geneNum = residueCounter.length;
        int popuSize = 19061;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];

                //one tailed test
                if (pArray[t] < 0) {
                    pArray[t] = 1 - Probability.normal(pArray[t]);
                } else {
                    pArray[t] = Probability.normal(-pArray[t]);
                }

            }
            MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = geneMutRateSheet.size();
            for (int t = 0; t < geneNum; t++) {
                countsRegGeneP.put(geneOrder.get(t), new double[]{residueCounter[t], pArray[t]});
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    // System.out.println(regressionFactors);
                    if (hasRefBackground) {
                        v[colNum - 3] = String.valueOf(p[0]);
                        v[colNum - 2] = String.valueOf(p[1]);
                    } else {
                        v[colNum - 2] = String.valueOf(p[0]);
                        v[colNum - 1] = String.valueOf(p[1]);
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    double[] pvalues = new double[2];

                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    hasP = true;
                    pvalues[0] = p[1];
                    pvalues[1] = p[0];
                    geneMutRegPValueAllVar.put(v[0], pvalues);
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes
                if (hasRefBackground && refGeneScores.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScore = geneScores.get(items[0]);
                    if (geneScore != null) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                }
                geneMutRateSheet.add(row);
            }
        }/*
        else {
            String msg = "Error, the hurdle regression regressionFactors-values are not correctly estimate due to missing data";
            LOG.error(msg);
        }*/


        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        return geneMutRateSheet;

    }

    public List<String[]> geneSomaticMutationRateTestFlexibleWeight(String rHost, int rPort, Genome genome, String[] indexLabels, Map<String, Map<String, Integer>> cosmicGeneMut, Map<String, double[]> geneScores,
            List<String> scoreHeads, double genePValueCutoff, boolean considerFunVar, Map<String, double[]> geneMutRegPValueAllVar,
            boolean noExplanatoryVar, String refMutGeneFile, int threadNum) throws Exception {
        Chromosome[] chroms = genome.getChromosomes();

        boolean needPubMedAnno = false;
        boolean needCosmic = false;
        int shiftCol = 0;

        if (cosmicGeneMut != null) {
            needCosmic = true;
        }

        String[] basicHeadRow = null;
        int independentVarCol = 0;
        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
        }
        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        if (needCosmic) {
            geneTableHeadRow.add("COSMICCancerInfo");
            shiftCol++;
        }

        for (String name : scoreHeads) {
            geneTableHeadRow.add(name);
        }

        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        if (refMutGeneFile != null) {
            hasRefBackground = true;
            geneTableHeadRow.add("MergedAlleleNum");
        }

        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        List<double[]> countsRegList = new ArrayList<double[]>();

        int colNum = geneTableHeadRow.size();
        int nsVar = 0, sVar = 0, nsVarScore = 0;

        int scoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        if (geneScores != null && !geneScores.isEmpty()) {
            scoreNum = geneScores.get((new ArrayList(geneScores.keySet())).get(0)).length;
            hasGeneScore = true;
        }
        scoreNum += (1 + independentVarCol);
        int nonZeroNonSynNum = 0;
        double nSNScore = 0;
        String COSMICCancerInfo;
        double[] geneScore = null;
        List<Gene> orderedGenes = new ArrayList<Gene>();
        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        Map< String, String[]> refGeneScores = null;
        if (refMutGeneFile != null) {
            refGeneScores = loadGeneScores(refMutGeneFile, 0.3);
        }
        //codes to address reviewers' comments
        boolean withCoverage = false;
        //codes to address reviewers' comments
        Map<String, double[]> geneCoverages = null;
        Map<String, double[]> geneVarNums = null;
        if (withCoverage) {
            geneVarNums = new HashMap<String, double[]>();
            geneCoverages = readGeneCoverages("LUADCov.txt", 90);
        }
        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");

        DoubleArrayList scoresDistr = new DoubleArrayList();
        int nonZeroSynNum = 0;
        Set<String> localGeneSet = new HashSet<String>();
        for (int i = 0; i < chroms.length; i++) {
            if (chroms[i] == null) {
                continue;
            }

            for (Gene gene : chroms[i].geneList) {
                if (gene.geneSymb == null) {
                    continue;
                }
                //remove low coverage genes
                if (withCoverage) {
                    if (!geneCoverages.containsKey(gene.geneSymb)) {
                        continue;
                    }
                }

                hasNA = false;
                if (hasGeneScore) {
                    geneScore = geneScores.get(gene.geneSymb);
                    if (geneScore == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScore.length; k++) {
                        if (Double.isNaN(geneScore[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }
                }

                //  System.out.println(gene.geneSymb);
                nsVar = gene.getDepVarMutNum(0);
                DoubleArrayList scores = gene.getDepMutScore();
                if (considerFunVar && scores != null) {
                    scoresDistr.addAllOf(scores);
                }
                nsVarScore = nsVar;
                if (!noExplanatoryVar) {
                    sVar = gene.getIndepVarMutNum(0);
                    if (sVar != 0) {
                        nonZeroSynNum++;
                    }
                }

                if (nsVar == 0) {
                    continue;
                }
                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                nSNScore = nsVarScore;

                if (nSNScore <= 0) {
                    String[] row = new String[colNum];
                    row[0] = gene.geneSymb;
                    row[1] = String.valueOf(nsVar);
                    row[2] = String.valueOf(nsVarScore);
                    if (!noExplanatoryVar) {
                        row[3] = String.valueOf(sVar);
                    }

                    if (hasGeneScore) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                    geneZeroMutRateSheet.add(row);
                    if (withCoverage) {
                        geneVarNums.put(gene.geneSymb, new double[]{0, sVar});
                    }
                    continue;
                }

                String[] row = new String[colNum];
                row[0] = gene.geneSymb;
                row[1] = String.valueOf(nsVar);
                row[2] = String.valueOf(nsVarScore);
                if (!noExplanatoryVar) {
                    row[3] = String.valueOf(sVar);
                }

                if (needPubMedAnno) {
                    //  geneTableRow.add(info[2]);
                }
                if (needCosmic) {
                    Map<String, Integer> sb = cosmicGeneMut.get(row[0]);
                    if (sb == null) {
                        COSMICCancerInfo = ".";
                    } else {
                        COSMICCancerInfo = sb.toString();
                    }
                    row[3 + independentVarCol] = COSMICCancerInfo;
                }
                localGeneSet.add(row[0]);

                double[] scoresM = new double[scoreNum];
                scoresM[0] = nSNScore;
                if (!noExplanatoryVar) {
                    scoresM[1] = sVar;
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }
                row[row.length - 1] = "0";

                if (refGeneScores != null && !refGeneScores.isEmpty()) {
                    String[] items = refGeneScores.get(row[0]);
                    if (items != null) {
                        scoresM[0] += Double.parseDouble(items[2]);
                        row[1] = String.valueOf(Double.parseDouble(row[1]) + Double.parseDouble(items[1]));
                        row[2] = String.valueOf(scoresM[0]);
                        if (!noExplanatoryVar) {
                            scoresM[1] += Double.parseDouble(items[3]);
                            row[3] = String.valueOf(scoresM[1]);
                        }
                        row[row.length - 1] = items[2];
                        gene.appendVarScore(items[items.length - 1]);

                    }

                }

                countsRegList.add(scoresM);
                geneMutRateSheet.add(row);
                nonZeroNonSynNum += scoresM[0];

                orderedGenes.add(gene);
            }
        }

        //add socres new genes       
        if (refGeneScores != null && !refGeneScores.isEmpty()) {
            for (Map.Entry<String, String[]> item : refGeneScores.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScore = geneScores.get(item.getKey());
                    if (geneScore == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScore.length; k++) {
                        if (Double.isNaN(geneScore[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }
                }
                String[] cells = item.getValue();
                double[] scoresM = new double[scoreNum];
                String[] row = new String[colNum];
                scoresM[0] = Double.parseDouble(cells[2]);
                if (!noExplanatoryVar) {
                    scoresM[1] = Double.parseDouble(cells[3]);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }
                row[0] = cells[0];
                row[1] = cells[1];
                row[2] = cells[2];
                if (!noExplanatoryVar) {
                    row[3] = cells[3];
                }
                countsRegList.add(scoresM);
                Gene g = new Gene(item.getKey());

                g.appendVarScore(cells[cells.length - 1]);
                orderedGenes.add(g);

                row[row.length - 1] = cells[2];
                geneMutRateSheet.add(row);
            }
        }
//bw.close();

        if (nonZeroSynNum < 5) {
            String info = "There seems no synonymous variants in your input data. The mutation burden analysis aborts!";
            LOG.error(info);
            return null;
        }
        //end of the testing codes
        if (nonZeroNonSynNum < 5) {
            String info = "There seems no non-synonymous variants in your input data. The mutation burden analysis aborts!";
            LOG.error(info);
            return null;
        }
        scoresDistr.quickSort();

        Map<String, String> geneAlleleScoreMap = new HashMap<String, String>();
        //keep the orginal scores and 
        for (Gene g : orderedGenes) {
            geneAlleleScoreMap.put(g.geneSymb, g.getVarScoreStrs());
        }
        //stardaize the scores of varaints to be ranged 0 and 1
        if (considerFunVar) {
            for (Gene g : orderedGenes) {
                g.rescaleVarScores(scoresDistr);
            }
        }
        scoresDistr.clear();

        double[] optimalBinCut = new double[1];
        //double[] residueCounter = caculateResidueByRIterativeExploreWeight(orderedGenes, scoreHeads, countsRegList, noExplanatoryVar, 0, considerFunVar, optimalBinCut);
        double[] residueCounter = caculateResidueWITERThread(rHost, rPort, orderedGenes, scoreHeads, countsRegList,
                noExplanatoryVar, considerFunVar, optimalBinCut, threadNum);

// double[] residueCounter = caculateResidueByRIterativeNegBi(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, 0);
        //double[] residueCounter = caculateResidueByRIterative0(orderedAllGenes, false, scoreHeads, countsRegListCopied,null, noExplanatoryVar);
        if (residueCounter == null) {
            return null;
        }
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        Map<String, Double> lmRegGeneP = new HashMap<String, Double>();
        int geneNum = residueCounter.length;
        int popuSize = 19061;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];

                //one tailed test
                if (pArray[t] < 0) {
                    pArray[t] = 1 - Probability.normal(pArray[t]);
                } else {
                    pArray[t] = Probability.normal(-pArray[t]);
                }

            }
            MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = geneMutRateSheet.size();
            for (int t = 0; t < geneNum; t++) {
                countsRegGeneP.put(orderedGenes.get(t).geneSymb, new double[]{residueCounter[t], pArray[t], orderedGenes.get(t).getDepVarMutNum(optimalBinCut[0])});
            }
            orderedGenes.clear();
            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    //the weighted mutation counts
                    v[2] = String.valueOf(p[2]);
                    // System.out.println(regressionFactors);
                    if (hasRefBackground) {
                        v[colNum - 3] = String.valueOf(p[0]);
                        v[colNum - 2] = String.valueOf(p[1]);
                    } else {
                        v[colNum - 2] = String.valueOf(p[0]);
                        v[colNum - 1] = String.valueOf(p[1]);
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    double[] pvalues = new double[2];

                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    hasP = true;
                    pvalues[0] = p[1];
                    pvalues[1] = p[0];
                    geneMutRegPValueAllVar.put(v[0], pvalues);
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes
                if (hasRefBackground && refGeneScores.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScore = geneScores.get(items[0]);
                    if (geneScore != null) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                }
                geneMutRateSheet.add(row);
            }

        }/*
        else {
            String msg = "Error, the hurdle regression regressionFactors-values are not correctly estimate due to missing data";
            LOG.error(msg);
        }*/


        //at the orginal scores    
        geneTableHeadRow.add("AlleleScore");
        List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>(geneMutRateSheet);
        geneMutRateSheet.clear();
        int size = geneMutRateSheetTmp.size();
        String varScores;
        for (int i = 0; i < size; i++) {
            String[] items = geneMutRateSheetTmp.get(i);
            varScores = geneAlleleScoreMap.get(items[0]);
            if (varScores == null) {
                varScores = ".;.";
            }
            String[] items1 = new String[items.length + 1];
            System.arraycopy(items, 0, items1, 0, items.length);
            items1[items.length] = varScores;
            geneMutRateSheet.add(items1);
        }
        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        return geneMutRateSheet;

    }

    public void appendPubmedAnnoteTopGenes(Map<String, String[]> genePMap, double genePValueCutoff, boolean pubSearchSig,
            int pubSearchGeneNum, List<String> pubmedMeshList, Map<String, String[]> geneNamesMap) throws Exception {
        DoubleArrayList pvList = new DoubleArrayList();
        String pStr, geneSymb, lastGeneFeature;
        double pv;
        double adjGenePValueCutoff, topPValueCutoff;
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        List<String> geneNames = new ArrayList<String>();
        Map<String, String[]> genePMapTmp = new HashMap<String, String[]>();
        String[] names;
        int account = 0;
        String[] values1 = null;
        //Append a outRow
        for (Map.Entry<String, String[]> item : genePMap.entrySet()) {
            String[] values = item.getValue();
            values1 = new String[values.length + 1];
            System.arraycopy(values, 0, values1, 0, values.length);
            genePMapTmp.put(item.getKey(), values1);
        }
        if (values1 == null) {
            return;
        }
        int pubMedIndex = values1.length - 1;
        int pVNum = pubMedIndex - 2;
        for (int i = 0; i < pVNum; i++) {
            topPValueCutoff = -1;
            for (Map.Entry<String, String[]> item : genePMapTmp.entrySet()) {
                pStr = item.getValue()[i];
                if (pStr == null || pStr.equals("NA")) {
                    continue;
                }
                pvList.add(Double.parseDouble(pStr));
            }
            pvList.quickSort();
            adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(genePValueCutoff, pvList);
            if (pubSearchGeneNum > 0) {
                topPValueCutoff = pvList.getQuick(pubSearchGeneNum - 1);
            }
            for (Map.Entry<String, String[]> item : genePMap.entrySet()) {
                if (item.getValue()[pubMedIndex] != null) {
                    continue;
                }
                pStr = item.getValue()[i];
                if (pStr == null || pStr.equals("NA")) {
                    continue;
                }
                pv = Double.parseDouble(pStr);
                if (pv > topPValueCutoff || pv > adjGenePValueCutoff) {
                    break;
                }

                geneSymb = item.getKey();

                geneNames.clear();

                names = geneNamesMap.get(geneSymb);
                if (names != null && names.length > 0) {
                    geneNames.addAll(Arrays.asList(names));
                }
                account++;
                geneNames.add(geneSymb);
                LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                lastGeneFeature = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);

                if (lastGeneFeature.trim().length() == 0) {
                    item.getValue()[pubMedIndex] = "N";
                } else {
                    item.getValue()[pubMedIndex] = lastGeneFeature;
                }

            }

        }

    }

    public void annotateGeneDrawQQPlot(List<String[]> geneMutRateSheet, double genePValueCutoff,
            boolean pubSearchSig, int pubSearchGeneNum, List<String> pubmedMeshList, Map<String, String[]> geneNamesMap, String geneSumOutFile) throws Exception {
        DoubleArrayList genePValuesForQQPlot = new DoubleArrayList();
        List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>();
        int newColNum = 0;
        int geneIndex = 0;
        int pIndex = -1;
        if (geneMutRateSheet == null) {
            return;
        }
        int t = 1, len = geneMutRateSheet.size();
        String[] item;
        if (pubSearchSig || pubSearchGeneNum > 0) {
            newColNum = 1;
        }
        String[] colNames = geneMutRateSheet.get(0);
        for (int i = 0; i < colNames.length; i++) {
            if (colNames[i].equals("P")) {
                pIndex = i;
                break;
            }
        }
        //qvalue column
        int qValueIndex = colNames.length;
        newColNum++;

        String[] itmeTmp = new String[colNames.length + newColNum];
        int pubmedIndex = itmeTmp.length - 1;
        itmeTmp[qValueIndex] = "BHFDR-q";
        System.arraycopy(colNames, 0, itmeTmp, 0, colNames.length);
        geneMutRateSheetTmp.add(itmeTmp);
        if (pubSearchSig || pubSearchGeneNum > 0) {
            geneMutRateSheetTmp.get(0)[pubmedIndex] = "PumMedID";
        }

        for (t = 1; t < len; t++) {
            item = geneMutRateSheet.get(t);
            itmeTmp = new String[item.length + newColNum];
            System.arraycopy(item, 0, itmeTmp, 0, item.length);
            geneMutRateSheetTmp.add(itmeTmp);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }
            genePValuesForQQPlot.add(Double.parseDouble(item[pIndex]));
        }
        geneMutRateSheet.clear();
        genePValuesForQQPlot.quickSort();
        List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
        List<String> nameList = new ArrayList<String>();
        pvalueLists.add(genePValuesForQQPlot);
        PValuePainter pvPainter = new PValuePainter(300, 300);
        File plotFile = new File(geneSumOutFile + ".qq.png");
        nameList.add("Gene p");
        pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);
        String info = "The QQ plot saved in " + plotFile.getCanonicalPath();
        LOG.info(info);
        DoubleArrayList geneQValue = new DoubleArrayList();
        double adjGenePValueCutoff = MultipleTestingMethod.BenjaminiHochbergFDR(genePValueCutoff, genePValuesForQQPlot, geneQValue);
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        //double mlfc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, genePValuesForQQPlot);
        //System.out.println("The MLFC score is " + mlfc);
        genePValuesForQQPlot.clear();
        StringBuilder sumSb = new StringBuilder();
        String geneSymb;
        double pv;
        int sigNum = 0;
        List<String> geneNames = new ArrayList<String>();
        String[] names;
        int account = 0;
        String lastGeneFeature;

        for (t = 1; t < len; t++) {
            item = geneMutRateSheetTmp.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }
            item[qValueIndex] = String.format(geneQValue.getQuick(t - 1) < 0.01 ? "%.2e" : "%.3f", geneQValue.getQuick(t - 1));
            //System.out.println(item[zIndex]+"\t"+ item[item.length - 1] );
        }

        for (t = 1; t < len; t++) {
            item = geneMutRateSheetTmp.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }

            pv = Double.parseDouble(item[pIndex]);
            if (pubSearchGeneNum <= account && pv > adjGenePValueCutoff) {
                break;
            }
            if (pv <= adjGenePValueCutoff) {
                sigNum++;
            }
            geneSymb = item[geneIndex];
            if ((pubSearchSig && (pv <= adjGenePValueCutoff)) || pubSearchGeneNum > account) {
                geneNames.clear();

                names = geneNamesMap.get(geneSymb);
                if (names != null && names.length > 0) {
                    geneNames.addAll(Arrays.asList(names));
                }
                account++;
                geneNames.add(geneSymb);
                LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                lastGeneFeature = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);

                if (lastGeneFeature.trim().length() == 0) {
                    item[pubmedIndex] = "N";
                } else {
                    item[pubmedIndex] = lastGeneFeature;
                }
            }

        }

        sumSb.append(sigNum).append(" genes with p-value <= ").append(adjGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());

        geneMutRateSheet.addAll(geneMutRateSheetTmp);

    }

    public void annotateGenePubMed(List<String[]> geneMutRateSheet, int sortCol, int pIndex, int pubmedCol, double genePValueCutoff,
            boolean pubSearchSig, int pubSearchGeneNum, List<String> pubmedMeshList, Map<String, String[]> geneNamesMap) throws Exception {

        int geneIndex = 0;

        if (geneMutRateSheet == null) {
            return;
        }
        int t = 1, len = geneMutRateSheet.size();
        String[] item;
        StringArrayIntegerComparator sic = new StringArrayIntegerComparator(sortCol);

        Collections.sort(geneMutRateSheet, sic);

        int pubmedIndex = pubmedCol;

        double adjGenePValueCutoff = genePValueCutoff;
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        //double mlfc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, genePValuesForQQPlot);
        //System.out.println("The MLFC score is " + mlfc);

        StringBuilder sumSb = new StringBuilder();
        String geneSymb;
        double pv;
        int sigNum = 0;
        List<String> geneNames = new ArrayList<String>();
        String[] names;
        int account = 0;
        String lastGeneFeature;

        for (t = 1; t < len; t++) {
            item = geneMutRateSheet.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }

            pv = Double.parseDouble(item[pIndex]);
            if (pubSearchGeneNum <= account && pv > adjGenePValueCutoff) {
                break;
            }
            if (pv <= adjGenePValueCutoff) {
                sigNum++;
            }
            geneSymb = item[geneIndex];
            if ((pubSearchSig && (pv <= adjGenePValueCutoff)) || pubSearchGeneNum > account) {
                geneNames.clear();

                names = geneNamesMap.get(geneSymb);
                if (names != null && names.length > 0) {
                    geneNames.addAll(Arrays.asList(names));
                }
                account++;
                geneNames.add(geneSymb);
                LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                lastGeneFeature = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);

                if (lastGeneFeature.trim().length() == 0) {
                    item[pubmedIndex] = "N";
                } else {
                    item[pubmedIndex] = lastGeneFeature;
                }
            }

        }

        sumSb.append(sigNum).append(" genes with p-value <= ").append(adjGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());

    }

    public void annotatePPIGeneAndOutput(List<String[]> geneMutRateSheet, boolean outExcel, boolean pubSearchSig, int pubSearchGeneNum,
            List<String> pubmedMeshList, Map<String, String[]> geneNamesMap, double genePValueCutoff, List<String[]> ppiPairs, String ppiSumOutFile) throws Exception {

        int newColNum = 0;
        if (pubSearchSig || pubSearchGeneNum > 0) {
            newColNum = 2;
        }
        DoubleArrayList genePValuesForQQPlot = new DoubleArrayList();
        DoubleArrayList ppiPValuesForQQPlot = new DoubleArrayList();

        int pIndex = -1;
        int t = 1, len = geneMutRateSheet.size();
        String[] item;
        Map<String, Double> genePMap = new HashMap<String, Double>();

        String[] colNames = geneMutRateSheet.get(0);
        for (int i = 0; i < colNames.length; i++) {
            if (colNames[i].equals("P")) {
                pIndex = i;
                break;
            }
        }

        double p;
        for (t = 1; t < len; t++) {
            item = geneMutRateSheet.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }
            p = Double.parseDouble(item[pIndex]);
            genePValuesForQQPlot.add(p);
            genePMap.put(item[0], p);
        }

        String[] ppicolNames = new String[9 + newColNum];
        ppicolNames[0] = "Gene1";
        ppicolNames[1] = "P1";
        ppicolNames[2] = "Gene2";
        ppicolNames[3] = "P2";
        ppicolNames[4] = "PPIScore";
        ppicolNames[5] = "CochranQ";
        ppicolNames[6] = "I2";
        ppicolNames[7] = "ppiP";
        ppicolNames[8] = "BHFDR-q";
        if (newColNum > 0) {
            ppicolNames[9] = "Gene1PubMedID";
            ppicolNames[10] = "Gene2PubMedID";
        }

        double[] pvalues = new double[2];
        double v1, v2;
        int ppiSize = ppiPairs.size();
        Double p1, p2;
        List<String[]> ppiMutRateSheet = new ArrayList<String[]>();

        for (int i = 0; i < ppiSize; i++) {
            String[] ppi = ppiPairs.get(i);
            p1 = genePMap.get(ppi[0]);
            if (p1 == null) {
                continue;
            }
            p2 = genePMap.get(ppi[1]);
            if (p2 == null) {
                continue;
            }
            pvalues[0] = p1;
            pvalues[1] = p2;
            v1 = MultipleTestingMethod.combinationHeterogeneityCochranQTest(pvalues);

            v2 = MultipleTestingMethod.combinationHeterogeneityI2(pvalues);
            //filter out pairs with hight heterogenity 
            if (v2 > 0.5) {
                continue;
            }

            String[] ppiItems = new String[9 + newColNum];
            ppiItems[0] = ppi[0];
            ppiItems[1] = String.valueOf(p1);
            ppiItems[2] = ppi[1];
            ppiItems[3] = String.valueOf(p2);
            ppiItems[4] = ppi[2];
            p = Math.log(p1) + Math.log(p2);
            p = Probability.chiSquareComplemented(4, -2 * p);
            // regressionFactors=Gamma.incompleteGammaComplement(2/2, -regressionFactors/2);
            //observedPpiValueArray.add(v);
            ppiItems[5] = String.valueOf(v1);

            ppiItems[6] = String.valueOf(v2);
            ppiItems[7] = String.valueOf(p);
            ppiMutRateSheet.add(ppiItems);
            ppiPValuesForQQPlot.add(p);
        }

        genePValuesForQQPlot.quickSort();
        ppiPValuesForQQPlot.quickSort();
        List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
        List<String> nameList = new ArrayList<String>();
        pvalueLists.add(genePValuesForQQPlot);
        pvalueLists.add(ppiPValuesForQQPlot);

        PValuePainter pvPainter = new PValuePainter(400, 400);
        File plotFile = new File(ppiSumOutFile + ".qq.png");
        nameList.add("Gene p");
        nameList.add("PPI p");
        pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);
        String info = "The QQ plot saved in " + plotFile.getCanonicalPath();
        LOG.info(info);
        DoubleArrayList ppiGeneQValue = new DoubleArrayList();
        double adjPPIGenePValueCutoff = MultipleTestingMethod.BenjaminiHochbergFDR(genePValueCutoff, ppiPValuesForQQPlot, ppiGeneQValue);

        //double mlfc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, genePValuesForQQPlot);
        //System.out.println("The MLFC score is " + mlfc);
        genePValuesForQQPlot.clear();
        StringBuilder sumSb = new StringBuilder();

        int sigNum = 0;

        int qValueIndex = 8;
        pIndex = 7;
        Collections.sort(ppiMutRateSheet, new StringArrayDoubleComparator(pIndex));
        ppiMutRateSheet.add(0, ppicolNames);
        len = ppiMutRateSheet.size();
        double pv;
        List<String> geneNames = new ArrayList<String>();
        String[] names;
        int account = 0;
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        Map<String, String> genePubMedIDMap = new HashMap<String, String>();
        String geneSymb, ids;
        int[] searchSymbolIndex = new int[]{0, 2};
        for (t = 1; t < len; t++) {
            item = ppiMutRateSheet.get(t);
            if (item[pIndex] == null || item[pIndex].equals(".")) {
                continue;
            }
            item[qValueIndex] = String.format(ppiGeneQValue.getQuick(t - 1) < 0.01 ? "%.2e" : "%.3f", ppiGeneQValue.getQuick(t - 1));
            //System.out.println(item[zIndex]+"\t"+ item[item.length - 1] );
            pv = Double.parseDouble(item[pIndex]);
            for (int k = 0; k < searchSymbolIndex.length; k++) {
                geneSymb = item[searchSymbolIndex[k]];
                ids = genePubMedIDMap.get(geneSymb);
                if (ids != null) {
                    item[9 + k] = ids;
                    continue;
                }
                if ((pubSearchSig && (pv <= adjPPIGenePValueCutoff)) || pubSearchGeneNum > account) {
                    geneNames.clear();

                    names = geneNamesMap.get(geneSymb);
                    if (names != null && names.length > 0) {
                        geneNames.addAll(Arrays.asList(names));
                    }
                    account++;
                    geneNames.add(geneSymb);
                    LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                    ids = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);

                    if (ids.trim().length() == 0) {
                        item[9 + k] = "N";
                        genePubMedIDMap.put(geneSymb, "N");
                    } else {
                        item[9 + k] = ids;
                        genePubMedIDMap.put(geneSymb, ids);
                    }
                }
            }

        }

        sumSb.append(sigNum).append(" genes with p-value <= ").append(adjPPIGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());

        String outFileName = ppiSumOutFile;
        if (outExcel) {
            outFileName += ".xlsx";
            LocalExcelFile.writeArray2XLSXFile(ppiSumOutFile, ppiMutRateSheet, true, -1, 0);
        } else {
            outFileName += ".txt";
            org.cobi.util.text.LocalFile.writeData(outFileName, ppiMutRateSheet, "\t", false);
        }
        ppiMutRateSheet.clear();
        info = "The results of PPI-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
        LOG.info(info);
    }

    public void annotateGenePairAndOutput(List<String[]> genePairs, String outFilePath, boolean pubSearchSig, int pubSearchGeneNum, List<String> pubmedMeshList,
            Map<String, String[]> geneNamesMap, double genePValueCutoff, boolean outExcel) throws Exception {

        int newColNum = 0;
        if (pubSearchSig || pubSearchGeneNum > 0) {
            newColNum = 2;
        }

        DoubleArrayList ppiPValuesForQQPlot = new DoubleArrayList();
        String[] ppicolNames = new String[15 + newColNum];
        ppicolNames[0] = "GeneA";
        ppicolNames[1] = "GeneAChrPos";
        ppicolNames[2] = "GeneB";
        ppicolNames[3] = "GeneBChrPos";
        ppicolNames[4] = "Score";
        ppicolNames[5] = "CaseSize";
        ppicolNames[6] = "ACase";
        ppicolNames[7] = "BCase";
        ppicolNames[8] = "ABCase";
        ppicolNames[9] = "ControlSize";
        ppicolNames[10] = "AControl";
        ppicolNames[11] = "BControl";
        ppicolNames[12] = "ABControl";
        ppicolNames[13] = "OR";
        ppicolNames[14] = "p";
        //  ppicolNames[11] = "BHFDR-q";
        if (newColNum > 0) {
            ppicolNames[15] = "Gene1PubMedID";
            ppicolNames[16] = "Gene2PubMedID";
        }

        double pv, v2;
        int ppiSize = genePairs.size();
        int qValueIndex = 11;
        int pIndex = 14;
        for (int i = 0; i < ppiSize; i++) {
            String[] ppi = genePairs.get(i);
            if (ppi[pIndex] != null) {
                pv = Double.parseDouble(ppi[pIndex]);
                ppiPValuesForQQPlot.add(pv);
            }

        }

        double adjPPIGenePValueCutoff = Double.NaN;
        boolean hasPValue = false;
        if (ppiPValuesForQQPlot.size() > 0) {
            ppiPValuesForQQPlot.quickSort();
            List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
            List<String> nameList = new ArrayList<String>();

            pvalueLists.add(ppiPValuesForQQPlot);

            PValuePainter pvPainter = new PValuePainter(400, 400);
            File plotFile = new File(outFilePath + ".qq.png");
            nameList.add("Gene pair p");
            pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);
            String info = "The QQ plot saved in " + plotFile.getCanonicalPath();
            LOG.info(info);
            DoubleArrayList ppiGeneQValue = new DoubleArrayList();
            adjPPIGenePValueCutoff = MultipleTestingMethod.BenjaminiHochbergFDR(genePValueCutoff, ppiPValuesForQQPlot, ppiGeneQValue);
            ppiPValuesForQQPlot.clear();
            hasPValue = true;
        }

        //double mlfc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, genePValuesForQQPlot);
        //System.out.println("The MLFC score is " + mlfc);
        StringBuilder sumSb = new StringBuilder();

        int sigNum = 0;

        if (hasPValue) {
            Collections.sort(genePairs, new StringArrayDoubleComparator(pIndex));
        }
        genePairs.add(0, ppicolNames);

        List<String> geneNames = new ArrayList<String>();
        String[] names;
        int account = 0;
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        Map<String, String> genePubMedIDMap = new HashMap<String, String>();
        String geneSymb, ids;
        int[] searchSymbolIndex = new int[]{0, 2};
        if (hasPValue) {
            for (int t = 1; t < ppiSize; t++) {
                String[] item = genePairs.get(t);

                if (item[pIndex] == null || item[pIndex].equals(".")) {
                    continue;
                }
                pv = Double.parseDouble(item[pIndex]);
                if (pv <= adjPPIGenePValueCutoff) {
                    for (int k = 0; k < searchSymbolIndex.length; k++) {
                        geneSymb = item[searchSymbolIndex[k]];
                        ids = genePubMedIDMap.get(geneSymb);
                        if (ids != null) {
                            item[9 + k] = ids;
                            continue;
                        }
                        if ((pubSearchSig && (pv <= adjPPIGenePValueCutoff)) || pubSearchGeneNum > account) {
                            geneNames.clear();

                            names = geneNamesMap.get(geneSymb);
                            if (names != null && names.length > 0) {
                                geneNames.addAll(Arrays.asList(names));
                            }
                            account++;
                            geneNames.add(geneSymb);
                            LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                            ids = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);

                            if (ids.trim().length() == 0) {
                                item[9 + k] = "N";
                                genePubMedIDMap.put(geneSymb, "N");
                            } else {
                                item[9 + k] = ids;
                                genePubMedIDMap.put(geneSymb, ids);
                            }
                        }
                    }

                }

            }
        }

        sumSb.append(sigNum).append(" genes with p-value <= ").append(adjPPIGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());

        String outFileName = outFilePath;
        if (outExcel) {
            outFileName += ".xlsx";
            LocalExcelFile.writeArray2XLSXFile(outFileName, genePairs, true, -1, 0);
        } else {
            outFileName += ".txt";
            org.cobi.util.text.LocalFile.writeData(outFileName, genePairs, "\t", false);
        }
        genePairs.clear();
        String info = "The results of gene pair test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
        LOG.info(info);
    }

    public List<String[]> geneMutationRateTestChangeFreq(String rHost, int rPort, Genome genome, String[] indexLabels, Map<String, double[]> orgGeneScoreMap,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double freqCut, List<String> scoreHeads, boolean useFunctionWeight, String refMutGeneFile,
            boolean noExplanatoryVar, boolean needInteraction, int orgScoreNum, int addedCovNum, int threadNum, int caseControlAlleleNumIndex, boolean usingLog, boolean protectiveEffect) throws Exception {

        Chromosome[] chroms = genome.getChromosomes();

        boolean needPubMedAnno = false;

        int shiftCol = 0;

        //fix the geneFreqScoreIndex to be the second column in countsRegListCopied
        int geneFreqScoreIndex = orgScoreNum;

        String[] basicHeadRow = null;
        int independentVarCol = 0;

        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseMut", "DetailedMut"};
        } else {
            //ResponseVarScore
            basicHeadRow = new String[]{"GeneSymbol", "ResponseMut", "DetailedMut", "ExplanatoryMut"};
            independentVarCol++;
            geneFreqScoreIndex++;
        }
        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        List<Gene> orderedGenes = new ArrayList<Gene>();

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        int orgScoreStart = 1;
        int orgScoreEnd = orgScoreStart + orgScoreNum;
        for (int i = 0; i < orgScoreNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i));
        }
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    geneTableHeadRow.add(scoreHeads.get(i) + "*" + scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i + orgScoreNum));
        }
        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        Map<String, String[]> referenceSampleGeneScoreMap = null;
        if (refMutGeneFile != null) {
            referenceSampleGeneScoreMap = loadGeneScores(refMutGeneFile, 0.4);
            if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                hasRefBackground = true;
                geneTableHeadRow.add("MergedAlleleNum");
            }

        }

        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        List<double[]> countsRegList = new ArrayList<double[]>();

        int colNum = geneTableHeadRow.size();
        int nsVar, nsVarScore;
        double sVar = 0;
        int totalScoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        if (orgGeneScoreMap != null && !orgGeneScoreMap.isEmpty()) {
            hasGeneScore = true;
        }
        int interactionCols = 0;
        if (needInteraction) {
            interactionCols = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        totalScoreNum = orgScoreNum + independentVarCol + interactionCols + addedCovNum;

        int nonZeroSynNum = 0;
        double nSNScore = 0;

        double[] geneScores = null;
        List<String> geneOrder = new ArrayList<String>();
        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        Set<String> localGeneSet = new HashSet<String>();
        IntArrayList mergedDepVarScores = new IntArrayList();
        IntArrayList mergedIndpVarScores = new IntArrayList();
        int mergedDepVarScore = 0, mergedIndpVarScore = 0;

        for (int i = 0; i < chroms.length; i++) {
            if (chroms[i] == null) {
                continue;
            }

            for (Gene gene : chroms[i].geneList) {
                if (gene.geneSymb == null) {
                    continue;
                }

                // note: when refGeneVarFreqScoreMap has no such a gene, it means the gene has very rare frequencies
                //so this condition is not suitable
                //however, some genes have no  refGeneVarFreqScoreMap probably only because it has no functional scores at its variants. Setting the gene frequency score as 0 may lead to many false positive predictions
//                if (!refGeneVarFreqScoreMap.containsKey(gene.geneSymb)) {
//                    continue;
//                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(gene.geneSymb);
                    if (geneScores == null) {
                        continue;
                    }
                    for (int k = geneScores.length - addedCovNum; k < geneScores.length; k++) {
                        if (Double.isNaN(geneScores[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    //if we use imput, we do not need exclude missing values
                    if (hasNA) {
                        continue;
                    }
                }
                nsVar = gene.getDepVarMutNum(0, caseControlAlleleNumIndex, 3);

                nsVarScore = nsVar;
                if (!noExplanatoryVar) {
                    sVar = gene.getIndepVarMutNum(0, caseControlAlleleNumIndex, 3);
                }

                if (nsVar == 0) {
                    continue;
                }
                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                nSNScore = nsVarScore;

                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                if (nSNScore <= 0) {
                    String[] row = new String[colNum];
                    row[0] = gene.geneSymb;
                    row[1] = String.valueOf(nsVar);
                    // row[2] = String.valueOf(nsVarScore);
                    row[2] = gene.getVarTypeCouts();

                    if (!noExplanatoryVar) {
                        row[3] = String.valueOf(sVar);
                    }

                    if (hasGeneScore) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }

                    geneZeroMutRateSheet.add(row);
                    continue;
                }

                mergedDepVarScore = 0;
                mergedIndpVarScore = 0;

                String[] outRow = new String[colNum];
                outRow[0] = gene.geneSymb;
                outRow[1] = String.valueOf(nsVar);
                // outRow[2] = String.valueOf(nsVarScore);
                outRow[2] = gene.getVarTypeCouts();
                if (!noExplanatoryVar) {
                    outRow[3] = String.valueOf(sVar);
                }

                if (needPubMedAnno) {
                    //  geneTableRow.add(info[2]);
                }

                localGeneSet.add(outRow[0]);

                //possible interaction columns
                //
                double[] calcRow = new double[totalScoreNum + 1];
                calcRow[0] = nSNScore;
                if (!noExplanatoryVar) {
                    calcRow[1] = sVar;
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScores.length; t++) {
                        calcRow[totalScoreNum + 1 - geneScores.length + t] = (geneScores[t]);
                        outRow[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                    }
                }

                outRow[outRow.length - 1] = "0";
                if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                    String[] items = referenceSampleGeneScoreMap.get(outRow[0]);

                    if (items != null) {
                        mergedDepVarScore = (int) Double.parseDouble(items[2]);
                        calcRow[0] += mergedDepVarScore;
                        if (!noExplanatoryVar) {
                            mergedIndpVarScore = (int) Double.parseDouble(items[3]);
                            calcRow[1] += mergedIndpVarScore;

                        }
                        outRow[outRow.length - 1] = items[2];

                        gene.appendVarScore(items[items.length - 1]);
                    }
                }

                countsRegList.add(calcRow);

                geneMutRateSheet.add(outRow);
                nonZeroSynNum += calcRow[0];
                mergedDepVarScores.add(mergedDepVarScore);
                mergedIndpVarScores.add(mergedIndpVarScore);

                geneOrder.add(gene.geneSymb);
                orderedGenes.add(gene);
            }
        }

        //add socres new genes  which have counts in the local gene sets    
        if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
            for (Map.Entry<String, String[]> item : referenceSampleGeneScoreMap.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(item.getKey());
                    if (geneScores == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScores.length; k++) {
                        if (Double.isNaN(geneScores[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }

                }

                double[] scoresM = new double[totalScoreNum + 1];
                String[] row = new String[colNum];
                mergedDepVarScore = (int) Double.parseDouble(item.getValue()[2]);
                scoresM[0] = mergedDepVarScore;
                if (!noExplanatoryVar) {
                    mergedIndpVarScore = (int) Double.parseDouble(item.getValue()[3]);
                    scoresM[1] = Double.parseDouble(item.getValue()[3]);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScores.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScores[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                    }
                }
                row[0] = item.getValue()[0];
                row[1] = item.getValue()[1];
                row[2] = item.getValue()[2];
                if (!noExplanatoryVar) {
                    row[3] = item.getValue()[3];
                }
                countsRegList.add(scoresM);
                geneOrder.add(item.getKey());

                mergedDepVarScores.add(mergedDepVarScore);
                mergedIndpVarScores.add(mergedIndpVarScore);

                row[row.length - 1] = item.getValue()[2];
                geneMutRateSheet.add(row);

                String[] cells = item.getValue();
                Gene g = new Gene(item.getKey());

                g.appendVarScore(cells[cells.length - 1]);
                orderedGenes.add(g);
            }
        }

//bw.close();
        if (nonZeroSynNum < 5) {
            String info = "There seems no variants in your input data. The mutation burden analysis aborts!";
            LOG.error(info);
            return null;
        }
        boolean isOneGene = true;
        //double[] residueCounter = caculateResidueByRIterative(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, geneFreqScores, scoreBinNum, geneFreqScoreIndex);
        double[] residueCounter = caculateResidueRUNNERThread(rHost, rPort, orderedGenes, scoreHeads, countsRegList, freqCut, noExplanatoryVar,
                refGeneVarFreqScoreMap, caseControlAlleleNumIndex, geneFreqScoreIndex, threadNum, needInteraction, orgScoreStart, orgScoreEnd,
                addedCovNum, useFunctionWeight, hasRefBackground, mergedDepVarScores, mergedIndpVarScores, isOneGene, usingLog, protectiveEffect);

        if (residueCounter == null) {
            return null;
        }
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        int geneNum = residueCounter.length;

        double[] pvalues = new double[2];
        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];
                if (!protectiveEffect) {
                    //one tailed test
                    if (pArray[t] < 0) {
                        pArray[t] = 1 - Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = Probability.normal(-pArray[t]);
                    }
                } else {
                    if (pArray[t] < 0) {
                        pArray[t] = Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = 1 - Probability.normal(-pArray[t]);
                    }
                }
            }
            // MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = geneMutRateSheet.size();
            for (int t = 0; t < geneNum; t++) {
                //the predictors have been updated
                double[] v = countsRegList.get(t);
                double[] nv = new double[v.length + 2];
                System.arraycopy(v, 0, nv, 0, v.length);
                nv[v.length] = residueCounter[t];
                nv[v.length + 1] = pArray[t];
                countsRegGeneP.put(geneOrder.get(t), nv);
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;
            int pVIndex = -1;
            double val;
            for (int i = 0; i < geneTableHeadRow.size(); i++) {
                if (geneTableHeadRow.get(i).equals("P")) {
                    pVIndex = i + 1;
                    break;
                }
            }

            for (String[] v : geneMutRateSheet) {
                double[] regressionFactors = countsRegGeneP.get(v[0]);
                hasP = false;
                if (regressionFactors != null) {
                    // System.out.println(regressionFactors);

                    //ingore the weighted mutation counts by +1
                    for (int i = pVIndex - regressionFactors.length + 1; i < pVIndex; i++) {
                        val = regressionFactors[i - pVIndex + regressionFactors.length];
                        if (Double.isNaN(val)) {
                            v[i] = null;
                        } else {
                            v[i] = String.valueOf(val);
                        }
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    pvalues[0] = regressionFactors[regressionFactors.length - 2];
                    pvalues[1] = regressionFactors[regressionFactors.length - 1];
                    if (Double.isNaN(pvalues[1])) {
                        hasP = false;
                    } else {
                        hasP = true;
                    }
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes        
                if (hasRefBackground && referenceSampleGeneScoreMap.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(items[0]);
                    if (geneScores != null) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }
                }
                geneMutRateSheet.add(row);
            }

        }
        //geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        Map<String, String> geneAlleleScoreMap = new HashMap<String, String>();
        //keep the orginal scores and 
        for (Gene g : orderedGenes) {
            geneAlleleScoreMap.put(g.geneSymb, g.getVarScoreStrs());
        }

        geneTableHeadRow.add("AlleleScore");
        List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>(geneMutRateSheet);
        geneMutRateSheet.clear();
        int size = geneMutRateSheetTmp.size();
        String varScores;
        for (int i = 0; i < size; i++) {
            String[] items = geneMutRateSheetTmp.get(i);
            varScores = geneAlleleScoreMap.get(items[0]);
            if (varScores == null) {
                varScores = ".;.";
            }
            String[] items1 = new String[items.length + 1];
            System.arraycopy(items, 0, items1, 0, items.length);
            items1[items.length] = varScores;
            geneMutRateSheet.add(items1);
        }
        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));
        return geneMutRateSheet;
    }

    public List<String[]> PPIMutationRateTestChangeFreq(String rHost, int rPort, Genome genome, String[] indexLabels, Map<String, double[]> orgGeneScoreMap,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double freqCut, List<String> scoreHeads, boolean useFunctionWeight, String refMutGeneFile,
            boolean noExplanatoryVar, boolean needInteraction, int orgScoreNum, int addedCovNum, int threadNum, int caseControlAlleleNumIndex, String ppiDBFile, boolean protectiveEffect) throws Exception {

        Chromosome[] chroms = genome.getChromosomes();

        boolean needPubMedAnno = false;

        int shiftCol = 0;

        //fix the geneFreqScoreIndex to be the second column in countsRegListCopied
        int geneFreqScoreIndex = orgScoreNum;

        String[] basicHeadRow = null;
        int independentVarCol = 0;

        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
            geneFreqScoreIndex++;
        }
        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        Map<String, Gene> mappedGenes = new HashMap<String, Gene>();

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        int orgScoreStart = 1;
        int orgScoreEnd = orgScoreStart + orgScoreNum;
        for (int i = 0; i < orgScoreNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i));
        }
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    geneTableHeadRow.add(scoreHeads.get(i) + "*" + scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i + orgScoreNum));
        }
        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        Map<String, String[]> referenceSampleGeneScoreMap = null;
        if (refMutGeneFile != null) {
            referenceSampleGeneScoreMap = loadGeneScores(refMutGeneFile, 0.4);
            if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                hasRefBackground = true;
                geneTableHeadRow.add("MergedAlleleNum");
            }

        }

        Map<String, double[]> geneScoreMap = new HashMap<String, double[]>();

        int colNum = geneTableHeadRow.size();
        int nsVar, nsVarScore;
        double sVar = 0;
        int totalScoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        if (orgGeneScoreMap != null && !orgGeneScoreMap.isEmpty()) {
            hasGeneScore = true;
        }
        int interactionCols = 0;
        if (needInteraction) {
            interactionCols = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        totalScoreNum = orgScoreNum + interactionCols + addedCovNum;

        int nonZeroSynNum = 0;
        double nSNScore = 0;

        double[] geneScores = null;

        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        Set<String> localGeneSet = new HashSet<String>();
        IntArrayList mergedDepVarScores = new IntArrayList();
        IntArrayList mergedIndpVarScores = new IntArrayList();
        int mergedDepVarScore = 0, mergedIndpVarScore = 0;

        for (int i = 0; i < chroms.length; i++) {
            if (chroms[i] == null) {
                continue;
            }

            for (Gene gene : chroms[i].geneList) {
                if (gene.geneSymb == null) {
                    continue;
                }
                if (!refGeneVarFreqScoreMap.containsKey(gene.geneSymb)) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(gene.geneSymb);
                    if (geneScores == null) {
                        continue;
                    }
                    for (int k = geneScores.length - addedCovNum; k < geneScores.length; k++) {
                        if (Double.isNaN(geneScores[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    //if we use imput, we do not need exclude missing values
                    if (hasNA) {
                        continue;
                    }
                }

                nsVar = gene.getDepVarMutNum(0, caseControlAlleleNumIndex, 3);

                nsVarScore = nsVar;
                if (!noExplanatoryVar) {
                    sVar = gene.getIndepVarMutNum(0, caseControlAlleleNumIndex, 3);
                }

                if (nsVar == 0) {
                    continue;
                }
                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                nSNScore = nsVarScore;

                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                if (nSNScore <= 0) {
                    String[] row = new String[colNum];
                    row[0] = gene.geneSymb;
                    row[1] = String.valueOf(nsVar);
                    row[2] = String.valueOf(nsVarScore);
                    if (!noExplanatoryVar) {
                        row[3] = String.valueOf(sVar);
                    }

                    if (hasGeneScore) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }

                    geneZeroMutRateSheet.add(row);
                    continue;
                }

                mergedDepVarScore = 0;
                mergedIndpVarScore = 0;

                //possible interaction columns
                //
                double[] calcRow = new double[totalScoreNum + 1];
                calcRow[0] = nSNScore;
                if (!noExplanatoryVar) {
                    calcRow[1] = sVar;
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScores.length; t++) {
                        calcRow[totalScoreNum + 1 - geneScores.length + t] = (geneScores[t]);
                    }
                }

                if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                    String[] items = referenceSampleGeneScoreMap.get(gene.geneSymb);

                    if (items != null) {
                        mergedDepVarScore = (int) Double.parseDouble(items[2]);
                        calcRow[0] += mergedDepVarScore;
                        if (!noExplanatoryVar) {
                            mergedIndpVarScore = (int) Double.parseDouble(items[3]);
                            calcRow[1] += mergedIndpVarScore;

                        }

                        gene.appendVarScore(items[items.length - 1]);
                    }
                }

                geneScoreMap.put(gene.geneSymb, calcRow);

                nonZeroSynNum += calcRow[0];
                mergedDepVarScores.add(mergedDepVarScore);
                mergedIndpVarScores.add(mergedIndpVarScore);

                mappedGenes.put(gene.geneSymb, gene);
            }
        }

        //add socres new genes  which have counts in the local gene sets    
        if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
            for (Map.Entry<String, String[]> item : referenceSampleGeneScoreMap.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                hasNA = false;
                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(item.getKey());
                    if (geneScores == null) {
                        continue;
                    }

                    for (int k = 0; k < geneScores.length; k++) {
                        if (Double.isNaN(geneScores[k])) {
                            hasNA = true;
                            break;
                        }
                    }
                    if (hasNA) {
                        continue;
                    }

                }

                double[] scoresM = new double[totalScoreNum + 1];
                String[] row = new String[colNum];
                mergedDepVarScore = (int) Double.parseDouble(item.getValue()[2]);
                scoresM[0] = mergedDepVarScore;
                if (!noExplanatoryVar) {
                    mergedIndpVarScore = (int) Double.parseDouble(item.getValue()[3]);
                    scoresM[1] = Double.parseDouble(item.getValue()[3]);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScores.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScores[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                    }
                }
                row[0] = item.getValue()[0];
                row[1] = item.getValue()[1];
                row[2] = item.getValue()[2];
                if (!noExplanatoryVar) {
                    row[3] = item.getValue()[3];
                }
                geneScoreMap.put(item.getKey(), scoresM);

                mergedDepVarScores.add(mergedDepVarScore);
                mergedIndpVarScores.add(mergedIndpVarScore);

                row[row.length - 1] = item.getValue()[2];

                String[] cells = item.getValue();
                Gene g = new Gene(item.getKey());

                g.appendVarScore(cells[cells.length - 1]);
                mappedGenes.put(g.geneSymb, g);
            }
        }

//bw.close();
        if (nonZeroSynNum < 5) {
            String info = "There seems no variants in your input data. The mutation burden analysis aborts!";
            LOG.error(info);
            return null;
        }
        PPIGraph ppiGraph = new PPIGraph();
        ppiGraph.readPPIItems(ppiDBFile, 800);
        List<String[]> ppiPairs = ppiGraph.getForwardInteractionItems();
        ArrayList<Gene> orderedGenePairs = new ArrayList<Gene>();
        List<double[]> countsRegList = new ArrayList<double[]>();
        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        for (String[] ppi : ppiPairs) {
            Gene g1 = mappedGenes.get(ppi[0]);
            Gene g2 = mappedGenes.get(ppi[1]);
            if (g1 == null || g2 == null) {
                continue;
            }
            Gene pairedGene = new Gene(g1.geneSymb + " " + g2.geneSymb);

            pairedGene.addDepMutScores(g1.getOrgDepMutScore());
            pairedGene.addDepMutScores(g2.getOrgDepMutScore());
            orderedGenePairs.add(pairedGene);
            double[] score1 = geneScoreMap.get(g1.geneSymb);
            double[] score2 = geneScoreMap.get(g2.geneSymb);
            double[] scoreC = new double[score1.length];
            Arrays.fill(scoreC, Double.NaN);
            for (int t = 0; t < score1.length; t++) {
                scoreC[t] = score1[t] + score2[t];
            }
            countsRegList.add(scoreC);
            String[] outRow = new String[colNum];
            outRow[0] = pairedGene.geneSymb;

            nsVar = pairedGene.getDepVarMutNum(0, caseControlAlleleNumIndex, 3);

            nsVarScore = nsVar;

            outRow[1] = String.valueOf(nsVar);
            outRow[2] = String.valueOf(nsVarScore);

            if (!noExplanatoryVar) {
                outRow[3] = String.valueOf(sVar);
            }

            localGeneSet.add(outRow[0]);
            if (hasGeneScore) {
                for (int t = 0; t < geneScores.length; t++) {
                    outRow[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                }
            }

            outRow[outRow.length - 1] = "0";
            geneMutRateSheet.add(outRow);
        }
        boolean isOneGene = false;
        //double[] residueCounter = caculateResidueByRIterative(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, geneFreqScores, scoreBinNum, geneFreqScoreIndex);
        double[] residueCounter = caculateResidueRUNNERThread(rHost, rPort, orderedGenePairs, scoreHeads, countsRegList, freqCut, noExplanatoryVar,
                refGeneVarFreqScoreMap, caseControlAlleleNumIndex, geneFreqScoreIndex, threadNum, needInteraction, orgScoreStart, orgScoreEnd, addedCovNum,
                useFunctionWeight, hasRefBackground, mergedDepVarScores, mergedIndpVarScores, isOneGene, false, protectiveEffect);

        if (residueCounter == null) {
            return null;
        }
        double[] pvalues = new double[2];
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        int geneNum = residueCounter.length;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];
                if (protectiveEffect) {
                    //one tailed test
                    if (pArray[t] < 0) {
                        pArray[t] = 1 - Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = Probability.normal(-pArray[t]);
                    }
                } else {
                    if (pArray[t] < 0) {
                        pArray[t] = Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = 1 - Probability.normal(-pArray[t]);
                    }
                }
            }
            // MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = geneMutRateSheet.size();
            for (int t = 0; t < geneNum; t++) {
                //the predictors have been updated
                double[] v = countsRegList.get(t);
                double[] nv = new double[v.length + 2];
                System.arraycopy(v, 0, nv, 0, v.length);
                nv[v.length] = residueCounter[t];
                nv[v.length + 1] = pArray[t];
                countsRegGeneP.put(orderedGenePairs.get(t).geneSymb, nv);
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;
            int pVIndex = -1;
            double val;
            for (int i = 0; i < geneTableHeadRow.size(); i++) {
                if (geneTableHeadRow.get(i).equals("P")) {
                    pVIndex = i + 1;
                    break;
                }
            }

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    // System.out.println(regressionFactors);
                    for (int i = pVIndex - p.length; i < pVIndex; i++) {
                        val = p[i - pVIndex + p.length];
                        if (Double.isNaN(val)) {
                            v[i] = null;
                        } else {
                            v[i] = String.valueOf(val);
                        }
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    pvalues[0] = p[p.length - 2];
                    pvalues[1] = p[p.length - 1];
                    if (Double.isNaN(pvalues[1])) {
                        hasP = false;
                    } else {
                        hasP = true;
                    }
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes        
                if (hasRefBackground && referenceSampleGeneScoreMap.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScores = orgGeneScoreMap.get(items[0]);
                    if (geneScores != null) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }
                }

                geneMutRateSheet.add(row);
            }

        }
        //geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        Map<String, String> geneAlleleScoreMap = new HashMap<String, String>();
        //keep the orginal scores and 
        for (Gene g : orderedGenePairs) {
            geneAlleleScoreMap.put(g.geneSymb, g.getVarScoreStrs());
        }

        geneTableHeadRow.add("AlleleScore");
        List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>(geneMutRateSheet);
        geneMutRateSheet.clear();
        int size = geneMutRateSheetTmp.size();
        String varScores;
        for (int i = 0; i < size; i++) {
            String[] items = geneMutRateSheetTmp.get(i);
            varScores = geneAlleleScoreMap.get(items[0]);
            if (varScores == null) {
                varScores = ".;.";
            }
            String[] items1 = new String[items.length + 1];
            System.arraycopy(items, 0, items1, 0, items.length);
            items1[items.length] = varScores;
            geneMutRateSheet.add(items1);
        }
        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        return geneMutRateSheet;

    }

    public List<String[]> diGeneMutationBurdenTest(String rHost, int rPort, String[] indexLabels, Map<String, double[]> geneScoreMap, Map<String, SampleVarGtyUnit> geneSampleMuts,
            int caseNum, int controlNum, String[] subLabels, boolean useExternalDigeneRefFreq, Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double freqCut, List<String> scoreHeads, boolean useFunctionWeight, String refMutGeneFile,
            boolean noExplanatoryVar, boolean needInteraction, int orgScoreNum, int addedCovNum, int threadNum, String ppiDBFile, double minScore, boolean usingLog, double minCaseControlFreqRatio,
            boolean protectiveEffect, boolean useMax, boolean adjMarginal, Map<String, Gene> mappedGenes) throws Exception {

        boolean needPubMedAnno = false;

        int shiftCol = 0;
        int interactGeneNum = 2;

        //fix the geneFreqScoreIndex to be the second column in countsRegListCopied
        int geneFreqScoreIndex = orgScoreNum;

        String[] basicHeadRow = null;
        int independentVarCol = 0;

        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "DiGeneScore", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "DiGeneScore", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
            geneFreqScoreIndex++;
        }
        //sometimes most gene pairs have zero control-counts and difficult to fit the model
        boolean useControlCounts = true;
        if (!useExternalDigeneRefFreq) {
            if (controlNum < 50) {
                useControlCounts = false;
            }
        }

        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        int orgScoreStart = 1;
        int orgScoreEnd = orgScoreStart + orgScoreNum;
        for (int i = 0; i < orgScoreNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i));
        }
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    geneTableHeadRow.add(scoreHeads.get(i) + "*" + scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i + orgScoreNum));
        }

        if (useControlCounts) {
            geneTableHeadRow.add("CtrlVarScore");
        }

        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        Map<String, String[]> referenceSampleGeneScoreMap = null;
        if (refMutGeneFile != null) {
            referenceSampleGeneScoreMap = loadGeneScores(refMutGeneFile, 0.4);
            if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                hasRefBackground = true;
                geneTableHeadRow.add("MergedAlleleNum");
            }

        }

        int colNum = geneTableHeadRow.size();

        int totalScoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        int interactionCols = 0;
        if (needInteraction) {
            interactionCols = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        totalScoreNum = orgScoreNum + interactionCols + addedCovNum;

        int nonZeroSynNum = 0;
        double nSNScore = 0;

        double[] geneScores = null;

        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        Set<String> localGeneSet = new HashSet<String>();
        IntArrayList mergedDepVarScores = new IntArrayList();
        IntArrayList mergedIndpVarScores = new IntArrayList();
        int mergedDepVarScore = 0, mergedIndpVarScore = 0;
        Map<String, Double> ppiScoreMap = new HashMap<>();

        ArrayList<Gene> orderedGenePairs = new ArrayList<Gene>();
        List<double[]> countsRegList = new ArrayList<double[]>();
        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        double scoreG1 = 0, scoreG2 = 0, totalCaseScore, totalControlScore, score, totalControlCount;
        int mutG1 = 0, mutG2 = 0, totalCaseCount;

        int varSize, id;
        int scoreIndex = 2;
        //this is fixed formate 
        int freqScoreIndex = 3;
        if (useFunctionWeight) {
            freqScoreIndex = 4;
        }
        BufferedReader br = LocalFileFunc.getBufferedReader(ppiDBFile);
        String[] ppi;
        String line = br.readLine();

        int g1VarSize, g2VarSize;
        double freqCase, freqControl;

        double[] scoreC;
        int varPairSize;
        int[] pair;
        double maxCombinedScore = -1, maxCombinedMut = -1;

        double allCombinedScoreG2 = -1, allCombinedMutG2 = -1, allCombinedScoreG1 = -1, allCombinedMutG1 = -1;
        StringBuilder details = new StringBuilder();
        boolean hasInc;

        Set<String> ineffectiveIDs = new HashSet<String>();
        IntArrayList g1Pos = new IntArrayList();
        IntArrayList g2Pos = new IntArrayList();
        List<String> interactPatientIDs = new ArrayList<>();

        double amplicationFactor = 1;
        while ((line = br.readLine()) != null) {
            ppi = line.split("\t");
            score = Double.parseDouble(ppi[scoreIndex]);
            if (score < minScore) {
                continue;
            }

            //g1 contains variants 
            SampleVarGtyUnit g1 = geneSampleMuts.get(ppi[0]);
            SampleVarGtyUnit g2 = geneSampleMuts.get(ppi[1]);
            if (g1 == null || g2 == null) {
                continue;
            }

            g1VarSize = g1.varScores.size();
            g2VarSize = g2.varScores.size();
            Set<String> g1Poss = new HashSet<>(g1.chrPosStr);
            Set<String> g2Poss = new HashSet<>(g2.chrPosStr);
            g1Poss.retainAll(g2Poss);
            //ignore genes with overlapped variants
            if (!g1Poss.isEmpty()) {
                continue;
            }
            interactPatientIDs.clear();

            minCaseControlFreqRatio = -1;
            //very slow for large sample 
            if (controlNum > 0 && minCaseControlFreqRatio > 1) {
                ineffectiveIDs.clear();
                for (int i = 0; i < g1VarSize; i++) {
                    for (int j = 0; j < g2VarSize; j++) {
                        scoreG1 = 0;
                        for (int k = 0; k < caseNum; k++) {
                            if (g1.subjectMutCount[k] == null || g2.subjectMutCount[k] == null) {
                                continue;
                            }
                            if (g1.subjectMutCount[k].get(i) > 0 && (g2.subjectMutCount[k].get(j) > 0)) {
                                scoreG1++;
                            }
                        }
                        if (scoreG1 == 0) {
                            continue;
                        }
                        freqCase = scoreG1 / caseNum;

                        scoreG1 = 0;
                        for (int k = 0; k < controlNum; k++) {
                            id = k + caseNum;
                            if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                                continue;
                            }
                            if (g1.subjectMutCount[id].get(i) > 0 && (g2.subjectMutCount[id].get(j) > 0)) {
                                scoreG1++;
                            }
                        }

                        freqControl = scoreG1 / controlNum;
                        if (freqCase < freqControl * minCaseControlFreqRatio) {
                            ineffectiveIDs.add(i + "-" + j);
                        }

                    }
                }

            }

            totalCaseScore = 0;
            totalCaseCount = 0;
            details.delete(0, details.length());
            for (int k = 0; k < caseNum; k++) {
                id = k;
                if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);
                g2.subjectMutCount[id].keys(g2Pos);
                g1VarSize = g1Pos.size();
                g2VarSize = g2Pos.size();
                maxCombinedScore = 0;
                maxCombinedMut = 0;
                allCombinedScoreG1 = 0;
                allCombinedMutG1 = 0;
                allCombinedScoreG2 = 0;
                allCombinedMutG2 = 0;
                hasInc = false;
                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = 0; j < g2VarSize; j++) {
                            if (ineffectiveIDs.contains(g1Pos.getQuick(i) + "-" + g2Pos.getQuick(j))) {
                                continue;
                            }
                            mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                            scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                            // if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) 
                            if (maxCombinedScore < (scoreG1 * scoreG2)) {
                                maxCombinedScore = scoreG1 * scoreG2;
                                // maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }
                    allCombinedScoreG1 += (scoreG1 * mutG1);
                    allCombinedMutG1 += mutG1;
                }
                for (int j = 0; j < g2VarSize; j++) {
                    mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                    scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                    allCombinedScoreG2 += (scoreG2 * mutG2);
                    allCombinedMutG2 += mutG2;
                }

                if (useMax) {
                    totalCaseScore += (maxCombinedScore);
                    totalCaseCount += (maxCombinedMut);
                    if (maxCombinedMut > 0) {
                        details.append((int) maxCombinedMut + "@" + subLabels[k]);                       
                        hasInc = true;
                    }
                } else {
                    totalCaseScore += (allCombinedScoreG1 * allCombinedScoreG2);
                    totalCaseCount += (allCombinedMutG1 * allCombinedMutG2);
                    if (allCombinedMutG1 > 0 && allCombinedMutG2 > 0) {
                        details.append((int) allCombinedMutG1).append("-").append((int) allCombinedMutG2 + "@" + subLabels[k]);                        
                        hasInc = true;
                    }

                }
                if (hasInc) {                    
                    details.append(';');
                }
            }

            if (totalCaseCount == 0) {
                continue;
            }

            totalControlScore = 0;
            totalControlCount = 0;
            for (int k = 0; k < controlNum; k++) {
                id = k + caseNum;
                if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);
                g2.subjectMutCount[id].keys(g2Pos);
                g1VarSize = g1Pos.size();
                g2VarSize = g2Pos.size();
                maxCombinedScore = 0;
                maxCombinedMut = 0;
                allCombinedScoreG1 = 0;
                allCombinedMutG1 = 0;
                allCombinedScoreG2 = 0;
                allCombinedMutG2 = 0;

                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = 0; j < g2VarSize; j++) {
                            if (ineffectiveIDs.contains(g1Pos.getQuick(i) + "-" + g2Pos.getQuick(j))) {
                                continue;
                            }
                            mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                            scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                            //use a single one
                            // if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) 
                            if (maxCombinedScore < (scoreG1 * scoreG2)) {
                                // maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedScore = scoreG1 * scoreG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }
                    allCombinedScoreG1 += (scoreG1 * mutG1);
                    allCombinedMutG1 += mutG1;
                }
                for (int j = 0; j < g2VarSize; j++) {
                    mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                    scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                    allCombinedScoreG2 += (scoreG2 * mutG2);
                    allCombinedMutG2 += mutG2;
                }

                if (useMax) {
                    totalControlScore += (maxCombinedScore);
                    totalControlCount += (maxCombinedMut);
                } else {
                    totalControlScore += (allCombinedScoreG1 * allCombinedScoreG2);
                    totalControlCount += (allCombinedMutG1 * allCombinedMutG2);
                }
            }

            Gene pairedGene = new Gene(ppi[0] + ":" + ppi[1]);

            if (useFunctionWeight) {
                //new idea
                if (controlNum > 0) {
                    totalCaseScore -= (caseNum * totalControlScore / controlNum);
                }

                if (totalCaseScore <= 0) {
                    continue;
                }
                pairedGene.caseMutScore = totalCaseScore;

                if (useExternalDigeneRefFreq) {
                    pairedGene.controlMutScore = Double.parseDouble(ppi[freqScoreIndex]) * amplicationFactor;
                } else {
                    pairedGene.controlMutScore = totalControlScore * amplicationFactor;
                }

            } else {
                //new idea
                if (controlNum > 0) {
                    totalCaseCount -= Math.round(caseNum * totalControlCount / controlNum);
                }
                if (totalCaseCount <= 0) {
                    continue;
                }

                pairedGene.caseMutScore = totalCaseCount;
                if (useExternalDigeneRefFreq) {
                    pairedGene.controlMutScore = Double.parseDouble(ppi[freqScoreIndex]) * amplicationFactor;
                } else {
                    pairedGene.controlMutScore = totalControlCount * amplicationFactor;
                }

            }

            double[] score1 = geneScoreMap.get(ppi[0]);
            if (score1 == null) {
                continue;
            }
            double[] score2 = geneScoreMap.get(ppi[1]);
            if (score2 == null) {
                continue;
            }
            orderedGenePairs.add(pairedGene);

            if (useControlCounts) {
                //the first column and last column are the case score and control score respectively
                scoreC = new double[score1.length + 2];
            } else {
                scoreC = new double[score1.length + 1];
            }
            Arrays.fill(scoreC, Double.NaN);
            for (int t = 0; t < score1.length; t++) {
                scoreC[t + 1] = score1[t] * score2[t];
            }
            countsRegList.add(scoreC);
            String[] outRow = new String[colNum];
            outRow[0] = pairedGene.geneSymb;
            ppiScoreMap.put(outRow[0], score);
            //1	25.55724	6.85E-04	0.017505247047002	0.317730970885909	1
            outRow[1] = String.valueOf(totalCaseCount) + "(" + details.substring(0, details.length() - 1) + ")";
            outRow[2] = String.valueOf(score);
            outRow[3] = String.valueOf(totalCaseScore);

            if (!noExplanatoryVar) {
                outRow[4] = String.valueOf(totalControlScore);
            }

            localGeneSet.add(outRow[0]);
            if (hasGeneScore) {
                for (int t = 0; t < geneScores.length; t++) {
                    outRow[t + shiftCol + 4 + independentVarCol] = String.valueOf(geneScores[t]);
                }
            }
            //outRow[outRow.length - 1] = "0";
            geneMutRateSheet.add(outRow);
        }

        br.close();
        geneSampleMuts.clear();
        System.gc();

        LOG.info(countsRegList.size() + " gene pairs are loaded for the interactive mutation burden test.");
        //double[] residueCounter = caculateResidueByRIterative(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, geneFreqScores, scoreBinNum, geneFreqScoreIndex);
        double[] residueCounter = caculateResidueRUNERGeneInteractionThread(rHost, rPort, orderedGenePairs, scoreHeads, countsRegList, freqCut, noExplanatoryVar,
                refGeneVarFreqScoreMap, geneFreqScoreIndex, threadNum, needInteraction, orgScoreStart, orgScoreEnd, addedCovNum,
                useFunctionWeight, hasRefBackground, mergedDepVarScores, mergedIndpVarScores, useControlCounts,
                usingLog, protectiveEffect, interactGeneNum, 5000, geneScoreMap, adjMarginal, mappedGenes);

        if (residueCounter == null) {
            return null;
        }
        double[] pvalues = new double[2];
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        int geneNum = residueCounter.length;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];

                if (!Double.isNaN(pArray[t])) {
                    //one tailed test
                    if (pArray[t] < 0) {
                        pArray[t] = 1 - Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = Probability.normal(-pArray[t]);
                    }
                }

            }
            // MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = countsRegList.size();
            for (int t = 0; t < geneNum; t++) {
                //the predictors have been updated
                double[] v = countsRegList.get(t);
                double[] nv = new double[v.length + 2];
                System.arraycopy(v, 0, nv, 0, v.length);
                nv[v.length] = residueCounter[t];
                nv[v.length + 1] = pArray[t];
                countsRegGeneP.put(orderedGenePairs.get(t).geneSymb, nv);
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;
            int digeneScoreIndex = -1;
            double val;
            for (int i = 0; i < geneTableHeadRow.size(); i++) {
                if (geneTableHeadRow.get(i).equals("DiGeneScore")) {
                    digeneScoreIndex = i + 1;
                    break;
                }
            }

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    // System.out.println(regressionFactors);
                    for (int i = 0; i < p.length; i++) {
                        val = p[i];
                        if (Double.isNaN(val)) {
                            v[digeneScoreIndex + i] = null;
                        } else {
                            v[digeneScoreIndex + i] = String.valueOf(val);
                        }
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    pvalues[0] = p[p.length - 2];
                    pvalues[1] = p[p.length - 1];
                    if (Double.isNaN(pvalues[1])) {
                        hasP = false;
                    } else {
                        hasP = true;
                    }
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes        
                if (hasRefBackground && referenceSampleGeneScoreMap.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScores = geneScoreMap.get(items[0]);
                    if (geneScores != null) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }
                }

                geneMutRateSheet.add(row);
            }

        }
        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        /*
    Map<String, String> geneAlleleScoreMap = new HashMap<String, String>();
    //keep the orginal scores and 
    for (Gene g : orderedGenePairs) {
      geneAlleleScoreMap.put(g.geneSymb, g.getVarScoreStrs());
    }

    geneTableHeadRow.add("AlleleScore");
    List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>(geneMutRateSheet);
    geneMutRateSheet.clear();
    varSize = geneMutRateSheetTmp.varSize();
    String varScores;
    for (int s = 0; s < varSize; s++) {
      String[] items = geneMutRateSheetTmp.get(s);
      varScores = geneAlleleScoreMap.get(items[0]);
      if (varScores == null) {
        varScores = ".;.";
      }
      String[] items1 = new String[items.length + 1];
      System.arraycopy(items, 0, items1, 0, items.length);
      items1[items.length] = varScores;
      geneMutRateSheet.add(items1);
    }
    geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));
         */
        return geneMutRateSheet;

    }

    public List<String[]> singleGeneInteractionMutationBurdenTest(String rHost, int rPort, String[] indexLabels, Map<String, double[]> geneScoreMap, Map<String, SampleVarGtyUnit> geneSampleMuts,
            int caseNum, int controlNum, boolean useExternalDigeneRefFreq, Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double freqCut, List<String> scoreHeads, boolean useFunctionWeight, String refMutGeneFile,
            boolean noExplanatoryVar, boolean needInteraction, int orgScoreNum, int addedCovNum, int threadNum, String ppiDBFile, double minScore, boolean usingLog, double minCaseControlFreqRatio,
            boolean protectiveEffect, boolean useMax, int minRegressionSample, boolean adjMarginal, Map<String, Gene> mappedGenes) throws Exception {

        boolean needPubMedAnno = false;

        int shiftCol = 0;
        int interactGeneNum = 1;
        //fix the geneFreqScoreIndex to be the second column in countsRegListCopied
        int geneFreqScoreIndex = orgScoreNum;

        String[] basicHeadRow = null;
        int independentVarCol = 0;

        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "DiGeneScore", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "DiGeneScore", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
            geneFreqScoreIndex++;
        }
        //sometimes most gene pairs have zero control-counts and difficult to fit the model
        boolean useControlCounts = true;
        if (!useExternalDigeneRefFreq) {
            if (controlNum < 50) {
                useControlCounts = false;
            }
        }

        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        int orgScoreStart = 1;
        int orgScoreEnd = orgScoreStart + orgScoreNum;
        for (int i = 0; i < orgScoreNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i));
        }
        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    geneTableHeadRow.add(scoreHeads.get(i) + "*" + scoreHeads.get(j));
                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            geneTableHeadRow.add(scoreHeads.get(i + orgScoreNum));
        }

        if (useControlCounts) {
            geneTableHeadRow.add("CtrlVarScore");
        }

        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");

        Map<String, String[]> referenceSampleGeneScoreMap = null;
        if (refMutGeneFile != null) {
            referenceSampleGeneScoreMap = loadGeneScores(refMutGeneFile, 0.4);
            if (referenceSampleGeneScoreMap != null && !referenceSampleGeneScoreMap.isEmpty()) {
                hasRefBackground = true;
                geneTableHeadRow.add("MergedAlleleNum");
            }

        }

        int colNum = geneTableHeadRow.size();

        int totalScoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        int interactionCols = 0;
        if (needInteraction) {
            interactionCols = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        totalScoreNum = orgScoreNum + interactionCols + addedCovNum;

        int nonZeroSynNum = 0;
        double nSNScore = 0;

        double[] geneScores = null;

        boolean hasNA;

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        IntArrayList mergedDepVarScores = new IntArrayList();
        IntArrayList mergedIndpVarScores = new IntArrayList();

        ArrayList<Gene> orderedGenePairs = new ArrayList<Gene>();
        List<double[]> countsRegList = new ArrayList<double[]>();
        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        double scoreG1 = 0, scoreG2 = 0, totalCaseScore, totalControlScore, score = 0, totalControlCount;
        int mutG1 = 0, mutG2 = 0, totalCaseCount;

        int varSize, id;
        int scoreIndex = 2;
        //this is fixed formate 
        int freqScoreIndex = 3;
        if (useFunctionWeight) {
            freqScoreIndex = 4;
        }

        int g1VarSize;
        double freqCase, freqControl;

        double[] scoreC;
        int varPairSize;
        int[] pair;
        double maxCombinedScore = -1, maxCombinedMut = -1;

        StringBuilder details = new StringBuilder();
        boolean hasInc;
        Gene pairedGene;
        String geneSymbol;
        Set<String> ineffectiveIDs = new HashSet<String>();
        IntArrayList g1Pos = new IntArrayList();

        double amplicationFactor = 1;

        for (Map.Entry<String, SampleVarGtyUnit> item : geneSampleMuts.entrySet()) {
            SampleVarGtyUnit g1 = item.getValue();
            g1VarSize = g1.varScores.size();

            if (controlNum > 0 && minCaseControlFreqRatio > 1) {
                ineffectiveIDs.clear();
                for (int i = 0; i < g1VarSize; i++) {
                    for (int j = i + 1; j < g1VarSize; j++) {
                        scoreG1 = 0;
                        for (int k = 0; k < caseNum; k++) {
                            if (g1.subjectMutCount[k] == null) {
                                continue;
                            }
                            if (g1.subjectMutCount[k].get(i) > 0 && (g1.subjectMutCount[k].get(j) > 0)) {
                                scoreG1++;
                            }
                        }
                        if (scoreG1 == 0) {
                            continue;
                        }
                        freqCase = scoreG1 / caseNum;

                        scoreG1 = 0;
                        for (int k = 0; k < controlNum; k++) {
                            id = k + caseNum;
                            if (g1.subjectMutCount[id] == null) {
                                continue;
                            }
                            if (g1.subjectMutCount[id].get(i) > 0 && (g1.subjectMutCount[id].get(j) > 0)) {
                                scoreG1++;
                            }
                        }

                        freqControl = scoreG1 / controlNum;
                        if (freqCase < freqControl * minCaseControlFreqRatio) {
                            ineffectiveIDs.add(i + "-" + j);
                        }

                    }
                }
            }

            totalCaseScore = 0;
            totalCaseCount = 0;
            details.delete(0, details.length());
            for (int k = 0; k < caseNum; k++) {
                id = k;
                if (g1.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);

                g1VarSize = g1Pos.size();
                if (g1VarSize < 2) {
                    continue;
                }
                maxCombinedScore = 0;
                maxCombinedMut = 0;

                hasInc = false;
                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = i + 1; j < g1VarSize; j++) {
                            if (ineffectiveIDs.contains(g1Pos.getQuick(i) + "-" + g1Pos.getQuick(j))) {
                                continue;
                            }
                            mutG2 = g1.subjectMutCount[id].get(g1Pos.getQuick(j));
                            scoreG2 = g1.varScores.getQuick(g1Pos.getQuick(j));
                            // if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) 
                            if (maxCombinedScore < (scoreG1 * scoreG2)) {
                                maxCombinedScore = scoreG1 * scoreG2;
                                // maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }

                }

                if (useMax) {
                    totalCaseScore += (maxCombinedScore);
                    totalCaseCount += (maxCombinedMut);
                    if (maxCombinedMut > 0) {
                        details.append((int) maxCombinedMut);
                        details.append(',');
                        hasInc = true;
                    }
                }
                if (hasInc) {
                    details.deleteCharAt(details.length() - 1);
                    details.append(';');
                }
            }

            if (totalCaseCount == 0) {
                continue;
            }

            totalControlScore = 0;
            totalControlCount = 0;
            for (int k = 0; k < controlNum; k++) {
                id = k + caseNum;
                if (g1.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);

                g1VarSize = g1Pos.size();

                maxCombinedScore = 0;
                maxCombinedMut = 0;
                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = i + 1; j < g1VarSize; j++) {
                            if (ineffectiveIDs.contains(g1Pos.getQuick(i) + "-" + g1Pos.getQuick(j))) {
                                continue;
                            }
                            mutG2 = g1.subjectMutCount[id].get(g1Pos.getQuick(j));
                            scoreG2 = g1.varScores.getQuick(g1Pos.getQuick(j));
                            //use a single one
                            // if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) 
                            if (maxCombinedScore < (scoreG1 * scoreG2)) {
                                // maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedScore = scoreG1 * scoreG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }

                }

                if (useMax) {
                    totalControlScore += (maxCombinedScore);
                    totalControlCount += (maxCombinedMut);
                }
            }

            geneSymbol = item.getKey();
            pairedGene = new Gene(geneSymbol);

            if (useFunctionWeight) {
                //new idea
                if (controlNum > 0) {
                    totalCaseScore -= (caseNum * totalControlScore / controlNum);
                }

                if (totalCaseScore <= 0) {
                    continue;
                }
                pairedGene.caseMutScore = totalCaseScore;

                if (useExternalDigeneRefFreq) {
                    // pairedGene.controlMutScore = Double.parseDouble(ppi[freqScoreIndex]) * amplicationFactor;
                } else {
                    pairedGene.controlMutScore = totalControlScore * amplicationFactor;
                }

            } else {
                //new idea
                if (controlNum > 0) {
                    totalCaseCount -= Math.round(caseNum * totalControlCount / controlNum);
                }
                if (totalCaseCount <= 0) {
                    continue;
                }

                pairedGene.caseMutScore = totalCaseCount;
                if (useExternalDigeneRefFreq) {
                    //  pairedGene.controlMutScore = Double.parseDouble(ppi[freqScoreIndex]) * amplicationFactor;
                } else {
                    pairedGene.controlMutScore = totalControlCount * amplicationFactor;
                }

            }

            double[] score1 = geneScoreMap.get(geneSymbol);
            if (score1 == null) {
                continue;
            }

            orderedGenePairs.add(pairedGene);

            if (useControlCounts) {
                //the first column and last column are the case score and control score respectively
                scoreC = new double[score1.length + 2];
            } else {
                scoreC = new double[score1.length + 1];
            }
            Arrays.fill(scoreC, Double.NaN);
            for (int t = 0; t < score1.length; t++) {
                scoreC[t + 1] = score1[t];
            }
            countsRegList.add(scoreC);
            String[] outRow = new String[colNum];
            outRow[0] = pairedGene.geneSymb;

            //1	25.55724	6.85E-04	0.017505247047002	0.317730970885909	1
            outRow[1] = String.valueOf(totalCaseCount) + "(" + details.substring(0, details.length() - 1) + ")";
            outRow[2] = String.valueOf(score);
            outRow[3] = String.valueOf(totalCaseScore);

            if (!noExplanatoryVar) {
                outRow[4] = String.valueOf(totalControlScore);
            }

            if (hasGeneScore) {
                for (int t = 0; t < geneScores.length; t++) {
                    outRow[t + shiftCol + 4 + independentVarCol] = String.valueOf(geneScores[t]);
                }
            }

            //outRow[outRow.length - 1] = "0";
            geneMutRateSheet.add(outRow);

        }

        geneSampleMuts.clear();
        System.gc();

        LOG.info(countsRegList.size() + " genes are loaded for the interactive mutation burden test.");
        //double[] residueCounter = caculateResidueByRIterative(orderedAllGenes, scoreHeads, countsRegListCopied, noExplanatoryVar, geneFreqScores, scoreBinNum, geneFreqScoreIndex);
        double[] residueCounter = caculateResidueRUNERGeneInteractionThread(rHost, rPort, orderedGenePairs, scoreHeads, countsRegList, freqCut, noExplanatoryVar,
                refGeneVarFreqScoreMap, geneFreqScoreIndex, threadNum, needInteraction, orgScoreStart, orgScoreEnd, addedCovNum, useFunctionWeight,
                hasRefBackground, mergedDepVarScores, mergedIndpVarScores, useControlCounts, usingLog, protectiveEffect, interactGeneNum, minRegressionSample,
                geneScoreMap, adjMarginal, mappedGenes);

        if (residueCounter == null) {
            return null;
        }
        double[] pvalues = new double[2];
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        int geneNum = residueCounter.length;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];

                if (!Double.isNaN(pArray[t])) {
                    //one tailed test
                    if (pArray[t] < 0) {
                        pArray[t] = 1 - Probability.normal(pArray[t]);
                    } else {
                        pArray[t] = Probability.normal(-pArray[t]);
                    }
                }

            }
            // MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = countsRegList.size();
            for (int t = 0; t < geneNum; t++) {
                //the predictors have been updated
                double[] v = countsRegList.get(t);
                double[] nv = new double[v.length + 2];
                System.arraycopy(v, 0, nv, 0, v.length);
                nv[v.length] = residueCounter[t];
                nv[v.length + 1] = pArray[t];
                countsRegGeneP.put(orderedGenePairs.get(t).geneSymb, nv);
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;
            int digeneScoreIndex = -1;
            double val;
            for (int i = 0; i < geneTableHeadRow.size(); i++) {
                if (geneTableHeadRow.get(i).equals("DiGeneScore")) {
                    digeneScoreIndex = i + 1;
                    break;
                }
            }

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    // System.out.println(regressionFactors);
                    for (int i = 0; i < p.length; i++) {
                        val = p[i];
                        if (Double.isNaN(val)) {
                            v[digeneScoreIndex + i] = null;
                        } else {
                            v[digeneScoreIndex + i] = String.valueOf(val);
                        }
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    pvalues[0] = p[p.length - 2];
                    pvalues[1] = p[p.length - 1];
                    if (Double.isNaN(pvalues[1])) {
                        hasP = false;
                    } else {
                        hasP = true;
                    }
                }

                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes        
                if (hasRefBackground && referenceSampleGeneScoreMap.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScores = geneScoreMap.get(items[0]);
                    if (geneScores != null) {
                        for (int t = 0; t < geneScores.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScores[t]);
                        }
                    }
                }

                geneMutRateSheet.add(row);
            }

        }
        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));

        /*
    Map<String, String> geneAlleleScoreMap = new HashMap<String, String>();
    //keep the orginal scores and 
    for (Gene g : orderedGenePairs) {
      geneAlleleScoreMap.put(g.geneSymb, g.getVarScoreStrs());
    }

    geneTableHeadRow.add("AlleleScore");
    List<String[]> geneMutRateSheetTmp = new ArrayList<String[]>(geneMutRateSheet);
    geneMutRateSheet.clear();
    varSize = geneMutRateSheetTmp.varSize();
    String varScores;
    for (int s = 0; s < varSize; s++) {
      String[] items = geneMutRateSheetTmp.get(s);
      varScores = geneAlleleScoreMap.get(items[0]);
      if (varScores == null) {
        varScores = ".;.";
      }
      String[] items1 = new String[items.length + 1];
      System.arraycopy(items, 0, items1, 0, items.length);
      items1[items.length] = varScores;
      geneMutRateSheet.add(items1);
    }
    geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));
         */
        return geneMutRateSheet;

    }

    public void geneMutationRateTest1(Genome genome, Map<String, Map<String, Integer>> cosmicGeneMut, Map<String, double[]> geneScores,
            List<String> scoreHeads, double genePValueCutoff, boolean considerFunVar, Map<String, double[]> geneMutRegPValueAllVar, String refMutGeneFile,
            String geneSumOutFile, boolean noExplanatoryVar, boolean outExcel) throws Exception {
        Chromosome[] chroms = genome.getChromosomes();
        int responseVarIndex = -1;
        int explanatoryVarIndex = -1;
        int somaticNSRatioIndex = -1;
        int somaticSRatioIndex = -1;

        boolean needPubMedAnno = false;
        boolean needCosmic = false;
        int shiftCol = 0;
        int responseVarScoreIndex = -1;

        List<String> featureLabels = genome.getGeneFeatureLabels();
        for (int i = 0; i < featureLabels.size(); i++) {
            if (featureLabels.get(i).equals("ResponseVar")) {
                responseVarIndex = i;
            } else if (featureLabels.get(i).equals("ExplanatoryVar")) {
                explanatoryVarIndex = i;
            } else if (featureLabels.get(i).equals("NonsynonymousReadsRatio")) {
                somaticNSRatioIndex = i;
            } else if (featureLabels.get(i).equals("SynonymousReadsRatio")) {
                somaticSRatioIndex = i;
            } else if (featureLabels.get(i).equals("ResponseVarFuncScore")) {
                responseVarScoreIndex = i;
            }
            if (explanatoryVarIndex >= 0 && responseVarIndex >= 0 && somaticNSRatioIndex >= 0 && somaticSRatioIndex >= 0) {
                break;
            }
        }

        if (cosmicGeneMut != null) {
            needCosmic = true;
        }

        String[] basicHeadRow = null;
        int independentVarCol = 0;
        if (noExplanatoryVar) {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore"};
        } else {
            basicHeadRow = new String[]{"GeneSymbol", "ResponseVar", "ResponseVarScore", "ExplanatoryVar"};
            independentVarCol++;
        }
        List<String> geneTableHeadRow = new ArrayList<String>();
        geneTableHeadRow.addAll(Arrays.asList(basicHeadRow));

        boolean hasRefBackground = false;

        if (needPubMedAnno) {
            geneTableHeadRow.add("PubMedID");
            shiftCol++;
        }
        if (needCosmic) {
            geneTableHeadRow.add("COSMICCancerInfo");
            shiftCol++;
        }

        for (String name : scoreHeads) {
            geneTableHeadRow.add(name);
        }

        geneTableHeadRow.add("Residual");
        geneTableHeadRow.add("P");
        boolean regReads = false;
        if (regReads) {
            geneTableHeadRow.add("RegReadsResidue");
            geneTableHeadRow.add("RegReadsP");
        }
        Map<String, String[]> otherGeneScoreMap = null;
        if (refMutGeneFile != null) {
            otherGeneScoreMap = loadGeneScores(refMutGeneFile, 0.3);
            if (otherGeneScoreMap != null && !otherGeneScoreMap.isEmpty()) {
                hasRefBackground = true;
                geneTableHeadRow.add("MergedAlleleNum");
            }
        }

        List<String[]> geneMutRateSheet = new ArrayList<String[]>();
        List<double[]> countsRegList = new ArrayList<double[]>();
        List<double[]> readsRegList = new ArrayList<double[]>();
        DoubleArrayList genePValuesForQQPlot = new DoubleArrayList();
        int colNum = geneTableHeadRow.size();
        String nsVar = null, sVar = null, nsVarScore = null;
        int scoreNum = 0;
        //the gene scores as covariables
        boolean hasGeneScore = false;

        if (geneScores != null && !geneScores.isEmpty()) {
            scoreNum = geneScores.get((new ArrayList(geneScores.keySet())).get(0)).length;
            hasGeneScore = true;
        }
        scoreNum += (1 + independentVarCol);
        int nonZeroSynNum = 0;
        double nSNScore = 0;
        String COSMICCancerInfo;
        double[] geneScore = null;
        List<String> geneOrder = new ArrayList<String>();

        List<String[]> geneZeroMutRateSheet = new ArrayList<String[]>();

        //output a file for MutSig for comparison
        //BufferedWriter bw = new BufferedWriter(new FileWriter("cov.txt"));
        //bw.write("gene\tnsVar\tsVar\tlen\texpr\treptime\thic\n");
        Set<String> localGeneSet = new HashSet<String>();
        for (int i = 0; i < chroms.length; i++) {
            if (chroms[i] == null) {
                continue;
            }

            for (Gene gene : chroms[i].geneList) {
                if (gene.geneSymb == null) {
                    continue;
                }

                if (hasGeneScore) {
                    geneScore = geneScores.get(gene.geneSymb);
                    if (geneScore == null) {
                        continue;
                    }
                }

                List<String> features = gene.featureValues;
                nsVar = features.get(responseVarIndex);
                if (considerFunVar) {
                    nsVarScore = features.get(responseVarScoreIndex);
                } else {
                    nsVarScore = features.get(responseVarIndex);
                }
                if (!noExplanatoryVar) {
                    sVar = features.get(explanatoryVarIndex);
                }

                if (nsVar.equals(".")) {
                    continue;
                }
                //bw.write(gene.geneSymb + "\t" + nsVar + "\t" + sVar + "\t" + geneLen.toString() + "\t" + geneScores[0] + "\t" + geneScores[1] + "\t" + geneScores[2] + "\n");
                nSNScore = Double.parseDouble(nsVarScore);

                if (nSNScore <= 0) {
                    String[] row = new String[colNum];
                    row[0] = gene.geneSymb;
                    row[1] = nsVar;
                    row[2] = nsVarScore;
                    if (!noExplanatoryVar) {
                        row[3] = sVar;
                    }

                    if (hasGeneScore) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                    geneZeroMutRateSheet.add(row);
                    continue;
                }
                if (!noExplanatoryVar) {
                    if (sVar.equals(".")) {
                        sVar = "0";
                    }
                }

                String[] row = new String[colNum];
                row[0] = gene.geneSymb;
                row[1] = nsVar;
                row[2] = nsVarScore;
                if (!noExplanatoryVar) {
                    row[3] = sVar;
                }

                if (needPubMedAnno) {
                    //  geneTableRow.add(info[2]);
                }
                if (needCosmic) {
                    Map<String, Integer> sb = cosmicGeneMut.get(row[0]);
                    if (sb == null) {
                        COSMICCancerInfo = ".";
                    } else {
                        COSMICCancerInfo = sb.toString();
                    }
                    row[3 + independentVarCol] = COSMICCancerInfo;
                }
                localGeneSet.add(row[0]);

                double[] scoresM = new double[scoreNum];
                scoresM[0] = nSNScore;
                if (!noExplanatoryVar) {
                    scoresM[1] = Double.parseDouble(sVar);
                }

                if (hasGeneScore) {
                    for (int t = 0; t < geneScore.length; t++) {
                        scoresM[1 + independentVarCol + t] = (geneScore[t]);
                        row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                    }
                }
                row[row.length - 1] = "0";
                if (otherGeneScoreMap != null && !otherGeneScoreMap.isEmpty()) {
                    String[] items = otherGeneScoreMap.get(row[0]);
                    if (items != null) {
                        for (int t = 0; t < 2; t++) {
                            scoresM[t] += Double.parseDouble(items[t + 2]);
                        }
                        row[row.length - 1] = "1";
                    }
                }

                countsRegList.add(scoresM);
                geneMutRateSheet.add(row);
                nonZeroSynNum += scoresM[0];

                if (regReads) {
                    double[] scoresS = new double[scoreNum];
                    scoresS[0] = Double.parseDouble(features.get(somaticNSRatioIndex));
                    scoresS[1] = Double.parseDouble(features.get(somaticSRatioIndex));

                    for (int t = 0; t < geneScore.length; t++) {
                        scoresS[2 + t] = (geneScore[t]);
                    }
                    readsRegList.add(scoresS);
                }
                geneOrder.add(gene.geneSymb);
            }
        }

        //add socres new genes       
        if (otherGeneScoreMap != null && !otherGeneScoreMap.isEmpty()) {
            for (Map.Entry<String, String[]> item : otherGeneScoreMap.entrySet()) {
                if (localGeneSet.contains(item.getKey())) {
                    continue;
                }
                double[] scoresM = new double[scoreNum];
                for (int t = 0; t < scoreNum; t++) {
                    scoresM[t] += Double.parseDouble(item.getValue()[t + 2]);
                }
                countsRegList.add(scoresM);
                geneOrder.add(item.getKey());
                String[] row = new String[colNum];
                System.arraycopy(item.getValue(), 0, row, 0, item.getValue().length);
                row[row.length - 1] = "2";
                geneMutRateSheet.add(row);
            }
        }
//bw.close();

        if (nonZeroSynNum < 5) {
            String info = "There seems no variants in your input data. The mutation burden analysis aborts!";
            LOG.error(info);
            return;
        }

        /*
         rcon.voidEval("sumR<-summary2.zerotrunc(m1)");
        System.out.println("Running mutation rate test");
        File file = new File(geneSumOutFile + "summary.txt");
        String infor = "sink('" + file.getCanonicalPath() + "')";
        System.out.println(infor);
        // rcon.voidEval("sink('" + file.getCanonicalPath() + "')");
        System.out.println("Running mutation rate test");
        rcon.voidEval("print(sumR)");
        rcon.voidEval("sink()"); 
        //rcon.voidEval("save(textSR " + ", file=" + file.getCanonicalPath() + ")");
        String summary = rcon.eval("readChar(file('" + file.getCanonicalPath() + "', 'r'), 200000)").asString();
        LOG.info(summary);
         */
        //double[] residueCounter = rcon.eval("m1$fitted.values").asDoubles();
        //standdize as standard normal distributiion
        //double[] residueCounter = caculateResidueByR(regReads, countsMatrix, countsRegListCopied.varSize(), countsRegListCopied.get(0).length, scoreHeads);
        double[] residueCounter = caculateResidueByRIterative(geneOrder, scoreHeads, countsRegList, noExplanatoryVar, 1);
        if (residueCounter == null) {
            return;
        }
        //mean=0;
        //sd=1;
        //mean = StdStats.min(residueCounter);
        //sd = StdStats.stddev(residueCounter);
        Map<String, double[]> countsRegGeneP = new HashMap<String, double[]>();
        Map<String, Double> lmRegGeneP = new HashMap<String, Double>();
        int geneNum = residueCounter.length;
        int popuSize = 19061;

        double[] pArray = new double[residueCounter.length];
        //if (geneNum == geneMutRateSheet.varSize()) 
        {
            //convert to regressionFactors-values
            for (int t = 0; t < geneNum; t++) {
                pArray[t] = residueCounter[t];

                //one tailed test
                if (pArray[t] < 0) {
                    pArray[t] = 1 - Probability.normal(pArray[t]);
                } else {
                    pArray[t] = Probability.normal(-pArray[t]);
                }
                genePValuesForQQPlot.add(pArray[t]);
            }
            MultipleTestingMethod.adjustByInflationFactor(pArray);

            geneNum = geneMutRateSheet.size();
            for (int t = 0; t < geneNum; t++) {
                countsRegGeneP.put(geneOrder.get(t), new double[]{residueCounter[t], pArray[t]});
                if (regReads) {
                    //lmRegGeneP.put(orderedAllGenes.get(t), residueReads[t]);
                }
                // System.out.println(res[t]);
            }

            List<String[]> geneMutRateSheet1 = new ArrayList<String[]>();
            List<String[]> geneMutRateSheet2 = new ArrayList<String[]>();
            boolean hasP = false;

            for (String[] v : geneMutRateSheet) {
                double[] p = countsRegGeneP.get(v[0]);
                hasP = false;
                if (p != null) {
                    // System.out.println(regressionFactors);
                    if (hasRefBackground) {
                        v[colNum - 3] = String.valueOf(p[0]);
                        v[colNum - 2] = String.valueOf(p[1]);
                    } else {
                        v[colNum - 2] = String.valueOf(p[0]);
                        v[colNum - 1] = String.valueOf(p[1]);
                    }

                    // regressionFactors = (regressionFactors - mean1) / sd1;
                    double[] pvalues = new double[1];

                    //  geneMutRegPValuePosVar.put(v[0], regressionFactors);
                    hasP = true;
                    pvalues[0] = p[1];
                    geneMutRegPValueAllVar.put(v[0], pvalues);
                }

                if (regReads) {
                    /*
                    regressionFactors = lmRegGeneP.get(v[0]);
                    if (regressionFactors != null) {
                        // System.out.println(regressionFactors);
                        v[colNum - 2] = regressionFactors.toString();
                        // regressionFactors = (regressionFactors - mean1) / sd1;
                        if (regressionFactors > 0) {
                            regressionFactors = Probability.normal(-regressionFactors);
                        } else {
                            regressionFactors = 1 - Probability.normal(regressionFactors);
                        }
                        v[colNum - 1] = regressionFactors.toString();
                        hasP = true;
                        // genePValues.add(Double.parseDouble(v[5]));

                        // System.out.println(regressionFactors);
                    }
                     */
                }
                if (hasP) {
                    geneMutRateSheet1.add(v);
                } else {
                    geneMutRateSheet2.add(v);
                }
            }
            if (hasRefBackground) {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 2));
            } else {
                Collections.sort(geneMutRateSheet1, new StringArrayDoubleComparator(colNum - 1));
            }

            geneMutRateSheet.clear();
            geneMutRateSheet.addAll(geneMutRateSheet1);
            geneMutRateSheet.addAll(geneMutRateSheet2);

            for (String[] items : geneZeroMutRateSheet) {
                //add remaining genes
                if (hasRefBackground && otherGeneScoreMap.containsKey(items[0])) {
                    continue;
                }
                String[] row = new String[colNum];
                System.arraycopy(items, 0, row, 0, items.length);

                if (hasGeneScore) {
                    geneScore = geneScores.get(items[0]);
                    if (geneScore != null) {
                        for (int t = 0; t < geneScore.length; t++) {
                            row[t + shiftCol + 3 + independentVarCol] = String.valueOf(geneScore[t]);
                        }
                    }
                }

                geneMutRateSheet.add(row);
            }

            genePValuesForQQPlot.quickSort();
            List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
            List<String> nameList = new ArrayList<String>();
            pvalueLists.add(genePValuesForQQPlot);
            PValuePainter pvPainter = new PValuePainter(400, 400);
            File plotFile = new File(geneSumOutFile + ".qq.png");
            nameList.add("Somatic");
            pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);
            String info = "The QQ plot saved in " + plotFile.getCanonicalPath();
            LOG.info(info);
        }/*
        else {
            String msg = "Error, the hurdle regression regressionFactors-values are not correctly estimate due to missing data";
            LOG.error(msg);
        }*/

        double adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(genePValueCutoff, genePValuesForQQPlot);

        //double mlfc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, genePValuesForQQPlot);
        //System.out.println("The MLFC score is " + mlfc);
        genePValuesForQQPlot.clear();
        StringBuilder sumSb = new StringBuilder();

        Set<String> wholeSigCandiGeneSet = new HashSet<String>();
        for (Map.Entry<String, double[]> geneP : geneMutRegPValueAllVar.entrySet()) {
            if (geneP.getValue()[0] <= adjGenePValueCutoff) {
                wholeSigCandiGeneSet.add(geneP.getKey());
            }
        }

        sumSb.append(wholeSigCandiGeneSet.size()).append(" genes with p-value <= ").append(adjGenePValueCutoff).append(" pass the Benjamini Hochberg FDR q value cutoff ")
                .append(genePValueCutoff).append(".\n");
        LOG.info(sumSb.toString());
        wholeSigCandiGeneSet.clear();

        geneMutRateSheet.add(0, geneTableHeadRow.toArray(new String[0]));
        String outFileName = geneSumOutFile;
        if (outExcel) {
            outFileName += ".xlsx";
            LocalExcelFile.writeArray2XLSXFile(geneSumOutFile, geneMutRateSheet, true, -1, 0);
        } else {
            outFileName += ".txt";
            org.cobi.util.text.LocalFile.writeData(outFileName, geneMutRateSheet, "\t", false);
        }
        String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";

        LOG.info(info);
    }

}
