/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import com.esotericsoftware.kryo.Kryo;
import com.esotericsoftware.kryo.io.Output;
import com.esotericsoftware.kryo.serializers.DefaultSerializers;
import com.esotericsoftware.kryo.serializers.DeflateSerializer;
import com.esotericsoftware.kryo.util.DefaultInstantiatorStrategy;

import edu.sysu.pmglab.container.array.BaseArray;
import edu.sysu.pmglab.container.array.StringArray;
import edu.sysu.pmglab.container.array.Array;
import edu.sysu.pmglab.gbc.GTBManager;
import edu.sysu.pmglab.gbc.GTBReader;

import edu.sysu.pmglab.gbc.variant.genotype.Genotype;
import edu.sysu.pmglab.gbc.variant.genotype.IGenotypes;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.GZIPInputStream;
import org.apache.log4j.Logger;
import org.cobi.kggseq.Constants;
import static org.cobi.kggseq.Constants.STAND_CHROM_NAMES;
import org.cobi.kggseq.GlobalManager;
import org.cobi.kggseq.entity.Chromosome;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.Individual;
import org.cobi.kggseq.entity.Variant;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.thread.Task;
import org.objenesis.strategy.StdInstantiatorStrategy;

/**
 *
 * @author mxli
 */
public class BinaryGtyProcessor implements Constants {

    private static final Logger LOG = Logger.getLogger(BinaryGtyProcessor.class);
    protected String pedigreeFileName;
    protected String mapFileName;
    //if kggseqBinaryFileName is not null, it must be a kggseq binary file
    protected String kggseqBinaryFileName;

    boolean needGzExtension = false;

    public BinaryGtyProcessor(String prefixName) {
        this.pedigreeFileName = prefixName + ".kam";
        this.mapFileName = prefixName + ".kim";
        this.kggseqBinaryFileName = prefixName + ".ked";
    }

    public BinaryGtyProcessor() {

    }

    public final int[] getUnphasedGtyAt(byte[] gtys, int alleleNum, int base, int indivID, int blockSize) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;
        boolean[] bits = new boolean[32];
        StringBuilder stringBuilder = new StringBuilder();
        bitNum = indivID;
        for (int i = 0; i < base; i++) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            bits[i] = (gtys[byteIndex1] & GlobalManager.byte1Opers[byteIndex2]) == GlobalManager.byte1Opers[byteIndex2];
            bitNum += blockSize;
        }
        switch (base) {
            case 2:
                /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                 Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                 */
                if (!bits[0] && !bits[1]) {
                    return new int[]{0, 0};
                } else if (!bits[0] && bits[1]) {
                    return new int[]{0, 1};
                } else if (bits[0] && !bits[1]) {
                    return new int[]{1, 1};
                } else if (bits[0] && bits[1]) {
                    return null;
                }
                break;
            default:
                stringBuilder.delete(0, stringBuilder.length());
                for (int i = 0; i < base; i++) {
                    if (bits[i]) {
                        stringBuilder.append(1);
                    } else {
                        stringBuilder.append(0);
                    }
                }
                stringBuilder.append(':').append(alleleNum);
                int[] alleles = GlobalManager.codingUnphasedGtyCodingMap.get(stringBuilder.toString());
                // String infor = "Sorry!!! squence variants with over 4 alleles are not supported and will be ignored!";
                // System.out.println(infor);
                return alleles;
        }
        return null;
    }

    //only works for biallelic variants
    public final boolean setUnphasedGtyAt(byte[] gtys, int alleleNum, int base, int indivID, int blockSize, int[] gty) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;

        /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                 Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
         */
        bitNum = indivID;
        if ((gty[0] == 0 && gty[1] == 0)) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;

            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;

        } else if ((gty[0] == 0 && gty[1] == 1) || (gty[0] == 1 && gty[1] == 0)) {

            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;

            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;

        } else if (gty[0] == 1 && gty[1] == 1) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;

            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;

        } else {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;

            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;
        }

        return true;
    }

    public final int[] getUnphasedGtyBool(boolean[] gtyBits, int alleleNum, int base, int indivID) {
        //tmp variants

        StringBuilder stringBuilder = new StringBuilder();
        switch (base) {
            case 2:
                /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                 Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                 */
                if (!gtyBits[0] && !gtyBits[1]) {
                    return new int[]{0, 0};
                } else if (!gtyBits[0] && gtyBits[1]) {
                    return new int[]{0, 1};
                } else if (gtyBits[0] && !gtyBits[1]) {
                    return new int[]{1, 1};
                } else if (gtyBits[0] && gtyBits[1]) {
                    return null;
                }
                break;
            default:
                stringBuilder.delete(0, stringBuilder.length());
                for (int i = 0; i < base; i++) {
                    if (gtyBits[i]) {
                        stringBuilder.append(1);
                    } else {
                        stringBuilder.append(0);
                    }
                }
                stringBuilder.append(':').append(alleleNum);
                int[] alleles = GlobalManager.codingUnphasedGtyCodingMap.get(stringBuilder.toString());
                // String infor = "Sorry!!! squence variants with over 4 alleles are not supported and will be ignored!";
                // System.out.println(infor);
                return alleles;
        }
        return null;
    }

    public final void getPhasedGtyAt1(byte[] gtys, int base, int indivID, boolean[] bits1, int blockSize) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;

        bitNum = indivID;
        for (int i = 0; i < base; i++) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            bits1[i] = (gtys[byteIndex1] & GlobalManager.byte1Opers[byteIndex2]) == GlobalManager.byte1Opers[byteIndex2];
            bitNum += blockSize;
        }
    }

    public final int[] getPhasedGtyAt(byte[] gtys, int alleleNum, int base, int indivID, int blockSize) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;
        boolean[] bits = new boolean[32];
        StringBuilder stringBuilder = new StringBuilder();
        bitNum = indivID;
        for (int i = 0; i < base; i++) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            bits[i] = (gtys[byteIndex1] & GlobalManager.byte1Opers[byteIndex2]) == GlobalManager.byte1Opers[byteIndex2];
            bitNum += blockSize;
        }

        switch (base) {
            case 2:
                /*       
                 missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	        000  	001	010	011	100
                 Order	0	1	2	3	4                
               
                 II.II Tri-allelic sequence variant (4 bits)
                 missing 	Reference homozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	0|0 	0|1 	0|2 	1|0 	1|1 	1|2
                 Bits      	000 	0001 	0010 	0011 	0100 	0101 	0110
                 Decimal 	0 	1 	2 	3 	4 	5 	6
                 Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	2|0 	2|1 	2|2 	.|. 
                 Bits     	0111 	1000 	1001
                 Decimal 	7 	8 	9     
                 */
                if (!bits[0] && !bits[1] && !bits[2]) {
                    return new int[]{0, 0};
                } else if (!bits[0] && !bits[1] && bits[2]) {
                    return new int[]{0, 1};
                } else if (!bits[0] && bits[1] && !bits[2]) {
                    return new int[]{1, 0};
                } else if (!bits[0] && bits[1] && bits[2]) {
                    return new int[]{1, 1};
                } else if (bits[0] && !bits[1] && !bits[2]) {
                    return null;
                }
                break;
            default:
                stringBuilder.delete(0, stringBuilder.length());
                for (int i = 0; i < base; i++) {
                    if (bits[i]) {
                        stringBuilder.append(1);
                    } else {
                        stringBuilder.append(0);
                    }
                }
                stringBuilder.append(':').append(alleleNum);
                int[] alleles = GlobalManager.codingPhasedGtyCodingMap.get(stringBuilder.toString());
                // String infor = "Sorry!!! squence variants with over 4 alleles are not supported and will be ignored!";
                // System.out.println(infor);
                return alleles;
        }
        return null;
    }

    //only implmented for bialleleic variants
    public final boolean setPhasedGtyAt(byte[] gtys, int alleleNum, int base, int indivID, int blockSize, int[] gty) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;

        /*       
                 missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	        000  	001	010	011	100
                 Order	0	1	2	3	4                
               
                 II.II Tri-allelic sequence variant (4 bits)
                 missing 	Reference homozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	0|0 	0|1 	0|2 	1|0 	1|1 	1|2
                 Bits      	000 	0001 	0010 	0011 	0100 	0101 	0110
                 Decimal 	0 	1 	2 	3 	4 	5 	6
                 Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	2|0 	2|1 	2|2 	.|. 
                 Bits     	0111 	1000 	1001
                 Decimal 	7 	8 	9     
         */
        bitNum = indivID;
        if (gty[0] == 0 && gty[0] == 0) {
            /// 000
            for (int i = 0; i < base; i++) {
                byteIndex1 = (bitNum) / 8;
                byteIndex2 = (bitNum) % 8;
                gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
                bitNum += blockSize;
            }
        } else if (gty[0] == 0 && gty[0] == 1) {
            //001
            for (int i = 0; i < 2; i++) {
                byteIndex1 = (bitNum) / 8;
                byteIndex2 = (bitNum) % 8;
                gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
                bitNum += blockSize;
            }
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;

        } else if (gty[0] == 1 && gty[0] == 0) {
            //010
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
            bitNum += blockSize;
        } else if (gty[0] == 1 && gty[0] == 1) {
            //011
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;
            for (int i = 0; i < 2; i++) {
                byteIndex1 = (bitNum) / 8;
                byteIndex2 = (bitNum) % 8;
                gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte0Opers[byteIndex2]);
                bitNum += blockSize;
            }

        } else {
            //100
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            gtys[byteIndex1] = (byte) (gtys[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
            bitNum += blockSize;

            for (int i = 0; i < 2; i++) {
                byteIndex1 = (bitNum) / 8;
                byteIndex2 = (bitNum) % 8;
                gtys[byteIndex1] = (byte) (gtys[byteIndex1] & GlobalManager.byte0Opers[byteIndex2]);
                bitNum += blockSize;
            }

        }

        return true;
    }

    public final int[] getPhasedGtyBool(boolean[] gtyBits, int alleleNum, int base, int indivID) {
        //tmp variants

        StringBuilder stringBuilder = new StringBuilder();
        switch (base) {
            case 2:
                /*       
                 missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	        000  	001	010	011	100
                 Order	0	1	2	3	4                
               
                 II.II Tri-allelic sequence variant (4 bits)
                 missing 	Reference homozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	0|0 	0|1 	0|2 	1|0 	1|1 	1|2
                 Bits      	000 	0001 	0010 	0011 	0100 	0101 	0110
                 Decimal 	0 	1 	2 	3 	4 	5 	6
                 Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	2|0 	2|1 	2|2 	.|. 
                 Bits     	0111 	1000 	1001
                 Decimal 	7 	8 	9     
                 */
                if (!gtyBits[0] && !gtyBits[1] && !gtyBits[2]) {
                    return new int[]{0, 0};
                } else if (!gtyBits[0] && !gtyBits[1] && gtyBits[2]) {
                    return new int[]{0, 1};
                } else if (!gtyBits[0] && gtyBits[1] && !gtyBits[2]) {
                    return new int[]{1, 0};
                } else if (!gtyBits[0] && gtyBits[1] && gtyBits[2]) {
                    return new int[]{1, 1};
                } else if (gtyBits[0] && !gtyBits[1] && !gtyBits[2]) {
                    return null;
                }
                break;
            default:
                stringBuilder.delete(0, stringBuilder.length());
                for (int i = 0; i < base; i++) {
                    if (gtyBits[i]) {
                        stringBuilder.append(1);
                    } else {
                        stringBuilder.append(0);
                    }
                }
                stringBuilder.append(':').append(alleleNum);
                int[] alleles = GlobalManager.codingPhasedGtyCodingMap.get(stringBuilder.toString());
                // String infor = "Sorry!!! squence variants with over 4 alleles are not supported and will be ignored!";
                // System.out.println(infor);
                return alleles;
        }
        return null;
    }

    public final void getUnphasedGtyAt1(byte[] gtys, int base, int indivID, boolean[] bits1, int blockSize) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;

        bitNum = indivID;
        for (int i = 0; i < base; i++) {
            byteIndex1 = (bitNum) / 8;
            byteIndex2 = (bitNum) % 8;
            bits1[i] = (gtys[byteIndex1] & GlobalManager.byte1Opers[byteIndex2]) == GlobalManager.byte1Opers[byteIndex2];
            bitNum += blockSize;
        }
    }

    public BinaryGtyProcessor(String pedigreeFileName, String mapFileName, String kggseqBinaryFileName) {
        this.pedigreeFileName = pedigreeFileName;
        this.mapFileName = mapFileName;
        this.kggseqBinaryFileName = kggseqBinaryFileName;
    }

    public boolean avaibleFiles() {
        File file = new File(pedigreeFileName);
        if (!file.exists()) {
            return false;
        }
        file = new File(mapFileName);
        if (!file.exists()) {
            return false;
        }
        file = new File(kggseqBinaryFileName);
        if (!file.exists()) {
            return false;
        }
        return true;
    }

    public void readPedigreeFile(List<Individual> indivList) throws Exception {
        StringBuilder tmpBuffer = new StringBuilder();
        String line = null;
        String delimiter = "\t\" \",/";
        BufferedReader br = null;

        File file = new File(pedigreeFileName + ".gz");
        if (file.exists()) {
            br = LocalFileFunc.getBufferedReader(file.getCanonicalPath());
            needGzExtension = true;
        } else {
            file = new File(pedigreeFileName);
            if (file.exists()) {
                br = LocalFileFunc.getBufferedReader(file.getCanonicalPath());
            } else {
                LOG.error(file.getCanonicalPath() + " does not exist!");
                return;
            }
        }

        while ((line = br.readLine()) != null) {
            line = line.toUpperCase();
            StringTokenizer tokenizer = new StringTokenizer(line, delimiter);
            Individual indiv = new Individual();
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(tokenizer.nextToken().trim());
            indiv.setFamilyID(tmpBuffer.toString());
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(tokenizer.nextToken().trim());
            indiv.setIndividualID(tmpBuffer.toString());
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(tokenizer.nextToken().trim());
            indiv.setDadID(tmpBuffer.toString());
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(tokenizer.nextToken().trim());
            indiv.setMomID(tmpBuffer.toString());
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(tokenizer.nextToken().trim());
            indiv.setGender(Integer.valueOf(tmpBuffer.toString()));
            // indiv.setLabelInChip(indiv.getFamilyID() + "@*@" + indiv.getIndividualID());
            indiv.setLabelInChip(indiv.getIndividualID());
            if (tokenizer.hasMoreTokens()) {
                indiv.setAffectedStatus(Integer.parseInt(tokenizer.nextToken().trim()));
            }

            //System.out.println(indiv.getLabelInChip());
            indivList.add(indiv);
        }
        br.close();
    }

    // public void calcualte
    public StringBuilder readBinaryGenotype(List<Individual> subjectList, Genome genome, int minOBS, int maxGtyAlleleNum, double sampleMafOver,
            double sampleMafLess, boolean considerSNP, boolean considerIndel) throws Exception {
        int indiSize = subjectList.size();
        IntArrayList caseSetID = new IntArrayList();
        IntArrayList controlSetID = new IntArrayList();

        for (int i = 0; i < indiSize; i++) {
            if (subjectList.get(i).getAffectedStatus() == 2) {
                caseSetID.add(i);
            } else if (subjectList.get(i).getAffectedStatus() == 1) {
                controlSetID.add(i);
            }
        }
        int subID = 0;
        int caseNum = caseSetID.size();
        int controlNum = controlSetID.size();

        String info = ("Reading genotype bit-file from [ " + kggseqBinaryFileName + " ] \n");
        //openkggseqPedFormat
        DataInputStream in = null;
        if (needGzExtension) {
            in = new DataInputStream(new BufferedInputStream(new GZIPInputStream(new FileInputStream(kggseqBinaryFileName + ".gz"))));
        } else {
            in = new DataInputStream(new BufferedInputStream(new FileInputStream(kggseqBinaryFileName)));
        }

        byte bt1 = in.readByte();
        byte bt2 = in.readByte();
        // System.out.println(bytesToHexString(new byte[]{bt1}));
        // System.out.println(bytesToHexString(new byte[]{bt2}));
        // printBitSet(b); 
        // Magic numbers for .ked file: 10011110 10000010  =9E 82
        if (bt1 != -98 || bt2 != -126) {
            throw new Exception("The " + kggseqBinaryFileName + " is not a valid kggseq binary file!!!");
        }
        boolean isPhased = false;

        bt1 = in.readByte();
        if (bt1 == 1) {
            isPhased = true;
            genome.setIsPhasedGty(true);
        }

        int indiviNum = subjectList.size();
        int alleleNum = 0;
        Chromosome[] chroms = genome.getChromosomes();
        int base = 0;
        int bitNum = 0;
        int intNum = 0;
        int[] gtys = null;
        boolean needAccoundAffect = false;
        boolean needAccoundUnaffect = false;
        int g11 = 0;
        int g12 = 0;
        int g22 = 0;
        int missingG = 0;
        if (caseNum > 0) {
            needAccoundAffect = true;
        }
        if (controlNum > 0) {
            needAccoundUnaffect = true;
        }

        List<Variant> tmpList = new ArrayList<Variant>();
        int ignoredLineNumMinOBS = 0, ignoredLineNumMinMAF = 0, ignoredLineNumMaxMAF = 0, ignoredVarBymaxGtyAlleleNum = 0;
        int obsS = 0;

        double sampleMafOverC = 1 - sampleMafOver;
        double sampleMafLessC = 1 - sampleMafLess;
        boolean needMAFQCOver = false;
        if (sampleMafOver >= 0) {
            needMAFQCOver = true;
        }
        boolean needMAFQCLess = false;
        if (sampleMafLess < 0.5) {
            needMAFQCLess = true;
        }
        boolean incomplete;
        double maf;
        final int gtyLen = 8;
        int codeI;
        byte[] tmpBytes;
//tmp variants
        int byteIndex1;
        int byteIndex2;

        boolean[] bits = new boolean[32];

        for (int chromID = 0; chromID < chroms.length; chromID++) {
            if (chroms[chromID] == null) {
                continue;
            }
            tmpList.clear();

            for (Variant var : chroms[chromID].variantList) {
                alleleNum = var.getAltAlleles().length + 1;

                if (isPhased) {
                    if (var.compressedGtyNum < 0) {
                        base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
                        bitNum = base * indiviNum;
                        intNum = bitNum / gtyLen;
                        if (bitNum % gtyLen != 0) {
                            intNum++;
                        }
                    } else {
                        intNum = var.compressedGtyNum;
                    }

                    var.encodedGty = new byte[intNum];
                    intNum = in.read(var.encodedGty);
                    if (intNum != var.encodedGty.length) {
                        String infor = "Error occurred when reading binary genotypes. Your binary genotypes may be broken!";
                        LOG.error(infor);
                        System.exit(1);
                    }
                } else {
                    if (var.compressedGtyNum < 0) {
                        base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
                        bitNum = base * indiviNum;
                        intNum = bitNum / gtyLen;
                        if (bitNum % gtyLen != 0) {
                            intNum++;
                        }
                    } else {
                        intNum = var.compressedGtyNum;
                    }
                    var.encodedGty = new byte[intNum];
                    intNum = in.read(var.encodedGty);
                    if (intNum != var.encodedGty.length) {
                        String infor = "Error occurred when reading binary genotypes. Your binary genotypes may be broken!";
                        LOG.error(infor);
                        System.exit(1);
                    }
                }
                //In any case, it must read the binary genotype data
                if (alleleNum > maxGtyAlleleNum) {
                    ignoredVarBymaxGtyAlleleNum++;
                    continue;
                }
                if (!considerSNP || !considerIndel) {
                    //a lazy point 
                    incomplete = true;

                    //only consider Indel
                    if (!considerSNP && var.isIndel) {
                        incomplete = false;
                    } else if (!considerIndel && !var.isIndel) {
                        incomplete = false;
                    }

                    if (incomplete) {
                        continue;
                    }
                }

                if (var.compressedGtyNum >= 0) {
                    if (isPhased) {
                        base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
                    } else {
                        base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
                    }
                    bitNum = base * indiviNum;
                    intNum = bitNum / gtyLen;
                    if (bitNum % gtyLen != 0) {
                        intNum++;
                    }

                    tmpBytes = new byte[intNum];
                    Arrays.fill(tmpBytes, (byte) 0);
                    for (int j = 0; j < var.compressedGtyNum; j += 3) {
                        codeI = (var.encodedGty[j + 2] & 0xFF) | ((var.encodedGty[j + 1] & 0xFF) << 8) | ((var.encodedGty[j] & 0x0F) << 16);
                        byteIndex1 = (codeI) / 8;
                        byteIndex2 = (codeI) % 8;
                        tmpBytes[byteIndex1] = (byte) (tmpBytes[byteIndex1] | GlobalManager.byte1Opers[byteIndex2]);
                    }
                    var.encodedGty = tmpBytes;
                }

                obsS = 0;
                g11 = 0;
                g12 = 0;
                g22 = 0;
                missingG = 0;
                for (int j = 0; j < indiSize; j++) {
                    subID = j;
                    if (isPhased) {
                        gtys = getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                    } else {
                        gtys = getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                    }
                    if (gtys == null) {
                        missingG++;
                        continue;
                    }
                    if (gtys[0] != gtys[1]) {
                        g12++;
                    } else if (gtys[0] == 0) {
                        g11++;
                    } else {
                        g22++;
                    }
                    obsS++;
                }
                var.setAffectedRefHomGtyNum(g11);
                var.setAffectedHetGtyNum(g12);
                var.setAffectedAltHomGtyNum(g22);
                var.setMissingtyNum(missingG);
                if (obsS < minOBS) {
                    ignoredLineNumMinOBS++;
                    continue;
                }
                maf = (g12 * 0.5 + g22) / (g11 + g12 + g22);
                if (needMAFQCOver || needMAFQCLess) {
                    if (needMAFQCOver) {
                        if (Double.isNaN(maf) || maf <= sampleMafOver || maf >= sampleMafOverC) {
                            ignoredLineNumMinMAF++;
                            continue;
                        }
                    }
                    if (needMAFQCLess) {
                        if (Double.isNaN(maf) || maf >= sampleMafLess && maf <= sampleMafLessC) {
                            ignoredLineNumMaxMAF++;
                            continue;
                        }
                    }
                }

                var.localAltAF = (float) maf;
                missingG = 0;
                if (needAccoundAffect) {
                    g11 = 0;
                    g12 = 0;
                    g22 = 0;
                    for (int j = 0; j < caseNum; j++) {
                        subID = caseSetID.getQuick(j);
                        if (isPhased) {
                            gtys = getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                        } else {
                            gtys = getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                        }
                        if (gtys == null) {
                            missingG++;
                            continue;
                        }
                        if (gtys[0] != gtys[1]) {
                            g12++;
                        } else if (gtys[0] == 0) {
                            g11++;
                        } else {
                            g22++;
                        }
                    }
                    var.setAffectedRefHomGtyNum(g11);
                    var.setAffectedHetGtyNum(g12);
                    var.setAffectedAltHomGtyNum(g22);
                }

                if (needAccoundUnaffect) {
                    g11 = 0;
                    g12 = 0;
                    g22 = 0;
                    for (int i = 0; i < controlNum; i++) {
                        subID = controlSetID.getQuick(i);
                        if (isPhased) {
                            gtys = getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                        } else {
                            gtys = getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, indiSize);
                        }
                        if (gtys == null) {
                            missingG++;
                            continue;
                        }
                        if (gtys[0] != gtys[1]) {
                            g12++;
                        } else if (gtys[0] == 0) {
                            g11++;
                        } else {
                            g22++;
                        }
                    }
                    var.setUnaffectedRefHomGtyNum(g11);
                    var.setUnaffectedHetGtyNum(g12);
                    var.setUnaffectedAltHomGtyNum(g22);
                    var.setMissingtyNum(missingG);
                }
                tmpList.add(var);
            }
            chroms[chromID].variantList.clear();
            chroms[chromID].variantList.addAll(tmpList);
            tmpList.clear();
        }
        in.close();
        StringBuilder message = new StringBuilder();
        message.append("Quality control summaries:\n");
        if (ignoredLineNumMinOBS > 0) {
            message.append(" ").append(ignoredLineNumMinOBS).append(" variants are ignored due to the number of non-null genotypes in sample (<").append(minOBS).append(")\n");
        }

        if (ignoredLineNumMinMAF > 0) {
            message.append(" ").append(ignoredLineNumMinMAF).append(" variants are ignored due to their minor allele frequency (MAF) in sample <=").append(sampleMafOver).append(")\n");
        }
        if (ignoredLineNumMaxMAF > 0) {
            message.append(" ").append(ignoredLineNumMaxMAF).append(" variants are ignored due to their minor allele frequency (MAF) in sample >=").append(sampleMafLess).append('\n');
        }
        if (ignoredVarBymaxGtyAlleleNum > 0) {
            message.append(" ").append(ignoredVarBymaxGtyAlleleNum).append(" variants are ignored because the number of alleles is > ").append(maxGtyAlleleNum).append(";\n");
        }

        return message;
    }

    public static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder("");
        if (src == null || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }

    public Genome readVariantsMapFile(int[] counts) throws Exception {
        BufferedReader br = null;
        File file = new File(mapFileName + ".gz");
        if (file.exists()) {
            br = LocalFileFunc.getBufferedReader(file.getCanonicalPath());
        } else {
            file = new File(mapFileName);
            if (file.exists()) {
                br = LocalFileFunc.getBufferedReader(file.getCanonicalPath());
            } else {
                LOG.error(file.getCanonicalPath() + " does not exist!");
                return null;
            }
        }

        String line = null;

        int chromIndex = 0;
        int labelIndex = 1;
        int positionIndex = 3;
        int refIndex = 4;
        int altIndex = 5;
        int codeIndex = 6;
        int maxIndex = codeIndex;

        Genome genome = new Genome("KGGSeqGenome", "ked");
        genome.removeTempFileFromDisk();
        String chrom;
        int position = -1;
        String label = null;
        String ref = null;
        String alt = null;
        String code = null;
        StringBuilder tmpBuffer = new StringBuilder();
        int index;
        int effectiveSNPNum = 0;
        int lineCounter = 0;
        int indelNum = 0;
        try {
            while ((line = br.readLine()) != null) {
                if (line.trim().length() == 0) {
                    continue;
                }
                lineCounter++;
                StringTokenizer tokenizer = new StringTokenizer(line);
                index = 0;

                chrom = null;
                position = -1;
                label = null;
                ref = null;
                alt = null;
                code = null;
                while (tokenizer.hasMoreTokens()) {
                    tmpBuffer.delete(0, tmpBuffer.length());
                    tmpBuffer.append(tokenizer.nextToken().trim());

                    if (index == chromIndex) {
                        chrom = tmpBuffer.toString();
                    } else if (index == positionIndex) {
                        position = Integer.parseInt(tmpBuffer.toString());
                    } else if (index == labelIndex) {
                        label = tmpBuffer.toString();
                    } else if (index == refIndex) {
                        ref = tmpBuffer.toString();
                    } else if (index == altIndex) {
                        alt = tmpBuffer.toString();
                    } else if (index == codeIndex) {
                        code = tmpBuffer.toString();
                    }

                    if (index == maxIndex) {
                        break;
                    }
                    index++;
                }

                effectiveSNPNum++;
                Variant var = new Variant(position, ref, alt.split(","));
                if (alt.indexOf('+') >= 0 || alt.indexOf('-') >= 0) {
                    indelNum++;
                    var.isIndel = true;
                }

                var.compressedGtyNum = Integer.parseInt(code);
                var.setLabel(label);
                genome.addVariant(chrom, var);
            }

            counts[0] = lineCounter;
            counts[1] = effectiveSNPNum;
            counts[2] = indelNum;

            /*
             StringBuilder runningInfo = new StringBuilder();
             runningInfo.append("The number of SNPs  in map file ");
             runningInfo.append(mapFile.getName());
             runningInfo.append(" is ");
             runningInfo.append(effectiveVariantNum);
             runningInfo.append(".");
             */
        } finally {
            br.close();
        }
        genome.setVarNum(effectiveSNPNum);
        return genome;
    }

    class GTBReadTask extends Task implements Callable<String> {

        GTBReader gtbReader;
        double minOBSRate;
        int minOBS, minOBSA, minOBSU, subSize, maxGtyAlleleNum;
        double minOBSARate, minOBSURate, sampleMafOver, sampleMafLess;
        IntArrayList caeSetIDInPed, controlSetIDInPed;
        boolean needGty, considerIndel, considerSNP;
        BaseArray<Integer> subIDs;

        protected int ignoredCNVNum = 0, ignoredVarBymaxGtyAlleleNum = 0, ignoredLineNumMinOBS = 0,
                ignoredLineNumMinMAF = 0, ignoredLineNumMaxMAF = 0, ignoredLineNumMinOBSA = 0, ignoredLineNumMinOBSU = 0,
                indelNum = 0, snvNum = 0, effectiveVariantNum = 0, allVariantNum = 0, ignoredVarByRegionsInNum = 0, ignoredVarByRegionsOutNum = 0;

        private final String storagePath;
        private final Kryo kryo = new Kryo();

        //As array is much faster than list; I try to use array when it does not was
        private int threadID = -1;
        private List<Variant>[] varChroms = null;
        private boolean isRegionInModel = false;
        private boolean isRegionOutModel = false;

        private int[][] regionsIn;
        private int[][] regionsOut;
        boolean accessAllSub;

        public GTBReadTask(int threadID, String storagePath) {
            this.storagePath = storagePath;
            this.threadID = threadID;
            varChroms = new ArrayList[STAND_CHROM_NAMES.length];
            for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                varChroms[i] = new ArrayList<>();
            }

            kryo.setReferences(false);
            kryo.setRegistrationRequired(false);
//        kryo.setInstantiatorStrategy(new StdInstantiatorStrategy());
//        kryo.register(char[].class);
//        kryo.register(long[].class);
//        kryo.register(float[].class);
//        kryo.register(String[].class);
//
//        kryo.register(StringBuilder.class);
//        kryo.register(Variant.class);
//        kryo.register(OpenIntIntHashMap.class);

            kryo.setInstantiatorStrategy(new DefaultInstantiatorStrategy(new StdInstantiatorStrategy()));

            kryo.register(Variant.class, 1);
            kryo.register(byte[].class, 0);
            kryo.register(char[].class, 2);
            kryo.register(long[].class, 3);
            kryo.register(float[].class, 4);

            kryo.register(String[].class, 5);
            kryo.register(StringBuilder.class, 6);
            kryo.register(String.class, new DeflateSerializer(new DefaultSerializers.StringSerializer()), 7);
            kryo.register(OpenIntIntHashMap.class, 8);
        }

        public void setRegionsIn(int[][] regions) {
            if (regions != null) {
                isRegionInModel = true;
                regionsIn = regions;
            }
        }

        public void setRegionsOut(int[][] regions) {
            if (regions != null) {
                isRegionOutModel = true;
                regionsOut = regions;
            }
        }

        public void setReadSubParams(GTBReader gtbReader, BaseArray<Integer> subIDs, int subSize, IntArrayList caeSetIDInPed, IntArrayList controlSetIDInPed, boolean accessAllSub) {
            this.gtbReader = gtbReader;
            this.caeSetIDInPed = caeSetIDInPed;
            this.controlSetIDInPed = controlSetIDInPed;
            this.subSize = subSize;
            this.accessAllSub = accessAllSub;
            this.subIDs = subIDs;
        }

        public void setMetricParams(int minOBS, double minOBSRate,
                int minOBSA, double minOBSARate, int minOBSU, double minOBSURate, int maxGtyAlleleNum, double sampleMafOver,
                double sampleMafLess, boolean considerSNP, boolean considerIndel, boolean needGty) {

            this.minOBS = minOBS;
            this.minOBSRate = minOBSRate;
            this.minOBSA = minOBSA;
            this.minOBSARate = minOBSARate;
            this.minOBSU = minOBSU;
            this.minOBSURate = minOBSURate;
            this.maxGtyAlleleNum = maxGtyAlleleNum;
            this.sampleMafOver = sampleMafOver;
            this.sampleMafLess = sampleMafLess;
            this.considerSNP = considerSNP;
            this.considerIndel = considerIndel;
            this.needGty = needGty;
        }

        @Override
        public String call() throws Exception {
            boolean needAccoundAffect = false, needAccoundUnaffect = false;
            if (minOBSRate != -1) {
                int c = (int) (subSize * minOBSRate);
                if (c > minOBS) {
                    minOBS = c;
                }
            }

            int caseSize = caeSetIDInPed.size();
            int controlSize = controlSetIDInPed.size();
            if (caseSize > 0) {
                needAccoundAffect = true;
            }
            if (controlSize > 0) {
                needAccoundUnaffect = true;
            }

            if (minOBSARate != -1) {
                int c = (int) (caseSize * minOBSARate);
                if (c > minOBSA) {
                    minOBSA = c;
                }
            }
            if (minOBSURate != -1) {
                int c = (int) (controlSize * minOBSURate);
                if (c > minOBSU) {
                    minOBSU = c;
                }
            }
            int gty1, gty2, obsS;

            int[] gtysPEDOrder = new int[subSize * 2];

            int idLabel, t, position, regionNum, g11, g12, g22, g11a, g12a, g22a, totalA = 0, totalN = 0;
            boolean isInvalid, isCNV, ignoreCNV = true, isIndel;
            String alt, ref;
            String[] alts;
            StringBuilder tmpSB = new StringBuilder();
            // BaseArray<Integer> lefts, rights;
            BaseArray<Genotype> genoypes;

            double maf;
            double sampleMafOverC = 1 - sampleMafOver, sampleMafLessC = 1 - sampleMafLess;
            boolean needMAFQCOver = false, needMAFQCLess = false;

            if (sampleMafOver != -1) {
                needMAFQCOver = true;
            }
            if (sampleMafLess > 0) {
                needMAFQCLess = true;
            }
            boolean isWithinRegion, isPhasedGty = gtbReader.getGtbFormat().phased;
            Map<Genotype, Integer> gtyCounts;

//            VariantFormatter<Boolean, int[]> haplotypeExtractor = new VariantFormatter<Boolean, int[]>() {
//                public int[] apply(edu.sysu.pmglab.gbc.variant.Variant variant, Boolean isLeft) {
//                    int[] haplotype = new int[variant.getSubjectNum()];
//                    if (isLeft) {
//                        for (int i = 0; i < haplotype.length; i++) {
//                            haplotype[i] = variant.getGenotype(i).getLeftGenotype();
//                        }
//                    } else {
//                        for (int i = 0; i < haplotype.length; i++) {
//                            haplotype[i] = variant.getGenotype(i).getRightGenotype();
//                        }
//                    }
//
//                    return haplotype;
//                }
//            };
            int chromI = 0;
            IGenotypes genotypes;
            for (edu.sysu.pmglab.gbc.variant.Variant variant : gtbReader) {
                position = variant.getPosition();

                if(position==186613305){
                    int ssssss=0;
                }
                chromI = variant.getChromosome().getChromosomeIndex();

                //System.out.println(posStr);
                allVariantNum++;

                if (isRegionInModel) {
                    int[] pos = regionsIn[chromI];
                    if (pos == null) {
                        ignoredVarByRegionsInNum++;
                        continue;
                    }
                    isWithinRegion = false;
                    regionNum = pos.length / 2;
                    for (int k = 0; k < regionNum; k++) {
                        if (position >= pos[k << 1] && position <= pos[k << 1 + 1]) {
                            isWithinRegion = true;
                            break;
                        }
                    }

                    if (!isWithinRegion) {
                        ignoredVarByRegionsInNum++;
                        continue;
                    }
                }

                if (isRegionOutModel) {
                    int[] pos = regionsOut[chromI];
                    if (pos != null) {
                        isWithinRegion = false;
                        regionNum = pos.length / 2;
                        for (int k = 0; k < regionNum; k++) {
                            if (position >= pos[k << 1] && position <= pos[k << 1 + 1]) {
                                isWithinRegion = true;
                                break;
                            }
                        }
                        if (isWithinRegion) {
                            ignoredVarByRegionsOutNum++;
                            continue;
                        }
                    }
                }

                if (variant.getAlleleNum() > maxGtyAlleleNum) {
                    ignoredVarBymaxGtyAlleleNum++;
                    continue;
                }

                ref = variant.alleleOfIndex(0).toString();

                alts = new String[variant.getAlleleNum() - 1];
                for (int i = 0; i < alts.length; i++) {
                    alts[i] = variant.alleleOfIndex(i + 1).toString();
                }

                //KGGSeq's formate for Indels
                isInvalid = false;

                if (ignoreCNV) {
                    isCNV = false;
                    for (int ss = 0; ss < alts.length; ss++) {
                        alt = alts[ss];
                        if (alt.charAt(0) == '<') {
                            isCNV = true;
                            break;
                        }
                    }
                    if (isCNV) {
                        ignoredCNVNum++;
                        continue;
                    }
                }

                isIndel = false;
                for (int ss = 0; ss < alts.length; ss++) {
                    alt = alts[ss];
                    //only one alternative alleles; the most common  scenario
                    if (ref.length() == alt.length()) {
                        //substitution
                        //now it can sonsider double polymorphsom
                        alts[ss] = alt;
                    } else if (ref.length() < alt.length()) {
                        //insertion
                        /*examples
                            insertion1
                            chr1 1900106 . TCT TCTCCT 217 . INDEL;DP=62;AF1=0.5;CI95=0.5,0.5;DP4=17,9,18,12;MQ=60;FQ=217;PV4=0.78,1,1,0.1 GT:PL:DP:SP:GQ 0/1:255,0,255:56:-991149567:99
                            
                            insertion2
                            chr1 109883576 . C CAT 214 . INDEL;DP=15;AF1=1;CI95=1,1;DP4=0,0,1,11;MQ=60;FQ=-70.5 GT:PL:DP:SP:GQ 1/1:255,36,0:12:-991149568:69
                            *
                         */
                        //for Indel TTCC TT--
                        //for Insertion T +TTTT
                        tmpSB.delete(0, tmpSB.length());
                        if (alt.startsWith(ref)) {
                            for (t = ref.length(); t > 0; t--) {
                                tmpSB.append('+');
                            }

                            tmpSB.append(alt.substring(ref.length()));
                            alts[ss] = tmpSB.toString();
                        } else if (alt.endsWith(ref)) {
                            tmpSB.append(alt.substring(0, alt.length() - ref.length()));
                            for (t = ref.length(); t > 0; t--) {
                                tmpSB.append('+');
                            }
                            alts[ss] = tmpSB.toString();
                        } else if (alt.charAt(0) == ref.charAt(0)) {
                            int startI = 0;
                            int len1 = Math.min(alt.length(), ref.length());
                            while (startI < len1) {
                                if (alt.charAt(startI) != ref.charAt(startI)) {
                                    break;
                                }
                                startI++;
                            }
                            for (t = startI; t > 0; t--) {
                                tmpSB.append('+');
                            }
                            tmpSB.append(alt.substring(startI));
                            alts[ss] = tmpSB.toString();
                        } else if (alt.charAt(alt.length() - 1) == ref.charAt(ref.length() - 1)) {
                            int startI = 0;
                            int len1 = Math.min(alt.length(), ref.length());
                            int lenA = alt.length() - 1;
                            int lenR = ref.length() - 1;
                            while (startI < len1) {
                                if (alt.charAt(lenA - startI) != ref.charAt(lenR - startI)) {
                                    break;
                                }
                                startI++;
                            }
                            tmpSB.append(alt.substring(0, alt.length() - startI));
                            for (t = startI; t > 0; t--) {
                                tmpSB.append('+');
                            }
                            alts[ss] = tmpSB.toString();
                        }

                        isIndel = true;
                    } else if (ref.length() > alt.length()) {
                        //deletion     
                        /*examples
                            deletion1
                            chr1 113659065 . ACTCT ACT 214 . INDEL;DP=61;AF1=1;CI95=1,1;DP4=0,0,22,34;MQ=60;FQ=-204 GT:PL:DP:SP:GQ 1/1:255,169,0:56:-991149568:99
                            deletion2
                            chr1 1289367 . CTG C 101 . INDEL;DP=14;AF1=0.5;CI95=0.5,0.5;DP4=5,2,5,1;MQ=60;FQ=104;PV4=1,0.4,1,1 GT:PL:DP:SP:GQ 0/1:139,0,168:13:-991149568:99
                         */
                        //Note it can work for multiple deletion alleles like:chr1	158164305	.	TAA	TA,T

                        //for Indel TTCC TT--
                        //for Insertion T +TTTT
                        tmpSB.delete(0, tmpSB.length());
                        if (ref.startsWith(alt)) {
                            tmpSB.append(alt);
                            for (t = ref.length() - alt.length(); t > 0; t--) {
                                tmpSB.append('-');
                            }
                            alts[ss] = tmpSB.toString();
                        } else if (ref.endsWith(alt)) {
                            for (t = ref.length() - alt.length(); t > 0; t--) {
                                tmpSB.append('-');
                            }
                            tmpSB.append(alt);
                            alts[ss] = tmpSB.toString();
                        } else if (alt.charAt(0) == ref.charAt(0)) {
                            tmpSB.append(alt);
                            for (t = ref.length() - alt.length(); t > 0; t--) {
                                tmpSB.append('-');
                            }
                            alts[ss] = tmpSB.toString();
                        } else if (alt.charAt(alt.length() - 1) == ref.charAt(ref.length() - 1)) {
                            for (t = ref.length() - alt.length(); t > 0; t--) {
                                tmpSB.append('-');
                            }
                            tmpSB.append(alt);
                        }
                        isIndel = true;
                    } else {
                        StringBuilder info = new StringBuilder("Unexpected (REF ALT) format when parsing variants at  :" + position);
                        LOG.warn(info);
                        isInvalid = true;
                        // throw new Exception(info.toString());
                    }

                }
                if (isInvalid) {
                    continue;
                }

//                    int[] lefts = variant.apply(haplotypeExtractor, true);
//                    int[] rights = variant.apply(haplotypeExtractor, false);
                //gtyCounts = variant.genotypeCounts();
//                    lefts = variant.getGenotypes().apply(Genotype::getLeftGenotype);
//                    rights = variant.getGenotypes().apply(Genotype::getRightGenotype);
                maf = 0;
                g11a = 0;
                g22a = 0;
                g12a = 0;
                //Genotypes genotypes = ((Genotypes) variant.getProperty(Genotypes.class)).subGenotypes(subIDs);
                genotypes = IGenotypes.load(variant);
                //this only efficient for all subjects
                if (genotypes.getAN() == 0 || genotypes.getAF() == 0f || genotypes.getAF() == 1f) {
                    continue;
                }
                if (!accessAllSub) {
                    genotypes = genotypes.subGenotypes(subIDs);
                }

                for (int i = 0; i < subSize; i++) {

                    idLabel = i << 1;
                    //this would be fatest way
                    Genotype genotype = genotypes.getGenotype(i);

                    if (genotype.isMissingGenotype()) {
                        gtysPEDOrder[idLabel] = -1;
                        gtysPEDOrder[idLabel + 1] = -1;
                        continue;
                    }

                    gtysPEDOrder[idLabel] = genotype.getLeftGenotype();
                    gtysPEDOrder[idLabel + 1] = genotype.getRightGenotype();

                    if (gtysPEDOrder[idLabel] == gtysPEDOrder[idLabel + 1]) {
                        if (gtysPEDOrder[idLabel] == 0) {
                            g11a++;
                        } else {
                            g22a++;
                            maf += 2;
                        }
                    } else {
                        g12a++;
                        if (gtysPEDOrder[idLabel] == 0) {
                            maf += 1;
                        }
                        if (gtysPEDOrder[idLabel + 1] == 0) {
                            maf += 1;
                        }

                    }
                }

                obsS = g11a + g12a + g22a;

                if (obsS < minOBS) {
                    ignoredLineNumMinOBS++;
                    continue;
                }
                Variant var = new Variant(position, ref, alts);
                var.isIndel = isIndel;

                maf /= (2 * obsS);
                if (needMAFQCOver || needMAFQCLess) {
                    if (needMAFQCOver) {
                        if (Double.isNaN(maf) || maf <= sampleMafOver || maf >= sampleMafOverC) {
                            ignoredLineNumMinMAF++;
                            continue;
                        }
                    }
                    if (needMAFQCLess) {
                        if (Double.isNaN(maf) || maf >= sampleMafLess && maf <= sampleMafLessC) {
                            ignoredLineNumMaxMAF++;
                            continue;
                        }
                    }
                }

                if (needAccoundAffect) {
                    g11a = 0;
                    g12a = 0;
                    g22a = 0;

                    for (int i = 0; i < caseSize; i++) {
                        idLabel = caeSetIDInPed.getQuick(i);
                        if (idLabel < 0) {
                            continue;
                        }
                        //BEGDecoder.getDecoder(false).decode(2, variant.BEGs[0]);
                        idLabel = idLabel << 1;
                        gty1 = gtysPEDOrder[idLabel];
                        gty2 = gtysPEDOrder[idLabel + 1];
                        if (gty1 == -1 || gty2 == -1) {
                            continue;
                        }

                        if (gty1 == gty2) {
                            if (gty1 == 0) {
                                g11a++;
                            } else {
                                g22a++;
                                maf += 2;
                            }
                        } else {
                            g12a++;
                            if (gty1 == 0) {
                                maf += 1;
                            }
                            if (gty2 == 0) {
                                maf += 1;
                            }

                        }

                    }
                    var.setAffectedRefHomGtyNum(g11a);
                    var.setAffectedHetGtyNum(g12a);
                    var.setAffectedAltHomGtyNum(g22a);
                    totalA = g11a + g12a + g22a;
                    if (!needAccoundUnaffect) {
                        maf = (g12a * 0.5 + g22a) / totalA;
                        var.localAltAF = (float) maf;
                    }
                    if (totalA < minOBSA) {
                        ignoredLineNumMinOBSA++;
                        continue;
                    }
                }

                if (needAccoundUnaffect) {
                    g11a = 0;
                    g12a = 0;
                    g22a = 0;

                    for (int i = 0; i < controlSize; i++) {
                        idLabel = controlSetIDInPed.getQuick(i);
                        if (idLabel < 0) {
                            continue;
                        }
                        idLabel = idLabel << 1;
                        gty1 = gtysPEDOrder[idLabel];
                        gty2 = gtysPEDOrder[idLabel + 1];
                        if (gty1 == -1 || gty2 == -1) {
                            continue;
                        }
                        if (gty1 == gty2) {
                            if (gty1 == 0) {
                                g11a++;
                            } else {
                                g22a++;
                                maf += 2;
                            }
                        } else {
                            g12a++;
                            if (gty1 == 0) {
                                maf += 1;
                            }
                            if (gty2 == 0) {
                                maf += 1;
                            }

                        }
                    }
                    var.setUnaffectedRefHomGtyNum(g11a);
                    var.setUnaffectedHetGtyNum(g12a);
                    var.setUnaffectedAltHomGtyNum(g22a);
                    //Record allele frequencies of controls
                    // if (!needAccoundAffect)
                    totalN = g11a + g12a + g22a;
                    {
                        maf = (g12a * 0.5 + g22a) / totalN;
                        var.localAltAF = (float) maf;
                    }
                    if (totalN < minOBSU) {
                        ignoredLineNumMinOBSU++;
                        continue;
                    }
                }

                if (!needAccoundAffect && !needAccoundUnaffect) {
                    var.setAffectedRefHomGtyNum(g11a);
                    var.setAffectedHetGtyNum(g12a);
                    var.setAffectedAltHomGtyNum(g22a);
                    maf = (g12a * 0.5 + g22a) / (g11a + g12a + g22a);
                    var.localAltAF = (float) maf;
                } else {
                    if (totalN + totalA < minOBS) {
                        ignoredLineNumMinOBS++;
                        continue;
                    }

                }

                if (isIndel) {
                    indelNum++;
                    if (!considerIndel) {
                        continue;
                    }
                } else {
                    if (!considerSNP) {
                        continue;
                    }
                    snvNum++;
                }
                if (needGty) {
                    encodeGenotype(var, isPhasedGty, subSize, gtysPEDOrder);
                }

                varChroms[chromI].add(var);

                effectiveVariantNum++;

                if (effectiveVariantNum % 100000 == 0) {
                    writeChromosomeToDiskClean();

                }
            }

            gtbReader.close();
            if (effectiveVariantNum > 0) {
                writeChromosomeToDiskClean();
            }
            return "";
            // 

        }

        private void writeChromosomeToDiskClean() {
            int chromID = -1;
            String chromeName;
            try {
                for (List<Variant> varList : varChroms) {
                    chromID++;
                    chromeName = STAND_CHROM_NAMES[chromID];
                    if (varList.isEmpty()) {
                        continue;
                    }
                    int fileIndex = -1;
                    String chrNameP = "Chromosome." + chromeName;
                    chrNameP = threadID + "." + chrNameP;
                    File fileName = null;
                    File folder = new File(storagePath);
                    if (folder.exists()) {
                        do {
                            fileIndex++;
                            fileName = new File(storagePath + File.separator + chrNameP + ".var.obj." + fileIndex);
                        } while (fileName.exists());
                    } else {
                        fileIndex++;
                        folder.mkdirs();
                    }

                    //comments: both Kryo and FSTObjectOutput are excellent tools for Serializationl. However, the former produced slightly smaller file and was slightly faster. So I used Kryo
                    fileName = new File(storagePath + File.separator + chrNameP + ".var.obj." + fileIndex);
                    //slower
                    //  kryo.setInstantiatorStrategy(new SerializingInstantiatorStrategy());            
                    Output output = new Output(new FileOutputStream(fileName), 1024 * 1024);
                    //  output.setBuffer(buffer);

                    for (Variant var : varList) {
                        kryo.writeObject(output, var);
                    }
                    output.flush();
                    output.close();
                    varList.clear();
                }
                System.gc();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

    public Genome readVariantsGTBFileThread(String gbtBinaryFileName, List<Individual> indivList, Genome genome, int minOBS, double minOBSRate,
            int minOBSA, double minOBSARate, int minOBSU, double minOBSURate, int maxGtyAlleleNum, double sampleMafOver,
            double sampleMafLess, boolean considerSNP, boolean considerIndel, int[] counts, boolean needGty, int nThreads, int[][] regionsIn, int[][] regionsOut) throws Exception {

        int effectiveVariantNum = 0;
        int allVariantNum = 0;
        int indelNum = 0;
        boolean isIndel;
        int ignoredLineNumMinOBS = 0, ignoredLineNumMinMAF = 0, ignoredLineNumMaxMAF = 0, ignoredVarBymaxGtyAlleleNum = 0,
                ignoredVarByRegionsInNum = 0, ignoredVarByRegionsOutNum = 0;

        String subID;
        List<String> unmappedSubjects = new ArrayList<>();
        int ignoredLineNumMinOBSU = 0, ignoredLineNumMinOBSA = 0;
        int[] gtysPEDOrder = null;
        int totalN = 0, totalA = 0, snvNum = 0, subSize;
        int ignoredCNVNum = 0;
        try {

            GTBManager manager = GTBManager.load(gbtBinaryFileName);
            GTBReader gtbReader = manager.instanceReader();
            IntArrayList caeSetIDInPed = new IntArrayList();
            IntArrayList controlSetIDInPed = new IntArrayList();
            int effectiveIndivNum = 0, id;
            BaseArray<Integer> subIDs = new Array<>();

            List<Individual> indivListWithGtys = new ArrayList<>();
            boolean useAllSubjects = false;
            if (indivList.isEmpty()) {
                effectiveIndivNum = gtbReader.getSubjectNum();
                subSize = effectiveIndivNum;
                for (int i = 0; i < subSize; i++) {
                    subIDs.add(i);
                }
                useAllSubjects = true;
            } else {
                StringArray gtbSubjects = new StringArray();

                subSize = indivList.size();
                for (int i = 0; i < subSize; i++) {
                    subID = indivList.get(i).getLabelInChip();
                    id = gtbReader.indexOfSubject(subID);
                    if (id < 0) {
                        unmappedSubjects.add(subID);
                    } else {
                        effectiveIndivNum++;
                        indivListWithGtys.add(indivList.get(i));
                        gtbSubjects.add(subID);
                        subIDs.add(id);
                        indivList.get(i).setHasGenotypes(true);
                    }
                }
                indivList.clear();
                indivList.addAll(indivListWithGtys);
                subSize = indivList.size();

                for (int j = 0; j < subSize; j++) {
                    if (indivList.get(j).getAffectedStatus() == 2) {
                        caeSetIDInPed.add(j);
                    } else if (indivList.get(j).getAffectedStatus() == 1) {
                        controlSetIDInPed.add(j);
                    }
                }
                gtbReader = manager.instanceReader();
                if (subIDs.size() == gtbReader.getSubjectNum()) {
                    useAllSubjects = true;
                }

            }
            if (!unmappedSubjects.isEmpty()) {
                LOG.info(unmappedSubjects.size() + " subjects in the pedigree file do not exist in the GTB file: " + unmappedSubjects.toString());
                if (unmappedSubjects.size() == indivList.size()) {
                    LOG.error("All subjects in the pedigree file have no IDs in the GTB file! The program stops.");
                    System.exit(2);
                }

            }

            File folder = new File(genome.getStoragePath());
            if (!folder.exists()) {
                folder.mkdirs();
            }

            // Map<edu.sysu.pmglab.gbc.variant.Chromosome, Interval<Long>> chromosomeTree = manager.getChromosomeTree();
            BaseArray<GTBReader> gtbReaders = gtbReader.part(nThreads);

            ExecutorService exec = Executors.newFixedThreadPool(nThreads);
            final CompletionService<String> serv = new ExecutorCompletionService<>(exec);

            int runningThread = 0;
            //I spend 2 days to write a new VCFParseTask which I expected to be faster by modifying the Uitl.tokenize function
            //Unfortunately, the new Task is much slower than
            //VCFParseTask[] parsTaskArray = new VCFParseTask[maxThreadNum];

            GTBReadTask[] parsTaskArray = new GTBReadTask[nThreads];
            for (int s = 0; s < nThreads; s++) {
                parsTaskArray[s] = new GTBReadTask(s, genome.getStoragePath()) {
                    @Override
                    public void fireTaskComplete() throws Exception {
                        synchronized (gtbReader) {

                        }

                    }
                };
                parsTaskArray[s].setMetricParams(minOBS, minOBSRate, minOBSA, minOBSARate, minOBSU, minOBSURate,
                        maxGtyAlleleNum, sampleMafOver, sampleMafLess, considerSNP, considerIndel, needGty);
                parsTaskArray[s].setReadSubParams(gtbReaders.get(s), subIDs, subSize, caeSetIDInPed, controlSetIDInPed, useAllSubjects);

                // parsTaskArray[s].setReadSubParams(gtbReader,subSize, caeSetIDInPed, controlSetIDInPed);
                parsTaskArray[s].setRegionsIn(regionsIn);
                parsTaskArray[s].setRegionsOut(regionsOut);
                serv.submit(parsTaskArray[s]);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                //  System.out.println(infor);
            }
            exec.shutdown();

            for (int s = 0; s < nThreads; s++) {
                ignoredLineNumMinOBS += parsTaskArray[s].ignoredLineNumMinOBS;
                ignoredLineNumMinMAF += parsTaskArray[s].ignoredLineNumMinMAF;
                ignoredLineNumMaxMAF += parsTaskArray[s].ignoredLineNumMaxMAF;
                ignoredVarBymaxGtyAlleleNum += parsTaskArray[s].ignoredVarBymaxGtyAlleleNum;
                ignoredLineNumMinOBSA += parsTaskArray[s].ignoredLineNumMinOBSA;
                ignoredLineNumMinOBSU += parsTaskArray[s].ignoredLineNumMinOBSU;
                ignoredCNVNum += parsTaskArray[s].ignoredCNVNum;
                allVariantNum += parsTaskArray[s].allVariantNum;
                effectiveVariantNum += parsTaskArray[s].effectiveVariantNum;
                indelNum += parsTaskArray[s].indelNum;
                ignoredVarByRegionsInNum += parsTaskArray[s].ignoredVarByRegionsInNum;
                ignoredVarByRegionsOutNum += parsTaskArray[s].ignoredVarByRegionsOutNum;
                //cnvNum += parsTaskArray[s].cnvNum;

            }
            counts[0] = allVariantNum;
            counts[1] = effectiveVariantNum;
            counts[2] = indelNum;
            StringBuilder message = new StringBuilder();
            message.append("Quality control summaries:\n");
            if (ignoredLineNumMinOBS > 0) {
                message.append(" ").append(ignoredLineNumMinOBS).append(" variants are ignored due to the number of non-null genotypes in sample (<").append(minOBS).append(")\n");
            }

            if (ignoredLineNumMinMAF > 0) {
                message.append(" ").append(ignoredLineNumMinMAF).append(" variants are ignored due to their minor allele frequency (MAF) in sample <=").append(sampleMafOver).append(")\n");
            }
            if (ignoredLineNumMaxMAF > 0) {
                message.append(" ").append(ignoredLineNumMaxMAF).append(" variants are ignored due to their minor allele frequency (MAF) in sample >=").append(sampleMafLess).append('\n');
            }
            if (ignoredVarBymaxGtyAlleleNum > 0) {
                message.append(" ").append(ignoredVarBymaxGtyAlleleNum).append(" variants are ignored because the number of alleles is > ").append(maxGtyAlleleNum).append(";\n");
            }

            if (ignoredLineNumMinOBSA > 0) {
                message.append(" ").append(ignoredLineNumMinOBSA).append(" variants are ignored due to the number of non-null genotypes in patients <").append(minOBSA).append('\n');
            }
            if (ignoredLineNumMinOBSU > 0) {
                message.append(" ").append(ignoredLineNumMinOBSU).append(" variants are ignored due to the number of non-null genotypes in controls <").append(minOBSU).append('\n');
            }

            if (ignoredCNVNum > 0) {
                message.append(" ").append(ignoredCNVNum).append(" CNV variants are ignored.").append('\n');
            }

            if (ignoredVarByRegionsInNum > 0) {
                message.append(" ").append(ignoredVarByRegionsInNum).append(" variants are ignored because they are beyond the specified region(s)\n");
            }
            if (ignoredVarByRegionsOutNum > 0) {
                message.append(" ").append(ignoredVarByRegionsOutNum).append(" variants are ignored because they are within the specified region(s)\n");
            }

            if (!considerIndel) {
                message.append(" ").append(indelNum).append(" Indel variants are ignored\n");
            }
            if (!considerSNP) {
                message.append(" ").append(snvNum).append(" SNV variants are ignored\n");
            }

//        if (ignoreCNV) {
//            message.append(" ").append(cnvNum).append(" CNV variants are ignored\n");
//        }
            LOG.info(message);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        genome.setVarNum(effectiveVariantNum);

        return genome;
    }

    private void encodeGenotype(Variant var, boolean isPhased, int totalPedSubjectNum, int[] gtys) {
        //tmp variants
        int byteIndex1;
        int byteIndex2;
        int bitNum;
        boolean[] bits;
        int base, byteNum, alleleNumShift, s1;
        //as the genotypes may be use for other purpose so we need record it before filtering 
        final int gtyLen = 8, alleleNum = var.getAltAlleles().length + 1;
        int missingNum = 0;
        int v;
        int vcfID, index;

        if (isPhased) {
            base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
            bitNum = base * totalPedSubjectNum;

            if (bitNum % gtyLen != 0) {
                byteNum = bitNum / gtyLen + 1;
            } else {
                byteNum = bitNum / gtyLen;
            }

            var.encodedGty = new byte[byteNum];
            Arrays.fill(var.encodedGty, (byte) 0);
            alleleNumShift = alleleNum << 16;
            for (index = 0; index < totalPedSubjectNum; index++) {
                vcfID = index << 1;
                //bitNum = pedEncodeGytID[index];
                bitNum = index;
                //Note: 00 does not denote missing any longer
                if (vcfID < 0) {
                    missingNum++;
                    //missing value      
                    if (alleleNum == 2) {
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;
                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                    } else {
                        v = alleleNum * alleleNum;
                        for (int i = 0; i < base; i++) {
                            if ((v & GlobalManager.intOpers[32 + i - base]) == GlobalManager.intOpers[32 + i - base]) {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            bitNum += totalPedSubjectNum;
                        }
                    }
                    continue;
                }

                if (gtys[vcfID] == -1) {
                    missingNum++;
                    //missing value      
                    if (alleleNum == 2) {
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;
                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                    } else {
                        v = alleleNum * alleleNum;
                        for (int i = 0; i < base; i++) {
                            if ((v & GlobalManager.intOpers[32 + i - base]) == GlobalManager.intOpers[32 + i - base]) {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            bitNum += totalPedSubjectNum;
                        }
                    }
                    continue;
                } else {
                    switch (alleleNum) {
                        case 2:
                            /*       
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                             VCF genotype	0|0	0|1	1|0	1|1 .|.	
                             Bits	        000  	001	010	011	100
                             Order	0	1	2	3	4                
               
                             II.II Tri-allelic sequence variant (4 bits)
                             missing 	Reference homozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Alternative homozygous
                             VCF genotype 	0|0 	0|1 	0|2 	1|0 	1|1 	1|2 .|. 	
                             Bits      	000 	0001 	0010 	0011 	0100 	0101 	0110
                             Decimal 	0 	1 	2 	3 	4 	5 	6
                             Heterozygous 	Heterozygous 	Alternative homozygous
                             VCF genotype 	2|0 	2|1 	2|2
                             Bits     	0111 	1000 	1001
                             Decimal 	7 	8 	9     
                             */

                            //to speedup the analysis
                            if (gtys[(vcfID)] == 0 && gtys[(vcfID) + 1] == 0) {

                            } else if (gtys[(vcfID)] == 0 && gtys[(vcfID) + 1] == 1) {
                                bitNum += (totalPedSubjectNum + totalPedSubjectNum);
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                //System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));

                            } else if (gtys[(vcfID)] == 1 && gtys[(vcfID) + 1] == 0) {
                                bitNum += totalPedSubjectNum;
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));

                            } else if (gtys[(vcfID)] == 1 && gtys[(vcfID) + 1] == 1) {
                                bitNum += totalPedSubjectNum;
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                bitNum += (totalPedSubjectNum);
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];

                            } else {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            break;
                        default:
                            bits = GlobalManager.phasedGtyCodingMap.get(gtys[(vcfID)] | (gtys[(vcfID) + 1] << 8) | (alleleNumShift));
                            for (int i = 0; i < base; i++) {
                                if (bits[i]) {
                                    byteIndex1 = (bitNum) / gtyLen;
                                    byteIndex2 = (bitNum) % gtyLen;
                                    var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                }
                                bitNum += totalPedSubjectNum;
                            }
                    }
                }
            }
        } else {

            base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
            bitNum = base * totalPedSubjectNum;

            if (bitNum % gtyLen != 0) {
                byteNum = bitNum / gtyLen + 1;
            } else {
                byteNum = bitNum / gtyLen;
            }

            var.encodedGty = new byte[byteNum];
            Arrays.fill(var.encodedGty, (byte) 0);
            alleleNumShift = alleleNum << 16;
            for (index = 0; index < totalPedSubjectNum; index++) {
                vcfID = index << 1;
                //bitNum = pedEncodeGytID[index];
                bitNum = index;
                if (vcfID < 0) {
                    missingNum++;
                    if (alleleNum == 2) {
                        //missing
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;
                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                        bitNum += totalPedSubjectNum;
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;
                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                    } else {
                        v = alleleNum * (alleleNum + 1);
                        v = v >>> 1;
                        for (int i = 0; i < base; i++) {
                            if ((v & GlobalManager.intOpers[32 + i - base]) == GlobalManager.intOpers[32 + i - base]) {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            bitNum += totalPedSubjectNum;
                        }
                    }
                    continue;
                }

                /*
                 missing	Reference homozygous	Heterozygous 	Alternative homozygous
                 VCF genotype		0/0	0/1	1/1 ./.
                 Bits	00  	01	10	11
                 Order	0	1	2	3        
                 */

 /*
                 missing	Reference homozygous	Heterozygous 	Heterozygous	Alternative homozygous	Heterozygous	Alternative homozygous
                 VCF genotype	0/0	0/1	0/2	1/1	1/2	2/2 ./.	
                 Bits	        000	001	010	011	100	101	110
                 Order	0	1	2	3	4	5	6 
                 */
 /*
                 I.III Quad-allelic sequence variant (4 bits)
                 missing 	Reference homozygous 	Heterozygous 	Heterozygous 	Heterozygous 	Alternative homozygous 	Heterozygous
                 VCF genotype 0/0 	0/1 	0/2 	0/3 	1/1 	1/2 		
                 Bits 	      000 	0001 	0010 	0011 	0100 	0101 	0110
                 Decimal 	0 	1 	2 	3 	4 	5 	6
                 Heterozygous 	Alternative homozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype 	1/3 	2/2 	2/3 	3/3 ./. 
                 Bits 	     0111 	1000 	1001 	1010
                 Decimal 	7 	8 	9 	10                               
                 */
                if (gtys[(vcfID)] == -1) {
                    missingNum++;
                    //missing value       
                    if (alleleNum == 2) {
                        //missing
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;
                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                        bitNum += totalPedSubjectNum;
                        byteIndex1 = (bitNum) / gtyLen;
                        byteIndex2 = (bitNum) % gtyLen;

                        var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                    } else {
                        v = alleleNum * (alleleNum + 1);
                        v = v >>> 1;
                        for (int i = 0; i < base; i++) {
                            if ((v & GlobalManager.intOpers[32 + i - base]) == GlobalManager.intOpers[32 + i - base]) {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            bitNum += totalPedSubjectNum;
                        }
                    }
                } else {
                    switch (alleleNum) {
                        case 2:
                            /*
                             missing	Reference homozygous	Heterozygous 	Alternative homozygous
                             VCF genotype	0/0	0/1	1/1 ./.
                             Bits	00  	01	10	11
                             Order	0	1	2	3        
                             */

                            //to speedup the analysis
                            if (gtys[(vcfID)] == 0 && gtys[(vcfID) + 1] == 0) {

                            } else if ((gtys[(vcfID)] == 0 && gtys[(vcfID) + 1] == 1) || (gtys[(vcfID)] == 1 && gtys[(vcfID) + 1] == 0)) {
                                //no blank bits between blocks
                                bitNum += totalPedSubjectNum;
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;

                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                //System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));

                            } else if (gtys[(vcfID)] == 1 && gtys[(vcfID) + 1] == 1) {
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                // System.out.println(Integer.toBinaryString(var.encodedGty[byteIndex1]));                               

                            } else {
                                //missing
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                bitNum += totalPedSubjectNum;
                                byteIndex1 = (bitNum) / gtyLen;
                                byteIndex2 = (bitNum) % gtyLen;
                                var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                            }
                            break;
                        default:
                            if (gtys[(vcfID)] > gtys[(vcfID) + 1]) {
                                s1 = gtys[(vcfID)];
                                gtys[(vcfID)] = gtys[(vcfID) + 1];
                                gtys[(vcfID) + 1] = s1;
                            }
                            //at most 64 alleles
                            bits = GlobalManager.unphasedGtyCodingMap.get(gtys[(vcfID)] | (gtys[(vcfID) + 1] << 8) | (alleleNumShift));
                            for (int i = 0; i < base; i++) {
                                if (bits[i]) {
                                    byteIndex1 = (bitNum) / gtyLen;
                                    byteIndex2 = (bitNum) % gtyLen;
                                    var.encodedGty[byteIndex1] |= GlobalManager.byte1Opers[byteIndex2];
                                }
                                bitNum += totalPedSubjectNum;
                            }
                    }
                }
            }
            //for (int t=0;t<var.encodedGty.length;t++)      System.out.println(String.format("%8s", Integer.toBinaryString(var.encodedGty[t]&0xff )).replace(' ', '0'));
        }

        var.setMissingtyNum(missingNum);
    }

    public static void main(String[] args) {
        try {
            //  byte byteInfo=-128;
            //  System.out.println(BitByteUtil.byteToBinaryString((byte) (byteInfo )));
            //                   System.out.println(BitByteUtil.byteToBinaryString((byte) (byteInfo>>> 2&0X3F)));                             
            List<Individual> indivList = new ArrayList<Individual>();
            BinaryGtyProcessor bgp = new BinaryGtyProcessor("./kggseq");
            bgp.readPedigreeFile(indivList);
            Genome genome = bgp.readVariantsMapFile(null);
            // bgp.readBinaryGenotype(indivList, genome);
            //   genome.export2FlatTextPlink(indivList, "./test");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
