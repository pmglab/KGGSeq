/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.RegressionParams;
import org.cobi.kggseq.entity.Variant;
import org.cobi.util.text.Util;
import org.cobi.util.thread.Task;

/**
 *
 * @author limx54
 */
public class RiskPredictionLogisticTask extends Task implements Callable<String> {

    List<Variant> variantList;
    List<CombOrders> combOrderList;
    List<String> names;
    int geneFeatureNum;
    int bestModelNum;

    //temp parameters
    RegressionParams tmpRP = null;
    RegressionParams bestRP = null;
    List<Integer> paramIndexes = new ArrayList<Integer>();
    Set<Integer> dataIndexes = new HashSet<Integer>();
    double[] priors = new double[]{0.05, 0.01, 0.0001};
    List<Integer> bestPParamIndexes = new ArrayList<Integer>();

    public RiskPredictionLogisticTask(List<CombOrders> combOrderList, int bestModelNum) {
        this.combOrderList = combOrderList;
        this.bestModelNum = bestModelNum;
    }

    public RiskPredictionLogisticTask(List<CombOrders> combOrderList, int bestModelNum, List<String> names, List<Variant> variantList, int geneFeatureNum) {
        this.variantList = variantList;
        this.combOrderList = combOrderList;
        this.names = names;
        this.geneFeatureNum = geneFeatureNum;
        this.bestModelNum = bestModelNum;
    }

    @Override
    public String call() throws Exception {

        double tmpP, bestP, prior;
        StringBuilder tmpStrB = new StringBuilder();
        boolean isDeleteriousness = false;
        int combListSize = combOrderList.size();
        double sum = 0;

      

        for (Variant var : variantList) {
           
            /*
            if (var.smallestFeatureID >= 15)
            {
                var.setFeatureValue(geneFeatureNum, null);
                var.setFeatureValue(geneFeatureNum + 1, null);
                var.setFeatureValue(geneFeatureNum + 2, null);
                continue;
            }
             */
       
            if (var.scores1 != null) {
                dataIndexes.clear();
                for (int j = 0; j < var.scores1.length; j++) {
                    if (!Float.isNaN(var.scores1[j])) {
                        dataIndexes.add(j);
                    }
                }
                if (dataIndexes.isEmpty()) {
                    var.setFeatureValue(geneFeatureNum, ".");
                    var.setFeatureValue(geneFeatureNum + 1, ".");
                    var.setFeatureValue(geneFeatureNum + 2, ".");
                    continue;
                }
                tmpRP = null;
                bestRP = null;
                bestP = 0;
                isDeleteriousness = false;
                tmpStrB.delete(0, tmpStrB.length());

                for (int t = combListSize - 1; t >= combListSize - bestModelNum; t--) {
                    CombOrders cmbOrder = combOrderList.get(t);

                    /*
                         * if
                         * (!testSet.containsAll(combOrderList.get(t).indexes)||
                         * combOrderList.get(t).indexes.size()!=2) { continue; }
                     */
                    paramIndexes.clear();
                    if (dataIndexes.containsAll(cmbOrder.indexes)) {
                        paramIndexes.addAll(cmbOrder.indexes);
                        Collections.sort(paramIndexes);
                        tmpRP = cmbOrder.rp;
                        sum = tmpRP.coef[0];
                        //because of tmpRP.coef[j], paramIndexes must be sorted.
                        for (int j = 1; j < tmpRP.coef.length; j++) {
                            sum += (tmpRP.coef[j] * var.scores1[paramIndexes.get(j - 1)]);
                        }
                        // calculate the conditional probablity with MAF
                        // if (Float.isNaN(var.altAF) || var.altAF <= 0.01)
                        {
                            prior = ((1 - priors[0]) / priors[0]) * tmpRP.sampleCase2CtrRatio;
                            tmpP = 1 + prior * Math.exp(-sum);
                            tmpP = 1 / tmpP;
                        }
                        /*
                             * else if (var.altAF <= 0.03) { prior = ((1 -
                             * priors[1]) / priors[1]) *
                             * tmpRP.sampleCase2CtrRatio; tmpP = 1 + prior *
                             * Math.exp(-sum); tmpP = 1 / tmpP; } else { tmpP =
                             * 0; }
                         */

                        if (bestP <= tmpP) {
                            bestP = tmpP;
                            bestRP = tmpRP;
                            bestPParamIndexes.clear();
                            bestPParamIndexes.addAll(combOrderList.get(t).indexes);
                            Collections.sort(bestPParamIndexes);
                            if (tmpP >= tmpRP.optimalCutoff) {
                                isDeleteriousness = true;
                            }
                        }

                        /*
                        if (tmpP >= tmpRP.optimalCutoff) {
                            var.setFeatureValue(geneFeatureNum, String.valueOf(tmpP));
                            var.setFeatureValue(geneFeatureNum + 1, "Y");
                            for (Integer ind : paramIndexes) {
                                tmpStrB.append(names.get(ind));
                                tmpStrB.append(';');
                            }
                            tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.optimalCutoff, 4));
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.truePositiveRate, 3));
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.trueNegativeRate, 3));
                            var.setFeatureValue(geneFeatureNum + 2, tmpStrB.toString());

                            isDeleteriousness = true;
                            //try to achieve the best score
                            break;
                        }
                         */
                    }
                }

                if (!isDeleteriousness) {
                    if (tmpRP == null) {
                        // keep varaint have no risk scores which may be
                        // safer
                        var.setFeatureValue(geneFeatureNum, ".");
                        var.setFeatureValue(geneFeatureNum + 1, ".");
                        var.setFeatureValue(geneFeatureNum + 2, ".");
                    } else {
                        var.setFeatureValue(geneFeatureNum, String.valueOf(bestP));
                        var.setFeatureValue(geneFeatureNum + 1, "N");
                        if (!bestPParamIndexes.isEmpty()) {
                            for (Integer ind : bestPParamIndexes) {
                                tmpStrB.append(names.get(ind));
                                tmpStrB.append(';');
                            }
                            tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                        }
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.optimalCutoff, 4));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.truePositiveRate, 3));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.trueNegativeRate, 3));
                        var.setFeatureValue(geneFeatureNum + 2, tmpStrB.toString());

                    }
                } else {
                    tmpStrB.delete(0, tmpStrB.length());

                    var.setFeatureValue(geneFeatureNum, String.valueOf(bestP));

                    if (bestP >= bestRP.optimalCutoff) {
                        var.setFeatureValue(geneFeatureNum + 1, "Y");
                    } else {
                        var.setFeatureValue(geneFeatureNum + 1, "N");
                    }
                    for (Integer ind : bestPParamIndexes) {
                        tmpStrB.append(names.get(ind));
                        tmpStrB.append(';');
                    }
                    tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                    tmpStrB.append(':');
                    tmpStrB.append(Util.doubleToString(bestRP.optimalCutoff, 4));
                    tmpStrB.append(':');
                    tmpStrB.append(Util.doubleToString(bestRP.truePositiveRate, 3));
                    tmpStrB.append(':');
                    tmpStrB.append(Util.doubleToString(bestRP.trueNegativeRate, 3));
                    var.setFeatureValue(geneFeatureNum + 2, tmpStrB.toString());

                    //try to achieve the best score
                }
            } else {
                // keep varaint have no risk scores which may be safer 
                var.setFeatureValue(geneFeatureNum, ".");
                var.setFeatureValue(geneFeatureNum + 1, ".");
                var.setFeatureValue(geneFeatureNum + 2, ".");
            }
        }
        return "";
    }

    public double predictByBestModels(List<CombOrders> combOrderList, float[] scores1) {
        int combListSize = combOrderList.size();
        double tmpP, bestP, prior, sum;
        tmpRP = null;
        bestRP = null;
        bestP = 0;
        dataIndexes.clear();
        for (int j = 0; j < scores1.length; j++) {
            if (!Float.isNaN(scores1[j])) {
                dataIndexes.add(j);
            }
        }

        for (int t = combListSize - 1; t >= combListSize - bestModelNum; t--) {
            CombOrders cmbOrder = combOrderList.get(t);
            paramIndexes.clear();
            if (dataIndexes.containsAll(cmbOrder.indexes)) {
                paramIndexes.addAll(cmbOrder.indexes);
                Collections.sort(paramIndexes);
                tmpRP = cmbOrder.rp;
                sum = tmpRP.coef[0];
                for (int j = 1; j < tmpRP.coef.length; j++) {
                    sum += (tmpRP.coef[j] * scores1[paramIndexes.get(j - 1)]);
                }
                // calculate the conditional probablity with MAF
                // if (Float.isNaN(var.altAF) || var.altAF <= 0.01)
                {
                    prior = ((1 - priors[0]) / priors[0]) * tmpRP.sampleCase2CtrRatio;
                    tmpP = 1 + prior * Math.exp(-sum);
                    tmpP = 1 / tmpP;
                }

                if (bestP <= tmpP) {
                    bestP = tmpP;
                    bestRP = tmpRP;
                    bestPParamIndexes.clear();
                    bestPParamIndexes.addAll(combOrderList.get(t).indexes);
                    Collections.sort(bestPParamIndexes);
                }

            }
        }
        return bestP;
    }

}
