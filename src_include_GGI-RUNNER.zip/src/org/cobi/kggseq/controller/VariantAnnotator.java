/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.BooleanArrayList;
import cern.colt.list.DoubleArrayList;
import cern.colt.list.FloatArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import cern.colt.map.OpenLongObjectHashMap;
import cern.jet.stat.Descriptive;
import cern.jet.stat.Probability;
import edu.sysu.pmglab.ccf.CCFFilter;
import edu.sysu.pmglab.ccf.CCFReader;
import edu.sysu.pmglab.ccf.CCFTable;
import edu.sysu.pmglab.ccf.FieldFilter;
import edu.sysu.pmglab.container.array.BaseArray;
import edu.sysu.pmglab.container.array.StringArray;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.zip.GZIPInputStream;
import javax.swing.tree.DefaultMutableTreeNode;
import org.apache.log4j.Logger;
import org.apache.poi.ss.formula.functions.T;
import org.cobi.bayes.Bayes;
import org.cobi.kggseq.Constants;
import org.cobi.kggseq.GlobalManager;
import org.cobi.kggseq.entity.*;
import org.cobi.randomforests.MyRandomForest;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.net.NCBIRetriever;
import org.cobi.util.stat.*;
import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.text.LocalFile;
import org.cobi.util.text.StringArrayStringComparator;
import org.cobi.util.text.Util;
import org.cobi.util.thread.Task;

import javax.swing.tree.DefaultMutableTreeNode;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.zip.GZIPInputStream;

/**
 * @author mxli
 */
public class VariantAnnotator implements Constants {

    private static final Logger LOG = Logger.getLogger(VariantAnnotator.class);
    private int indexChrom = 0;
    private int indexPosition = 1;
    private int indexREF = 2;
    private int indexALT = 3;
    Map<String, Integer> chromNameIndexMap = new HashMap<String, Integer>();
    List<String> pubMedFilter;
    Map<String, Byte> geneFeatureMap = new HashMap<String, Byte>();
    BinaryGtyProcessor bgp = new BinaryGtyProcessor();

    public VariantAnnotator() {
        for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
            chromNameIndexMap.put(STAND_CHROM_NAMES[i], i);
            //variantPositionIndexMap[t] = new OpenIntIntHashMap();
        }
        for (int i = 0; i < VAR_FEATURE_NAMES.length; i++) {
            geneFeatureMap.put(VAR_FEATURE_NAMES[i], (byte) i);
        }
        pubMedFilter = new ArrayList<String>();
        pubMedFilter.add("gene");
        pubMedFilter.add("genes");
        pubMedFilter.add("mRNA");
        pubMedFilter.add("protein");
        pubMedFilter.add("proteins");
        pubMedFilter.add("transcription");
        pubMedFilter.add("transcript");
        pubMedFilter.add("transcripts");
        pubMedFilter.add("expressed");
        pubMedFilter.add("expression");
        pubMedFilter.add("expressions");
        pubMedFilter.add("locus");
        pubMedFilter.add("loci");
        pubMedFilter.add("SNP");
    }

    public Map<String, String[]> readGeneNames(String dbPath) throws Exception {
        List<String[]> geneItems = new ArrayList<String[]>();
        int[] indices = new int[3];
        /*
         * indices[0] = 1;//Approved\tSymbol indices[1] = 2;//Approved Name
         * indices[2] = 4;//Previous Symbols // indices[3] = 5; //Synonyms
         * indices[3] = 7; //Accession Numbers indices[4] = 8; //RefSeq IDs
         */

        indices[0] = 1;// Approved\tSymbol
        indices[1] = 7;// Approved Name
        indices[2] = 8;// Previous Symbols
        // indices[3] = 5; //Synonyms
        // indices[3] = 7; //Accession Numbers
        // indices[4] = 8; //RefSeq IDs

        LocalFile.retrieveData(dbPath, geneItems, indices, "\t");
        Map<String, String[]> geneSymMap = new HashMap<String, String[]>();
        List<String> tempList = new ArrayList<String>();

        for (String[] item : geneItems) {
            // ignore the full name of genes
            // tempList.add(item[1]);
            for (int i = 2; i < item.length; i++) {
                if (item[i].trim().isEmpty()) {
                    continue;
                }
                String[] cells = item[i].split(",");
                for (int t = 0; t < cells.length; t++) {
                    tempList.add(cells[t].trim());
                }
            }
            geneSymMap.put(item[0], tempList.toArray(new String[tempList.size()]));
            tempList.clear();
        }
        return geneSymMap;
    }

    //put this function in stack to speed up the parsing
    private void tokenize(String string, char delimiter, int maxIndex, String[] temp) {
        int wordCount = 0;
        int i = 0;
        int j = string.indexOf(delimiter);

        while (j >= 0) {
            temp[wordCount] = string.substring(i, j);
            if (wordCount >= maxIndex) {
                wordCount++;
                break;
            }
            wordCount++;
            i = j + 1;
            j = string.indexOf(delimiter, i);

        }
        if (wordCount <= maxIndex) {
            if (i < string.length()) {
                temp[wordCount++] = string.substring(i);
            }
        }
    }

    private int tokenize(String string, char delimiter, String[] temp) {
        int wordCount = 0;
        int i = 0;
        int j = string.indexOf(delimiter);

        while (j >= 0) {
            temp[wordCount++] = string.substring(i, j);
            i = j + 1;
            j = string.indexOf(delimiter, i);
        }

        if (i < string.length()) {
            temp[wordCount++] = string.substring(i);
        }
        return wordCount;
    }

    public void readExonicScoreNSFPNucleotideMerge(Chromosome chromosome, String resourcePath, String refGenomeVer,
            int[] scoreIndexes, int[] predicIndex, FiltrationSummarySet ass, boolean needProgressionIndicator) {
        int indexPos = 0;
        int indexref = 1;
        int indexalt = 2;
        int indexaaref = 6;
        int indexaaalt = 7;

        int maxColNum = indexPos;
        maxColNum = Math.max(maxColNum, indexPos);
        maxColNum = Math.max(maxColNum, indexref);
        maxColNum = Math.max(maxColNum, indexalt);
        int varFeatureNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        // String currChr = null;
        int currFilePostion = 0;

        char ref, alt;

        float[] scores = new float[scoreIndexes.length];
        String[] predicResults = new String[predicIndex.length];
        String missingLabel = ".";
        StringBuilder tmpBuffer = new StringBuilder();
        Variant[] vars = null;
        long lineCounter = 0;
        int varAssignedScore = 0;

        // for development of new method
        DoubleArrayList[] scoreLists = new DoubleArrayList[5];
        for (int i = 0; i < scoreLists.length; i++) {
            scoreLists[i] = new DoubleArrayList();
        }
        boolean fullMatch;

        // int varFeatureNum = genome.getVariantFeatureLabels().size();
        File rsFile = null;
        int unmatchedNum = 0;
        try {
            String chrName = chromosome.getName();
            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            rsFile = new File(resourcePath + chrName + ".gz");
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.print(" Chromosome " +
            // Options.REF_CHROM_NAMES[t]);

            BufferedReader br = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());

            lineCounter++;
            // skip to the head line
            currentLine = br.readLine();
            String[] cells = Util.tokenize(currentLine, '\t', maxColNum);
            String[] fullCells = Util.tokenize(currentLine, '\t');

            String[] tmpStrs;

            boolean hasNoScore;

            int varIndex = 0;
            // ensure all dependentVariants are sorted according to the
            // refStartPosition; otherwise itwil get stucked.
            Variant var = null;
            int varListSize = chromosome.variantList.size();
            int varPos = -1;
            boolean needNewRow = true;

            int varIndex1 = 0;
            int varPos1 = 0;
            var = chromosome.variantList.get(varIndex);
            varPos = var.refStartPosition;

            while (varIndex < varListSize) {
                // System.out.println(currentLine);
                if (needNewRow) {
                    // StringTokenizer st = new
                    // StringTokenizer(currentLine.trim(), "\t");
                    currentLine = br.readLine();
                    if (currentLine == null) {
                        break;
                    }
                    tokenize(currentLine, '\t', maxColNum, cells);
                    if (cells[indexPos].equals(missingLabel)) {
                        currFilePostion = -1;
                        continue;
                    } else {
                        currFilePostion = Util.parseInt(cells[indexPos]);
                    }
                    lineCounter++;
                    if (needProgressionIndicator && lineCounter % 50000 == 0) {
                        String prog = String.valueOf(lineCounter);
                        System.out.print(prog);
                        char[] backSpaces = new char[prog.length()];
                        Arrays.fill(backSpaces, '\b');
                        System.out.print(backSpaces);
                    }
                    needNewRow = false;
                }

                if (varPos > currFilePostion) {
                    needNewRow = true;
                    continue;
                } else if (varPos < currFilePostion) {
                    varIndex++;
                    if (varIndex >= varListSize) {
                        break;
                    }
                    var = chromosome.variantList.get(varIndex);
                    varPos = var.refStartPosition;
                    continue;
                }

                //ingore indel
                if (var.isIndel) {
                    varIndex++;
                    if (varIndex >= varListSize) {
                        break;
                    }
                    var = chromosome.variantList.get(varIndex);
                    varPos = var.refStartPosition;
                    continue;
                }

                // in the variant genome, there is only one unique variant
                varIndex1 = varIndex;

                //this alogrithm does not work for indels
                //it must be equal and there may be multiple positions equal
                ref = cells[indexref].charAt(0);
                alt = cells[indexalt].charAt(0);
                unmatchedNum = 0;
                //The list may have dependentVariants with the same coordinates 
                do {
                    var = chromosome.variantList.get(varIndex1);
                    varPos1 = var.refStartPosition;

                    if (varPos1 > currFilePostion) {
                        break;
                    }
                    fullMatch = false;
                    String[] altAlleles = var.getAltAlleles();
                    for (String altA : altAlleles) {
                        if (altA == null) {
                            continue;
                        }
                        // assum there is ony one alternative allele Note
                        // the second condition is not safe
                        if (var.getRefAllele().charAt(0) == ref && altA.charAt(0) == alt
                                || var.getRefAllele().charAt(0) == alt && altA.charAt(0) == ref) {
                            fullMatch = true;
                            break;
                        }
                    }
                    if (fullMatch && var.scores1 == null) {
                        tokenize(currentLine, '\t', fullCells);
                        Arrays.fill(scores, Float.NaN);
                        Arrays.fill(predicResults, null);

                        for (int iCol = 0; iCol < scoreIndexes.length; iCol++) {
                            if (fullCells[scoreIndexes[iCol]].equals(missingLabel)) {

                                scores[iCol] = Float.NaN;
                            } else if (!fullCells[scoreIndexes[iCol]].contains(";")) {
                                scores[iCol] = Util.parseFloat(fullCells[scoreIndexes[iCol]]);
                            } else {
                                // just use the first one
                                // System.out.println(tmpBuffer.toString());
                                tmpStrs = fullCells[scoreIndexes[iCol]].split(";");
                                hasNoScore = true;
                                for (String tmpStr : tmpStrs) {
                                    if (!tmpStr.equals(missingLabel)) {
                                        scores[iCol] = Util.parseFloat(tmpStr);
                                        hasNoScore = false;
                                        break;
                                    }
                                }
                                if (hasNoScore) {
                                    scores[iCol] = Float.NaN;
                                }
                            }
                        }
                        for (int iCol = 0; iCol < predicIndex.length; iCol++) {
                            if (fullCells[predicIndex[iCol]].equals(missingLabel)) {

                                predicResults[iCol] = ".";
                            } else {

                                predicResults[iCol] = fullCells[predicIndex[iCol]];
                            }
                        }
                        var.scores1 = new float[scores.length];
                        System.arraycopy(scores, 0, var.scores1, 0, scores.length);
                        varAssignedScore++;
                        for (int k = 0; k < predicIndex.length; k++) {
                            var.setFeatureValue(varFeatureNum + k, predicResults[k]);
                        }

                    } else {
                        unmatchedNum++;
                    }
                    varIndex1++;
                } while (varIndex1 < varListSize);
//The same coordinate but unmatched
                if (unmatchedNum == 0) {
                    varIndex++;
                    if (varIndex >= varListSize) {
                        break;
                    }
                    var = chromosome.variantList.get(varIndex);
                    varPos = var.refStartPosition;
                }
                //otherwise only move file's index
                needNewRow = true;
            }
            br.close();
            ass.increaseCount(0, varAssignedScore);
            for (Variant var1 : chromosome.variantList) {
                if (var1.scores1 == null) {

                    var1.scores1 = new float[scores.length];
                    Arrays.fill(var1.scores1, Float.NaN);
                    for (int k = 0; k < predicResults.length; k++) {
                        var1.setFeatureValue(varFeatureNum + k, null);
                    }
                }
            }

        } catch (Exception e) {
            LOG.error("Exception at line \"" + currentLine + "\" of file " + rsFile.getName());
            e.printStackTrace();
        }
    }

    public void readExonicScoreNSFPNucleotideMergeMultiThread(Chromosome chromosome, String resourcePath, String refGenomeVer,
            int[] scoreIndexes, int[] predicIndex, FiltrationSummarySet ass, boolean needProgressionIndicator, int threadNum) {
        int indexPos = 0;
        int indexref = 1;
        int indexalt = 2;
        int indexaaref = 6;
        int indexaaalt = 7;

        int maxColNum = indexPos;
        maxColNum = Math.max(maxColNum, indexPos);
        maxColNum = Math.max(maxColNum, indexref);
        maxColNum = Math.max(maxColNum, indexalt);
        int varFeatureNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        // String currChr = null;
        int currFilePostion = 0;

        char ref, alt;

        float[] scores = new float[scoreIndexes.length];
        String[] predicResults = new String[predicIndex.length];
        String missingLabel = ".";
        StringBuilder tmpBuffer = new StringBuilder();
        Variant[] vars = null;
        long lineCounter = 0;
        int varAssignedScore = 0;

        // for development of new method
        DoubleArrayList[] scoreLists = new DoubleArrayList[5];
        for (int i = 0; i < scoreLists.length; i++) {
            scoreLists[i] = new DoubleArrayList();
        }
        boolean fullMatch;

        // int varFeatureNum = genome.getVariantFeatureLabels().size();
        File rsFile = null;
        int unmatchedNum = 0;
        try {
            String chrName = chromosome.getName();
            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            rsFile = new File(resourcePath + chrName + ".gz");
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.print(" Chromosome " +
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), -1, 0, true);
            }

            bfIndexes.readIndex(false, null);
            int indexCHROM = -1, indexPOS = 0;
            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;
            boolean hasHead = true;

            for (int f = 1; f < bounderies.length; f++) {
                long[] pos = null;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);
                }
                if (pos[0] == pos[1]) {
                    for (int t = bounderies[f - 1]; t <= bounderies[f] - 1; t++) {
                        for (int s = 0; s < predicIndex.length; s++) {
                            chromosome.variantList.get(t).setFeatureValue(varFeatureNum + s, ".");
                        }
                        chromosome.variantList.get(t).scores1 = new float[scores.length];
                        Arrays.fill(chromosome.variantList.get(t).scores1, Float.NaN);
                    }
                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                bf.adjustPos(pos[0], pos[1]);
                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }
                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], chromosome.variantList.subList(bounderies[f - 1], bounderies[f]), indexCHROM, indexPOS, predicIndex, scoreIndexes, ass, 0) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                serv.submit(varTaks);
                runningThread++;
            }
            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

            ass.increaseCount(0, varAssignedScore);
            for (Variant var1 : chromosome.variantList) {
                if (var1.scores1 == null) {
                    var1.scores1 = new float[scores.length];
                    Arrays.fill(var1.scores1, Float.NaN);
                    for (int k = 0; k < predicResults.length; k++) {
                        var1.setFeatureValue(varFeatureNum + k, null);
                    }
                }
            }

        } catch (Exception e) {
            LOG.error("Exception at line \"" + currentLine + "\" of file " + rsFile.getName());
            e.printStackTrace();
        }
    }

    public void readPextScoreSNVFilterMultiThread(Chromosome chromosome, String resourcePath, String refGenomeVer,
            int[] scoreIndexes, String[] scoreNames, AnnotationSummarySet ass, double pextCut, int threadNum) {

        int indexCHROM = 0, indexPOS = 1;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        try {
            int lineCounter = 0;

            int existVarNum = 0;

            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            File rsFile = new File(resourcePath);
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            //int[] ids= chromosome.lookupVariantIndexes(15462758);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            boolean hasHead = true;
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), 0, 1, hasHead);
            }
            //the index file has no head generally.
            bfIndexes.readIndex(false, chromName);

            //No matched SNPs means null 
            String missingVal = ".";
            for (Variant var : chromosome.variantList) {
                for (int i = 0; i < scoreIndexes.length; i++) {
                    var.setFeatureValue(feautreNum + i, missingVal);
                }
                var.hasBeenAcced = false;
            }

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;

            for (int f = 1; f < bounderies.length; f++) {
                long[] pos;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);
                }
                // System.out.println(pos[0]+"\t"+pos[1]);
                if (pos[0] == pos[1]) {
                    for (int t = bounderies[f - 1]; t <= bounderies[f] - 1; t++) {
                        for (int i = 0; i < scoreIndexes.length; i++) {
                            chromosome.variantList.get(t).setFeatureValue(feautreNum + 1, ".");
                        }
                    }
                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                bf.adjustPos(pos[0], pos[1]);

                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }

                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], indexCHROM, indexPOS, chromosome, ass, 4) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                varTaks.setCurrChr(chromName.getBytes());
                varTaks.setPredicColIndexes(scoreIndexes);
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

            int hitNum = 0;
            List<Variant> tmpVariantList = new ArrayList<Variant>();

            if (pextCut > 0) {
                int len1 = chromosome.variantList.size();
                int expCount = 0;
                String sVal;
                for (int j = 0; j < len1; j++) {
                    Variant var = chromosome.variantList.get(j);

                    expCount = 0;
                    for (int i = 0; i < scoreIndexes.length; i++) {
                        sVal = var.getFeatureValues()[feautreNum + i];
                        if (sVal != null && !sVal.equals(".")) {
                            if (Double.parseDouble(sVal) >= pextCut) {
                                expCount++;
                            }
                        }
                    }
                    if (expCount > 0) {
                        tmpVariantList.add(var);
                    } else {
                        hitNum++;
                    }

                }

                ass.setLeftNum(ass.getLeftNum() + tmpVariantList.size());

                chromosome.variantList.clear();
                chromosome.variantList.addAll(tmpVariantList);
                tmpVariantList.clear();
                chromosome.buildVariantIndexMap();
            }
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }

    }

    public void readCustomizedScoreSNVFilterMultiThread(Chromosome chromosome, String resourcePath,
            int[] scoreIndexes, AnnotationSummarySet ass, double scoreCut, int threadNum) {

        int indexCHROM = 0, indexPOS = 1;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        try {
            int lineCounter = 0;

            int existVarNum = 0;

            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            File rsFile = new File(resourcePath);
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            boolean isGZ = rsFile.getName().endsWith(".gz");
            boolean hasHead = true;
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, isGZ);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), 0, 1, hasHead);
            }
            bfIndexes.readIndex(false, chromName);

            //No matched SNPs means null 
            String missingVal = ".";
            for (Variant var : chromosome.variantList) {
                for (int i = 0; i < scoreIndexes.length; i++) {
                    var.setFeatureValue(feautreNum + i, missingVal);
                }
                var.hasBeenAcced = false;
            }

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;

            for (int f = 1; f < bounderies.length; f++) {
                long[] pos;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);
                }
                // System.out.println(pos[0]+"\t"+pos[1]);
                if (pos[0] == pos[1]) {
                    for (int t = bounderies[f - 1]; t <= bounderies[f] - 1; t++) {
                        for (int i = 0; i < scoreIndexes.length; i++) {
                            chromosome.variantList.get(t).setFeatureValue(feautreNum + 1, ".");
                        }
                    }
                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                bf.adjustPos(pos[0], pos[1]);

                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }
                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], indexCHROM, indexPOS, chromosome, ass, 3) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                varTaks.setCurrChr(chromName.getBytes());
                varTaks.setAltFreqColIndexes(scoreIndexes);
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

            int hitNum = 0;
            List<Variant> tmpVariantList = new ArrayList<Variant>();

            // if (scoreCut > 0)
            {
                int len1 = chromosome.variantList.size();
                int expCount = 0;
                String sVal;
                for (int j = 0; j < len1; j++) {
                    Variant var = chromosome.variantList.get(j);

                    expCount = 0;
                    for (int i = 0; i < scoreIndexes.length; i++) {
                        sVal = var.getFeatureValues()[feautreNum + i];
                        if (sVal != null && !sVal.equals(".")) {
                            if (Double.parseDouble(sVal) >= scoreCut) {
                                expCount++;
                            }
                        }
                    }
                    if (expCount > 0) {
                        //  tmpVariantList.add(var);
                        hitNum++;
                    } else {
                        //   hitNum++;
                    }

                }

                ass.setLeftNum(ass.getLeftNum() + hitNum);

//                chromosome.variantList.clear();
//                chromosome.variantList.addAll(tmpVariantList);
//                tmpVariantList.clear();
//                chromosome.buildVariantIndexMap();
            }
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }

    }

    //Important comments: Acually, the postitions of dependentVariants cannot be retreived by a positions because 1) a variant may be splitted into multiple ones according
    //to their alternative alleles and 2) the flexible annotation of Indels. This the the reason why we cannot use merged searching alogrithm to speeed up (Sadly!).
    //The good news is that there is a very fast hashmap OpenIntIntHashMap from Colt and I used it
    public int hardFilterByANNOVARefFormat(Chromosome chromosome, int chrID, AnnotationSummarySet ass, boolean needProgressionIndicator) {
        indexChrom = 0;
        indexPosition = 1;
        indexREF = 2;
        indexALT = 3;
        List<Variant> varList = chromosome.variantList;
        BufferedReader br = ass.getBr();
        StringBuilder newLine = ass.getLastLine();

        //No matched SNPs means null 
        //This is much faster than Set<Integer> 
        OpenIntIntHashMap excludeIndexes = new OpenIntIntHashMap();
        String currentLine = null;
        try {
            int maxColNum = indexChrom;
            maxColNum = Math.max(maxColNum, indexPosition);
            maxColNum = Math.max(maxColNum, indexREF);
            maxColNum = Math.max(maxColNum, indexALT);

            int lineCounter = 0;
            boolean incomplete = true;

            int filePosition = -1;
            StringBuilder tmpBuffer = new StringBuilder();
            String ref;
            String alt;
            String mafStr = null;

            String[] alts;
            //  String[] mafStrs;
            int[] varIndexes = null;
            boolean isDeleion = false;
            boolean isInsertion = false;

            char[] backSpaces = null;
            int delNum = 0;
            StringBuilder sb = new StringBuilder();

            String[] cells = null;
            if (newLine.length() == 0) {
                currentLine = br.readLine();
                if (currentLine == null) {
                    return 0;
                }
            } else {
                currentLine = newLine.toString();
                newLine.delete(0, newLine.length());
            }
            int fileChrID = 0;
            do {
                /*
                 if (currentLine.indexOf("BP") >= 0 || currentLine.indexOf("bp") >= 0) {
                 continue;
                 }
                 */
                lineCounter++;
                if (needProgressionIndicator && lineCounter % 50000 == 0) {
                    String prog = String.valueOf(lineCounter);
                    System.out.print(prog);
                    backSpaces = new char[prog.length()];
                    Arrays.fill(backSpaces, '\b');
                    System.out.print(backSpaces);
                }

                //StringTokenizer st = new StringTokenizer(currentLine.trim());
                cells = Util.tokenize(currentLine, '\t');
                if (cells.length < 2) {
                    cells = Util.tokenizeIngoreConsec(currentLine, ' ');
                }

                fileChrID = chromNameIndexMap.get(cells[indexChrom]);
                if (chrID < fileChrID) {
                    newLine.append(currentLine);
                    break;
                } else if (chrID > fileChrID) {
                    continue;
                }

                filePosition = Util.parseInt(cells[indexPosition]);
                //initialize varaibles
                incomplete = true;
                ref = cells[indexREF];
                alt = cells[indexALT];

                alts = alt.split(",");
                int tmpPos = 0;

                //once the variant is in db, it at least has a zero freq
                for (int s = 0; s < alts.length; s++) {
                    if (alts[s] == null || alts[s].isEmpty()) {
                        continue;
                    }

                    isDeleion = false;
                    isInsertion = false;
                    tmpPos = filePosition;
                    alt = alts[s];
                    //deletion
                    //format:1	45113	-	0TATGG	0.715732
///1	53599	CTA	3	0.890916
//1	223450	CT	1	0.207385
                    //1	229450	C	T,G	0.207385,0.1
                    //1	229450	C	T,G	0.207385,
                    if (alt.charAt(0) == '0') {
                        isInsertion = true;
                    } else if (alt.charAt(0) - '0' <= 9 && alt.charAt(0) - '0' > 0) {
                        isDeleion = true;
                        tmpPos--;
                    }

                    varIndexes = chromosome.lookupVariantIndexes(tmpPos);
                    if (varIndexes == null) {
                        continue;
                    }

                    // System.out.println(fileChr);

                    /*
                     if (chrID == null) {
                     //System.out.println("Unrecognized chromosome name: " + fileChr + " at line " + lineCounter + ": " + currentLine);
                     } else {
                     }
                     * 
                     */
                    for (int index : varIndexes) {
                        Variant var = varList.get(index);
                        if (isDeleion || isInsertion) {
                            if (var.isIndel) {
                                String varRef = var.getRefAllele();
                                String[] altAlleles = var.getAltAlleles();
                                //keep dependentVariants with score less than minAlleleFreq
                                for (String varAlt : altAlleles) {
                                    //insertion in 1KG
                                    if (isInsertion) {
                                        if (varAlt.substring(1).equals(alt.substring(1))) {
                                            //record the maximal allele frequencies 
                                            excludeIndexes.put(index, 0);
                                            break;
                                        }
                                    } else if (alt.charAt(0) != '0') {
                                        //deletion in 1KG
                                        sb.delete(0, sb.length());
                                        for (int t = 0; t < varAlt.length(); t++) {
                                            if (varAlt.charAt(t) == '-') {
                                                sb.append(varRef.charAt(t));
                                            }
                                        }

                                        delNum = Util.parseInt(alt);
                                        if (sb.toString().equals(ref.substring(ref.length() - delNum))) {
                                            excludeIndexes.put(index, 0);
                                            break;
                                        }
                                    }
                                }
                            } else {
                                continue;
                            }
                        } else if (var.isIndel) {
                            continue;
                        } else {
                            String[] altAlleles = var.getAltAlleles();
                            for (String str : altAlleles) {
                                if (str.charAt(0) == alt.charAt(0)) {
                                    excludeIndexes.put(index, 0);
                                    break;
                                }
                            }
                        }
                    }
                }
            } while ((currentLine = br.readLine()) != null);

            int leftVarNum = varList.size();
            List<Variant> tmpVariantList = new ArrayList<Variant>();
            for (int j = 0; j < leftVarNum; j++) {
                if (!excludeIndexes.containsKey(j)) {
                    tmpVariantList.add(varList.get(j));
                }
            }
            ass.setAnnotNum(excludeIndexes.size() + ass.getAnnotNum());

            varList.clear();
            varList.addAll(tmpVariantList);
            tmpVariantList.clear();
            leftVarNum = varList.size();
            ass.setLeftNum(leftVarNum + ass.getLeftNum());

            ass.setTotalNum(lineCounter + ass.getTotalNum());
            // String info = leftVarNum + " variant(s) are retained after hard filtering in database " + dbName + "!";
            //   LOG.info(info);
            if (needProgressionIndicator) {
                backSpaces = new char[7];
                Arrays.fill(backSpaces, '\b');
                System.out.print(backSpaces);
            }

            return leftVarNum;
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
        return 0;
    }

    private void tokenizeIngoreConsec(String string, char delimiter, String[] temp) {
        int wordCount = 0;
        int i = 0;
        int j = string.indexOf(delimiter);

        while (j >= 0) {
            if (i < j) {
                temp[wordCount++] = string.substring(i, j);
            }
            i = j + 1;
            j = string.indexOf(delimiter, i);
        }

        if (i < string.length()) {
            temp[wordCount++] = string.substring(i);
        }
    }

    public void markByANNOVARefFormat(Chromosome chromosome, int chrID, AnnotationSummarySet ass, boolean needProgressionIndicator) {
        indexChrom = 0;
        indexPosition = 1;
        indexREF = 2;
        indexALT = 3;
        int indexMAF = 4;
        List<Variant> varList = chromosome.variantList;
        BufferedReader br = ass.getBr();
        StringBuilder newLine = ass.getLastLine();

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = ass.getAvailableFeatureIndex();

        //No matched SNPs means null 
        String missingVal = "N";
        for (Variant var : varList) {
            var.setFeatureValue(feautreNum, missingVal);
        }
        String currentLine = null;
        try {
            String varChrom = chromosome.getName();
            int maxColNum = indexChrom;
            maxColNum = Math.max(maxColNum, indexPosition);
            maxColNum = Math.max(maxColNum, indexREF);
            maxColNum = Math.max(maxColNum, indexALT);
            maxColNum = Math.max(maxColNum, indexMAF);

            int lineCounter = 0;

            int filePosition = -1;
            StringBuilder tmpBuffer = new StringBuilder();
            String ref;
            String alt;
            String mafStr = null;
            float maf;
            String[] alts;
            String[] mafStrs;
            int[] varIndex = null;
            boolean isDeleion = false;
            boolean isInsertion = false;

            /*
             File CHAIN_FILE = new File("./resources/hg19ToHg18.over.chain");
             LiftOver liftOver = new LiftOver(CHAIN_FILE);
             int failtedMapVarNum = 0;
             * 
             */
            char[] backSpaces = null;
            int delNum = 0;
            int existVarNum = 0;
            StringBuilder sb = new StringBuilder();
            boolean hitOnce = false;

            String[] cells = null;
            if (newLine.length() == 0) {
                currentLine = br.readLine();
                if (currentLine == null) {
                    return;
                }
            } else {
                currentLine = newLine.toString();
                newLine.delete(0, newLine.length());
            }
            int fileChrID;
            //get the column of a row
            cells = Util.tokenize(currentLine, '\t');
            boolean ingoreConsec = false;
            if (cells.length < 2) {
                cells = Util.tokenizeIngoreConsec(currentLine, ' ');
                ingoreConsec = true;
            }
            do {
                /*
                 if (currentLine.indexOf("BP") >= 0 || currentLine.indexOf("bp") >= 0) {
                 continue;
                 }*/
                lineCounter++;
                if (needProgressionIndicator && lineCounter % 50000 == 0) {
                    String prog = String.valueOf(lineCounter);
                    System.out.print(prog);
                    backSpaces = new char[prog.length()];
                    Arrays.fill(backSpaces, '\b');
                    System.out.print(backSpaces);
                }

                //StringTokenizer st = new StringTokenizer(currentLine.trim());
                if (ingoreConsec) {
                    tokenizeIngoreConsec(currentLine, ' ', cells);
                } else {
                    tokenize(currentLine, '\t', cells);
                }

                //initialize varaibles
                mafStrs = null;

                fileChrID = chromNameIndexMap.get(cells[indexChrom]);
                if (chrID < fileChrID) {
                    newLine.append(currentLine);
                    break;
                } else if (chrID > fileChrID) {
                    continue;
                }
                filePosition = Util.parseInt(cells[indexPosition]);
                ref = cells[indexREF];
                alt = cells[indexALT];
                if (cells.length > indexMAF) {
                    mafStr = cells[indexMAF];
                }

                alts = alt.split(",");
                if (mafStr != null) {
                    mafStrs = mafStr.split(",", -1);
                }

                //  System.err.println(currentLine);
                hitOnce = false;
                int tmpPos = 0;
                //once the variant is in db, it at least has a zero freq
                for (int s = 0; s < alts.length; s++) {
                    if (alts[s] == null || alts[s].isEmpty()) {
                        continue;
                    }
                    maf = Float.NaN;
                    if (mafStrs != null && s < mafStrs.length) {
                        //this missing score is denoted by .
                        if (mafStrs[s] != null && !mafStrs[s].isEmpty() && !mafStrs[s].equals(".")) {
                            maf = Util.parseFloat(mafStrs[s]);
                        }
                    }
                    tmpPos = filePosition;
                    isDeleion = false;
                    isInsertion = false;

                    alt = alts[s];
                    //deletion
                    //format:1	45113	-	0TATGG	0.715732
///1	53599	CTA	3	0.890916
//1	223450	CT	1	0.207385
                    //1	229450	C	T,G	0.207385,0.1
                    //1	229450	C	T,G	0.207385,

                    if (alt.charAt(0) == '0') {
                        isInsertion = true;
                    } else if (alt.charAt(0) - '0' <= 9 && alt.charAt(0) - '0' > 0) {
                        isDeleion = true;
                        tmpPos--;
                    }

                    varIndex = chromosome.lookupVariantIndexes(tmpPos);
                    if (varIndex == null) {
                        continue;
                    }

                    // System.out.println(fileChr);
                    for (int index : varIndex) {
                        Variant var = varList.get(index);

                        if (isDeleion || isInsertion) {
                            if (var.isIndel) {
                                String varRef = var.getRefAllele();
                                String[] altAlleles = var.getAltAlleles();
                                //keep dependentVariants with score less than minAlleleFreq
                                for (String varAlt : altAlleles) {
                                    //insertion in 1KG
                                    if (isInsertion) {
                                        if (varAlt.substring(1).equals(alt.substring(1))) {
                                            //record the maximal allele frequencies
                                            if (var.altAF == -1 || Float.isNaN(var.altAF) || (maf > var.altAF)) {
                                                var.altAF = maf;
                                            }
                                            hitOnce = true;
                                            if (Float.isNaN(maf)) {
                                                var.setFeatureValue(feautreNum, ".");
                                            } else {
                                                var.setFeatureValue(feautreNum, String.valueOf(maf));
                                            }
                                            break;
                                        }
                                    } else if (alt.charAt(0) != '0') {
                                        //deletion in 1KG
                                        sb.delete(0, sb.length());
                                        for (int t = 0; t < varAlt.length(); t++) {
                                            if (varAlt.charAt(t) == '-') {
                                                sb.append(varRef.charAt(t));
                                            }
                                        }

                                        delNum = Util.parseInt(alt);
                                        if (sb.toString().equals(ref.substring(ref.length() - delNum))) {
                                            //record the maximal allele frequencies
                                            if (var.altAF == -1 || Float.isNaN(var.altAF) || (maf > var.altAF)) {
                                                // if (Float.isNaN(var.altAF) || (!Float.isNaN(score) && score > var.altAF)) {
                                                var.altAF = maf;
                                            }
                                            hitOnce = true;
                                            if (Float.isNaN(maf)) {
                                                var.setFeatureValue(feautreNum, ".");
                                            } else {
                                                var.setFeatureValue(feautreNum, String.valueOf(maf));
                                            }
                                            break;
                                        }
                                    }
                                }
                            } else {
                                continue;
                            }
                        } else if (var.isIndel) {
                            continue;
                        } else {
                            String[] altAlleles = var.getAltAlleles();
                            for (String str : altAlleles) {
                                if (str.charAt(0) == alt.charAt(0)) {
                                    //record treadVariantsInFileOnlyFastTokenhe maximal allele frequencies
                                    if (var.altAF == -1 || Float.isNaN(var.altAF) || (maf > var.altAF)) {
                                        //if (Float.isNaN(var.altAF) || (!Float.isNaN(score) && score > var.altAF)) {
                                        var.altAF = maf;
                                    }
                                    hitOnce = true;
                                    if (Float.isNaN(maf)) {
                                        var.setFeatureValue(feautreNum, ".");
                                    } else {
                                        var.setFeatureValue(feautreNum, String.valueOf(maf));
                                    }
                                    break;
                                }
                            }
                        }

                    }
                }
                if (hitOnce) {
                    existVarNum++;
                }
            } while ((currentLine = br.readLine()) != null);

            ass.setLeftNum(existVarNum + ass.getLeftNum());
            ass.setAnnotNum(existVarNum + ass.getAnnotNum());
            ass.setTotalNum(lineCounter + ass.getTotalNum());
            if (needProgressionIndicator) {
                backSpaces = new char[7];
                Arrays.fill(backSpaces, '\b');
                System.out.print(backSpaces);
            }
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    public void markByANNOVARefFormatThread(String filePath, Chromosome chromosome, AnnotationSummarySet ass, int threadNum) {
        int indexCHROM = 0, indexPOS = 1;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        try {
            int lineCounter = 0;
            char[] backSpaces = null;
            int delNum = 0;
            int existVarNum = 0;
            StringBuilder sb = new StringBuilder();

            String chrName = chromosome.getName();
            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            File rsFile = new File(filePath);
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), 0, 1, false);
            }
            bfIndexes.readIndex(false, chromName);

            //No matched SNPs means null 
            String missingVal = "N";
            for (Variant var : chromosome.variantList) {
                var.setFeatureValue(feautreNum, missingVal);
                var.hasBeenAcced = false;
            }

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;
            boolean hasHead = false;
            for (int f = 1; f < bounderies.length; f++) {
                long[] pos;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);
                }
                if (pos[0] == pos[1]) {
                    for (int t = bounderies[f - 1]; t <= bounderies[f] - 1; t++) {
                        chromosome.variantList.get(t).setFeatureValue(feautreNum, ".");
                    }
                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                bf.adjustPos(pos[0], pos[1]);

                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }
                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], indexCHROM, indexPOS, chromosome, ass, 1) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

            ass.setLeftNum(existVarNum + ass.getLeftNum());
            ass.setAnnotNum(existVarNum + ass.getAnnotNum());
            ass.setTotalNum(lineCounter + ass.getTotalNum());
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    public void markByVCFAlleleFormatThread(String filePath, int[] altFreqColIndexes, Chromosome chromosome, AnnotationSummarySet ass, int threadNum) {
        int indexCHROM = 0, indexPOS = 1;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = ass.getAvailableFeatureIndex();

        String currentLine = null;
        try {
            int lineCounter = 0;

            int existVarNum = 0;

            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            File rsFile = new File(filePath);
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), 0, 1, false);
            }
            bfIndexes.readIndex(false, chromName);

            //No matched SNPs means null 
            String missingVal = "N";
            for (Variant var : chromosome.variantList) {
                for (int i = 0; i < altFreqColIndexes.length; i++) {
                    var.setFeatureValue(feautreNum + i, missingVal);
                }
                var.hasBeenAcced = false;
            }

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;
            boolean hasHead = false;
            for (int f = 1; f < bounderies.length; f++) {
                long[] pos;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);
                }
                // System.out.println(pos[0]+"\t"+pos[1]);
                if (pos[0] == pos[1]) {
                    for (int t = bounderies[f - 1]; t <= bounderies[f] - 1; t++) {
                        for (int i = 0; i < altFreqColIndexes.length; i++) {
                            chromosome.variantList.get(t).setFeatureValue(feautreNum + i, ".");
                        }
                    }
                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                bf.adjustPos(pos[0], pos[1]);

                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }
                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], indexCHROM, indexPOS, chromosome, ass, 3) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                varTaks.setAltFreqColIndexes(altFreqColIndexes);
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

            ass.setLeftNum(existVarNum + ass.getLeftNum());
            ass.setAnnotNum(existVarNum + ass.getAnnotNum());
            ass.setTotalNum(lineCounter + ass.getTotalNum());
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    public void readNocodeScoreNucleotideMultiThread(String filePath, Chromosome chromosome, AnnotationSummarySet ass, int threadNum, int annotationType) {
        int indexCHROM = 0, indexPOS = 2;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }
        int feautreGenomeIndex = ass.getAvailableFeatureIndex();
        int[] featureIndexes = ass.getColDBIndexes();

        String currentLine = null;
        try {
            int lineCounter = 0;
            int delNum = 0;
            int existVarNum = 0;
            StringBuilder sb = new StringBuilder();

            String chrName = chromosome.getName();
            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            File rsFile = new File(filePath);
            if (!rsFile.exists()) {
                LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                return;
            }
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();
            BGZFInputStream bfIndexes = new BGZFInputStream(rsFile.getCanonicalPath(), actualThreadNum, true);
            if (!bfIndexes.checkIndex()) {
                bfIndexes.adjustPos();
                bfIndexes.buildIndex(rsFile.getCanonicalPath(), indexCHROM, indexPOS, true);
            }
            bfIndexes.readIndex(false, chromName);

            //No matched SNPs means null 
            String missingVal = ".";
            for (Variant var : chromosome.variantList) {
                var.setFeatureValue(feautreGenomeIndex, missingVal);
                var.hasBeenAcced = false;
            }
            int scoreNum = 10;

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;
            boolean hasHead = true;
            for (int f = 1; f < bounderies.length; f++) {
                long[] pos;
                if (f == bounderies.length - 1) {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f] - 1).refStartPosition);
                } else {
                    pos = bfIndexes.findIndex(chromosome.variantList.get(bounderies[f - 1]).refStartPosition, chromosome.variantList.get(bounderies[f]).refStartPosition);

                }
                if (pos[0] == pos[1]) {

                    continue;
                }
                final BGZFInputStream bf = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
                // System.out.println(chromosome.variantList.get(bounderies[f - 1]).refStartPosition+" : "+chromosome.variantList.get(bounderies[f] - 1).refStartPosition+" : "+pos[0] + " : " + pos[1]);
                bf.adjustPos(pos[0], pos[1]);

                bf.creatSpider(pos[0] != 0);
                if (hasHead && pos[0] == 0) {
                    //skip the head line
                    bf.spider[0].readLine();
                }
                VarAnnotTask varTaks = new VarAnnotTask(bf.spider[0], chromosome.variantList.subList(bounderies[f - 1], bounderies[f]),
                        indexCHROM, indexPOS, ass, annotationType) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            bf.spider[0].closeInputStream();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                varTaks.setCurrChr(chromName.getBytes());
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();
            ass.setTotalNum(varSize + ass.getTotalNum());
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    // 位置与碱基对的匹配
    public void readCCFScoreNucleotideMultiThread(CCFReader originReader, Map<Integer, BaseArray<edu.sysu.pmglab.container.Interval<Long>>> chromosomeInterval,
            Chromosome chromosome, AnnotationSummarySet ass, int threadNum, int annotationType) {
        int indexCHROM = 0, indexPOS = 2;
        List<Variant> varList = chromosome.variantList;

        if (varList.isEmpty()) {
            return;
        }

        String currentLine = null;
        try {

            if (chromosome == null || chromosome.variantList == null || chromosome.variantList.isEmpty()) {
                return;
            }

            System.out.println(chromosome.getName());
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = chromosome.variantList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;
            String chromName = chromosome.getName();

            BaseArray<edu.sysu.pmglab.container.Interval<Long>> intervals = chromosomeInterval.get(chromosome.getId());

            if (intervals == null) {
                int varFeatureIndex = ass.getAvailableFeatureIndex();
                //No matched SNPs means null 
                String missingVal = ".";
                String[] colNames = ass.getDbColNames();
                for (Variant var : chromosome.variantList) {
                    for (int i = 0; i < colNames.length; i++) {
                        var.setFeatureValue(varFeatureIndex + i, missingVal);
                    }
                    var.hasBeenAcced = false;
                }
                return;
            }

            originReader.limit(intervals.get(0));

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;
            boolean hasHead = true;
            for (int f = 1; f < bounderies.length; f++) {
                CCFReader newReader = originReader.newInstance();
                // 限定在指定的染色体区间范围, 注意, 如果文件是无序的, BaseArray<edu.sysu.pmglab.container.Interval<Long>> 会对应多个区间
                newReader.limit(intervals.get(0));
                VarAnnotTask varTaks = new VarAnnotTask(newReader, chromosome.variantList.subList(bounderies[f - 1], bounderies[f]),
                        indexCHROM, indexPOS, ass, annotationType) {
                    @Override
                    protected void fireTaskComplete() {
                        try {
                            newReader.close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                };
                varTaks.setCurrChr(chromName.getBytes());
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();
            ass.setTotalNum(varSize + ass.getTotalNum());
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    public void riskPredictionRareDiseaseBest(Chromosome chromosome, List<CombOrders> combOrderList, boolean filterNonDisMut, List<String> names,
            FiltrationSummarySet dbNSFPMendelPred) throws Exception {

        int triedTime = 0;
        int maxTriedTime = 1;
        StringBuilder tmpStrB = new StringBuilder();

        // humvar predict
        double[] priors = new double[]{0.05, 0.01, 0};
        double[] mafBins = new double[]{0.01, 0.02, 0.03};
        double prior;

        List<Integer> paramIndexes = new ArrayList<Integer>();
        Set<Integer> dataIndexes = new HashSet<Integer>();
        int combListSize = combOrderList.size();
        List<Variant> tempVarList = new ArrayList<Variant>();
        int totalVarNum = 0;
        Set<String> geneSymbSet = new HashSet<String>();

        int counterDis = 0;
        int counterCon = 0;

        double sum = 0;
        RegressionParams tmpRP = null;
        RegressionParams bestRP = null;

        double tmpP, bestP;
        List<Integer> bestPParamIndexes = new ArrayList<Integer>();

        boolean isDeleteriousness = false;
        int featureNum = dbNSFPMendelPred.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.scores1 != null) {
                dataIndexes.clear();
                for (int j = 0; j < var.scores1.length; j++) {
                    if (!Float.isNaN(var.scores1[j])) {
                        dataIndexes.add(j);
                    }
                }

                bestRP = null;
                tmpRP = null;
                bestP = 0;
                isDeleteriousness = false;
                tmpStrB.delete(0, tmpStrB.length());
                triedTime = 0;

                for (int t = combListSize - 1; t >= 0; t--) {
                    CombOrders cmbOrder = combOrderList.get(t);
                    paramIndexes.clear();
                    if (dataIndexes.containsAll(cmbOrder.indexes)) {
                        paramIndexes.addAll(cmbOrder.indexes);
                        Collections.sort(paramIndexes);
                        tmpRP = cmbOrder.rp;
                        sum = tmpRP.coef[0];
                        for (int j = 1; j < tmpRP.coef.length; j++) {
                            sum += (tmpRP.coef[j] * var.scores1[paramIndexes.get(j - 1)]);
                        }
                        // calculate the conditional probablity with MAF
                        // if (Float.isNaN(var.altAF) || var.altAF <= 0.01)
                        {
                            prior = ((1 - priors[0]) / priors[0]) * tmpRP.sampleCase2CtrRatio;
                            tmpP = 1 + prior * Math.exp(-sum);
                            tmpP = 1 / tmpP;
                        }
                        /*
                         * else if (var.altAF <= 0.03) { prior = ((1 -
                         * priors[1]) / priors[1]) *
                         * tmpRP.sampleCase2CtrRatio; tmpP = 1 + prior *
                         * Math.exp(-sum); tmpP = 1 / tmpP; } else { tmpP =
                         * 0; }
                         */

                        if (bestP <= tmpP) {
                            bestP = tmpP;
                            bestRP = tmpRP;
                            bestPParamIndexes.clear();
                            bestPParamIndexes.addAll(combOrderList.get(t).indexes);
                            Collections.sort(bestPParamIndexes);
                        }

                        if (tmpP >= tmpRP.optimalCutoff) {
                            var.setFeatureValue(featureNum, String.valueOf(tmpP));
                            var.setFeatureValue(featureNum + 1, "Y");
                            for (Integer ind : paramIndexes) {
                                tmpStrB.append(names.get(ind));
                                tmpStrB.append(';');
                            }
                            tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.optimalCutoff, 4));
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.truePositiveRate, 3));
                            tmpStrB.append(':');
                            tmpStrB.append(Util.doubleToString(tmpRP.trueNegativeRate, 3));
                            var.setFeatureValue(featureNum + 2, tmpStrB.toString());
                            counterDis += 1;
                            if (filterNonDisMut) {
                                tempVarList.add(var);
                            }
                            if (var.geneSymb != null) {
                                geneSymbSet.add(var.geneSymb);
                            }

                            isDeleteriousness = true;
                            // to reduce false positive only test once
                            break;
                        } else {
                            triedTime++;
                        }

                        if (triedTime >= maxTriedTime) {
                            // to reduce false positive only test once
                            break;
                        }
                    }
                }

                if (!isDeleteriousness) {
                    if (tmpRP == null) {
                        // keep varaint have no risk scores which may be
                        // safer
                        tempVarList.add(var);
                        var.setFeatureValue(featureNum, null);
                        var.setFeatureValue(featureNum + 1, null);
                        var.setFeatureValue(featureNum + 2, null);

                    } else {
                        // noly filter it for missense dependentVariants
                        if (var.smallestFeatureID != 6) {
                            tempVarList.add(var);
                        }
                        var.setFeatureValue(featureNum, String.valueOf(bestP));
                        var.setFeatureValue(featureNum + 1, "N");
                        if (!bestPParamIndexes.isEmpty()) {
                            for (Integer ind : bestPParamIndexes) {
                                tmpStrB.append(names.get(ind));
                                tmpStrB.append(';');
                            }
                            tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                        }
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.optimalCutoff, 4));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.truePositiveRate, 3));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.trueNegativeRate, 3));
                        var.setFeatureValue(featureNum + 2, tmpStrB.toString());
                        counterCon += 1;
                    }
                }
            } else {
                // keep varaint have no risk scores which may be safer
                tempVarList.add(var);
                var.setFeatureValue(featureNum, null);
                var.setFeatureValue(featureNum + 1, null);
                var.setFeatureValue(featureNum + 2, null);
            }
        }

        if (filterNonDisMut) {
            chromosome.variantList.clear();
            chromosome.variantList.addAll(tempVarList);
            totalVarNum += tempVarList.size();
            tempVarList.clear();

        }

        chromosome.buildVariantIndexMap();
        dbNSFPMendelPred.increaseCount(0, counterDis);
        dbNSFPMendelPred.increaseCount(1, geneSymbSet.size());
        dbNSFPMendelPred.increaseCount(2, counterCon);
        dbNSFPMendelPred.increaseCount(3, totalVarNum);
    }

    public void weightScoreByExpression(Chromosome chromosome, int expStartIndex, int expNum, int scoreIndex) throws Exception {
        double score, exp;
        String[] features;
        int effectiveNum;
        for (Variant var : chromosome.variantList) {
            features = var.getFeatureValues();
            effectiveNum = 0;
            exp = 0;
            for (int i = 0; i < expNum; i++) {
                if (features[expStartIndex + i] != null && !features[expStartIndex + i].equals(".")) {
                    exp += Double.parseDouble(features[expStartIndex + i]);
                    effectiveNum++;
                }
            }
            if (effectiveNum > 0) {
                exp /= effectiveNum;
            }
            score = 0;
            if (features[scoreIndex] != null && !features[scoreIndex].equals(".")) {
                score = Double.parseDouble(features[scoreIndex]);
            }
            score *= exp;
            var.setFeatureValue(scoreIndex, String.valueOf(score));
            //  var.setFeatureValue(scoreIndex, String.valueOf(exp));
        }
    }

    public void riskPredictionRareDiseaseFixParam(Chromosome chromosome, CombOrders cmbOrder, boolean filterNonDisMut, List<String> names, FiltrationSummarySet dbNSFPMendelPred) throws Exception {
        // humvar predict
        double[] priors = new double[]{0.05, 0.01, 0.0001};
        double[] mafBins = new double[]{0.01, 0.02, 0.03};
        double prior;

        List<Integer> paramIndexes = new ArrayList<Integer>();
        Set<Integer> dataIndexes = new HashSet<Integer>();

        List<Variant> tempVarList = new ArrayList<Variant>();
        int totalVarNum = 0;
        Set<String> geneSymbSet = new HashSet<String>();

        int counterDis = 0;
        int counterCon = 0;

        double sum = 0;
        RegressionParams tmpRP = null;
        RegressionParams bestRP = null;

        double tmpP, bestP;
        List<Integer> bestPParamIndexes = new ArrayList<Integer>();
        int featureNum = dbNSFPMendelPred.getAvailableFeatureIndex();
        boolean isDeleteriousness = false;
        StringBuilder tmpStrB = new StringBuilder();
        if (chromosome == null) {
            return;
        }
        for (Variant var : chromosome.variantList) {

            if (var.scores1 != null) {
                dataIndexes.clear();
                for (int j = 0; j < var.scores1.length; j++) {
                    if (!Float.isNaN(var.scores1[j])) {
                        dataIndexes.add(j);
                    }
                }

                tmpRP = null;
                bestRP = null;
                bestP = 0;
                isDeleteriousness = false;
                tmpStrB.delete(0, tmpStrB.length());

                paramIndexes.clear();
                if (dataIndexes.containsAll(cmbOrder.indexes)) {
                    paramIndexes.addAll(cmbOrder.indexes);
                    Collections.sort(paramIndexes);
                    tmpRP = cmbOrder.rp;
                    sum = tmpRP.coef[0];
                    for (int j = 1; j < tmpRP.coef.length; j++) {
                        sum += (tmpRP.coef[j] * var.scores1[paramIndexes.get(j - 1)]);
                    }
                    // calculate the conditional probablity with MAF
                    // if (Float.isNaN(var.altAF) || var.altAF <= 0.01)
                    {
                        prior = ((1 - priors[0]) / priors[0]) * tmpRP.sampleCase2CtrRatio;
                        tmpP = 1 + prior * Math.exp(-sum);
                        tmpP = 1 / tmpP;
                    }
                    /*
                     * else if (var.altAF <= 0.03) { prior = ((1 -
                     * priors[1]) / priors[1]) *
                     * tmpRP.sampleCase2CtrRatio; tmpP = 1 + prior *
                     * Math.exp(-sum); tmpP = 1 / tmpP; } else { tmpP =
                     * 0; }
                     */

                    if (bestP <= tmpP) {
                        bestP = tmpP;
                        bestRP = tmpRP;
                        bestPParamIndexes.clear();
                        bestPParamIndexes.addAll(cmbOrder.indexes);
                        Collections.sort(bestPParamIndexes);
                    }

                    if (tmpP >= tmpRP.optimalCutoff) {
                        var.setFeatureValue(featureNum, String.valueOf(tmpP));
                        var.setFeatureValue(featureNum + 1, "Y");
                        for (Integer ind : paramIndexes) {
                            tmpStrB.append(names.get(ind));
                            tmpStrB.append(';');
                        }
                        tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(tmpRP.optimalCutoff, 4));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(tmpRP.truePositiveRate, 3));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(tmpRP.trueNegativeRate, 3));
                        var.setFeatureValue(featureNum + 2, tmpStrB.toString());
                        counterDis += 1;
                        if (filterNonDisMut) {
                            tempVarList.add(var);
                        }
                        if (var.geneSymb != null) {
                            geneSymbSet.add(var.geneSymb);
                        }
                        isDeleteriousness = true;
                    }
                }

                if (!isDeleteriousness) {
                    if (tmpRP == null) {
                        // keep varaint have no risk scores which may be
                        // safer
                        tempVarList.add(var);
                        var.setFeatureValue(featureNum, null);
                        var.setFeatureValue(featureNum + 1, null);
                        var.setFeatureValue(featureNum + 2, null);
                    } else {
                        // noly filter it for missense dependentVariants
                        if (var.smallestFeatureID != 6) {
                            tempVarList.add(var);
                        }
                        var.setFeatureValue(featureNum, String.valueOf(bestP));
                        var.setFeatureValue(featureNum + 1, "N");
                        if (!bestPParamIndexes.isEmpty()) {
                            for (Integer ind : bestPParamIndexes) {
                                tmpStrB.append(names.get(ind));
                                tmpStrB.append(';');
                            }
                            tmpStrB.deleteCharAt(tmpStrB.length() - 1);
                        }
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.optimalCutoff, 4));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.truePositiveRate, 3));
                        tmpStrB.append(':');
                        tmpStrB.append(Util.doubleToString(bestRP.trueNegativeRate, 3));
                        var.setFeatureValue(featureNum + 2, tmpStrB.toString());
                        counterCon += 1;
                    }
                }
            } else {
                // keep varaint have no risk scores which may be safer
                tempVarList.add(var);
                var.setFeatureValue(featureNum, null);
                var.setFeatureValue(featureNum + 1, null);
                var.setFeatureValue(featureNum + 2, null);
            }
        }

        if (filterNonDisMut) {
            chromosome.variantList.clear();
            chromosome.variantList.addAll(tempVarList);
            totalVarNum += tempVarList.size();
            tempVarList.clear();
        }

        chromosome.buildVariantIndexMap();
        dbNSFPMendelPred.increaseCount(0, counterDis);
        dbNSFPMendelPred.increaseCount(1, geneSymbSet.size());
        dbNSFPMendelPred.increaseCount(2, counterCon);
        dbNSFPMendelPred.increaseCount(3, totalVarNum);

    }

    public void pseudogeneAnnotationGene(Chromosome chromosome, AnnotationSummarySet ass, String dbPath) throws Exception {
//        genome.addmRNAFeatureLabel("GeneDescription");
//        genome.addmRNAFeatureLabel("Pseudogenes");

        List<String[]> geneItems = new ArrayList<String[]>();
        int[] indices = new int[3];
        indices[0] = 1;
        indices[1] = 2;
        indices[2] = 3;
        LocalFile.retrieveData(dbPath, geneItems, indices, "\t");
        StringArrayStringComparator sacmp = new StringArrayStringComparator(0);
        Collections.sort(geneItems, sacmp);
        String lastGeneSymb = null;
        String[] lastGeneFeature = null;
        String[] keys = new String[3];
        int intCount = 0;

//        Chromosome[] chroms = genome.getChromosomes();
//        for (int t = 0; t < chroms.length; t++) {
        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGeneFeature = null;
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.geneSymb != null) {
                if (lastGeneSymb != null && mrna.geneSymb.equals(lastGeneSymb)) {
                    mrna.addFeatureValue(lastGeneFeature[0]);
                    mrna.addFeatureValue(lastGeneFeature[1]);
                } else {
                    keys[0] = mrna.geneSymb;
                    lastGeneFeature = searchRelevantGeneSymbols(geneItems, sacmp, keys, 0);
                    lastGeneSymb = mrna.geneSymb;
                    mrna.addFeatureValue(lastGeneFeature[0]);
                    mrna.addFeatureValue(lastGeneFeature[1]);
                }
                intCount++;
            } else {
                mrna.addFeatureValue(".");
                mrna.addFeatureValue(".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + intCount);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - intCount);
        //       }
    }

    public String[] searchRelevantGeneSymbols(List<String[]> geneItems, StringArrayStringComparator sacmp, String[] key, int keyIndex) throws Exception {
        String[] geneDescrip = new String[2];
        StringBuilder sb = new StringBuilder();
        int index = Collections.binarySearch(geneItems, key, sacmp);
        if (index < 0) {
            return geneDescrip;
        } else {
            int startIndex = index - 1;
            while (startIndex >= 0 && geneItems.get(startIndex)[keyIndex].startsWith(key[keyIndex])) {
                startIndex--;
            }
            startIndex++;
            int endIndex = index + 1;
            while (endIndex < geneItems.size() && geneItems.get(endIndex)[keyIndex].startsWith(key[keyIndex])) {
                endIndex++;
            }
            for (int i = startIndex; i < endIndex; i++) {
                if (geneItems.get(i)[1].contains("pseudogene")) {
                    sb.append(geneItems.get(i)[0]);
                    sb.append(", ");
                }
            }
            geneDescrip[0] = geneItems.get(index)[1] + " (" + geneItems.get(index)[2] + ")";
            if (sb.length() > 0) {
                geneDescrip[1] = sb.substring(0, sb.length() - 2);
            } else {
                geneDescrip[1] = ".";
            }
            return geneDescrip;
        }

    }

    public void pseudogeneAnnotationVar(Chromosome chromosome, AnnotationSummarySet ass, String dbPath) throws Exception {
//        genome.addVariantFeatureLabel("GeneDescription");
//        genome.addVariantFeatureLabel("Pseudogenes");

        List<String[]> geneItems = new ArrayList<String[]>();
        int[] indices = new int[3];
        indices[0] = 1;
        indices[1] = 2;
        indices[2] = 3;
        LocalFile.retrieveData(dbPath, geneItems, indices, "\t");//time-consuming
        StringArrayStringComparator sacmp = new StringArrayStringComparator(0);
        Collections.sort(geneItems, sacmp);
        String lastGeneSymb = null;
        String[] lastGeneFeature = null;
        String[] keys = new String[3];
        int intCount = 0;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGeneFeature = null;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(ass.getAvailableFeatureIndex(), lastGeneFeature[0]);
                    var.setFeatureValue(ass.getAvailableFeatureIndex() + 1, lastGeneFeature[1]);
                } else {
                    keys[0] = var.geneSymb;
                    lastGeneFeature = searchRelevantGeneSymbols(geneItems, sacmp, keys, 0);
                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(ass.getAvailableFeatureIndex(), lastGeneFeature[0]);
                    var.setFeatureValue(ass.getAvailableFeatureIndex() + 1, lastGeneFeature[1]);
                }
                intCount++;
            } else {
                var.setFeatureValue(ass.getAvailableFeatureIndex(), ".");
                var.setFeatureValue(ass.getAvailableFeatureIndex() + 1, ".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + intCount);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - intCount);
    }

    public void omimGeneAnnotationGene(Chromosome chromosome, AnnotationSummarySet ass, String dbPath) throws Exception {

        List<String[]> geneItems = new ArrayList<String[]>();
        int[] indices = new int[3];
        indices[0] = 0;
        indices[1] = 1;
        indices[2] = 2;
        LocalFile.retrieveData(dbPath, geneItems, indices, "[|]");
        Map<String, IntArrayList> geneRowMap = new HashMap<String, IntArrayList>();
        int size = geneItems.size();
        for (int i = 0; i < size; i++) {
            String[] item = geneItems.get(i);
            String[] genes = item[1].split(",");
            for (String gs : genes) {
                IntArrayList indexes = geneRowMap.get(gs);
                if (indexes == null) {
                    indexes = new IntArrayList();
                    indexes.add(i);
                    geneRowMap.put(gs, indexes);
                } else {
                    indexes.add(i);
                }
            }
        }

        String lastGeneSymb = null;
        String[] lastGeneFeature = null;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGeneFeature = null;
        int intCount = 0;
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.geneSymb != null) {
                if (mrna.geneSymb != null) {
                    if (lastGeneSymb != null && mrna.geneSymb.equals(lastGeneSymb)) {
                        mrna.addFeatureValue(lastGeneFeature[0]);
                        mrna.addFeatureValue(lastGeneFeature[1]);
                    } else {
                        Arrays.fill(lastGeneFeature, null);
                        IntArrayList indexes = geneRowMap.get(mrna.geneSymb);
                        if (indexes != null) {
                            lastGeneFeature[0] = geneItems.get(indexes.getQuick(0))[0];
                            lastGeneFeature[1] = geneItems.get(indexes.getQuick(0))[2];
                            for (int t = 1; t < indexes.size(); t++) {
                                lastGeneFeature[0] += ("|" + geneItems.get(indexes.getQuick(t))[0]);
                                // lastGeneFeature[1] += ("|" +
                                // geneItems.get(indexes.getQuick(t))[2]);
                            }
                        }

                        lastGeneSymb = mrna.geneSymb;
                        mrna.addFeatureValue(lastGeneFeature[0]);
                        mrna.addFeatureValue(lastGeneFeature[1]);
                    }
                    intCount++;
                } else {
                    mrna.addFeatureValue(".");
                    mrna.addFeatureValue(".");
                }
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + intCount);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - intCount);
    }

    public void omimGeneAnnotationVar(Chromosome chromosome, AnnotationSummarySet ass, String dbPath) throws Exception {
        List<String[]> geneItems = new ArrayList<String[]>();
        int[] indices = new int[3];
        indices[0] = 0;
        indices[1] = 1;
        indices[2] = 2;

        //LocalFile.retrieveData(dbPath, geneItems, indices, "[|]");
        //since 2017 Dec the morbility file used tab to seperate the columns
        LocalFile.retrieveData(dbPath, geneItems, indices, "\t", '#');
        Map<String, IntArrayList> geneRowMap = new HashMap<String, IntArrayList>();
        int size = geneItems.size();
        for (int i = 0; i < size; i++) {
            String[] item = geneItems.get(i);
            String[] genes = item[1].split(",");
            for (String gs : genes) {
                IntArrayList indexes = geneRowMap.get(gs);
                if (indexes == null) {
                    indexes = new IntArrayList();
                    indexes.add(i);
                    geneRowMap.put(gs, indexes);
                } else {
                    indexes.add(i);
                }
            }
        }

        String lastGeneSymb = null;
        String[] lastGeneFeature = null;
        lastGeneFeature = new String[2];
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        Arrays.fill(lastGeneFeature, null);
        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(avialbleIndex, lastGeneFeature[0]);
                    var.setFeatureValue(avialbleIndex + 1, lastGeneFeature[1]);
                } else {
                    Arrays.fill(lastGeneFeature, null);
                    IntArrayList indexes = geneRowMap.get(var.geneSymb);
                    if (indexes != null) {
                        lastGeneFeature[0] = geneItems.get(indexes.getQuick(0))[0];
                        lastGeneFeature[1] = geneItems.get(indexes.getQuick(0))[2];
                        for (int t = 1; t < indexes.size(); t++) {
                            lastGeneFeature[0] += ("|" + geneItems.get(indexes.getQuick(t))[0]);
                            // lastGeneFeature[1] += ("|" +
                            // geneItems.get(indexes.getQuick(t))[2]);
                        }
                    }
                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(avialbleIndex, lastGeneFeature[0]);
                    var.setFeatureValue(avialbleIndex + 1, lastGeneFeature[1]);
                    hitNum++;
                }
            } else {
                var.setFeatureValue(avialbleIndex, ".");
                var.setFeatureValue(avialbleIndex + 1, ".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
        // LOG.info(hitNum + " sequence variant(s) are highlighted by OMIM information!");
    }

    public void tissueSpecGeneAnnotationVar(Chromosome chromosome, AnnotationSummarySet ass, Map<String, StringBuilder> tissueSpecGeneMap) throws Exception {
        String lastGeneSymb = null;
        String[] lastGeneFeature = null;
        lastGeneFeature = new String[2];
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        Arrays.fill(lastGeneFeature, null);
        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(avialbleIndex, lastGeneFeature[0]);

                } else {
                    Arrays.fill(lastGeneFeature, null);
                    StringBuilder annots = tissueSpecGeneMap.get(var.geneSymb);
                    if (annots != null) {
                        lastGeneFeature[0] = annots.substring(0, annots.length() - 1);
                    }
                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(avialbleIndex, lastGeneFeature[0]);
                    hitNum++;
                }
            } else {
                var.setFeatureValue(avialbleIndex, ".");

            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
        // LOG.info(hitNum + " sequence variant(s) are highlighted by OMIM information!");
    }

    public void cosmicGeneAnnotationVar(Chromosome chromosome, AnnotationSummarySet ass, Map<String, Map<String, Integer>> cosmicGeneMut) throws Exception {
        String lastGeneSymb = null;
        String lastGeneFeature = ".";

        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;

        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(avialbleIndex, lastGeneFeature);
                } else {
                    lastGeneSymb = var.geneSymb;
                    Map<String, Integer> mutInfor = cosmicGeneMut.get(lastGeneSymb);
                    if (mutInfor != null) {
                        lastGeneFeature = mutInfor.toString();
                    } else {
                        lastGeneFeature = ".";
                    }
                    var.setFeatureValue(avialbleIndex, lastGeneFeature);
                    hitNum++;
                }
            } else {
                var.setFeatureValue(avialbleIndex, ".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
        // LOG.info(hitNum + " sequence variant(s) are highlighted by OMIM information!");
    }

    public void superDupAnnotation(Chromosome chromosome, AnnotationSummarySet ass, ReferenceGenome refGenome) throws Exception {
        int leftVariantNum = 0;
        int gainNum = 0;
        int lossNum = 0;
        int sampleSize = 0;
        StringBuilder sb = new StringBuilder();

        if (chromosome == null) {
            return;
        }
        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            List<RefDup> cnvList = refGenome.getDupFeature(chromosome.getName(), var, new RNABoundaryIndex(0));
            if (cnvList == null || cnvList.isEmpty()) {
                var.setFeatureValue(avialbleIndex, ".");
                continue;
            }

            for (RefDup refCNC : cnvList) {
                sb.append(refCNC.getJcKScore());
                sb.append(", ");
            }
            leftVariantNum++;
            var.setFeatureValue(avialbleIndex, sb.substring(0, sb.length() - 2));

            sb.delete(0, sb.length());
        }

        ass.setAnnotNum(ass.getAnnotNum() + leftVariantNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - leftVariantNum);

    }

    public void cnvAnnotation(Chromosome chromosome, AnnotationSummarySet ass, ReferenceGenome refGenome) throws Exception {
        int leftVariantNum = 0;
        int gainNum = 0;
        int lossNum = 0;
        int sampleSize = 0;

        StringBuilder sb = new StringBuilder();

        if (chromosome == null) {
            return;
        }
        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            List<RefCNV> cnvList = refGenome.getCNVFeature(chromosome.getName(), var, new RNABoundaryIndex(0));
            if (cnvList == null || cnvList.isEmpty()) {
                var.setFeatureValue(avialbleIndex, ".");
                var.setFeatureValue(avialbleIndex + 1, ".");
                var.setFeatureValue(avialbleIndex + 2, ".");
                var.setFeatureValue(avialbleIndex + 3, ".");
                continue;
            }
            gainNum = 0;
            lossNum = 0;
            sampleSize = 0;
            for (RefCNV refCNC : cnvList) {
                sampleSize += refCNC.getSampleSize();
                gainNum += refCNC.getObservedGains();
                lossNum += refCNC.getObservedLosses();
                sb.append(refCNC.getDescription());
                sb.append(", ");
            }
            leftVariantNum++;
            var.setFeatureValue(avialbleIndex, sb.substring(0, sb.length() - 2));
            var.setFeatureValue(avialbleIndex + 1, String.valueOf(sampleSize));
            var.setFeatureValue(avialbleIndex + 2, String.valueOf(lossNum));
            var.setFeatureValue(avialbleIndex + 3, String.valueOf(gainNum));

            sb.delete(0, sb.length());
        }

        ass.setAnnotNum(ass.getAnnotNum() + leftVariantNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - leftVariantNum);
    }

    public void canidateGeneExploreGene(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet) {
        int hitNum = 0;
        if (chromosome == null) {
            return;
        }
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.geneSymb != null) {
                if (candiGeneSet.contains(mrna.geneSymb)) {
                    mrna.addFeatureValue("Y");
                    hitNum++;
                } else {
                    mrna.addFeatureValue("N");
                }
            } else {
                mrna.addFeatureValue(".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - hitNum);
    }

    public void canidateGeneExploreVar(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet) {
        int hitNum = 0;
        if (chromosome == null) {
            return;
        }
        int afI = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (candiGeneSet.contains(var.geneSymb)) {
                    var.setFeatureValue(afI, "Y");
                    hitNum++;
                } else {
                    var.setFeatureValue(afI, "N");
                }
            } else {
                var.setFeatureValue(afI, ".");
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
    }

    public void canidateGenePPIExploreGene(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet, PPIGraph ppiTree, int ppiDepth) throws Exception {
        String lastGeneSymb = null;
        String lastGenePPIFeature = null;

        StringBuilder sb = new StringBuilder();
        DefaultMutableTreeNode proteinTree = null;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGenePPIFeature = "";
        int hitNum = 0;
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.getSymbol() != null) {
                if (lastGeneSymb != null && mrna.getSymbol().equals(lastGeneSymb)) {//Maybe isoforms?
                    mrna.addFeatureValue(lastGenePPIFeature);
                    if (lastGenePPIFeature.length() > 0) {
                        hitNum++;
                    }
                } else {
                    sb.delete(0, sb.length());

                    proteinTree = new DefaultMutableTreeNode(mrna.getSymbol());
                    ppiTree.constructPPITree(proteinTree, 0, ppiDepth);
                    ppiTree.trimPPITree(proteinTree, candiGeneSet);
                    if (proteinTree.getChildCount() > 0) {
                        ppiTree.convertTree2Text(proteinTree, sb);
                        // System.out.println(sb);
                    }
                    if (sb.length() > 0) {
                        lastGenePPIFeature = sb.substring(0, sb.length() - 1);
                        hitNum++;
                    } else {
                        lastGenePPIFeature = "";
                    }
                    lastGeneSymb = mrna.getSymbol();
                    mrna.addFeatureValue(lastGenePPIFeature);
                }
            } else {
                mrna.addFeatureValue(null);
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - hitNum);
    }

    public void canidateGenePPIExploreVar(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet, PPIGraph ppiTree, int ppiDepth) throws Exception {
        String lastGeneSymb = null;
        String lastGenePPIFeature = null;

        StringBuilder sb = new StringBuilder();
        DefaultMutableTreeNode proteinTree = null;
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGenePPIFeature = "";

        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(avialbleIndex, lastGenePPIFeature);
                    if (lastGenePPIFeature.length() > 0) {
                        hitNum++;
                    }
                } else {
                    sb.delete(0, sb.length());

                    proteinTree = new DefaultMutableTreeNode(var.geneSymb);
                    ppiTree.constructPPITree(proteinTree, 0, ppiDepth);
                    ppiTree.trimPPITree(proteinTree, candiGeneSet);
                    if (proteinTree.getChildCount() > 0) {
                        ppiTree.convertTree2Text(proteinTree, sb);
                        // System.out.println(sb);
                    }
                    if (sb.length() > 0) {
                        lastGenePPIFeature = sb.substring(0, sb.length() - 1);
                        hitNum++;
                    } else {
                        lastGenePPIFeature = "";
                    }
                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(avialbleIndex, lastGenePPIFeature);
                }
            } else {
                var.setFeatureValue(avialbleIndex, null);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
        //LOG.info(hitNum + " sequence variant(s) are highlighted by PPI information!");
    }

    public void canidateGenePathwayExploreGene(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet, Map<String, GeneSet> mappedPathes) throws Exception {

        String lastGeneSymb = null;
        // protein-coding gene \t19061
        int popuSize = 19061;
        int subPopuSize = 0;
        int sampleSize = 0;
        int subSampleSize = 0;

        String lastGenePathwayFeature = null;
        StringBuilder sb = new StringBuilder();
        List<PathwayP> pathwayPList = new ArrayList<PathwayP>();

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGenePathwayFeature = "";
        int hitNum = 0;
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.geneSymb != null) {
                if (lastGeneSymb != null && mrna.geneSymb.equals(lastGeneSymb)) {
                    mrna.addFeatureValue(lastGenePathwayFeature);
                    if (lastGenePathwayFeature.length() > 0) {
                        hitNum++;
                    }
                } else {
                    // find pahtway information
                    pathwayPList.clear();
                    for (Map.Entry<String, GeneSet> mPathway : mappedPathes.entrySet()) {
                        HashSet<String> pathwayGenes = mPathway.getValue().getGeneSymbols();
                        if (pathwayGenes.contains(mrna.geneSymb)) {
                            sb.delete(0, sb.length());
                            sb.append(mPathway.getKey());
                            sb.append('#');
                            sb.append(pathwayGenes.size());
                            sb.append(":(");
                            sb.append(mrna.geneSymb);
                            if (!candiGeneSet.contains(mrna.geneSymb)) {
                                subSampleSize = 0;
                            } else {
                                subSampleSize = 1;
                            }

                            Iterator<String> itSeed = candiGeneSet.iterator();
                            while (itSeed.hasNext()) {
                                String gene1 = itSeed.next();
                                if (pathwayGenes.contains(gene1)) {
                                    sb.append(',');
                                    sb.append(gene1);
                                }
                            }
                            sb.append(") ");
                            subPopuSize = pathwayGenes.size();
                            sampleSize = candiGeneSet.size();
                            if (!candiGeneSet.contains(mrna.geneSymb)) {
                                sampleSize++;
                            }

                            double p = MultipleTestingMethod.hypergeometricEnrichmentTest(popuSize, subPopuSize, sampleSize, subSampleSize);
                            pathwayPList.add(new PathwayP(p, sb.toString()));
                        }
                    }

                    sb.delete(0, sb.length());
                    if (!pathwayPList.isEmpty()) {
                        Collections.sort(pathwayPList, new PathwayPComparator());
                        for (PathwayP pp : pathwayPList) {
                            sb.append(pp.pathway);
                            sb.append(" p=").append(Util.formatPValue(pp.p));
                            sb.append("; ");
                        }
                    }

                    if (sb.length() > 0) {
                        lastGenePathwayFeature = sb.substring(0, sb.length() - 2);
                        hitNum++;
                    } else {
                        lastGenePathwayFeature = "";
                    }
                    lastGeneSymb = mrna.geneSymb;
                    mrna.addFeatureValue(lastGenePathwayFeature);
                }
            } else {
                mrna.addFeatureValue(null);
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - hitNum);
    }

    public void canidateGenePathwayExploreVar(Chromosome chromosome, AnnotationSummarySet ass, Set<String> candiGeneSet, Map<String, GeneSet> mappedPathes) throws Exception {
        // protein-coding gene \t19061
        int popuSize = 19061;

        int subPopuSize = 0;
        int sampleSize = 0;
        int subSampleSize = 0;
        String lastGeneSymb = null;
        String lastGenePathwayFeature = null;
        StringBuilder sb = new StringBuilder();
        List<PathwayP> pathwayPList = new ArrayList<PathwayP>();
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }

        lastGeneSymb = null;
        lastGenePathwayFeature = "";

        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(avialbleIndex, lastGenePathwayFeature);
                    if (lastGenePathwayFeature.length() > 0) {
                        hitNum++;
                    }
                } else {
                    // find pahtway information
                    pathwayPList.clear();

                    for (Map.Entry<String, GeneSet> mPathway : mappedPathes.entrySet()) {
                        HashSet<String> pathwayGenes = mPathway.getValue().getGeneSymbols();
                        if (pathwayGenes.contains(var.geneSymb)) {
                            sb.delete(0, sb.length());
                            sb.append(mPathway.getKey());
                            sb.append('#');
                            sb.append(pathwayGenes.size());
                            sb.append(":(");
                            sb.append(var.geneSymb);

                            if (!candiGeneSet.contains(var.geneSymb)) {
                                subSampleSize = 0;
                            } else {
                                subSampleSize = 1;
                            }
                            Iterator<String> itSeed = candiGeneSet.iterator();
                            while (itSeed.hasNext()) {
                                String gene1 = itSeed.next();
                                if (pathwayGenes.contains(gene1)) {
                                    sb.append(',');
                                    sb.append(gene1);
                                    subSampleSize++;
                                }
                            }
                            sb.append(") ");
                            subPopuSize = pathwayGenes.size();
                            sampleSize = candiGeneSet.size();
                            if (!candiGeneSet.contains(var.geneSymb)) {
                                sampleSize++;
                            }
                            double p = MultipleTestingMethod.hypergeometricEnrichmentTest(popuSize, subPopuSize, sampleSize, subSampleSize);
                            pathwayPList.add(new PathwayP(p, sb.toString()));
                        }
                    }
                    sb.delete(0, sb.length());
                    if (!pathwayPList.isEmpty()) {
                        Collections.sort(pathwayPList, new PathwayPComparator());
                        for (PathwayP pp : pathwayPList) {
                            sb.append(pp.pathway);
                            sb.append(" p=").append(Util.formatPValue(pp.p));
                            sb.append("; ");
                        }
                    }

                    if (sb.length() > 0) {
                        lastGenePathwayFeature = sb.substring(0, sb.length() - 2);
                        hitNum++;
                    } else {
                        lastGenePathwayFeature = "";
                    }
                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(avialbleIndex, lastGenePathwayFeature);
                }
            } else {
                var.setFeatureValue(avialbleIndex, null);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - hitNum);
        //LOG.info(hitNum + " sequence variant(s) are highlighted by GeneSet/Pathway information!");
    }

    public void ibdRegionExplore(Chromosome chromosome, AnnotationSummarySet ass, List<String[]> regionItems) {

        List<Variant> tmpList = new ArrayList<Variant>();
//        int hitNum = 0;
        if (chromosome == null) {
            return;
        }

        int avialbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            String[] ibdGrams = searchIbdRegions(regionItems, chromosome.getName(), var.refStartPosition);
            if (ibdGrams != null) {
                var.setFeatureValue(avialbleIndex, ibdGrams[0]);
                var.setFeatureValue(avialbleIndex + 1, ibdGrams[1]);
                tmpList.add(var);
            } else {
                var.setFeatureValue(avialbleIndex, null);
                var.setFeatureValue(avialbleIndex + 1, null);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + tmpList.size());
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - tmpList.size());
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpList);
        tmpList.clear();
//        hitNum += chromosome.variantList.size();
        chromosome.buildVariantIndexMap();
//        genome.buildVariantIndexMapOnChromosomes();
//        genome.setVarNum(hitNum);
//        LOG.info(hitNum + " variant(s) are retained after filtered by IBD Region filtering!");
    }

    public void exploreLongIBSRegion(Chromosome chromosome, AnnotationSummarySet ass, List<Variant> allVariants, int minIBS, boolean isPhased, List<Individual> subjectList, int[] pedEncodeGytIDMap, int[] caeSetID) {
        int caseNum = caeSetID.length;
        if (caseNum <= 1) {
            String info = "The number of patients is only " + caseNum + ".  Identical by state (IBS) checking (--ibs-check) function doese not work!";
            LOG.info(info);
            return;
        }
        IntSet tmpIntSet = new IntSet(0, 0, (byte) 0);

        String endMak = "";
        String startMak = "";
        StringBuilder info = new StringBuilder();
        int[] alleles1 = null;
        int[] alleles2 = null;
        IntSetComparator1 intsetCmp = new IntSetComparator1();
        OpenIntIntHashMap sharedAlleles = new OpenIntIntHashMap();
        boolean hasShared = true;
        int index1 = 0, index2 = 0;
        int begIndex = 0;
        int subID = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        endMak = "";
        startMak = "";
        OpenIntIntHashMap posIDMap = new OpenIntIntHashMap();

        int base = 0;
        int alleleNum = 0;
        int varNum = allVariants.size();
        BooleanArrayList isValid = new BooleanArrayList(varNum);
        boolean[] bits = new boolean[32];
        int startIndex;
        int subNum = pedEncodeGytIDMap.length;
        for (Variant var : allVariants) {
            sharedAlleles.clear();
            begIndex = 0;
            alleleNum = var.getAltAlleles().length + 1;
            if (isPhased) {
                base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
            } else {
                base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
            }

            hasShared = true;
            do {
                subID = caeSetID[begIndex];
                subID = pedEncodeGytIDMap[subID];
                if (subID < 0) {
                    begIndex++;
                    continue;
                }
                if (var.compressedGtyNum >= 0) {
                    if (var.compressedGtyNum == 0) {
                        Arrays.fill(bits, 0, base, false);
                    } else {
                        startIndex = subID;
                        for (int i = 0; i < base; i++) {
                            if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = false;
                            } else if (startIndex < var.compressedGty[0]) {
                                bits[i] = false;
                            } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = true;
                            } else if (startIndex == var.compressedGty[0]) {
                                bits[i] = true;
                            } else {
                                bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                            }
                            startIndex += subNum;
                        }
                    }

                    if (isPhased) {
                        alleles1 = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                    } else {
                        alleles1 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    }
                } else if (isPhased) {
                    alleles1 = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                } else {
                    alleles1 = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                }

                if (alleles1 == null) {
                    begIndex++;
                } else {
                    break;
                }
            } while (begIndex < caseNum);

            if (alleles1 == null) {
                continue;
            }
            sharedAlleles.put(alleles1[0], 0);
            sharedAlleles.put(alleles1[1], 0);

            for (int j = begIndex + 1; j < caseNum; j++) {
                subID = caeSetID[j];
                subID = pedEncodeGytIDMap[subID];
                if (subID < 0) {
                    continue;
                }
                if (var.compressedGtyNum >= 0) {
                    if (var.compressedGtyNum == 0) {
                        Arrays.fill(bits, 0, base, false);
                    } else {
                        startIndex = subID;
                        for (int i = 0; i < base; i++) {
                            if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = false;
                            } else if (startIndex < var.compressedGty[0]) {
                                bits[i] = false;
                            } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = true;
                            } else if (startIndex == var.compressedGty[0]) {
                                bits[i] = true;
                            } else {
                                bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                            }
                            startIndex += subNum;
                        }
                    }

                    if (isPhased) {
                        alleles2 = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                    } else {
                        alleles2 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    }
                } else if (isPhased) {
                    alleles2 = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                } else {
                    alleles2 = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                }

                if (alleles2 == null) {
                    continue;
                }
                if (!sharedAlleles.containsKey(alleles2[0]) && !sharedAlleles.containsKey(alleles2[1])) {
                    hasShared = false;
                    break;
                }
            }
            isValid.add(hasShared);
            posIDMap.put(var.refStartPosition, isValid.size() - 1);
            //System.out.println(var.refStartPosition + "\t" + hasShared);
        }

        index1 = 0;
        index2 = 0;
        tmpVarList.clear();
        int regionLen = 0;
        int availbleIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            tmpIntSet.index1 = var.refStartPosition;
            index1 = posIDMap.get(tmpIntSet.index1);

            if (index1 <= 0) {
                var.setFeatureValue(availbleIndex, null);
                var.setFeatureValue(availbleIndex + 1, null);
                continue;
            }
            index1--;
            index2 = index1 + 1;
            while (index2 < varNum && isValid.getQuick(index2)) {
                index2++;
            }
            while (index1 >= 0 && isValid.getQuick(index1)) {
                index1--;
            }
            if (index2 >= varNum) {
                index2 = varNum - 1;
                endMak = "EndAtTail";
            }
            if (index1 < 0) {
                index1 = 0;
                startMak = "StartAtTail";
            }
            info.delete(0, info.length());
            info.append("chr").append(STAND_CHROM_NAMES[chromosome.getId()]).append(":").append(allVariants.get(index1).refStartPosition).append("-").append(allVariants.get(index2).refStartPosition)
                    .append("#Var:").append(index2 - index1 + 1);

            if (startMak.length() > 0) {
                info.append(startMak);
            }
            if (endMak.length() > 0) {
                info.append(endMak);
            }
            var.setFeatureValue(availbleIndex, info.toString());
            regionLen = allVariants.get(index2).refStartPosition - allVariants.get(index1).refStartPosition + 1;
            var.setFeatureValue(availbleIndex + 1, String.valueOf(regionLen));
            if (regionLen >= minIBS) {
                tmpVarList.add(var);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + tmpVarList.size());
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - tmpVarList.size());

        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        hitNum += tmpVarList.size();
        tmpVarList.clear();

        chromosome.buildVariantIndexMap();
        //testingGenome.buildVariantIndexMapOnChromosomes();
        //testingGenome.setVarNum(hitNum);
        //LOG.info(hitNum + " variant(s) are retained after filtered by IBS filtering!");
    }

    public void exploreLongHomozygosityRegion(Chromosome chromosome, AnnotationSummarySet ass, List<Variant> allVariants, int minIBS, boolean isPhased, List<Individual> subjectList, int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlSetID) {
        int caseNum = caeSetID.length;
        if (caseNum <= 0) {
            String info = "There is no patients. Identical by state (IBS) checking (--ibs-check) function doese not work!";
            LOG.info(info);
            return;
        }
        int controlNum = controlSetID.length;
        IntSet tmpIntSet = new IntSet(0, 0, (byte) 0);

        String endMak = "";
        String startMak = "";
        StringBuilder info = new StringBuilder();

        int[] alleles1 = null;
        int[] alleles2 = null;
        IntSetComparator1 intsetCmp = new IntSetComparator1();

        boolean hasShared = true;
        int index1 = 0, index2 = 0;
        int begIndex = 0;
        int hitNum = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        int subID = 0;

        if (chromosome == null) {
            return;
        }
        endMak = "";
        startMak = "";
        OpenIntIntHashMap posIDMap = new OpenIntIntHashMap();

        int base = 0;
        int alleleNum = 0;
        int varNum = allVariants.size();
        BooleanArrayList isValid = new BooleanArrayList(varNum);
        int startIndex;
        boolean[] bits = new boolean[32];
        int subNum = pedEncodeGytIDMap.length;
        for (Variant var : allVariants) {
            begIndex = 0;
            if (begIndex >= caseNum) {
                continue;
            }
            alleleNum = var.getAltAlleles().length + 1;
            if (isPhased) {
                base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
            } else {
                base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
            }
            hasShared = true;
            do {
                subID = caeSetID[begIndex];
                subID = pedEncodeGytIDMap[subID];
                if (subID < 0) {
                    begIndex++;
                    continue;
                }
                if (var.compressedGtyNum >= 0) {
                    if (var.compressedGtyNum == 0) {
                        Arrays.fill(bits, 0, base, false);
                    } else {
                        startIndex = subID;
                        for (int i = 0; i < base; i++) {
                            if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = false;
                            } else if (startIndex < var.compressedGty[0]) {
                                bits[i] = false;
                            } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = true;
                            } else if (startIndex == var.compressedGty[0]) {
                                bits[i] = true;
                            } else {
                                bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                            }
                            startIndex += subNum;
                        }
                    }
                    if (isPhased) {
                        alleles1 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    } else {
                        alleles1 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    }
                } else if (isPhased) {
                    alleles1 = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                } else {
                    alleles1 = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                }

                if (alleles1 == null) {
                    begIndex++;
                } else {
                    break;
                }
            } while (begIndex < caseNum);

            if (alleles1 == null) {
                isValid.add(true);
                posIDMap.put(var.refStartPosition, isValid.size() - 1);
                continue;
            }
            if (alleles1[0] != alleles1[1]) {
                isValid.add(false);
                posIDMap.put(var.refStartPosition, isValid.size() - 1);
                continue;
            }

            for (int j = begIndex + 1; j < caseNum; j++) {
                subID = caeSetID[j];
                subID = pedEncodeGytIDMap[subID];
                if (subID < 0) {
                    continue;
                }
                if (var.compressedGtyNum >= 0) {
                    if (var.compressedGtyNum == 0) {
                        Arrays.fill(bits, 0, base, false);
                    } else {
                        startIndex = subID;
                        for (int i = 0; i < base; i++) {
                            if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = false;
                            } else if (startIndex < var.compressedGty[0]) {
                                bits[i] = false;
                            } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = true;
                            } else if (startIndex == var.compressedGty[0]) {
                                bits[i] = true;
                            } else {
                                bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                            }
                            startIndex += subNum;
                        }
                    }
                    if (isPhased) {
                        alleles2 = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                    } else {
                        alleles2 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    }
                } else if (isPhased) {
                    alleles2 = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                } else {
                    alleles2 = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                }

                if (alleles2 == null) {
                    continue;
                }
                if (alleles2[0] != alleles2[1] || alleles2[0] != alleles1[0]) {
                    hasShared = false;
                    break;
                }
            }
            for (int j = 0; j < controlNum; j++) {
                subID = controlSetID[j];
                subID = pedEncodeGytIDMap[subID];
                if (subID < 0) {
                    continue;
                }
                if (var.compressedGtyNum >= 0) {
                    if (var.compressedGtyNum == 0) {
                        Arrays.fill(bits, 0, base, false);
                    } else {
                        startIndex = subID;
                        for (int i = 0; i < base; i++) {
                            if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = false;
                            } else if (startIndex < var.compressedGty[0]) {
                                bits[i] = false;
                            } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                bits[i] = true;
                            } else if (startIndex == var.compressedGty[0]) {
                                bits[i] = true;
                            } else {
                                bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                            }
                            startIndex += subNum;
                        }
                    }
                    if (isPhased) {
                        alleles2 = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                    } else {
                        // alleles2 = subjectList.get(subID).markerGtySetArray.getUnphasedGtyBool(pair.index2, pair.len);
                        alleles2 = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                    }
                } else if (isPhased) {
                    alleles2 = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                } else {
                    // alleles2 = subjectList.get(subID).markerGtySetArray.getUnphasedGtyBool(pair.index2, pair.len);
                    alleles2 = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, subNum);
                }

                if (alleles2 == null) {
                    continue;
                }
                if (alleles2[0] == alleles2[1] && alleles2[0] == alleles1[0]) {
                    hasShared = false;
                    break;
                }
            }
            isValid.add(hasShared);
            posIDMap.put(var.refStartPosition, isValid.size() - 1);
        }
        index1 = 0;
        index2 = 0;
        tmpVarList.clear();
        int regionLen = 0;
        int availableIndex = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            tmpIntSet.index1 = var.refStartPosition;
            index1 = posIDMap.get(tmpIntSet.index1);
            if (index1 <= 0) {
                var.setFeatureValue(availableIndex, null);
                var.setFeatureValue(availableIndex + 1, null);
                continue;
            }
            index1--;
            index2 = index1 + 1;
            while (index2 < varNum && isValid.getQuick(index2)) {
                index2++;
            }
            while (index1 >= 0 && isValid.getQuick(index1)) {
                index1--;
            }
            if (index2 >= varNum) {
                index2 = varNum - 1;
                endMak = "EndAtTail";
            }
            if (index1 < 0) {
                index1 = 0;
                startMak = "StartAtTail";
            }
            info.delete(0, info.length());
            info.append("chr").append(STAND_CHROM_NAMES[chromosome.getId()]).append(":").append(allVariants.get(index1).refStartPosition).append("-").append(allVariants.get(index2).refStartPosition)
                    .append("#Var:").append(index2 - index1 + 1);

            if (startMak.length() > 0) {
                info.append(startMak);
            }
            if (endMak.length() > 0) {
                info.append(endMak);
            }
            var.setFeatureValue(availableIndex, info.toString());
            regionLen = allVariants.get(index2).refStartPosition - allVariants.get(index1).refStartPosition + 1;
            var.setFeatureValue(availableIndex + 1, String.valueOf(regionLen));
            if (regionLen >= minIBS) {
                tmpVarList.add(var);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + tmpVarList.size());
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - tmpVarList.size());

        hitNum += tmpVarList.size();
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();

        chromosome.buildVariantIndexMap();

    }

    // model 0: allelic; 1: dominant; 2: recessive; 3: genotypic
    public void assocTestVar(Chromosome chromosome, AnnotationSummarySet ass, DoubleArrayList[] pValueList) throws Exception {

        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
//        Chromosome[] chroms = genome.getChromosomes();
        int[] caseGtys = new int[3];
        int[] controlGtys = new int[3];

        boolean hasLess5 = false;

        long[][] countsInt = new long[2][3];
        double[] oddsValues = new double[3];
        double[] pValues = new double[4];

        if (chromosome == null) {
            return;
        }
        int avialbleIndex = ass.getAvailableFeatureIndex();

        for (Variant var : chromosome.variantList) {
            Arrays.fill(caseGtys, 0);
            caseGtys[0] = var.getAffectedRefHomGtyNum();
            caseGtys[1] = var.getAffectedHetGtyNum();
            caseGtys[2] = var.getAffectedAltHomGtyNum();
            Arrays.fill(controlGtys, 0);
            controlGtys[0] = var.getUnaffectedRefHomGtyNum();
            controlGtys[1] = var.getUnaffectedHetGtyNum();
            controlGtys[2] = var.getUnaffectedAltHomGtyNum();
            /*
             * % wild risk % ___________ % case | A | B |Rs1 % |_____|_____|
             * % control | C | D |Rs2 % |_____|_____|____ % Cs1 Cs2 N
             */
            hasLess5 = false;
            // model 0: allelic;
            for (int k = 0; k < 2; k++) {
                Arrays.fill(countsInt[k], 0);
            }
            countsInt[0][0] = caseGtys[0] * 2 + caseGtys[1];
            countsInt[0][1] = caseGtys[2] * 2 + caseGtys[1];
            countsInt[1][0] = controlGtys[0] * 2 + controlGtys[1];
            countsInt[1][1] = controlGtys[2] * 2 + controlGtys[1];

            for (int k = 0; k < 2; k++) {
                for (int j = 0; j < 2; j++) {
                    if (countsInt[k][j] < 0) {
                        countsInt[k][j] = 0;
                    }
                    if (countsInt[k][j] < 5) {
                        hasLess5 = true;
                    }
                }
            }

            oddsValues[0] = ((double) countsInt[0][1] / (countsInt[1][1] == 0 ? 0.5f : countsInt[1][1]))
                    * ((double) countsInt[1][0] / (countsInt[0][0] == 0 ? 0.5f : countsInt[0][0]));
            if (hasLess5) {
                pValues[0] = ContingencyTable.fisherExact22(countsInt, 2, 2, 2);
            } else {
                pValues[0] = ContingencyTable.pearsonChiSquared22(countsInt);
                pValues[0] = Probability.chiSquareComplemented(1, pValues[0]);
            }
            if (!Double.isNaN(pValues[0])) {
                pValueList[0].add(pValues[0]);
            }

            hasLess5 = false;
            // 1: dominant;
            countsInt[0][0] = caseGtys[0];
            countsInt[0][1] = caseGtys[2] + caseGtys[1];
            countsInt[1][0] = controlGtys[0];
            countsInt[1][1] = controlGtys[2] + controlGtys[1];

            for (int k = 0; k < 2; k++) {
                for (int j = 0; j < 2; j++) {
                    if (countsInt[k][j] < 0) {
                        countsInt[k][j] = 0;
                    }
                    if (countsInt[k][j] < 5) {
                        hasLess5 = true;
                    }
                }
            }

            oddsValues[1] = ((double) countsInt[0][1] / (countsInt[1][1] == 0 ? 0.5f : countsInt[1][1]))
                    * ((double) countsInt[1][0] / (countsInt[0][0] == 0 ? 0.5f : countsInt[0][0]));
            if (hasLess5) {
                pValues[1] = ContingencyTable.fisherExact22(countsInt, 2, 2, 2);
            } else {
                pValues[1] = ContingencyTable.pearsonChiSquared22(countsInt);
                pValues[1] = Probability.chiSquareComplemented(1, pValues[1]);
            }

            if (!Double.isNaN(pValues[1])) {
                pValueList[1].add(pValues[1]);
            }
            hasLess5 = false;
            // 2: recessive; 3: genotypic
            countsInt[0][0] = caseGtys[0] + caseGtys[1];
            countsInt[0][1] = caseGtys[2];
            countsInt[1][0] = controlGtys[0] + controlGtys[1];
            countsInt[1][1] = controlGtys[2];

            for (int k = 0; k < 2; k++) {
                for (int j = 0; j < 2; j++) {
                    if (countsInt[k][j] < 0) {
                        countsInt[k][j] = 0;
                    }
                    if (countsInt[k][j] < 5) {
                        hasLess5 = true;
                    }
                }
            }

            oddsValues[2] = ((double) countsInt[0][1] / (countsInt[1][1] == 0 ? 0.5f : countsInt[1][1]))
                    * ((double) countsInt[1][0] / (countsInt[0][0] == 0 ? 0.5f : countsInt[0][0]));
            if (hasLess5) {
                pValues[2] = ContingencyTable.fisherExact22(countsInt, 2, 2, 2);
            } else {
                pValues[2] = ContingencyTable.pearsonChiSquared22(countsInt);
                pValues[2] = Probability.chiSquareComplemented(1, pValues[2]);
            }
            if (!Double.isNaN(pValues[2])) {
                pValueList[2].add(pValues[2]);
            }

            countsInt[0][0] = caseGtys[0];
            countsInt[0][1] = caseGtys[1];
            countsInt[0][2] = caseGtys[2];
            countsInt[1][0] = controlGtys[0];
            countsInt[1][1] = controlGtys[1];
            countsInt[1][2] = controlGtys[2];

            pValues[3] = ContingencyTable.chiSquareTest(countsInt);
            pValues[3] = Probability.chiSquareComplemented(2, pValues[3]);
            /*
             for (int k = 0; k < 2; k++) {
             for (int j = 0; j < 3; j++) {
             if (countsInt[k][j] < 0) {
             countsInt[k][j] = 0;
             }
             if (countsInt[k][j] < 5) {
             hasLess5 = true;
             }
             }
             }
             if (hasLess5) {
             pValues[3] = ContingencyTable.fisherExact22(countsInt, 2, 3, 2);
             } else {
             pValues[3] = ContingencyTable.chiSquareTest(countsInt);
             pValues[3] = Probability.chiSquareComplemented(2, pValues[3]);
             }*/

            for (int t = 0; t < 3; t++) {
                if (Double.isNaN(pValues[t])) {
                    var.setFeatureValue(avialbleIndex + t * 2, ".");
                } else {
                    var.setFeatureValue(avialbleIndex + t * 2, String.valueOf(pValues[t]));
                }

                if (Double.isNaN(oddsValues[t])) {
                    var.setFeatureValue(avialbleIndex + t * 2 + 1, ".");
                } else {
                    var.setFeatureValue(avialbleIndex + t * 2 + 1, String.valueOf(oddsValues[t]));
                }
            }
            if (!Double.isNaN(pValues[3])) {
                pValueList[3].add(pValues[3]);
                var.setFeatureValue(avialbleIndex + 6, String.valueOf(pValues[3]));
            } else {
                var.setFeatureValue(avialbleIndex + 6, ".");
            }
        }
    }

    public void pubMedIDGeneExploreGene(Chromosome chromosome, AnnotationSummarySet ass, List<String> pubmedMeshList, Map<String, String[]> geneNamesMap, Map<String, String> genePubMedID) throws Exception {
        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        String lastGeneSymb = null;
        String lastGeneFeature = null;
        int account = 1;
        List<String> geneNames = new ArrayList<String>();
        String[] names;

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGeneFeature = null;
        for (mRNA mrna : chromosome.mRNAList) {
            if (mrna.geneSymb != null) {
                if (lastGeneSymb != null && mrna.geneSymb.equals(lastGeneSymb)) {
                    mrna.addFeatureValue(lastGeneFeature);
                } else {
                    lastGeneFeature = genePubMedID.get(mrna.geneSymb);
                    if (lastGeneFeature == null) {
                        geneNames.clear();

                        names = geneNamesMap.get(mrna.geneSymb);
                        if (names != null && names.length > 0) {
                            geneNames.addAll(Arrays.asList(names));
                        }

                        geneNames.add(mrna.geneSymb);
                        LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                        lastGeneFeature = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);
                        account++;
                    }

                    lastGeneSymb = mrna.geneSymb;
                    mrna.addFeatureValue(lastGeneFeature);
                }
            } else {
                mrna.addFeatureValue(null);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + account);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - account);
    }

    public void pubMedIDIdeogramExploreVar(Chromosome chromosome, AnnotationSummarySet ass, List<String> pubmedMeshList, List<String[]> ideogramItems, String refGenomeVersion, boolean ignoreNonPathogenic, int driverPredicIndex) throws Exception {
        if (!pubmedMeshList.isEmpty() && pubmedMeshList.get(0).equals("ANY")) {
            return;
        }

        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        int account = 1;

        List<String> ideoGrams = null;
        Map<String, String> historyResultMap = new HashMap<String, String>();
        StringBuilder result = new StringBuilder();
        String predicType;

        if (chromosome == null) {
            return;
        }
        int featureNum = ass.getAvailableFeatureIndex();
        int hitNum = 0;
        for (Variant var : chromosome.variantList) {

            //only did it for missens variant
            if (var.smallestFeatureID == 6) {
                if (ignoreNonPathogenic && driverPredicIndex >= 0) {
                    predicType = var.getFeatureValues()[driverPredicIndex];
                    if (predicType != null && predicType.equals("N")) {
                        var.setFeatureValue(featureNum, null);
                        continue;
                    }
                }
            }

            result.delete(0, result.length());
            ideoGrams = searchIdeogramRegions(ideogramItems, chromosome.getName(), var.refStartPosition);
            for (String reg : ideoGrams) {
                // ignore regions which are two broad
                /*
                 * if (reg.indexOf(".") < 0) { continue; }
                 */
                String pubIDs = historyResultMap.get(reg);
                if (pubIDs == null) {
                    if (ignoreNonPathogenic && driverPredicIndex >= 0) {
                        predicType = var.getFeatureValues()[driverPredicIndex];
                        if (predicType != null && predicType.equals("N")) {
                            var.setFeatureValue(featureNum, null);
                            continue;
                        }
                    }

                    LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + reg);
                    while ((pubIDs = ncbiRetriever.pubMedIDESearch(pubmedMeshList, reg)) == null) {
                        // System.out.print("reconnecting...");
                    }

                    // System.out.println(pubIDs);
                    if (pubIDs == null) {
                        pubIDs = "";
                    }
                    // System.out.println();
                    historyResultMap.put(reg, pubIDs);
                    account++;
                }
                if (pubIDs.trim().length() > 0) {
                    result.append(reg).append(":[").append(pubIDs).append("] ");
                }
            }
            if (result != null && result.length() > 0) {
                hitNum++;
            }
            var.setFeatureValue(featureNum, result.toString());
        }

        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - hitNum);
    }

    public void pubMedIDGeneExploreVar(Chromosome chromosome, AnnotationSummarySet ass, List<String> pubmedMeshList, boolean ignoreNonPathogenic, Map<String, String[]> geneNamesMap, Map<String, String> genePubMedID, int driverPredicIndex) throws Exception {
        NCBIRetriever ncbiRetriever = new NCBIRetriever();

        String lastGeneSymb = null;
        String lastGeneFeature = null;
        int account = 1;
        String predicType = null;
        List<String> geneNames = new ArrayList<String>();

        if (chromosome == null) {
            return;
        }
        lastGeneSymb = null;
        lastGeneFeature = null;
        int featureNum = ass.getAvailableFeatureIndex();
        int hitNum = 0;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                //only did it for missens variant
                if (var.smallestFeatureID == 6) {
                    if (ignoreNonPathogenic && driverPredicIndex >= 0) {
                        predicType = var.getFeatureValues()[driverPredicIndex];
                        if (predicType != null && predicType.equals("N")) {
                            var.setFeatureValue(featureNum, null);
                            continue;
                        }
                    }
                }
                if (lastGeneSymb != null && var.geneSymb.equals(lastGeneSymb)) {
                    var.setFeatureValue(featureNum, lastGeneFeature);
                } else {
                    lastGeneFeature = genePubMedID.get(var.geneSymb);
                    if (lastGeneFeature == null) {
                        geneNames.clear();
                        // unforturnately after I add the alais, there are
                        // too many false postive hits
                        // so I finally withraw this function
                        String[] names = geneNamesMap.get(var.geneSymb);
                        if (names != null && names.length > 0) {
                            geneNames.addAll(Arrays.asList(names));
                        }

                        geneNames.add(var.geneSymb);

                        LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + geneNames.toString());
                        lastGeneFeature = ncbiRetriever.pubMedIDESearch(pubmedMeshList, geneNames, pubMedFilter, 10);
                        account++;
                        //System.out.println(lastGeneFeature);
                    }

                    lastGeneSymb = var.geneSymb;
                    var.setFeatureValue(featureNum, lastGeneFeature);
                }
                if (lastGeneFeature != null && lastGeneFeature.length() > 0) {
                    hitNum++;
                }
            } else {
                var.setFeatureValue(featureNum, null);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + hitNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - hitNum);
    }

    // Read ChrPosRs File
    public void readChrPosRs(OpenIntIntHashMap[] altMapID, File resourceFileRSID)
            throws FileNotFoundException, IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(resourceFileRSID))));
        String line = null;
        while ((line = reader.readLine()) != null) {
            String[] array = line.split("\t");
            int id = Integer.parseInt(array[0]);
            int chr = 0;
            if (array[1].equals("AltOnly") || array[1].equals("NotOn") || array[1].equals("PAR") || array[1].equals("Multi") || array[1].equals("") || array[2].equals("")) {
                continue;
            }
            if (array[1].matches("\\d+")) {
                chr = Integer.parseInt(array[1]);
            } else if (array[1].equals("X")) {
                chr = 23;
            } else if (array[1].equals("Y")) {
                chr = 24;
            } else if (array[1].equals("XY")) {
                chr = 25;
            } else if (array[1].equals("MT")) {
                chr = 26;
            } else if (array[1].equals("Un")) {
                chr = 27;
            }
            int index = chr - 1;
            int pos = Integer.parseInt(array[2]);
            // pos in dbsnp SNPChrPosOnRef is 0-based, So we changed it into 1-based and save in hashMap
            pos++;
            altMapID[index].put(pos, id);
        }
        reader.close();
    }

    public void addRSID(Chromosome chr, AnnotationSummarySet ass, OpenIntIntHashMap altMapID) {
        int total = 0;
        int annotNum = 0;
        String chrNam = chr.getName();
        for (Variant var : chr.variantList) {
            int pos = var.refStartPosition;
            total++;
            if (altMapID.containsKey(pos)) {
                annotNum++;
                var.label = "rs" + altMapID.get(pos);
            } else {
                var.label = chrNam + ":" + pos;
            }
        }
        ass.setAnnotNum(ass.getAnnotNum() + annotNum);
        ass.setTotalNum(ass.getTotalNum() + total);
        ass.setLeftNum(ass.getLeftNum() + total - annotNum);
    }

    public void assignSelectedVar2Genes(List<Variant> variantList, String chrName, Map<String, List<Variant>> geneVars, Set<Byte> varFeatureSet) {
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        int index;
        Set<String> geneSet = new HashSet<String>();
        Map<String, Set<String>> unifyingSet = new HashMap<String, Set<String>>();
        Map<String, int[]> geneVarNum = new HashMap<String, int[]>();
        StringBuilder id = new StringBuilder();
        for (Variant var : variantList) {
            String strGene = var.geneSymb;
            if (strGene == null) {
                continue;
            }
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            if (sb.length() > 0) {
                geneVarNum.clear();
                extractAllGeneVarsByFeatures(geneVarNum, sb, varFeatureSet, null);
                sb.delete(0, sb.length());

                geneSet.addAll(geneVarNum.keySet());

            }
            if (var.label == null || var.label.equals(".")) {
                id.append(chrName).append(':').append(var.refStartPosition).append(":").append(var.getRefAllele());
                for (String altA : var.getAltAlleles()) {
                    id.append(":");
                    id.append(altA);
                }
                var.label = id.toString();
                id.delete(0, id.length());
            }
           

            for (String strGene1 : geneSet) {

                List<Variant> vars = geneVars.get(strGene1);
                Set<String> idSet = unifyingSet.get(strGene1);

                if (vars == null) {
                    vars = new ArrayList<Variant>();
                    geneVars.put(strGene1, vars);

                    idSet = new HashSet<String>();
                    unifyingSet.put(strGene1, idSet);
                }
                if (!idSet.contains(var.label)) {
                    vars.add(var);
                    idSet.add(var.label);
                }
            }

            geneSet.clear();
        }
        unifyingSet.clear();

    }

    public void cleanGtyAtGeneWithTooManyVarInIndividual(Map<String, List<Variant>> geneVars, boolean isPhasedGty,
            int[] pedEncodeGytIDMap, int[] caeSetIDs, int[] controlIDs, double maxDiffMutPerGenePerPerson, int maxThreadNum) throws Exception {

        // multiple thread   class
        class CleanGtyTask implements Callable<String> {

            String geneSymb;
            List<Variant> geneDisVars;

            public CleanGtyTask(List<Variant> geneDisVars) {
                this.geneDisVars = geneDisVars;
            }

            @Override
            public String call() {
                int controlNum = controlIDs.length, caseNum = caeSetIDs.length;
                int[] gtys;
                int subNum = pedEncodeGytIDMap.length;
                int num = 0, size, gtyID;

                double[] caseMutNums = new double[caseNum];
                double[] controlMutNums = new double[controlNum];

                double median, diff;
                String label;

                // try to remove outlier variants; however it seems not necessary because var with too high freq in patients have been excluded by --filter-sample-maf-oe
                //but this is a relative diff; I do not know
                double med, count, factor = 10;
                DoubleArrayList counts = new DoubleArrayList();
                for (Variant tVar : geneDisVars) {
                    count = tVar.getAffectedHetGtyNum() + tVar.getAffectedAltHomGtyNum() * 2;
                    counts.add(count);

                }
                counts.quickSort();
                med = Descriptive.median(counts);
                if(med==0){
                    med=1;
                }
                med = med * factor;

                for (Variant tVar : geneDisVars) {
                    count = tVar.getAffectedHetGtyNum() + tVar.getAffectedAltHomGtyNum() * 2;
                    
                    if (count > med) {
//set the gnotypes of all individuals as missing 
                        for (int j = 0; j < caseNum; j++) {
                            gtyID = caeSetIDs[j];
                            modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                        }
                        for (int j = 0; j < controlNum; j++) {
                            gtyID = controlIDs[j];
                            modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                        }
                    }
                }

                Set<String> excludedVarsInCases = new HashSet<String>();
                Set<String> excludedVarsInControls = new HashSet<String>();

                Arrays.fill(caseMutNums, 0);
                for (int j = 0; j < caseNum; j++) {
                    gtyID = caeSetIDs[j];
                    for (Variant tVar : geneDisVars) {
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0) {
                            caseMutNums[j]++;
                        }
                        if (gtys[1] != 0) {
                            caseMutNums[j]++;
                        }
                    }
                }

                if (caseNum > 2) {
                    //relativeMutNums = scl.robustZScore(caseMutNums, true);
                    median = StdStats.median(caseMutNums);
                    for (int j = 0; j < caseMutNums.length; j++) {
                        diff = Math.abs(median - caseMutNums[j]);
                        if (median < 1) {
                            if (diff <= maxDiffMutPerGenePerPerson) {
                                continue;
                            }
                        } else if (diff <= median * maxDiffMutPerGenePerPerson) {
                            continue;
                        }
                        gtyID = caeSetIDs[j];
                        //LOG.info("Subject " + gtyID + " of gene " + item.getKey() + " is removed because he/she has " + ((int) caseMutNums[j]) + " mutations in this gene!");
                        for (Variant tVar : geneDisVars) {
                            label = j + ":" + tVar.refStartPosition;
                            if (excludedVarsInCases.contains(label)) {
                                continue;
                            } else {
                                excludedVarsInCases.add(label);
                            }

                            //some analysis directly use the counts
                            gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                            if (gtys == null) {
                                continue;
                            }
                            if (gtys[0] != 0 && gtys[1] != 0) {
                                num = tVar.getAffectedAltHomGtyNum();
                                num--;
                                tVar.setAffectedAltHomGtyNum(num);
                            } else if (gtys[0] != 0 || gtys[1] != 0) {
                                num = tVar.getAffectedHetGtyNum();
                                num--;
                                tVar.setAffectedHetGtyNum(num);
                            } else if (gtys[0] == 0 && gtys[1] == 0) {
                                num = tVar.getAffectedRefHomGtyNum();
                                num--;
                                tVar.setAffectedRefHomGtyNum(num);
                            }
//set the gnotypes as missing 
                            modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                        }
                    }
                }

                num = 0;
                Arrays.fill(controlMutNums, 0);
                for (int j = 0; j < controlNum; j++) {
                    gtyID = controlIDs[j];

                    for (Variant tVar : geneDisVars) {
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0) {
                            controlMutNums[j]++;
                        }
                        if (gtys[1] != 0) {
                            controlMutNums[j]++;
                        }
                    }
                }

                //relativeMutNums = scl.robustZScore(controlMutNums, true);
                if (controlNum > 2) {
                    median = StdStats.median(controlMutNums);
                    for (int j = 0; j < controlMutNums.length; j++) {
                        diff = Math.abs(median - controlMutNums[j]);
                        if (median < 1) {
                            if (diff <= maxDiffMutPerGenePerPerson) {
                                continue;
                            }
                        } else if (diff <= median * maxDiffMutPerGenePerPerson) {
                            continue;
                        }
                        gtyID = controlIDs[j];

                        for (Variant tVar : geneDisVars) {
                            label = j + ":" + tVar.refStartPosition;
                            if (excludedVarsInControls.contains(label)) {
                                continue;
                            } else {
                                excludedVarsInControls.add(label);
                            }

                            //some analysis directly use the counts
                            gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                            if (gtys == null) {
                                continue;
                            }
                            if (gtys[0] != 0 && gtys[1] != 0) {
                                num = tVar.getUnaffectedAltHomGtyNum();
                                num--;
                                tVar.setUnaffectedAltHomGtyNum(num);
                            } else if (gtys[0] != 0 || gtys[1] != 0) {
                                num = tVar.getUnaffectedHetGtyNum();
                                num--;
                                tVar.setUnaffectedHetGtyNum(num);
                            } else if (gtys[0] == 0 && gtys[1] == 0) {
                                num = tVar.getUnaffectedRefHomGtyNum();
                                num--;
                                tVar.setUnaffectedRefHomGtyNum(num);
                            }
                            //set the gnotypes as missing 
                            modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                        }
                    }

                }
                return "finished";
            }

        }

        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<>(exec);

        int runningThreads = 0;
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars = item.getValue();
            CleanGtyTask cgt = new CleanGtyTask(geneDisVars);
            serv.submit(cgt);
            runningThreads++;
        }
        for (int t = 0; t < runningThreads; t++) {
            serv.take();
        }
        exec.shutdown();

    }

    public void cleanGtyAtGeneWithTooManyVarInIndividual(Map<String, List<Variant>> geneVars, boolean isPhasedGty, int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlIDs, double maxDiffMutPerGenePerPerson) {
        int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID;

        int[] gtys;
        int subNum = pedEncodeGytIDMap.length;
        int num, size;

        List<Variant> geneDisVars = new ArrayList<Variant>();
        double[] caseMutNums = new double[caseNum];
        double[] controlMutNums = new double[controlNum];
        double[] relativeMutNums;
        OutlierDetector scl = new OutlierDetector();
        double pCut = 0.001;
        double median, diff;

        Set<String> excludedVarsInCases = new HashSet<String>();
        Set<String> excludedVarsInControls = new HashSet<String>();
        String label;
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars0 = item.getValue();

            geneDisVars.clear();
            geneDisVars.addAll(geneDisVars0);
            excludedVarsInCases.clear();
            excludedVarsInControls.clear();

            num = 0;
            Arrays.fill(caseMutNums, 0);
            for (int j = 0; j < caseNum; j++) {
                gtyID = caeSetID[j];
                for (Variant tVar : geneDisVars) {
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        caseMutNums[j]++;
                    }
                    if (gtys[1] != 0) {
                        caseMutNums[j]++;
                    }
                }
            }

            if (caseNum > 2) {
                //relativeMutNums = scl.robustZScore(caseMutNums, true);
                median = StdStats.median(caseMutNums);
                for (int j = 0; j < caseMutNums.length; j++) {
                    diff = Math.abs(median - caseMutNums[j]);
                    if (median < 1) {
                        if (diff <= maxDiffMutPerGenePerPerson) {
                            continue;
                        }
                    } else if (diff <= median * maxDiffMutPerGenePerPerson) {
                        continue;
                    }
                    gtyID = caeSetID[j];
                    //LOG.info("Subject " + gtyID + " of gene " + item.getKey() + " is removed because he/she has " + ((int) caseMutNums[j]) + " mutations in this gene!");
                    for (Variant tVar : geneDisVars) {
                        label = j + ":" + tVar.refStartPosition;
                        if (excludedVarsInCases.contains(label)) {
                            continue;
                        } else {
                            excludedVarsInCases.add(label);
                        }

                        //some analysis directly use the counts
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0 && gtys[1] != 0) {
                            num = tVar.getAffectedAltHomGtyNum();
                            num--;
                            tVar.setAffectedAltHomGtyNum(num);
                        } else if (gtys[0] != 0 || gtys[1] != 0) {
                            num = tVar.getAffectedHetGtyNum();
                            num--;
                            tVar.setAffectedHetGtyNum(num);
                        } else if (gtys[0] == 0 && gtys[1] == 0) {
                            num = tVar.getAffectedRefHomGtyNum();
                            num--;
                            tVar.setAffectedRefHomGtyNum(num);
                        }
//set the gnotypes as missing 
                        modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                    }
                }
            }

            num = 0;
            Arrays.fill(controlMutNums, 0);
            for (int j = 0; j < controlNum; j++) {
                gtyID = controlIDs[j];

                for (Variant tVar : geneDisVars) {
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        controlMutNums[j]++;
                    }
                    if (gtys[1] != 0) {
                        controlMutNums[j]++;
                    }
                }
            }

            //relativeMutNums = scl.robustZScore(controlMutNums, true);
            if (controlNum > 2) {
                median = StdStats.median(controlMutNums);
                for (int j = 0; j < controlMutNums.length; j++) {
                    diff = Math.abs(median - controlMutNums[j]);
                    if (median < 1) {
                        if (diff <= maxDiffMutPerGenePerPerson) {
                            continue;
                        }
                    } else if (diff <= median * maxDiffMutPerGenePerPerson) {
                        continue;
                    }
                    gtyID = controlIDs[j];

                    for (Variant tVar : geneDisVars) {
                        label = j + ":" + tVar.refStartPosition;
                        if (excludedVarsInControls.contains(label)) {
                            continue;
                        } else {
                            excludedVarsInControls.add(label);
                        }

                        //some analysis directly use the counts
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0 && gtys[1] != 0) {
                            num = tVar.getUnaffectedAltHomGtyNum();
                            num--;
                            tVar.setUnaffectedAltHomGtyNum(num);
                        } else if (gtys[0] != 0 || gtys[1] != 0) {
                            num = tVar.getUnaffectedHetGtyNum();
                            num--;
                            tVar.setUnaffectedHetGtyNum(num);
                        } else if (gtys[0] == 0 && gtys[1] == 0) {
                            num = tVar.getUnaffectedRefHomGtyNum();
                            num--;
                            tVar.setUnaffectedRefHomGtyNum(num);
                        }
                        //set the gnotypes as missing 
                        modifyVarGty(tVar, isPhasedGty, subNum, gtyID, new int[]{-1, -1});
                    }
                }

            }

        }

    }

    private int[] getVarGty(Variant var, boolean isPhasedGty, int subNum, int gtyID) {
        int startIndex, base;
        boolean[] bits = new boolean[32];
        int[] gtys = null;
        int alleleNum = var.getAltAlleles().length + 1;
        if (isPhasedGty) {
            base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
            if (var.compressedGtyNum >= 0) {
                if (var.compressedGtyNum == 0) {
                    Arrays.fill(bits, 0, base, false);
                } else {
                    startIndex = gtyID;
                    for (int i = 0; i < base; i++) {
                        if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = false;
                        } else if (startIndex < var.compressedGty[0]) {
                            bits[i] = false;
                        } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = true;
                        } else if (startIndex == var.compressedGty[0]) {
                            bits[i] = true;
                        } else {
                            bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                        }
                        startIndex += subNum;
                    }
                }
                gtys = bgp.getPhasedGtyBool(bits, alleleNum, base, gtyID);
            } else {
                gtys = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, gtyID, subNum);
            }

        } else {
            base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
            if (var.compressedGtyNum >= 0) {
                if (var.compressedGtyNum == 0) {
                    Arrays.fill(bits, 0, base, false);
                } else {
                    startIndex = gtyID;
                    for (int i = 0; i < base; i++) {
                        if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = false;
                        } else if (startIndex < var.compressedGty[0]) {
                            bits[i] = false;
                        } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = true;
                        } else if (startIndex == var.compressedGty[0]) {
                            bits[i] = true;
                        } else {
                            bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                        }
                        startIndex += subNum;
                    }
                }
                gtys = bgp.getUnphasedGtyBool(bits, alleleNum, base, gtyID);
            } else {
                gtys = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, gtyID, subNum);
            }

        }

        return gtys;
    }

    private int[] deleteByValue(int[] values, int value) {
        int index = Arrays.binarySearch(values, value);
        if (index < 0) {
            return null;
        }
        int[] newList = new int[values.length - 1];
        System.arraycopy(values, 0, newList, 0, index);
        System.arraycopy(values, index + 1, newList, index, newList.length - index);
        return newList;
    }

    private int[] addAValue(int[] values, int value) {
        int index = Arrays.binarySearch(values, value);
        if (index >= 0) {
            return null;
        }
        index = -index - 1;
        int[] newList = new int[values.length + 1];
        if (index == values.length) {
            System.arraycopy(values, 0, newList, 0, index);
            newList[index] = value;
        } else {
            System.arraycopy(values, 0, newList, 0, index + 1);
            newList[index] = value;
            System.arraycopy(values, index, newList, index + 1, values.length - index);
        }
        return newList;
    }

    //only implemented for biallelic variants 
    private void modifyVarGty(Variant var, boolean isPhasedGty, int subNum, int gtyID, int[] newGty) {
        int startIndex, base;
        boolean[] bits = new boolean[32];
        int[] gtys = null;
        int alleleNum = var.getAltAlleles().length + 1;

//        System.out.println(var.refStartPosition);
//        if (var.refStartPosition == 197099171) {
//            int sss = 0;
//        }
        if (isPhasedGty) {
            base = GlobalManager.phasedAlleleBitMap.get(alleleNum);

            if (var.compressedGtyNum >= 0) {
                if (var.compressedGtyNum == 0) {
                    Arrays.fill(bits, 0, base, false);
                } else {
                    startIndex = gtyID;
                    for (int i = 0; i < base; i++) {
                        if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = false;
                        } else if (startIndex < var.compressedGty[0]) {
                            bits[i] = false;
                        } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = true;
                        } else if (startIndex == var.compressedGty[0]) {
                            bits[i] = true;
                        } else {
                            bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                        }
                        startIndex += subNum;
                    }
                }
                /*
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	        000  	001	010	011	100
                 Order	0	1	2	3	4   
                 */
                if (newGty[0] == 0 && newGty[1] == 0) {
                    if (!bits[0] && !bits[1] && !bits[2]) {
                        // return new int[]{0, 0};
                    } else if (!bits[0] && !bits[1] && bits[2]) {
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        // return new int[]{0, 1};
                    } else if (!bits[0] && bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        //return new int[]{1, 0};
                    } else if (!bits[0] && bits[1] && bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        //return new int[]{1, 1};
                    } else if (bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        // return null;
                    }

                } else if (newGty[0] == 0 && newGty[1] == 1) {
                    /*
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	            000  	001	010	011	100
                 Order	0	1	2	3	4   
                     */
                    if (!bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 0};
                    } else if (!bits[0] && !bits[1] && bits[2]) {

                        // return new int[]{0, 1};
                    } else if (!bits[0] && bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{1, 0};
                    } else if (!bits[0] && bits[1] && bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        //return new int[]{1, 1};
                    } else if (bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return null;
                    }
                } else if (newGty[0] == 1 && newGty[1] == 0) {
                    /*
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	            000  	001	010	011	100
                 Order	0	1	2	3	4   
                     */
                    if (!bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 0};
                    } else if (!bits[0] && !bits[1] && bits[2]) {
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 1};
                    } else if (!bits[0] && bits[1] && !bits[2]) {

                        //return new int[]{1, 0};
                    } else if (!bits[0] && bits[1] && bits[2]) {
                        startIndex = gtyID + subNum * 2;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        //return new int[]{1, 1};
                    } else if (bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return null;
                    }
                } else if (newGty[0] == 1 && newGty[1] == 1) {

                    /*
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	            000  	001	010	011	100
                 Order	0	1	2	3	4   
                     */
                    if (!bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 0};
                    } else if (!bits[0] && !bits[1] && bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 1};
                    } else if (!bits[0] && bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{1, 0};
                    } else if (!bits[0] && bits[1] && bits[2]) {

                        //return new int[]{1, 1};
                    } else if (bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return null;
                    }

                } else {
                    //the new must be missing values
                    /*
                             missing	Reference homozygous	Heterozygous 	Heterozygous 	Alternative homozygous
                 VCF genotype		0|0	0|1	1|0	1|1 .|.
                 Bits	            000  	001	010	011	100
                 Order	0	1	2	3	4   
                     */
                    if (!bits[0] && !bits[1] && !bits[2]) {
                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);

                        // return new int[]{0, 0};
                    } else if (!bits[0] && !bits[1] && bits[2]) {
                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);

                        // return new int[]{0, 1};
                    } else if (!bits[0] && bits[1] && !bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{1, 0};
                    } else if (!bits[0] && bits[1] && bits[2]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        startIndex = gtyID + subNum + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{1, 1};
                    } else if (bits[0] && !bits[1] && !bits[2]) {

                        // return null;
                    }

                }
                var.compressedGtyNum = var.compressedGty.length;

            } else {
                bgp.setPhasedGtyAt(var.encodedGty, alleleNum, base, gtyID, subNum, newGty);
            }

        } else {
            base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
            if (var.compressedGtyNum >= 0) {
                if (var.compressedGtyNum == 0) {
                    Arrays.fill(bits, 0, base, false);
                } else {
                    startIndex = gtyID;
                    for (int i = 0; i < base; i++) {
                        if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = false;
                        } else if (startIndex < var.compressedGty[0]) {
                            bits[i] = false;
                        } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                            bits[i] = true;
                        } else if (startIndex == var.compressedGty[0]) {
                            bits[i] = true;
                        } else {
                            bits[i] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                        }
                        startIndex += subNum;
                    }
                }

                if (newGty[0] == 0 && newGty[1] == 0) {
                    /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                 Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                     */
                    if (!bits[0] && !bits[1]) {
                        //return new int[]{0, 0};
                    } else if (!bits[0] && bits[1]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        // return new int[]{0, 1};
                    } else if (bits[0] && !bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        // return new int[]{1, 1};
                    } else if (bits[0] && bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        //return null;
                    }

                } else if ((newGty[0] == 0 && newGty[1] == 1) || (newGty[0] == 1 && newGty[1] == 0)) {
                    /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                 Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                     */
                    if (!bits[0] && !bits[1]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{0, 0};
                    } else if (!bits[0] && bits[1]) {

                        // return new int[]{0, 1};
                    } else if (bits[0] && !bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{1, 1};
                    } else if (bits[0] && bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        //return null;
                    }
                } else if (newGty[0] == 1 && newGty[1] == 1) {
                    /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                   Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                     */
                    if (!bits[0] && !bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{0, 0};
                    } else if (!bits[0] && bits[1]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 1};
                    } else if (bits[0] && !bits[1]) {

                        // return new int[]{1, 1};
                    } else if (bits[0] && bits[1]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = deleteByValue(var.compressedGty, startIndex);

                        //return null;
                    }
                } else {
                    /*
                 missing	  Reference homozygous	 Heterozygous 	Alternative homozygous
                 VCF genotype	  0/0	       0/1	         1/1  ./.	           
                   Bits           00          01	       10	         11
                 Order	         0	              1	                2	         3        
                     */
                    if (!bits[0] && !bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        //return new int[]{0, 0};
                    } else if (!bits[0] && bits[1]) {
                        startIndex = gtyID;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{0, 1};
                    } else if (bits[0] && !bits[1]) {
                        startIndex = gtyID + subNum;
                        var.compressedGty = addAValue(var.compressedGty, startIndex);
                        // return new int[]{1, 1};
                    } else if (bits[0] && bits[1]) {

                        //return null;
                    }
                }
                var.compressedGtyNum = var.compressedGty.length;
            } else {
                bgp.setUnphasedGtyAt(var.encodedGty, alleleNum, base, gtyID, subNum, newGty);
            }

        }

    }

    public void summarizeVarCountsBySubject(Map<String, List<Variant>> geneVars, OpenLongObjectHashMap wahBit, List<Individual> subjectList, int[] pedEncodeGytIDMap, boolean isPhasedGty, Map<String, Integer> geneAlleCount) throws Exception {
        if (geneVars == null) {
            return;
        }
        int[] gtys = null;
        int alleleNum, base = 2;
        int subID = -1;
        int gtyID = 0;
        int count;

        boolean[] bits = new boolean[32];
        int startIndex;
        int subNum = subjectList.size();
        for (Individual indiv : subjectList) {
            if (indiv == null) {
                continue;
            }

            subID++;
            gtyID = pedEncodeGytIDMap[subID];
            if (gtyID < 0) {
                continue;
            }

            for (Map.Entry<String, List<Variant>> items : geneVars.entrySet()) {
                List<Variant> vars = items.getValue();
                count = 0;
                for (Variant var : vars) {
                    gtys = this.getVarGty(var, isPhasedGty, subNum, gtyID);
                    if (gtys != null) {
                        if (gtys[0] != 0) {
                            count++;
                        }
                        if (gtys[1] != 0) {
                            count++;
                        }
                    }
                }
                geneAlleCount.put(items.getKey(), count);
            }
        }

    }

    public void assignSelectedVar2Genesets(Map<String, GeneSet> dbPathwaySet, Map<String, List<Variant>> geneVars,
            Map<String, List<Variant>> genesetVars, byte chrID, List<Variant> invlovledVariantListst) {
        Map<String, Set<String>> unifyingSet = new HashMap<String, Set<String>>();
        Set<String> idSetAll = new HashSet<String>();
        for (Map.Entry<String, GeneSet> item : dbPathwaySet.entrySet()) {
            GeneSet refGeneSet = item.getValue();
            Set<String> geneSet = refGeneSet.getGeneSymbols();

            List<Variant> vars1 = genesetVars.get(item.getKey());
            Set<String> idSet = unifyingSet.get(item.getKey());
            if (vars1 == null) {
                vars1 = new ArrayList<Variant>();
                genesetVars.put(item.getKey(), vars1);
            }
            if (idSet == null) {
                idSet = new HashSet<String>();
                unifyingSet.put(item.getKey(), idSet);
            }
            for (String gen : geneSet) {
                List<Variant> vars = geneVars.get(gen);
                if (vars == null) {
                    continue;
                }

                for (Variant var : vars) {
                    if (!idSet.contains(var.label)) {
                        var.chrID = chrID;
                        vars1.add(var);
                        idSet.add(var.label);
                    }
                    if (!idSetAll.contains(var.label)) {
                        idSetAll.add(var.label);
                        invlovledVariantListst.add(var);
                    }
                }
            }
        }
        idSetAll.clear();
        unifyingSet.clear();

    }

    public void extractGeneSampleMuations(Map<String, List<Variant>> geneVars, boolean isPhasedGty,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlIDs, int scoreIndex, Map<String, double[]> geneSampleMuts, String chrName, Map<String, String[]> genePositions) {
        int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID, count;

        int[] gtys;
        int subNum = pedEncodeGytIDMap.length;
        scoreIndex++;
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars = item.getValue();
            double[] subMutations = geneSampleMuts.get(item.getKey());
            if (subMutations == null) {
                subMutations = new double[caseNum + controlNum];
                geneSampleMuts.put(item.getKey(), subMutations);
            }
            boolean considerScore = false;
            if (scoreIndex > 0) {
                considerScore = true;
            }
            String[] features;
            for (int j = 0; j < caseNum; j++) {
                gtyID = caeSetID[j];
                count = 0;
                for (Variant tVar : geneDisVars) {
                    if (considerScore) {
                        features = tVar.getFeatureValues();
                        if (features == null || features[scoreIndex] == null || !features[scoreIndex].equals("Y")) {
                            continue;
                        }
                    }
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                    }
                }
                if (count == 0) {
                    subMutations[j] = -1;
                } else {
                    subMutations[j] = count;
                }
            }
            for (int j = 0; j < controlNum; j++) {
                gtyID = controlIDs[j];
                count = 0;
                for (Variant tVar : geneDisVars) {
                    if (considerScore) {
                        features = tVar.getFeatureValues();
                        if (features == null || features[scoreIndex] == null || !features[scoreIndex].equals("Y")) {
                            continue;
                        }
                    }
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                    }
                }
                if (count == 0) {
                    subMutations[caseNum + j] = -1;
                } else {
                    subMutations[caseNum + j] = count;
                }
            }
            genePositions.put(item.getKey(),
                    new String[]{chrName, String.valueOf(geneDisVars.get(0).refStartPosition), String.valueOf(geneDisVars.get(geneDisVars.size() - 1).refStartPosition)});
        }
    }

    public void extractGeneSampleMuationScores0(Map<String, List<Variant>> geneVars, boolean isPhasedGty,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlIDs, int scoreIndex, Map<String, FloatArrayList[]> geneSampleMuts, DoubleArrayList rareMutScores, String chrName, Map<String, String[]> genePositions, double minCCFreqRatio) {
        int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID, count, totalCount;

        int[] gtys;
        int subNum = pedEncodeGytIDMap.length;
        int num, size;
        float score, avgScore;
        String[] features;
        Set<Integer> effectiveScoreIndex = new HashSet<Integer>();
        double maxAltf = 0.5, maf1, maf2, hetAff, homAff, totalAff, hetUnaff, homUnaff, totalUnaff;
        List<Variant> geneDisVars = new ArrayList<Variant>();
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars0 = item.getValue();

            geneDisVars.clear();
            if (minCCFreqRatio > 0) {
                for (Variant var : geneDisVars0) {
                    hetAff = var.getAffectedHetGtyNum();
                    homAff = var.getAffectedAltHomGtyNum();
                    totalAff = var.getAffectedRefHomGtyNum() + hetAff + homAff;
                    hetUnaff = var.getUnaffectedHetGtyNum();
                    homUnaff = var.getUnaffectedAltHomGtyNum();
                    totalUnaff = var.getUnaffectedRefHomGtyNum() + hetUnaff + homUnaff;
                    maf1 = (0.5 * hetAff + homAff) / totalAff;

                    maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;

                    if (Double.isNaN(maf2)) {
                        //no unaffected sample
                        geneDisVars.add(var);
                    } else if (maf1 >= maf2 * minCCFreqRatio) {
                        geneDisVars.add(var);
                    }
                }
            } else {
                geneDisVars.addAll(geneDisVars0);
            }

            //rows are subject and columns are variants
            FloatArrayList[] subjectMutations = new FloatArrayList[caseNum + controlNum];
            for (int j = 0; j < subjectMutations.length; j++) {
                subjectMutations[j] = new FloatArrayList();
            }
            totalCount = 0;
            effectiveScoreIndex.clear();
            avgScore = 0;
            num = 0;

            for (int j = 0; j < caseNum; j++) {
                gtyID = caeSetID[j];

                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    features = tVar.getFeatureValues();

                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        subjectMutations[j].add(0);
                        subjectMutations[j].add(0);
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        //the first is count and the second is the weight
                        subjectMutations[j].add(count);
                        if (scoreIndex >= 0) {
                            if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                                subjectMutations[j].add(-1);
                            } else {
                                score = Float.parseFloat(features[scoreIndex]);

                                subjectMutations[j].add(score);
                                avgScore += score;
                                num++;
                            }
                        } else {
                            subjectMutations[j].add(1);
                        }

                        effectiveScoreIndex.add(tVar.refStartPosition);
                    } else {
                        //to keep the order of the variant list for later calculation
                        subjectMutations[j].add(0);
                        subjectMutations[j].add(0);
                    }
                }
            }
            if (scoreIndex >= 0) {
                avgScore /= num;
                for (int j = 0; j < caseNum; j++) {
                    size = subjectMutations[j].size();
                    for (int k = 0; k < size; k += 2) {
                        if (subjectMutations[j].getQuick(k + 1) == -1) {
                            subjectMutations[j].setQuick(k + 1, avgScore);
                        }
                    }
                }
            }

            avgScore = 0;
            num = 0;
            for (int j = 0; j < controlNum; j++) {
                gtyID = controlIDs[j];

                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    features = tVar.getFeatureValues();
                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        subjectMutations[caseNum + j].add(0);
                        subjectMutations[caseNum + j].add(0);
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        //the first is count and the second is the weight
                        subjectMutations[caseNum + j].add(count);
                        if (scoreIndex >= 0) {
                            if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                                subjectMutations[caseNum + j].add(-1);
                            } else {
                                score = Float.parseFloat(features[scoreIndex]);
                                subjectMutations[caseNum + j].add(score);
                                avgScore += score;
                                num++;
                            }
                        } else {
                            subjectMutations[caseNum + j].add(1);
                        }
                        effectiveScoreIndex.add(tVar.refStartPosition);
                    } else {
                        //to keep the order of the variant list for later calculation
                        subjectMutations[caseNum + j].add(0);
                        subjectMutations[caseNum + j].add(0);
                    }

                }
            }

            if (scoreIndex >= 0) {
                avgScore /= num;
                for (int j = 0; j < controlNum; j++) {
                    size = subjectMutations[j + caseNum].size();
                    for (int k = 0; k < size; k += 2) {
                        if (subjectMutations[j + caseNum].getQuick(k + 1) == -1) {
                            subjectMutations[j + caseNum].setQuick(k + 1, avgScore);
                        }
                    }
                }

                for (Variant tVar : geneDisVars) {
                    //if (effectiveScoreIndex.contains(tVar.refStartPosition)) 
                    {
                        if (tVar.localAltAF > maxAltf) {
                            continue;
                        }
                        features = tVar.getFeatureValues();
                        if (features != null && features[scoreIndex] != null && !features[scoreIndex].equals(".")) {
                            score = Float.parseFloat(features[scoreIndex]);
                            rareMutScores.add(score);
                        }
                    }
                }
            }

            if (totalCount > 0) {
//                //zero mutation variats
//                FloatArrayList[] subjectMutations1 = new FloatArrayList[caseNum + controlNum];
//                for (int j = 0; j < subjectMutations1.length; j++) {
//                    subjectMutations1[j] = new FloatArrayList();
//                }
//                size = subjectMutations[0].size();
//                for (int startI = 0; startI < size; startI += 2) {
//                    count = 0;
//                    for (int j = 0; j < subjectMutations.length; j++) {
//                        count += subjectMutations[j].getQuick(startI);
//                    }
//                    if (count > 0) {
//                        for (int j = 0; j < subjectMutations.length; j++) {
//                            subjectMutations1[j].add(subjectMutations[j].getQuick(startI));
//                            subjectMutations1[j].add(subjectMutations[j].getQuick(startI + 1));
//                        }
//                    }
//                }
                geneSampleMuts.put(item.getKey(), subjectMutations);
                genePositions.put(item.getKey(),
                        new String[]{chrName, String.valueOf(geneDisVars.get(0).refStartPosition), String.valueOf(geneDisVars.get(geneDisVars.size() - 1).refStartPosition)});
            }
        }

    }

    public void extractGeneSampleMuationScores(Map<String, List<Variant>> geneVars, boolean isPhasedGty,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlIDs, int scoreIndex,
            Map<String, SampleVarGtyUnit> geneSampleMuts, DoubleArrayList rareMutScores, String chrName,
            Map<String, String[]> genePositions, double minCCFreqRatio, int maxThreadNum) throws Exception {

        class ExtractGtyTask implements Callable<String> {

            String geneSymbol;
            List<Variant> geneDisVars0;

            public ExtractGtyTask(String geneSymbol, List<Variant> geneDisVars0) {
                this.geneSymbol = geneSymbol;
                this.geneDisVars0 = geneDisVars0;
            }

            @Override
            public String call() {
                
                int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID, count, totalCount;

                int[] gtys;
                int subNum = pedEncodeGytIDMap.length;
                int num, size;
                float score, avgScore;
                String[] features;
                Set<Integer> effectiveScoreIndex = new HashSet<>();
                double maxAltf = 0.5, maf1, maf2, hetAff, homAff, totalAff, hetUnaff, homUnaff, totalUnaff;
                List<Variant> geneDisVars = new ArrayList<>();
                SampleVarGtyUnit svg;
                IntArrayList missingScoreIndexes = new IntArrayList();
                DoubleArrayList rareMutScoresTmp = new DoubleArrayList();
               
                if (minCCFreqRatio > 0) {
                    for (Variant var : geneDisVars0) {                        
                        hetAff = var.getAffectedHetGtyNum();
                        homAff = var.getAffectedAltHomGtyNum();
                        totalAff = var.getAffectedRefHomGtyNum() + hetAff + homAff;
                        hetUnaff = var.getUnaffectedHetGtyNum();
                        homUnaff = var.getUnaffectedAltHomGtyNum();
                        totalUnaff = var.getUnaffectedRefHomGtyNum() + hetUnaff + homUnaff;
                        maf1 = (0.5 * hetAff + homAff) / totalAff;

                        maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;

                        if (Double.isNaN(maf2)) {
                            //no unaffected sample
                            geneDisVars.add(var);
                        } else if (maf1 >= maf2 * minCCFreqRatio) {
                            geneDisVars.add(var);
                        }
                    }
                } else {
                    geneDisVars.addAll(geneDisVars0);
                }

                FloatArrayList varScores = new FloatArrayList();
                Set<String> chrPosStr = new HashSet<>();
                avgScore = 0;
                num = 0;
                missingScoreIndexes.clear();
                for (Variant tVar : geneDisVars) {                    
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    if (scoreIndex >= 0) {
                        features = tVar.getFeatureValues();
                        if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                            missingScoreIndexes.add(varScores.size());
                            varScores.add(Float.NaN);
                            chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                        } else {
                            score = Float.parseFloat(features[scoreIndex]);

                            varScores.add(score);
                            chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                            avgScore += score;
                            num++;
                            rareMutScoresTmp.add(score);

                        }
                    } else {
                        varScores.add(1);
                        chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                    }
                }

                if (scoreIndex >= 0) {
                    avgScore /= num;
                    size = missingScoreIndexes.size();
                    for (int j = 0; j < size; j++) {
                        varScores.setQuick(missingScoreIndexes.getQuick(j), avgScore);
                    }
                }

                totalCount = 0;
                effectiveScoreIndex.clear();
                OpenIntIntHashMap[] subjectMutations = new OpenIntIntHashMap[caseNum + controlNum];

                for (int j = 0; j < caseNum; j++) {
                    gtyID = caeSetID[j];

                    num = -1;
                    for (Variant tVar : geneDisVars) {
                        if (tVar.localAltAF > maxAltf) {
                            continue;
                        }

                        num++;
                        count = 0;
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0) {
                            count++;
                            totalCount++;
                        }
                        if (gtys[1] != 0) {
                            count++;
                            totalCount++;
                        }
                        if (count > 0) {
                            if (subjectMutations[j] == null) {
                                subjectMutations[j] = new OpenIntIntHashMap(1);
                            }
                            subjectMutations[j].put(num, count);
                            effectiveScoreIndex.add(tVar.refStartPosition);
                        }
                    }
                }

                for (int j = 0; j < controlNum; j++) {
                    gtyID = controlIDs[j];

                    num = -1;
                    for (Variant tVar : geneDisVars) {
                        if (tVar.localAltAF > maxAltf) {
                            continue;
                        }
                        num++;
                        count = 0;
                        gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                        if (gtys == null) {
                            continue;
                        }
                        if (gtys[0] != 0) {
                            count++;
                            totalCount++;
                        }
                        if (gtys[1] != 0) {
                            count++;
                            totalCount++;
                        }
                        if (count > 0) {
                            //the first is count and the second is the weight
                            if (subjectMutations[j + caseNum] == null) {
                                subjectMutations[j + caseNum] = new OpenIntIntHashMap(1);
                            }
                            subjectMutations[caseNum + j].put(num, count);
                            effectiveScoreIndex.add(tVar.refStartPosition);
                        }

                    }
                }

                if (totalCount > 0) {
                    svg = new SampleVarGtyUnit();
                    svg.varScores = varScores;
                    svg.subjectMutCount = subjectMutations;
                    svg.chrPosStr = chrPosStr;
                    svg.subjectMutBestScore = new double[subjectMutations.length];
                    Arrays.fill(svg.subjectMutBestScore, 0);

                    synchronized (geneVars) {
                        geneSampleMuts.put(geneSymbol, svg);
                        genePositions.put(geneSymbol,
                                new String[]{chrName, String.valueOf(geneDisVars.get(0).refStartPosition), String.valueOf(geneDisVars.get(geneDisVars.size() - 1).refStartPosition)});
                        rareMutScores.addAllOf(rareMutScoresTmp);
                    }
                }
                return "finished";
            }

        }

        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<>(exec);

        int runningThreads = 0;
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {            
            List<Variant> geneDisVars = item.getValue();            
            ExtractGtyTask cgt = new ExtractGtyTask(item.getKey(), geneDisVars);
            serv.submit(cgt);
            runningThreads++;
        }
        for (int t = 0; t < runningThreads; t++) {
            serv.take();
        }
        exec.shutdown();

    }

    public void extractGeneSampleMuationScores(Map<String, List<Variant>> geneVars, boolean isPhasedGty,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlIDs, int scoreIndex,
            Map<String, SampleVarGtyUnit> geneSampleMuts, DoubleArrayList rareMutScores, String chrName,
            Map<String, String[]> genePositions, double minCCFreqRatio) {
        int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID, count, totalCount;

        int[] gtys;
        int subNum = pedEncodeGytIDMap.length;
        int num, size;
        float score, avgScore;
        String[] features;
        Set<Integer> effectiveScoreIndex = new HashSet<Integer>();
        double maxAltf = 0.5, maf1, maf2, hetAff, homAff, totalAff, hetUnaff, homUnaff, totalUnaff;
        List<Variant> geneDisVars = new ArrayList<Variant>();
        SampleVarGtyUnit svg;
        IntArrayList missingScoreIndexes = new IntArrayList();
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars0 = item.getValue();

            geneDisVars.clear();
            if (minCCFreqRatio > 0) {
                for (Variant var : geneDisVars0) {
                    hetAff = var.getAffectedHetGtyNum();
                    homAff = var.getAffectedAltHomGtyNum();
                    totalAff = var.getAffectedRefHomGtyNum() + hetAff + homAff;
                    hetUnaff = var.getUnaffectedHetGtyNum();
                    homUnaff = var.getUnaffectedAltHomGtyNum();
                    totalUnaff = var.getUnaffectedRefHomGtyNum() + hetUnaff + homUnaff;
                    maf1 = (0.5 * hetAff + homAff) / totalAff;

                    maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;

                    if (Double.isNaN(maf2)) {
                        //no unaffected sample
                        geneDisVars.add(var);
                    } else if (maf1 >= maf2 * minCCFreqRatio) {
                        geneDisVars.add(var);
                    }
                }
            } else {
                geneDisVars.addAll(geneDisVars0);
            }

            FloatArrayList varScores = new FloatArrayList();
            Set<String> chrPosStr = new HashSet<String>();
            avgScore = 0;
            num = 0;
            missingScoreIndexes.clear();
            for (Variant tVar : geneDisVars) {
                if (tVar.localAltAF > maxAltf) {
                    continue;
                }
                if (scoreIndex >= 0) {
                    features = tVar.getFeatureValues();
                    if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                        missingScoreIndexes.add(varScores.size());
                        varScores.add(Float.NaN);
                        chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                    } else {
                        score = Float.parseFloat(features[scoreIndex]);

                        varScores.add(score);
                        chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                        avgScore += score;
                        num++;
                        rareMutScores.add(score);
                    }
                } else {
                    varScores.add(1);
                    chrPosStr.add(chrName + ":" + tVar.refStartPosition);
                }
            }

            if (scoreIndex >= 0) {
                avgScore /= num;
                size = missingScoreIndexes.size();
                for (int j = 0; j < size; j++) {
                    varScores.setQuick(missingScoreIndexes.getQuick(j), avgScore);
                }
            }

            totalCount = 0;
            effectiveScoreIndex.clear();
            OpenIntIntHashMap[] subjectMutations = new OpenIntIntHashMap[caseNum + controlNum];

            for (int j = 0; j < caseNum; j++) {
                gtyID = caeSetID[j];

                num = -1;
                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }

                    num++;
                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        if (subjectMutations[j] == null) {
                            subjectMutations[j] = new OpenIntIntHashMap(1);
                        }
                        subjectMutations[j].put(num, count);
                        effectiveScoreIndex.add(tVar.refStartPosition);
                    }
                }
            }

            for (int j = 0; j < controlNum; j++) {
                gtyID = controlIDs[j];

                num = -1;
                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    num++;
                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        //the first is count and the second is the weight
                        if (subjectMutations[j + caseNum] == null) {
                            subjectMutations[j + caseNum] = new OpenIntIntHashMap(1);
                        }
                        subjectMutations[caseNum + j].put(num, count);
                        effectiveScoreIndex.add(tVar.refStartPosition);
                    }

                }
            }

            if (totalCount > 0) {
                svg = new SampleVarGtyUnit();
                svg.varScores = varScores;
                svg.subjectMutCount = subjectMutations;
                svg.chrPosStr = chrPosStr;
                svg.subjectMutBestScore = new double[subjectMutations.length];
                Arrays.fill(svg.subjectMutBestScore, 0);

                geneSampleMuts.put(item.getKey(), svg);
                genePositions.put(item.getKey(),
                        new String[]{chrName, String.valueOf(geneDisVars.get(0).refStartPosition), String.valueOf(geneDisVars.get(geneDisVars.size() - 1).refStartPosition)});
            }
        }

    }

    public void extractGeneSampleSingleMuationScores(Map<String, List<Variant>> geneVars, boolean isPhasedGty, int[] pedEncodeGytIDMap,
            int[] caeSetID, int[] controlIDs, int scoreIndex, Map<String, float[]> geneSampleMuts, DoubleArrayList rareMutScores,
            String chrName, Map<String, String[]> genePositions, double minCCFreqRatio) {
        int controlNum = controlIDs.length, caseNum = caeSetID.length, gtyID, count, totalCount;

        int[] gtys;
        int subNum = pedEncodeGytIDMap.length;
        int num, size;
        float score, avgScore;
        String[] features;
        Set<Integer> effectiveScoreIndex = new HashSet<Integer>();
        double maxAltf = 0.5, maf1, maf2, hetAff, homAff, totalAff, hetUnaff, homUnaff, totalUnaff;
        List<Variant> geneDisVars = new ArrayList<Variant>();
        for (Map.Entry<String, List<Variant>> item : geneVars.entrySet()) {
            List<Variant> geneDisVars0 = item.getValue();

            geneDisVars.clear();
            if (minCCFreqRatio > 0) {
                for (Variant var : geneDisVars0) {
                    hetAff = var.getAffectedHetGtyNum();
                    homAff = var.getAffectedAltHomGtyNum();
                    totalAff = var.getAffectedRefHomGtyNum() + hetAff + homAff;
                    hetUnaff = var.getUnaffectedHetGtyNum();
                    homUnaff = var.getUnaffectedAltHomGtyNum();
                    totalUnaff = var.getUnaffectedRefHomGtyNum() + hetUnaff + homUnaff;
                    maf1 = (0.5 * hetAff + homAff) / totalAff;

                    maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;

                    if (Double.isNaN(maf2)) {
                        //no unaffected sample
                        geneDisVars.add(var);
                    } else if (maf1 >= maf2 * minCCFreqRatio) {
                        geneDisVars.add(var);
                    }
                }
            } else {
                geneDisVars.addAll(geneDisVars0);
            }

            float[] subjectMutations = new float[caseNum + controlNum];
            Arrays.fill(subjectMutations, Float.NaN);
            totalCount = 0;
            effectiveScoreIndex.clear();
            avgScore = 0;
            num = 0;
            float highestScore;

            for (int j = 0; j < caseNum; j++) {
                gtyID = caeSetID[j];

                highestScore = Float.NaN;
                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    features = tVar.getFeatureValues();

                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        //the first is count and the second is the weight                        
                        if (scoreIndex >= 0) {
                            if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                                highestScore = -1;
                                continue;
                            } else {
                                score = Float.parseFloat(features[scoreIndex]);

                                highestScore = (score);
                                avgScore += score;
                                num++;
                            }
                        } else {
                            highestScore = (1);
                        }

                        effectiveScoreIndex.add(tVar.refStartPosition);
                    }
                }
                subjectMutations[j] = highestScore;
            }
            if (scoreIndex >= 0) {
                avgScore /= num;
                for (int j = 0; j < caseNum; j++) {
                    if (subjectMutations[j] == -1) {
                        subjectMutations[j] = avgScore;
                    }
                }
            }

            avgScore = 0;
            num = 0;
            for (int j = 0; j < controlNum; j++) {
                gtyID = controlIDs[j];

                highestScore = Float.NaN;
                for (Variant tVar : geneDisVars) {
                    if (tVar.localAltAF > maxAltf) {
                        continue;
                    }
                    features = tVar.getFeatureValues();
                    count = 0;
                    gtys = getVarGty(tVar, isPhasedGty, subNum, gtyID);
                    if (gtys == null) {
                        continue;
                    }
                    if (gtys[0] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (gtys[1] != 0) {
                        count++;
                        totalCount++;
                    }
                    if (count > 0) {
                        //the first is count and the second is the weight                      
                        if (scoreIndex >= 0) {
                            if (features == null || features[scoreIndex] == null || features[scoreIndex].equals(".")) {
                                highestScore = (-1);
                            } else {
                                score = Float.parseFloat(features[scoreIndex]);
                                highestScore = (score);
                                avgScore += score;
                                num++;
                            }
                        } else {
                            highestScore = (1);
                        }
                        effectiveScoreIndex.add(tVar.refStartPosition);
                    }

                }
                subjectMutations[caseNum + j] = highestScore;
            }

            if (scoreIndex >= 0) {
                avgScore /= num;
                for (int j = 0; j < controlNum; j++) {
                    if (subjectMutations[j + caseNum] == -1) {
                        subjectMutations[j + caseNum] = avgScore;
                    }
                }

                for (Variant tVar : geneDisVars) {
                    //if (effectiveScoreIndex.contains(tVar.refStartPosition)) 
                    {
                        if (tVar.localAltAF > maxAltf) {
                            continue;
                        }
                        features = tVar.getFeatureValues();
                        if (features != null && features[scoreIndex] != null && !features[scoreIndex].equals(".")) {
                            score = Float.parseFloat(features[scoreIndex]);
                            rareMutScores.add(score);
                        }
                    }
                }
            }

            if (totalCount > 0) {
                geneSampleMuts.put(item.getKey(), subjectMutations);
                genePositions.put(item.getKey(),
                        new String[]{chrName, String.valueOf(geneDisVars.get(0).refStartPosition), String.valueOf(geneDisVars.get(geneDisVars.size() - 1).refStartPosition)});
            }
        }

    }

    public void casecontrolUniqueModelFilterVar(Chromosome chromosome, AnnotationSummarySet ass, boolean[] uniqueFilters) {
        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
        int hardFilteringNum = 0;
//        Set<Byte> caseSharedHomoAllele = new HashSet<Byte>();
//        Set<Byte> caseSharedHeteAllele = new HashSet<Byte>();
//        Set<Byte> controlSharedHomoAllele = new HashSet<Byte>();
//        Set<Byte> caseSharedAllele = new HashSet<Byte>();
//        Set<Byte> controlSharedAllele = new HashSet<Byte>();

        byte[] gtys = null;
        int subID = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        int hitNum = 0;

        if (chromosome == null) {
            return;
        }
        tmpVarList.clear();
        for (Variant var : chromosome.variantList) {
//            caseSharedHomoAllele.clear();
//            caseSharedHeteAllele.clear();
//            controlSharedHomoAllele.clear();
//            caseSharedAllele.clear();
//            controlSharedAllele.clear();

            // "case-unique"
            if (uniqueFilters[0]) {
                if ((var.getUnaffectedHetGtyNum() <= 0 && var.getUnaffectedAltHomGtyNum() <= 0 && (var.getAffectedHetGtyNum() > 0 || var.getAffectedAltHomGtyNum() > 0))
                        || (var.getUnaffectedHetGtyNum() <= 0 && var.getUnaffectedRefHomGtyNum() <= 0 && (var.getAffectedHetGtyNum() > 0 || var.getAffectedRefHomGtyNum() > 0))) // if
                // (hetA
                // +
                // homA
                // == 0
                // ||
                // hetU
                // +
                // homU
                // > 0)
                {
                    tmpVarList.add(var);
                } else {
                    hardFilteringNum++;
                }
                // //"control-unique"
            } else if (uniqueFilters[1]) {
                if ((var.getAffectedHetGtyNum() <= 0 && var.getAffectedAltHomGtyNum() <= 0 && (var.getUnaffectedHetGtyNum() > 0 || var.getUnaffectedAltHomGtyNum() > 0))
                        || (var.getAffectedHetGtyNum() <= 0 && var.getAffectedRefHomGtyNum() <= 0 && (var.getUnaffectedHetGtyNum() > 0 || var.getUnaffectedRefHomGtyNum() > 0))) // if
                // (hetA
                // +
                // homA
                // == 0
                // ||
                // hetU
                // +
                // homU
                // > 0)
                {
                    tmpVarList.add(var);
                } else {
                    hardFilteringNum++;
                }
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + tmpVarList.size());
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - tmpVarList.size());
//        hitNum += tmpVarList.size();
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();

//        genome.setVarNum(hitNum);
//        genome.buildVariantIndexMapOnChromosomes();
        chromosome.buildVariantIndexMap();
//        StringBuilder message = new StringBuilder();
//        if (hardFilteringNum > 0) {
//            // message.append(hardFilteringNum).append(" dependentVariants are ignored by genotype-based hard-filtering;\n");
//        }
//        message.append(hitNum).append(" variant(s) are retained after filtration according to ").append(hardFilterModel).append("!");
//        LOG.info(message.toString());
    }

    public void overlappedGeneExploreVar(Chromosome chromosome, AnnotationSummarySet ass, List<Individual> subjectList, int[] pedEncodeGytIDMap, boolean ignoreNonPathogenic, IntArrayList caseSubIDs, IntArrayList controlSubIDs, int pathogenicPredicIndex, Genome uniqueGenome) {
        String lastGeneSymb = null;
        String predicType = null;
        int caseNum = caseSubIDs.size();
        int controlNum = controlSubIDs.size();
        boolean isPhased = uniqueGenome.isIsPhasedGty();

        List<Variant> geneVars = new ArrayList<Variant>();
        List<Variant> tmpVarListIndiv = new ArrayList<Variant>();
        List<Variant> tmpVarListGene = new ArrayList<Variant>();
        List<Variant> tmpVarListChrom = new ArrayList<Variant>();
        OpenIntIntHashMap haveMutSubIDSet = new OpenIntIntHashMap();
        OpenIntIntHashMap caseUniqeAlleles = new OpenIntIntHashMap();
//        int leftVarNum = 0;

        if (chromosome == null) {
            return;
        }
        if (chromosome.variantList == null || chromosome.variantList.isEmpty()) {
            return;
        }
        lastGeneSymb = null;
        geneVars.clear();
        int subID = 0;
        int[] gty;
        boolean[] bits = new boolean[32];
        Map<String, List<Variant>> disGeneVarMap = new HashMap<String, List<Variant>>();
        List<Variant> geneDisVars = new ArrayList<Variant>();
        int startIndex;
        int subNum = subjectList.size();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb != null) {
                //only allow ignoreNonPathogenic to workfor misssense dependentVariants
                if (var.smallestFeatureID == 6 && ignoreNonPathogenic && pathogenicPredicIndex >= 0) {
//                    predicType = var.getFeatureValues().get(pathogenicPredicIndex);
                    predicType = var.getFeatureValues()[pathogenicPredicIndex];
                    if (predicType != null && predicType.equals("N")) {
                        continue;
                    }
                }

                geneDisVars = disGeneVarMap.get(var.geneSymb);
                if (geneDisVars == null) {
                    geneDisVars = new ArrayList<Variant>();
                    disGeneVarMap.put(var.geneSymb, geneDisVars);
                }
                geneDisVars.add(var);
            }
        }

        int effectiveCase = 0;
        for (int j = 0; j < caseNum; j++) {
            subID = caseSubIDs.getQuick(j);
            subID = pedEncodeGytIDMap[subID];
            if (subID < 0) {
                continue;
            }
            effectiveCase++;
        }

        for (Map.Entry<String, List<Variant>> item : disGeneVarMap.entrySet()) {
            lastGeneSymb = item.getKey();
            geneVars = item.getValue();
            tmpVarListGene.clear();
            haveMutSubIDSet.clear();
            caseUniqeAlleles.clear();

            for (Variant tVar : geneVars) {
                tmpVarListIndiv.clear();
                int alleleNum = tVar.getAltAlleles().length + 1;
                int base = 0;
                if (isPhased) {
                    base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
                } else {
                    base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
                }
                for (int j = 0; j < caseNum; j++) {
//                            Individual mIndiv = subjectList.get(caseSubIDs.getQuick(j));
                    subID = caseSubIDs.getQuick(j);
                    subID = pedEncodeGytIDMap[subID];
                    if (subID < 0) {
                        continue;
                    }
                    if (tVar.compressedGtyNum >= 0) {
                        if (tVar.compressedGtyNum == 0) {
                            Arrays.fill(bits, 0, base, false);
                        } else {
                            startIndex = subID;
                            for (int i = 0; i < base; i++) {
                                if (startIndex > tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = false;
                                } else if (startIndex < tVar.compressedGty[0]) {
                                    bits[i] = false;
                                } else if (startIndex == tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = true;
                                } else if (startIndex == tVar.compressedGty[0]) {
                                    bits[i] = true;
                                } else {
                                    bits[i] = (Arrays.binarySearch(tVar.compressedGty, startIndex) >= 0);
                                }
                                startIndex += subNum;
                            }
                        }
                        if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                        } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                        }
                    } else if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getPhasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getUnphasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    }

                    if (gty == null) {
                        continue;
                    }
                    if (gty[0] != gty[1]) {
                        caseUniqeAlleles.put(gty[0], 0);
                        caseUniqeAlleles.put(gty[1], 0);
                    } else {
                        caseUniqeAlleles.put(gty[0], 0);
                    }
                }

                if (caseUniqeAlleles.isEmpty()) {
                    continue;
                }
                // deliberately remove reference allele
                caseUniqeAlleles.removeKey(0);
                for (int j = 0; j < controlNum; j++) {
                    subID = controlSubIDs.getQuick(j);
                    subID = pedEncodeGytIDMap[subID];
                    if (subID < 0) {
                        continue;
                    }
                    if (tVar.compressedGtyNum >= 0) {
                        if (tVar.compressedGtyNum == 0) {
                            Arrays.fill(bits, 0, base, false);
                        } else {
                            startIndex = subID;
                            for (int i = 0; i < base; i++) {
                                if (startIndex > tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = false;
                                } else if (startIndex < tVar.compressedGty[0]) {
                                    bits[i] = false;
                                } else if (startIndex == tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = true;
                                } else if (startIndex == tVar.compressedGty[0]) {
                                    bits[i] = true;
                                } else {
                                    bits[i] = (Arrays.binarySearch(tVar.compressedGty, startIndex) >= 0);
                                }
                                startIndex += subNum;
                            }
                        }
//                            Individual mIndiv = subjectList.get(controlSubIDs.getQuick(j));
                        if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                        } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                        }
                    } else if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getPhasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getUnphasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    }

                    if (gty == null) {
                        continue;
                    }
                    if (gty[0] != gty[1]) {
                        caseUniqeAlleles.removeKey(gty[0]);
                        caseUniqeAlleles.removeKey(gty[1]);
                    } else {
                        caseUniqeAlleles.removeKey(gty[0]);
                    }
                    if (caseUniqeAlleles.isEmpty()) {
                        break;
                    }
                }
                // If this dependentVariants have no case-unqie dependentVariants
                if (caseUniqeAlleles.isEmpty()) {
                    continue;
                }
                tmpVarListGene.add(tVar);
                for (int j = 0; j < caseNum; j++) {
                    subID = caseSubIDs.getQuick(j);
                    subID = pedEncodeGytIDMap[subID];
                    if (subID < 0) {
                        continue;
                    }
                    if (tVar.compressedGtyNum >= 0) {
                        if (tVar.compressedGtyNum == 0) {
                            Arrays.fill(bits, 0, base, false);
                        } else {
                            startIndex = subID;
                            for (int i = 0; i < base; i++) {
                                if (startIndex > tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = false;
                                } else if (startIndex < tVar.compressedGty[0]) {
                                    bits[i] = false;
                                } else if (startIndex == tVar.compressedGty[tVar.compressedGty.length - 1]) {
                                    bits[i] = true;
                                } else if (startIndex == tVar.compressedGty[0]) {
                                    bits[i] = true;
                                } else {
                                    bits[i] = (Arrays.binarySearch(tVar.compressedGty, startIndex) >= 0);
                                }
                                startIndex += subNum;
                            }
                        }
                        if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                        } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                            gty = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                        }
                    } else if (isPhased) {
//                                gty = mIndiv.markerGtySetArray.getPhasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getPhasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    } else {
//                                gty = mIndiv.markerGtySetArray.getUnphasedGtyBool(tVar.genotypeIndex, tVar.getAltAlleles().length + 1);
                        gty = bgp.getUnphasedGtyAt(tVar.encodedGty, alleleNum, base, subID, subNum);
                    }

                    if (gty == null) {
                        continue;
                    }
                    if (caseUniqeAlleles.containsKey(gty[0])) {
                        haveMutSubIDSet.put(caseSubIDs.getQuick(j), 0);
                    } else if (caseUniqeAlleles.containsKey(gty[1])) {
                        haveMutSubIDSet.put(caseSubIDs.getQuick(j), 0);
                    }
                }
            }
            // require every one has a least one case-unique
            // dependentVariants at a gene
            if (effectiveCase == haveMutSubIDSet.size()) {
                tmpVarListChrom.addAll(tmpVarListGene);
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + tmpVarListChrom.size());
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + tmpVarListChrom.size());

        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarListChrom);
        chromosome.setHasNotOrderVariantList(true);
        tmpVarListChrom.clear();
//        leftVarNum += (chromosome.variantList.size());

        chromosome.buildVariantIndexMap();
//        genome.buildVariantIndexMapOnChromosomes();

//        StringBuilder info = new StringBuilder();
//        info.append(leftVarNum).append(" variant(s) are retained after filtered by the unique dependentVariants on gene level.\n");
//
//        LOG.info(info);
//        genome.setVarNum(leftVarNum);
    }

    public int[] partitionEvenBlock(int totalSnpSize, int blockNum) throws Exception {
        int[] bigBlockIndexes;
        int intervalLen = totalSnpSize / blockNum;
        if (intervalLen == 0) {
            bigBlockIndexes = new int[totalSnpSize + 1];
            for (int i = 0; i < bigBlockIndexes.length; i++) {
                bigBlockIndexes[i] = i;
            }
        } else {
            bigBlockIndexes = new int[blockNum + 1];
            Arrays.fill(bigBlockIndexes, 0);
            for (int s = 1; s < blockNum; s++) {
                bigBlockIndexes[s] = s * intervalLen;
            }
            bigBlockIndexes[blockNum] = totalSnpSize;
        }

        return bigBlockIndexes;
    }

    private void formatBialleleicUnphasedBits(List<Variant> variantList, int totalPedSubjectNum, int[][] bits1,
            int[][] bits2, int[][] bits3, int[][] bits4, double[] mean1, int[] sum12, boolean[] hasMissingGty) {
        int varSize = variantList.size();
        int firstBitByteEnd;

        final int bitCalcuLen = 32;
        int unitNum;
        int firstTailLen = totalPedSubjectNum % 8;
        int offsetTmp = 0;
        if (totalPedSubjectNum % bitCalcuLen != 0) {
            unitNum = totalPedSubjectNum / bitCalcuLen + 1;
        } else {
            unitNum = totalPedSubjectNum / bitCalcuLen;
        }

        if (totalPedSubjectNum % 8 != 0) {
            firstBitByteEnd = totalPedSubjectNum / 8 + 1;
        } else {
            firstBitByteEnd = totalPedSubjectNum / 8;
        }

        int secondBitByteStart = (totalPedSubjectNum) / 8;
        int secondBitBytEnd = totalPedSubjectNum * 2 / 8;
        if ((totalPedSubjectNum * 2) % 8 != 0) {
            secondBitBytEnd += 1;
        }

        int lastWordID = unitNum - 1;
        int maskInt = totalPedSubjectNum % bitCalcuLen;
        int c = 0;
        if (maskInt != 0) {
            c = (0x80000000 >> (maskInt - 1));
            c = ~c;
            //System.out.println(Integer.toBinaryString(c));
        }
        int nonNumIndiv = 0;
        int startIndex;
        boolean isOne;
        int subID;
        int index1, index2;
        for (int i = 0; i < varSize; i++) {
            Variant var = variantList.get(i);
            if (var.getAltAlleles().length > 1) {
                continue;
            }

            bits1[i] = new int[unitNum];
            bits2[i] = new int[unitNum];
            bits3[i] = new int[unitNum];
            bits4[i] = new int[unitNum];

            Arrays.fill(bits1[i], 0);
            Arrays.fill(bits2[i], 0);
            Arrays.fill(bits3[i], 0);
            Arrays.fill(bits4[i], 0);
            if (var.compressedGtyNum >= 0) {
                //first bit block
                for (subID = 0; subID < totalPedSubjectNum; subID++) {
                    startIndex = subID;
                    if (var.compressedGtyNum == 0) {
                        isOne = false;
                    } else if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = false;
                    } else if (startIndex < var.compressedGty[0]) {
                        isOne = false;
                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = true;
                    } else if (startIndex == var.compressedGty[0]) {
                        isOne = true;
                    } else {
                        isOne = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                    }
                    if (isOne) {
                        index1 = subID / bitCalcuLen;
                        index2 = subID % bitCalcuLen;
                        bits1[i][index1] |= GlobalManager.intOpers[index2];
                    }
                }

                //first bit block
                for (subID = 0; subID < totalPedSubjectNum; subID++) {
                    startIndex = subID + totalPedSubjectNum;
                    if (var.compressedGtyNum == 0) {
                        isOne = false;
                    } else if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = false;
                    } else if (startIndex < var.compressedGty[0]) {
                        isOne = false;
                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = true;
                    } else if (startIndex == var.compressedGty[0]) {
                        isOne = true;
                    } else {
                        isOne = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                    }
                    if (isOne) {
                        index1 = subID / bitCalcuLen;
                        index2 = subID % bitCalcuLen;
                        bits3[i][index1] |= GlobalManager.intOpers[index2];
                    }
                }

                if (maskInt != 0) {
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                    bits1[i][lastWordID] |= c;
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                }
                if (maskInt != 0) {
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                    bits3[i][lastWordID] |= c;
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                }
            } else {
                byte[] bytes = var.encodedGty;
                for (int j = 0; j < firstBitByteEnd; j++) {
                    lastWordID = j >>> 2;
                    offsetTmp = j - (lastWordID << 2);
                    bits1[i][lastWordID] |= ((bytes[j] & 0xFF) << (24 - (offsetTmp << 3)));
                    //  System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                }
                if (maskInt != 0) {
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                    bits1[i][lastWordID] |= c;
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                }

                /*
            for (int j = 0; j < unitNum; j++) {
                System.out.println(String.format("%32s", Integer.toBinaryString(bits1[t][j])).replace(' ', '0'));
            }
                 */
                for (int j = secondBitByteStart; j < secondBitBytEnd; j++) {
                    lastWordID = (j - secondBitByteStart) >>> 2;
                    if (lastWordID == unitNum) {
                        lastWordID--;
                        // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                        break;
                    }
                    offsetTmp = (j - secondBitByteStart) - (lastWordID << 2);
                    bits3[i][lastWordID] |= (((bytes[j] & 0xFF) << (24 - (offsetTmp << 3) + firstTailLen)));
                    // System.out.println(String.format("%32s", Integer.toBinaryString(bits3[t][lastWordID])).replace(' ', '0'));
                    if (offsetTmp == 3 && firstTailLen != 0) {
                        // c = (0x80000000 >> (32 - 8 + firstTailLen - 1));
                        //System.out.println(String.format("%8s", Integer.toBinaryString(c)).replace(' ', '0'));
                        if (j + 1 >= bytes.length) {
                            break;
                        }
                        bits3[i][lastWordID] |= (((bytes[j + 1] & 0xFF)) >>> (8 - firstTailLen));
                        //byte kk = (byte) ((bytes[j + 1] & 0xFF) & c);
                        //System.out.println(String.format("%8s", Integer.toBinaryString(kk).replace(' ', '0')));
                    }
                    // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                }

                //it is necessary when they are more than two bits
                if (maskInt != 0) {
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                    bits3[i][lastWordID] |= c;
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                }
                /*
            for (int j = 0; j < unitNum; j++) {
                System.out.println(String.format("%32s", Integer.toBinaryString(bits3[t][j])).replace(' ', '0'));
            }
            System.out.println();
                 */
            }
            nonNumIndiv = 0;
            for (int j = 0; j < unitNum; j++) {
                bits4[i][j] = ~(bits1[i][j] & bits3[i][j]);
                bits1[i][j] = bits1[i][j] & bits4[i][j];
                bits3[i][j] = bits3[i][j] & bits4[i][j];
                bits2[i][j] = (bits1[i][j] | bits3[i][j]);
                mean1[i] += ((Integer.bitCount(bits1[i][j]) << 1) + Integer.bitCount(bits3[i][j]));
                sum12[i] += ((Integer.bitCount(bits1[i][j]) << 2) + Integer.bitCount(bits3[i][j]));
                nonNumIndiv += Integer.bitCount(bits4[i][j]);
                //System.out.println(String.format("%32s", Integer.toBinaryString(bits4[j][j])).replace(' ', '0'));
            }
            hasMissingGty[i] = nonNumIndiv != totalPedSubjectNum;
        }

    }

    private void formatBialleleicPhasedBits(List<Variant> variantList, int totalPedSubjectNum, int[][] bits1,
            int[][] bits2, int[][] bits3, double[] mean1, boolean[] hasMissingGty) {
        int varSize = variantList.size();
        int firstBitByteEnd;

        final int gtyLen = 32;
        int unitNum;
        int firstTailLen = totalPedSubjectNum % 8;
        int offsetTmp = 0;
        if (totalPedSubjectNum % gtyLen != 0) {
            unitNum = totalPedSubjectNum / gtyLen + 1;
        } else {
            unitNum = totalPedSubjectNum / gtyLen;
        }

        if (totalPedSubjectNum % 8 != 0) {
            firstBitByteEnd = totalPedSubjectNum / 8 + 1;
        } else {
            firstBitByteEnd = totalPedSubjectNum / 8;
        }

        int secondTailLen = totalPedSubjectNum * 2 % 8;
        int base = 2;
        int secondBitByteStart = (totalPedSubjectNum) / 8;
        int secondBitBytEnd = totalPedSubjectNum * 2 / 8;
        if ((totalPedSubjectNum * 2) % 8 != 0) {
            secondBitBytEnd += 1;
        }

        int thirdBitByteStart = (totalPedSubjectNum * 2) / 8;
        int thirdBitBytEnd = totalPedSubjectNum * 3 / 8;
        if ((totalPedSubjectNum * 3) % 8 != 0) {
            thirdBitBytEnd += 1;
        }

        int lastWordID = unitNum - 1;
        int maskInt = totalPedSubjectNum % gtyLen;
        int c = 0;
        if (maskInt != 0) {
            c = (0x80000000 >> (maskInt - 1));
            c = ~c;
            //System.out.println(Integer.toBinaryString(c));
        }
        int nonNumIndiv = 0;
        int startIndex;
        boolean isOne;
        int subID;
        int index1, index2;
        for (int i = 0; i < varSize; i++) {
            Variant var = variantList.get(i);
            if (var.getAltAlleles().length > 1) {
                continue;
            }

            bits1[i] = new int[unitNum];
            bits2[i] = new int[unitNum];
            bits3[i] = new int[unitNum];
            Arrays.fill(bits1[i], 0);
            Arrays.fill(bits2[i], 0);
            Arrays.fill(bits3[i], 0);

            if (var.compressedGtyNum >= 0) {
                for (subID = 0; subID < totalPedSubjectNum; subID++) {
                    startIndex = subID;
                    if (var.compressedGtyNum == 0) {
                        isOne = false;
                    } else if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = false;
                    } else if (startIndex < var.compressedGty[0]) {
                        isOne = false;
                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = true;
                    } else if (startIndex == var.compressedGty[0]) {
                        isOne = true;
                    } else {
                        isOne = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                    }
                    if (isOne) {
                        index1 = subID / gtyLen;
                        index2 = subID % gtyLen;
                        bits3[i][index1] |= GlobalManager.intOpers[index2];
                    }
                }
                for (subID = 0; subID < totalPedSubjectNum; subID++) {
                    startIndex = subID + totalPedSubjectNum;
                    if (var.compressedGtyNum == 0) {
                        isOne = false;
                    } else if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = false;
                    } else if (startIndex < var.compressedGty[0]) {
                        isOne = false;
                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = true;
                    } else if (startIndex == var.compressedGty[0]) {
                        isOne = true;
                    } else {
                        isOne = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                    }
                    if (isOne) {
                        index1 = subID / gtyLen;
                        index2 = subID % gtyLen;
                        bits1[i][index1] |= GlobalManager.intOpers[index2];
                    }
                }

                for (subID = 0; subID < totalPedSubjectNum; subID++) {
                    startIndex = subID + totalPedSubjectNum + totalPedSubjectNum;
                    if (var.compressedGtyNum == 0) {
                        isOne = false;
                    } else if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = false;
                    } else if (startIndex < var.compressedGty[0]) {
                        isOne = false;
                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                        isOne = true;
                    } else if (startIndex == var.compressedGty[0]) {
                        isOne = true;
                    } else {
                        isOne = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                    }
                    if (isOne) {
                        index1 = subID / gtyLen;
                        index2 = subID % gtyLen;
                        bits2[i][index1] |= GlobalManager.intOpers[index2];
                    }
                }
                if (maskInt != 0) {
                    //System.out.println(Integer.toBinaryString(c));
                    bits1[i][lastWordID] |= c;
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                }
                if (maskInt != 0) {
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                    bits2[i][lastWordID] |= c;
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                }
                if (maskInt != 0) {
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                    bits3[i][lastWordID] |= c;
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                }
            } else {
                byte[] bytes = var.encodedGty;
                for (int j = 0; j < firstBitByteEnd; j++) {
                    lastWordID = j >>> 2;
                    offsetTmp = j - (lastWordID << 2);
                    bits3[i][lastWordID] |= ((bytes[j] & 0xFF) << (24 - (offsetTmp << 3)));
                    //  System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                }
                if (maskInt != 0) {
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                    bits3[i][lastWordID] |= c;
                    //System.out.println(Integer.toBinaryString(bits1[t][lastWordID]));
                }

                /*
            for (int j = 0; j < unitNum; j++) {
                System.out.println(String.format("%32s", Integer.toBinaryString(bits1[t][j])).replace(' ', '0'));
            }
                 */
                for (int j = secondBitByteStart; j < secondBitBytEnd; j++) {
                    lastWordID = (j - secondBitByteStart) >>> 2;
                    if (lastWordID == unitNum) {
                        lastWordID--;
                        // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                        break;
                    }
                    offsetTmp = (j - secondBitByteStart) - (lastWordID << 2);
                    bits1[i][lastWordID] |= (((bytes[j] & 0xFF) << (24 - (offsetTmp << 3) + firstTailLen)));
                    // System.out.println(String.format("%32s", Integer.toBinaryString(bits3[t][lastWordID])).replace(' ', '0'));
                    if (offsetTmp == 3 && firstTailLen != 0) {
                        // c = (0x80000000 >> (32 - 8 + firstTailLen - 1));
                        //System.out.println(String.format("%8s", Integer.toBinaryString(c)).replace(' ', '0'));
                        bits1[i][lastWordID] |= (((bytes[j + 1] & 0xFF)) >>> (8 - firstTailLen));
                        //byte kk = (byte) ((bytes[j + 1] & 0xFF) & c);
                        //System.out.println(String.format("%8s", Integer.toBinaryString(kk).replace(' ', '0')));
                    }
                    // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                }

                //it is necessary when they are more than two bits
                if (maskInt != 0) {
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                    bits1[i][lastWordID] |= c;
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                }

                for (int j = thirdBitByteStart; j < thirdBitBytEnd; j++) {
                    lastWordID = (j - thirdBitByteStart) >>> 2;
                    if (lastWordID == unitNum) {
                        lastWordID--;
                        // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                        break;
                    }
                    offsetTmp = (j - thirdBitByteStart) - (lastWordID << 2);
                    bits2[i][lastWordID] |= (((bytes[j] & 0xFF) << (24 - (offsetTmp << 3) + secondTailLen)));
                    // System.out.println(String.format("%32s", Integer.toBinaryString(bits3[t][lastWordID])).replace(' ', '0'));
                    if (offsetTmp == 3 && firstTailLen != 0) {
                        // c = (0x80000000 >> (32 - 8 + firstTailLen - 1));
                        //System.out.println(String.format("%8s", Integer.toBinaryString(c)).replace(' ', '0'));
                        bits2[i][lastWordID] |= (((bytes[j + 1] & 0xFF)) >>> (8 - secondTailLen));
                        //byte kk = (byte) ((bytes[j + 1] & 0xFF) & c);
                        //System.out.println(String.format("%8s", Integer.toBinaryString(kk).replace(' ', '0')));
                    }
                    // System.out.println(String.format("%8s", Integer.toBinaryString(bytes[j] & 0xFF)).replace(' ', '0'));
                }

                //it is necessary when they are more than two bits
                if (maskInt != 0) {
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                    bits2[i][lastWordID] |= c;
                    // System.out.println(Integer.toBinaryString(bits3[t][lastWordID]));
                }

                /*
            for (int j = 0; j < unitNum; j++) {
                System.out.println(String.format("%32s", Integer.toBinaryString(bits3[t][j])).replace(' ', '0'));
            }
            System.out.println();
                 */
            }
            nonNumIndiv = 0;
            for (int j = 0; j < unitNum; j++) {
                bits3[i][j] = ~bits3[i][j];
                bits1[i][j] = (bits1[i][j] & bits3[i][j]);
                bits2[i][j] = (bits2[i][j] & bits3[i][j]);
                mean1[i] += (Integer.bitCount(bits1[i][j]) + Integer.bitCount(bits2[i][j]));
                nonNumIndiv += Integer.bitCount(bits3[i][j]);
                //System.out.println(String.format("%32s", Integer.toBinaryString(bits1[j][j])).replace(' ', '0'));
                //System.out.println(String.format("%32s", Integer.toBinaryString(bits2[j][j])).replace(' ', '0'));
                //System.out.println(String.format("%32s", Integer.toBinaryString(bits3[j][j])).replace(' ', '0'));
            }
            hasMissingGty[i] = nonNumIndiv != totalPedSubjectNum;
            mean1[i] /= (nonNumIndiv << 1);
        }

    }

    private double getCorrelation(DoubleArrayList xVect, DoubleArrayList yVect) {
        double meanX = 0.0, meanY = 0.0;
        for (int i = 0; i < xVect.size(); i++) {
            meanX += xVect.getQuick(i);
            meanY += yVect.getQuick(i);
        }

        meanX /= xVect.size();
        meanY /= yVect.size();

        double sumXY = 0.0, sumX2 = 0.0, sumY2 = 0.0;
        for (int i = 0; i < xVect.size(); i++) {
            sumXY += ((xVect.getQuick(i) - meanX) * (yVect.getQuick(i) - meanY));
            sumX2 += Math.pow(xVect.getQuick(i) - meanX, 2.0);
            sumY2 += Math.pow(yVect.getQuick(i) - meanY, 2.0);
        }

        return (sumXY / (Math.sqrt(sumX2) * Math.sqrt(sumY2)));
    }

    private void formatUnphasedGenotypesCalCorr(List<Variant> variantList, int[] pedEncodeGytIDMap) {
        int varSize = variantList.size();
        int base = 2;
        int alleleNum = 2;
        int gtyID;
        int[] gtys;
        int[][] genotypes = new int[varSize][];
        boolean[][] genotypeMissing = new boolean[varSize][];
        int totalPedSubjectNum = pedEncodeGytIDMap.length;
        int nonMssingNum = 0;
        for (int t = 0; t < varSize; t++) {
            Variant var = variantList.get(t);
            if (var.getAltAlleles().length > 1) {
                continue;
            }
            genotypeMissing[t] = new boolean[totalPedSubjectNum];
            genotypes[t] = new int[totalPedSubjectNum];
            Arrays.fill(genotypes[t], 0);
            Arrays.fill(genotypeMissing[t], false);
            nonMssingNum = 0;
            for (int i = 0; i < totalPedSubjectNum; i++) {
                gtyID = pedEncodeGytIDMap[i];
                gtys = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, gtyID, totalPedSubjectNum);
                if (gtys == null) {
                    genotypeMissing[t][i] = true;
                    continue;
                } else if (gtys[0] == 1 && gtys[1] == 1) {
                    genotypes[t][i] = 2;
                    // mean1[t] += 2;
                    //  sum12[t] += 4;
                } else if (gtys[0] == 1 || gtys[1] == 1) {
                    genotypes[t][i] = 1;
                    //  mean1[t]++;
                    //  sum12[t]++;
                }
                nonMssingNum++;
            }
            // mean1[t] /= Math.sqrt(nonNumIndiv);
            //sum12[t] = Math.sqrt(sum12[t] - mean1[t] * mean1[t]);
        }
        DoubleArrayList groupA = new DoubleArrayList();
        DoubleArrayList groupB = new DoubleArrayList();
        double meanA, meanB, r;
        Long startTime = System.nanoTime();
        for (int t = 0; t < varSize; t++) {
            for (int i = t + 1; i < varSize; i++) {
                groupB.clear();
                groupA.clear();
                for (int k = 0; k < totalPedSubjectNum; k++) {
                    if (!genotypeMissing[t][k] && !genotypeMissing[i][k]) {
                        groupA.add(genotypes[t][k]);
                        groupB.add(genotypes[i][k]);
                    }
                }
                if (groupB.isEmpty()) {
                    continue;
                }
                //meanA = Descriptive.mean(groupA);
                // meanB = Descriptive.mean(groupB);

                r = getCorrelation(groupA, groupB);
                if (r > 0.05) {
                    System.out.print(variantList.get(t).refStartPosition + "\t" + variantList.get(i).refStartPosition + "\t" + r + "\n");
                }
            }
            //System.out.println();
        }
        // System.out.println("formatUnphasedGenotypesCalCorr:" + (System.nanoTime() - startTime) / 1000000000.0);
    }

    private void formatPhasedGenotypesCalLD(List<Variant> variantList, int[] pedEncodeGytIDMap) {
        int varSize = variantList.size();
        int base = 3;
        int alleleNum = 2;
        int gtyID;
        int[] gtys;
        int totalPedSubjectNum = pedEncodeGytIDMap.length;
        int[][] genotypes = new int[totalPedSubjectNum * 2][];
        boolean[][] genotypeMissing = new boolean[totalPedSubjectNum][];

        for (int i = 0; i < totalPedSubjectNum; i++) {
            genotypes[i * 2] = new int[varSize];
            genotypes[i * 2 + 1] = new int[varSize];
            genotypeMissing[i] = new boolean[varSize];
            Arrays.fill(genotypeMissing[i], false);
            Arrays.fill(genotypes[i * 2], 0);
            Arrays.fill(genotypes[i * 2 + 1], 0);
            gtyID = pedEncodeGytIDMap[i];

            for (int t = 0; t < varSize; t++) {
                Variant var = variantList.get(t);
                if (var.getAltAlleles().length > 1) {
                    continue;
                }
                gtys = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, gtyID, totalPedSubjectNum);
                if (gtys == null) {
                    genotypeMissing[i][t] = true;
                } else {
                    genotypes[i * 2][t] = gtys[0];
                    genotypes[i * 2 + 1][t] = gtys[1];
                }
            }
        }

        double meanA, meanB, r;
        Long startTime = System.nanoTime();
        double freqAB = 0;
        double freqA = 0;
        double freqB = 0;
        int nonMissing = 0;
        for (int t = 0; t < varSize; t++) {
            for (int i = t + 1; i < varSize; i++) {
                freqAB = 0;
                freqA = 0;
                freqB = 0;
                nonMissing = 0;
                for (int k = 0; k < totalPedSubjectNum; k++) {
                    if (!genotypeMissing[k][t] && !genotypeMissing[k][i]) {
                        if (genotypes[k * 2][t] == 1) {
                            freqA += 1;
                        }
                        if (genotypes[k * 2][i] == 1) {
                            freqB += 1;
                        }
                        if (genotypes[k * 2][t] == 1 && genotypes[k * 2][i] == 1) {
                            freqAB += 1;
                        }
                        if (genotypes[k * 2 + 1][t] == 1) {
                            freqA += 1;
                        }
                        if (genotypes[k * 2 + 1][i] == 1) {
                            freqB += 1;
                        }
                        if (genotypes[k * 2 + 1][t] == 1 && genotypes[k * 2 + 1][i] == 1) {
                            freqAB += 1;
                        }
                        nonMissing += 2;
                    }
                }
                freqA = freqA / nonMissing;
                freqB = freqB / nonMissing;
                freqAB = freqAB / nonMissing;
                r = freqAB - freqA * freqB;
                r = r / Math.sqrt(freqA * (1 - freqA) * freqB * (1 - freqB));
                if (r > 0.05) {
                    System.out.print(variantList.get(t).refStartPosition + "\t" + variantList.get(i).refStartPosition + "\t" + r + "\n");
                }
            }
            //System.out.println();
        }
        // System.out.println("formatUnphasedGenotypesCalCorr:" + (System.nanoTime() - startTime) / 1000000000.0);
    }

    public void calculateLDVar(Chromosome chromosome, List<Individual> subjectList,
            int[] pedEncodeGytIDMap, boolean isPhased, int threadNum, int windowWidth, double minR2, BufferedWriter bwLD) throws Exception {
        if (chromosome == null) {
            return;
        }
        if (chromosome.variantList == null || chromosome.variantList.isEmpty()) {
            return;
        }
        List<Variant> selectedVariantList = new ArrayList<Variant>();
        for (Variant var : chromosome.variantList) {
            //onle consider biallelic dependentVariants
            if (var.getAltAlleles().length > 1) {
                continue;
            }
            selectedVariantList.add(var);
        }
        int[] positions = new int[selectedVariantList.size()];
        for (int i = 0; i < positions.length; i++) {
            positions[i] = selectedVariantList.get(i).refStartPosition;
        }
        String chromName = chromosome.getName();
        int varSize = selectedVariantList.size();
        int[][] bits1 = new int[varSize][];
        int[][] bits2 = new int[varSize][];
        int[][] bits3 = new int[varSize][];
        int[][] bits4 = null;
        double[] mean1 = new double[varSize];
        int[] sum12 = null;
        boolean[] hasMissingGty = new boolean[varSize];
        int totalPedSubjectNum = pedEncodeGytIDMap.length;
        if (isPhased) {
            formatBialleleicPhasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, mean1, hasMissingGty);
            //formatPhasedGenotypesCalLD(selectedVariantList, pedEncodeGytIDMap);
        } else {
            bits4 = new int[varSize][];
            sum12 = new int[varSize];
            formatBialleleicUnphasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty);
            //formatUnphasedGenotypesCalCorr(selectedVariantList, pedEncodeGytIDMap);
        }

        //cannot be too large
        //double[] corrs = new double[varSize * (varSize - 1) / 2];
        int runningThread = 0;
        // int[] smallBlockIndexes = cc.partitionEvenBlock(size, threadNum > 50 ? threadNum : 50);
        int[] smallBlockIndexes = partitionEvenBlock(varSize, threadNum * 5);
        int smallBlockNum = smallBlockIndexes.length - 1;
        int lastButOneIndex = smallBlockIndexes[smallBlockNum - 1];
        int lastBlockLen = smallBlockIndexes[smallBlockNum] - smallBlockIndexes[smallBlockNum - 1];

        int blockLen = smallBlockIndexes[1] - smallBlockIndexes[0];
        int ti = 0;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        Long startTime = System.nanoTime();
        for (int i = 0; i < smallBlockNum; i++) {
            final double[][] rArray = new double[smallBlockNum - i][];
            runningThread = 0;
            for (int j = i; j < smallBlockNum; j++) {
                //always prepare a rectangle
                rArray[j - i] = new double[(smallBlockIndexes[i + 1] - smallBlockIndexes[i]) * (smallBlockIndexes[j + 1] - smallBlockIndexes[j])];
                LDCalcTask task = new LDCalcTask(bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty, totalPedSubjectNum, smallBlockIndexes[i], smallBlockIndexes[i + 1],
                        smallBlockIndexes[j], smallBlockIndexes[j + 1], rArray[j - i], isPhased);
                task.setPositionCutoff(positions, windowWidth);
                serv.submit(task);
                runningThread++;
            }

            for (int index = 0; index < runningThread; index++) {
                Future task1 = serv.take();
                String infor1 = (String) task1.get();
                // System.out.println(infor);
            }

            //unfortunately the last block often have uneven size 
            //correct for dependency
            double r;
            for (int t = smallBlockIndexes[i]; t < smallBlockIndexes[i + 1]; t++) {
                for (int k = t + 1; k < varSize; k++) {
                    if (k < lastButOneIndex) {
                        r = rArray[(k - smallBlockIndexes[i]) / blockLen][(t - smallBlockIndexes[i]) * blockLen + (k - smallBlockIndexes[i]) % blockLen];
                    } else {
                        r = rArray[smallBlockNum - i - 1][(t - smallBlockIndexes[i]) * lastBlockLen + k - lastButOneIndex];
                    }
                    // corrs[ti] = r;
                    r = r * r;
                    if (r > minR2) {
                        bwLD.write(chromName + "\t" + selectedVariantList.get(t).refStartPosition + "\t" + selectedVariantList.get(k).refStartPosition + "\t" + r + "\n");
                    }
                    // tmpFileWriter.write(allData.get(t).id + "\t" + allData.get(k).id + "\t" + r + "\n");
                    //System.out.print("(" + t + "," + k + ":" + r + ")");
                    //  System.out.println(ti + ":" + r);
                    ti++;
                }
                //System.out.println();
            }
        }//end of  for (int t = 0; t < smallBlockNum; t++)
        // System.out.println("LDCalcTask:" + (System.nanoTime() - startTime) / 1000000000.0);
        exec.shutdown();

    }

    public double[] calculateLDVarRegion(Chromosome chromosome, int regionStart, int regionEnd, List<Individual> subjectList,
            int[] pedEncodeGytIDMap, boolean isPhased, int threadNum) throws Exception {
        if (chromosome == null) {
            return new double[]{-1, -1};
        }
        if (chromosome.variantList == null || chromosome.variantList.isEmpty()) {
            return new double[]{-1, -1};
        }
        int windowWidth = 10000000;
        List<Variant> selectedVariantList = new ArrayList<Variant>();
        int[] indexes = new int[2];
        chromosome.lookupVariantByRegions(regionStart, regionEnd, indexes);
        int homR, het, homA;
        for (int i = indexes[0]; i < indexes[1]; i++) {
            Variant var = chromosome.variantList.get(i);
            homR = var.getAffectedRefHomGtyNum();
            het = var.getAffectedHetGtyNum();
            homA = var.getAffectedAltHomGtyNum();

            if ((homA == 0 && homA == het) || (homR == 0 && homR == het) || (homR == 0 && homR == homR)) {
                continue;
            }
            //onle consider biallelic dependentVariants
            if (var.getAltAlleles().length > 1) {
                continue;
            }

            selectedVariantList.add(var);
            // System.out.println(var.refStartPosition + "\t" + var.getAffectedRefHomGtyNum() + "\t" + var.getAffectedHetGtyNum() + "\t" + var.getAffectedAltHomGtyNum());
        }

        int[] positions = new int[selectedVariantList.size()];
        for (int i = 0; i < positions.length; i++) {
            positions[i] = selectedVariantList.get(i).refStartPosition;
        }
        String chromName = chromosome.getName();
        int varSize = selectedVariantList.size();
        int[][] bits1 = new int[varSize][];
        int[][] bits2 = new int[varSize][];
        int[][] bits3 = new int[varSize][];
        int[][] bits4 = null;
        double[] mean1 = new double[varSize];
        int[] sum12 = null;
        boolean[] hasMissingGty = new boolean[varSize];
        int totalPedSubjectNum = pedEncodeGytIDMap.length;
        if (isPhased) {
            formatBialleleicPhasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, mean1, hasMissingGty);
            //formatPhasedGenotypesCalLD(selectedVariantList, pedEncodeGytIDMap);
        } else {
            bits4 = new int[varSize][];
            sum12 = new int[varSize];
            formatBialleleicUnphasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty);
            //formatUnphasedGenotypesCalCorr(selectedVariantList, pedEncodeGytIDMap);
        }

        //cannot be too large
        //double[] corrs = new double[varSize * (varSize - 1) / 2];
        double[] ldValues = new double[3];

        Arrays.fill(ldValues, 0);
        if (varSize <= 1) {
            return ldValues;
        }
        ldValues[0] = varSize;
        int runningThread = 0;
        // int[] smallBlockIndexes = cc.partitionEvenBlock(size, threadNum > 50 ? threadNum : 50);
        int[] smallBlockIndexes = partitionEvenBlock(varSize, threadNum * 5);
        int smallBlockNum = smallBlockIndexes.length - 1;
        int lastButOneIndex = smallBlockIndexes[smallBlockNum - 1];
        int lastBlockLen = smallBlockIndexes[smallBlockNum] - smallBlockIndexes[smallBlockNum - 1];

        int blockLen = smallBlockIndexes[1] - smallBlockIndexes[0];
        int ti = 0;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        Long startTime = System.nanoTime();

        for (int i = 0; i < smallBlockNum; i++) {
            final double[][] rArray = new double[smallBlockNum - i][];
            runningThread = 0;
            for (int j = i; j < smallBlockNum; j++) {
                //always prepare a rectangle
                rArray[j - i] = new double[(smallBlockIndexes[i + 1] - smallBlockIndexes[i]) * (smallBlockIndexes[j + 1] - smallBlockIndexes[j])];
                LDCalcTask task = new LDCalcTask(bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty, totalPedSubjectNum, smallBlockIndexes[i], smallBlockIndexes[i + 1],
                        smallBlockIndexes[j], smallBlockIndexes[j + 1], rArray[j - i], isPhased);
                task.setPositionCutoff(positions, windowWidth);
                serv.submit(task);
                runningThread++;
            }

            for (int index = 0; index < runningThread; index++) {
                Future task1 = serv.take();
                String infor1 = (String) task1.get();
                // System.out.println(infor);
            }

            //unfortunately the last block often have uneven size 
            //correct for dependency
            double r;
            for (int t = smallBlockIndexes[i]; t < smallBlockIndexes[i + 1]; t++) {
                for (int k = t + 1; k < varSize; k++) {
                    if (k < lastButOneIndex) {
                        r = rArray[(k - smallBlockIndexes[i]) / blockLen][(t - smallBlockIndexes[i]) * blockLen + (k - smallBlockIndexes[i]) % blockLen];
                    } else {
                        r = rArray[smallBlockNum - i - 1][(t - smallBlockIndexes[i]) * lastBlockLen + k - lastButOneIndex];
                    }
                    // corrs[ti] = r;
                    if (!Double.isNaN(r)) {
                        ldValues[1] += 1;
                        r = r * r;
                        ldValues[2] += r;
                    }

                    // tmpFileWriter.write(allData.get(t).id + "\t" + allData.get(k).id + "\t" + r + "\n");
                    //System.out.print("(" + t + "," + k + ":" + r + ")");
                    //  System.out.println(ti + ":" + r);
                    ti++;
                }
                //System.out.println();
            }
        }//end of  for (int t = 0; t < smallBlockNum; t++)
        // System.out.println("LDCalcTask:" + (System.nanoTime() - startTime) / 1000000000.0);
        exec.shutdown();
        return ldValues;
    }

    public void LDPruneWithinDistance(Chromosome chromosome, List<Individual> subjectList,
            int[] pedEncodeGytIDMap, boolean isPhased, int threadNum, int windowWidth, double r2, AnnotationSummarySet ass) throws Exception {

        if (chromosome == null) {
            return;
        }
        if (chromosome.variantList == null || chromosome.variantList.isEmpty()) {
            return;
        }
        List<Variant> selectedVariantList = new ArrayList<Variant>();

        for (Variant var : chromosome.variantList) {
            //onle consider biallelic dependentVariants
            if (var.getAltAlleles().length > 1) {
                continue;
            }
            selectedVariantList.add(var);
        }
        int[] positions = new int[selectedVariantList.size()];
        for (int i = 0; i < positions.length; i++) {
            positions[i] = selectedVariantList.get(i).refStartPosition;
        }
        String chromName = chromosome.getName();
        int varSize = selectedVariantList.size();
        int[][] bits1 = new int[varSize][];
        int[][] bits2 = new int[varSize][];
        int[][] bits3 = new int[varSize][];
        int[][] bits4 = null;
        double[] mean1 = new double[varSize];
        int[] sum12 = null;
        boolean[] hasMissingGty = new boolean[varSize];
        int totalPedSubjectNum = pedEncodeGytIDMap.length;
        if (isPhased) {
            formatBialleleicPhasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, mean1, hasMissingGty);
            //formatPhasedGenotypesCalLD(selectedVariantList, pedEncodeGytIDMap);
        } else {
            bits4 = new int[varSize][];
            sum12 = new int[varSize];
            formatBialleleicUnphasedBits(selectedVariantList, totalPedSubjectNum, bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty);
            //formatUnphasedGenotypesCalCorr(selectedVariantList, pedEncodeGytIDMap);
        }

        //cannot be too large
        //double[] corrs = new double[varSize * (varSize - 1) / 2];
        int runningThread = 0;
        // int[] smallBlockIndexes = cc.partitionEvenBlock(size, threadNum > 50 ? threadNum : 50);
        int[] smallBlockIndexes = partitionEvenBlock(varSize, threadNum * 5);
        int smallBlockNum = smallBlockIndexes.length - 1;
        int lastButOneIndex = smallBlockIndexes[smallBlockNum - 1];
        int lastBlockLen = smallBlockIndexes[smallBlockNum] - smallBlockIndexes[smallBlockNum - 1];

        int blockLen = smallBlockIndexes[1] - smallBlockIndexes[0];

        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        OpenIntIntHashMap redundantVars = new OpenIntIntHashMap();
        for (int i = 0; i < smallBlockNum; i++) {
            final double[][] rArray = new double[smallBlockNum - i][];
            runningThread = 0;
            for (int j = i; j < smallBlockNum; j++) {
                //always prepare a rectangle
                rArray[j - i] = new double[(smallBlockIndexes[i + 1] - smallBlockIndexes[i]) * (smallBlockIndexes[j + 1] - smallBlockIndexes[j])];
                Arrays.fill(rArray[j - i], 0);
                LDCalcTask task = new LDCalcTask(bits1, bits2, bits3, bits4, mean1, sum12, hasMissingGty, totalPedSubjectNum, smallBlockIndexes[i], smallBlockIndexes[i + 1],
                        smallBlockIndexes[j], smallBlockIndexes[j + 1], rArray[j - i], isPhased);
                task.setPositionCutoff(positions, windowWidth);
                serv.submit(task);
                runningThread++;
            }

            for (int index = 0; index < runningThread; index++) {
                Future task1 = serv.take();
                String infor1 = (String) task1.get();
                // System.out.println(infor);
            }

            //unfortunately the last block often have uneven size 
            //correct for dependency
            double r;
            for (int t = smallBlockIndexes[i]; t < smallBlockIndexes[i + 1]; t++) {
                for (int k = t + 1; k < varSize; k++) {
                    if (k < lastButOneIndex) {
                        r = rArray[(k - smallBlockIndexes[i]) / blockLen][(t - smallBlockIndexes[i]) * blockLen + (k - smallBlockIndexes[i]) % blockLen];
                    } else {
                        r = rArray[smallBlockNum - i - 1][(t - smallBlockIndexes[i]) * lastBlockLen + k - lastButOneIndex];
                    }
                    // corrs[ti] = r;
                    r = r * r;
                    if (r >= r2) {
                        if (!redundantVars.containsKey(selectedVariantList.get(t).refStartPosition) && !redundantVars.containsKey(selectedVariantList.get(k).refStartPosition)) {
                            redundantVars.put(selectedVariantList.get(k).refStartPosition, 0);
                        }
                    }
                    // tmpFileWriter.write(allData.get(t).id + "\t" + allData.get(k).id + "\t" + r + "\n");
                    //System.out.print("(" + t + "," + k + ":" + r + ")");
                    //  System.out.println(ti + ":" + r);

                }
                //System.out.println();
            }
        }//end of  for (int t = 0; t < smallBlockNum; t++)
        // System.out.println("LDCalcTask:" + (System.nanoTime() - startTime) / 1000000000.0);
        exec.shutdown();

        if (!redundantVars.isEmpty()) {
            selectedVariantList.clear();
            selectedVariantList.addAll(chromosome.variantList);
            chromosome.variantList.clear();
            for (Variant var : selectedVariantList) {
                //onle consider biallelic dependentVariants
                if (!redundantVars.containsKey(var.refStartPosition)) {
                    chromosome.variantList.add(var);
                }
            }
            //System.out.println("On chromosome " + chromName + ", " + redundantVars.size() + " dependentVariants in high LD r2>" + r2 + " are removed!");
            redundantVars.clear();
            chromosome.buildVariantIndexMap();
        }
        //  System.out.println(chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size());
    }

    public void calculateLDVarComp(Chromosome chromosome, OpenLongObjectHashMap wahBit, List<Individual> subjectList,
            int[] pedEncodeGytIDMap, boolean isPhased, int threadNum) throws Exception {
        if (chromosome == null) {
            return;
        }
        if (chromosome.variantList == null || chromosome.variantList.isEmpty()) {
            return;
        }
        List<Variant> selectedVariantList = new ArrayList<Variant>();
        for (Variant var : chromosome.variantList) {
            //onle consider biallelic dependentVariants
            if (var.getAltAlleles().length > 1) {
                continue;
            }
            selectedVariantList.add(var);
        }
        List<Variant> runningList = new ArrayList<Variant>();
        int testingSize = 1000;
        ExecutorService exec = Executors.newFixedThreadPool(threadNum);
        CompletionService serv = new ExecutorCompletionService(exec);
        do {
            for (int s = 0; s < testingSize; s++) {
                runningList.add(selectedVariantList.get(s));
            }
            System.out.println("Testing size: " + testingSize);
            int varSize = runningList.size();
            int[][] bits1 = new int[varSize][];
            int[][] bits2 = new int[varSize][];
            int[][] bits3 = new int[varSize][];
            int[][] bits4 = new int[varSize][];
            double[] sum1 = new double[varSize];
            int[] sum12 = new int[varSize];
            boolean[] hasMissingGty = new boolean[varSize];
            int totalPedSubjectNum = pedEncodeGytIDMap.length;
            formatBialleleicUnphasedBits(runningList, totalPedSubjectNum, bits1, bits2, bits3, bits4, sum1, sum12, hasMissingGty);
            //  formatUnphasedGenotypesCalCorr(runningList, pedEncodeGytIDMap);
            double[] corrs = new double[varSize * (varSize - 1) / 2];
            int runningThread = 0;
            // int[] smallBlockIndexes = cc.partitionEvenBlock(size, threadNum > 50 ? threadNum : 50);
            int[] smallBlockIndexes = partitionEvenBlock(varSize, threadNum * 5);
            int smallBlockNum = smallBlockIndexes.length - 1;
            int lastButOneIndex = smallBlockIndexes[smallBlockNum - 1];
            int lastBlockLen = smallBlockIndexes[smallBlockNum] - smallBlockIndexes[smallBlockNum - 1];

            int blockLen = smallBlockIndexes[1] - smallBlockIndexes[0];
            int ti = 0;

            Long startTime = System.nanoTime();
            for (int i = 0; i < smallBlockNum; i++) {
                final double[][] rArray = new double[smallBlockNum - i][];
                runningThread = 0;
                for (int j = i; j < smallBlockNum; j++) {
                    //always prepare a rectangle
                    rArray[j - i] = new double[(smallBlockIndexes[i + 1] - smallBlockIndexes[i]) * (smallBlockIndexes[j + 1] - smallBlockIndexes[j])];
                    LDCalcTask task = new LDCalcTask(bits1, bits2, bits3, bits4, sum1, sum12, hasMissingGty, totalPedSubjectNum, smallBlockIndexes[i], smallBlockIndexes[i + 1],
                            smallBlockIndexes[j], smallBlockIndexes[j + 1], rArray[j - i], isPhased);
                    serv.submit(task);
                    runningThread++;
                }

                for (int index = 0; index < runningThread; index++) {
                    Future task1 = serv.take();
                    String infor1 = (String) task1.get();
                    // System.out.println(infor);
                }

                //unfortunately the last block often have uneven size 
                //correct for dependency
                double r;
                for (int t = smallBlockIndexes[i]; t < smallBlockIndexes[i + 1]; t++) {
                    for (int k = t + 1; k < varSize; k++) {
                        if (k < lastButOneIndex) {
                            r = rArray[(k - smallBlockIndexes[i]) / blockLen][(t - smallBlockIndexes[i]) * blockLen + (k - smallBlockIndexes[i]) % blockLen];
                        } else {
                            r = rArray[smallBlockNum - i - 1][(t - smallBlockIndexes[i]) * lastBlockLen + k - lastButOneIndex];
                        }
                        corrs[ti] = r;

                        // tmpFileWriter.write(allData.get(t).id + "\t" + allData.get(k).id + "\t" + r + "\n");
                        //System.out.print("(" + t + "," + k + ":" + r + ")");
                        //  System.out.println(ti + ":" + r);
                        ti++;
                    }
                    //  System.out.println();
                }
            }//end of  for (int t = 0; t < smallBlockNum; t++)
            System.out.println("LDCalcTask：" + (System.nanoTime() - startTime) / 1000000000.0);
            testingSize += 3000;
            runningList.clear();
        } while (testingSize < selectedVariantList.size());

        exec.shutdown();

    }

    public void addPatho(Chromosome chromosome, AnnotationSummarySet ass, HashMap<String, String[]> hmpPatho, int intPatho) {
        int intNum = 0;
        if (chromosome == null) {
            return;
        }
        //exclude the first column
        intPatho = intPatho - 1;
        int varFeatureNum = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            for (int i = 0; i < intPatho; i++) {
                var.setFeatureValue(varFeatureNum + i, null);
            }
        }
        String[] cells = null;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }
            String strGene = var.geneSymb.toUpperCase();
            cells = hmpPatho.get(strGene);
            if (cells == null) {
                continue;
            }
            for (int i = 0; i < intPatho; i++) {
                var.setFeatureValue(varFeatureNum + i, hmpPatho.get(strGene)[i]);
            }
            intNum++;
        }

        ass.setAnnotNum(ass.getAnnotNum() + intNum);
    }

    public void annotateGenes(Chromosome chromosome, AnnotationSummarySet ass, HashMap<String, String> g2Phe) {
        int intNum = 0;
        if (chromosome == null) {
            return;
        }

        int varFeatureNum = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                var.setFeatureValue(varFeatureNum, null);
                continue;
            }
            String strGene = var.geneSymb.toUpperCase();
            if (g2Phe.containsKey(strGene)) {
                var.setFeatureValue(varFeatureNum, g2Phe.get(strGene));
                intNum++;
            } else {
                var.setFeatureValue(varFeatureNum, ".");
            }
        }

        ass.setAnnotNum(ass.getAnnotNum() + intNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - intNum);
    }

    public void annotateGenesArray(Chromosome chromosome, AnnotationSummarySet ass, Map<String, String[]> g2Phe, int valueNum) {
        int intNum = 0;
        if (chromosome == null) {
            return;
        }
        String[] values = null;
        int varFeatureNum = ass.getAvailableFeatureIndex();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                var.setFeatureValue(varFeatureNum, null);
                continue;
            }
            String strGene = var.geneSymb.toUpperCase();
            values = g2Phe.get(strGene);
            if (values != null) {
                for (int i = 0; i < valueNum; i++) {
                    var.setFeatureValue(varFeatureNum + i, values[i]);
                }
                intNum++;
            } else {
                for (int i = 0; i < valueNum; i++) {
                    var.setFeatureValue(varFeatureNum + i, ".");
                }
            }

        }

        ass.setAnnotNum(ass.getAnnotNum() + intNum);
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size() - intNum);
    }

    public void hweTestVar(Chromosome chromosome, double hwdPCase, double hwdPControl, double hwdPAll, AnnotationSummarySet ass) {
        if (chromosome == null) {
            return;
        }

        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
        int[] caseGtys = new int[3];
        int[] controlGtys = new int[3];
        int excludeCase = 0, exludeControl = 0, excludeAll = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        for (Variant var : chromosome.variantList) {
            Arrays.fill(caseGtys, 0);
            caseGtys[0] = var.getAffectedRefHomGtyNum();
            caseGtys[1] = var.getAffectedHetGtyNum();
            caseGtys[2] = var.getAffectedAltHomGtyNum();

            Arrays.fill(controlGtys, 0);
            controlGtys[0] = var.getUnaffectedRefHomGtyNum();
            controlGtys[1] = var.getUnaffectedHetGtyNum();
            controlGtys[2] = var.getUnaffectedAltHomGtyNum();

            if (hwdPCase > 0) {
                if (hwdPCase > HardyWeinbergCalculation.hwCalculate(caseGtys[0], caseGtys[1], caseGtys[2])) {
                    excludeCase++;
                    continue;
                }
            }
            // System.out.println(var.refStartPosition);
//            if(var.refStartPosition==887801){
//                int ssss=0;
//            }
            if (hwdPControl > 0) {
                if (hwdPControl > HardyWeinbergCalculation.hwCalculate(controlGtys[0], controlGtys[1], controlGtys[2])) {
                    exludeControl++;
                    continue;
                }
            }

            if (hwdPAll > 0) {
                if (hwdPAll > HardyWeinbergCalculation.hwCalculate(caseGtys[0] + controlGtys[0], caseGtys[1] + controlGtys[1], caseGtys[2] + controlGtys[2])) {
                    excludeAll++;
                    continue;
                }
            }
            tmpVarList.add(var);
        }
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();
        chromosome.buildVariantIndexMap();

        ass.setAnnotNum(ass.getAnnotNum() + excludeCase);//The annotNum is used to denote the excludeCase temporarily. 
        ass.setLeftNum(ass.getLeftNum() + exludeControl);//The leftNum is used to denote the excludeControl temporarily. 
        ass.setTotalNum(ass.getTotalNum() + excludeAll);//The excludeAll is used to denote the excludeAll temporarily. 

    }

    public void caseControlMAFFilterVar(Chromosome chromosome, double caseMafLess, double caseMafOver, double controlMafLess, double controlMafOver, AnnotationSummarySet ass) {
        if (chromosome == null) {
            return;
        }
        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
        int[] caseGtys = new int[3];
        int[] controlGtys = new int[3];
        int excludeCase = 0, exludeControl = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        double caseMafLessC = 1 - caseMafLess;
        double caseMafOverC = 1 - caseMafOver;
        double controlMafLessC = 1 - controlMafLess;
        double controlMafOverC = 1 - controlMafOver;
        double altFreqCase, altFreqControl;
        for (Variant var : chromosome.variantList) {
            Arrays.fill(caseGtys, 0);
            caseGtys[0] = var.getAffectedRefHomGtyNum();
            caseGtys[1] = var.getAffectedHetGtyNum();
            caseGtys[2] = var.getAffectedAltHomGtyNum();
            altFreqCase = (caseGtys[1] * 0.5 + caseGtys[2]) / (caseGtys[0] + caseGtys[1] + caseGtys[2]);

            Arrays.fill(controlGtys, 0);
            controlGtys[0] = var.getUnaffectedRefHomGtyNum();
            controlGtys[1] = var.getUnaffectedHetGtyNum();
            controlGtys[2] = var.getUnaffectedAltHomGtyNum();
            altFreqControl = (controlGtys[1] * 0.5 + controlGtys[2]) / (controlGtys[0] + controlGtys[1] + controlGtys[2]);

            if (caseMafOver > 0) {
                if (altFreqCase <= 0.5) {
                    if (altFreqCase < caseMafOver) {
                        excludeCase++;
                        continue;
                    }
                } else {
                    if (altFreqCase > caseMafOverC) {
                        excludeCase++;
                        continue;
                    }
                }
            }
            if (caseMafLess < 1) {
                if (altFreqCase <= 0.5) {
                    if (altFreqCase > caseMafLess) {
                        excludeCase++;
                        continue;
                    }
                } else {
                    if (altFreqCase < caseMafLessC) {
                        excludeCase++;
                        continue;
                    }
                }
            }

            if (controlMafOver > 0) {
                if (altFreqControl <= 0.5) {
                    if (altFreqControl < controlMafOver) {
                        exludeControl++;
                        continue;
                    }
                } else {
                    if (altFreqControl > controlMafOverC) {
                        exludeControl++;
                        continue;
                    }
                }
            }
            if (controlMafLess < 1) {
                if (altFreqControl <= 0.5) {
                    if (altFreqControl > controlMafLess) {
                        exludeControl++;
                        continue;
                    }
                } else {
                    if (altFreqControl < controlMafLessC) {
                        exludeControl++;
                        continue;
                    }
                }
            }

            tmpVarList.add(var);
        }
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();
        chromosome.buildVariantIndexMap();

        // ass.setAnnotNum(ass.getAnnotNum() + excludeCase);//The annotNum is used to denote the excludeCase temporarily. 
        ass.setLeftNum(ass.getLeftNum() + excludeCase);//The leftNum is used to denote the excludeControl temporarily. 
        ass.setTotalNum(ass.getTotalNum() + exludeControl);//The excludeAll is used to denote the excludeAll temporarily. 

    }

    public void caseControlMAFRatioFilterVar(Chromosome chromosome, double minCaseControlRatio, AnnotationSummarySet ass) {

        if (chromosome == null) {
            return;
        }
        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
        int[] caseGtys = new int[3];
        int[] controlGtys = new int[3];
        int excludeCase = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();

        double altFreqCase, altFreqControl;
        for (Variant var : chromosome.variantList) {
            Arrays.fill(caseGtys, 0);
            caseGtys[0] = var.getAffectedRefHomGtyNum();
            caseGtys[1] = var.getAffectedHetGtyNum();
            caseGtys[2] = var.getAffectedAltHomGtyNum();
            altFreqCase = (caseGtys[1] * 0.5 + caseGtys[2]) / (caseGtys[0] + caseGtys[1] + caseGtys[2]);

            Arrays.fill(controlGtys, 0);
            controlGtys[0] = var.getUnaffectedRefHomGtyNum();
            controlGtys[1] = var.getUnaffectedHetGtyNum();
            controlGtys[2] = var.getUnaffectedAltHomGtyNum();
            altFreqControl = (controlGtys[1] * 0.5 + controlGtys[2]) / (controlGtys[0] + controlGtys[1] + controlGtys[2]);
            if (altFreqCase < minCaseControlRatio * altFreqControl) {
                excludeCase++;
                continue;
            }

            tmpVarList.add(var);
        }
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();
        chromosome.buildVariantIndexMap();

        // ass.setAnnotNum(ass.getAnnotNum() + excludeCase);//The annotNum is used to denote the excludeCase temporarily. 
        ass.setLeftNum(ass.getLeftNum() + excludeCase);//The leftNum is used to denote the excludeControl temporarily. 
        ass.setTotalNum(ass.getTotalNum() + chromosome.variantList.size());
    }

    public void ctTypeFilterVar(Chromosome chromosome, int ctType, AnnotationSummarySet ass) {
        if (chromosome == null) {
            return;
        }
        // AffectedRefHomGtyNum\tAffectedHetGtyNum\tAffectedAltHomGtyNum\tUnaffectedRefHomGtyNum\tUnaffectedHetGtyNum\tUnaffectedAltHomGtyNum
        int excludeCase = 0;
        List<Variant> tmpVarList = new ArrayList<Variant>();
        StringBuilder sb = new StringBuilder();
//ctType: 0 for all; 1 for only ct; 2 for no ct
        for (Variant var : chromosome.variantList) {
            sb.delete(0, sb.length());
            if (ctType == 1) {
                if (var.getAltAlleles().length > 1) {
                    excludeCase++;
                    continue;
                }
                sb.append(var.getRefAllele());
                sb.append(var.getAltAllele(0));
                if (!sb.toString().toUpperCase().equals("CT") && !sb.toString().toUpperCase().equals("TC")) {
                    excludeCase++;
                    continue;
                }
            } else if (ctType == 2) {
                if (var.getAltAlleles().length == 1) {
                    sb.append(var.getRefAllele());
                    sb.append(var.getAltAllele(0));
                    if (sb.toString().toUpperCase().equals("CT") || sb.toString().toUpperCase().equals("TC")) {
                        excludeCase++;
                        continue;
                    }
                }
            }

            tmpVarList.add(var);
        }
        chromosome.variantList.clear();
        chromosome.variantList.addAll(tmpVarList);
        tmpVarList.clear();
        chromosome.buildVariantIndexMap();

        // ass.setAnnotNum(ass.getAnnotNum() + excludeCase);//The annotNum is used to denote the excludeCase temporarily. 
        ass.setLeftNum(ass.getLeftNum() + chromosome.variantList.size());//The leftNum is used to denote the excludeControl temporarily. 
        ass.setTotalNum(ass.getTotalNum() + excludeCase);

    }

    private class GeneFeatureAnnotTask extends Task implements Callable<String> {

        List<Variant> varList;
        int chrID;
        ReferenceGenome refGenome;
        Set<Byte> featureInSet;
        int featureNum;

        public GeneFeatureAnnotTask(List<Variant> varList, int chrID, ReferenceGenome refGenome, Set<Byte> featureInSet, int featureNum) {
            this.varList = varList;
            this.chrID = chrID;
            this.refGenome = refGenome;
            this.featureInSet = featureInSet;
            this.featureNum = featureNum;
        }

        @Override
        public String call() throws Exception {

            if (refGenome.getName().equals("refgene")) {
                if (varList == null) {
                    return null;
                }

                for (Variant var : varList) {

                    GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                    // Feature for UniProtFeature
                    if (gf.getInfor() == null) {
                        var.setFeatureValue(featureNum, ".");
                    } else {
                        var.setFeatureValue(featureNum, gf.getInfor());
                    }
                    var.setRefGeneAnnot(gf.getName());
                }
            } else if (refGenome.getName().equals("gencode")) {
                if (varList == null) {
                    return null;
                }
                for (Variant var : varList) {
                    GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                    // Feature for UniProtFeature
                    if (gf.getInfor() == null) {
                        var.setFeatureValue(featureNum, ".");
                    } else {
                        var.setFeatureValue(featureNum, gf.getInfor());
                    }
                    var.setgEncodeAnnot(gf.getName());

                }

            } else if (refGenome.getName().equals("knowngene")) {
                if (varList == null) {
                    return null;
                }
                for (Variant var : varList) {
                    GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                    // Feature for UniProtFeature
                    if (gf.getInfor() == null) {
                        var.setFeatureValue(featureNum, ".");
                    } else {
                        var.setFeatureValue(featureNum, gf.getInfor());
                    }
                    var.setKnownGeneAnnot(gf.getName());
                }

            } else if (refGenome.getName().equals("ensembl")) {
                if (varList == null) {
                    return null;
                }
                for (Variant var : varList) {
                    GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                    // Feature for UniProtFeature
                    if (gf.getInfor() == null) {
                        var.setFeatureValue(featureNum, ".");
                    } else {
                        var.setFeatureValue(featureNum, gf.getInfor());
                    }
                    var.setEnsemblGeneAnnot(gf.getName());
                }
            } else {
                //customized gene feature 
                if (varList == null) {
                    return null;
                }
                for (Variant var : varList) {
                    GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                    // Feature for UniProtFeature
                    if (gf.getInfor() == null) {
                        var.setFeatureValue(featureNum, ".");
                    } else {
                        var.setFeatureValue(featureNum, gf.getInfor());
                    }
                    var.setCustomizedGeneAnnot(gf.getName());
                }
            }
            return "";
        }
    }

    public int[] partitionEvenBlock(int threadNum, int startIndex, int endIndex) throws Exception {
        int totalSnpSize = endIndex - startIndex;
        int intervalLen = totalSnpSize / threadNum;
        int[] bigBlockIndexes = null;

        if (intervalLen == 0) {
            // no need to block
            bigBlockIndexes = new int[2];
            bigBlockIndexes[0] = startIndex;
            bigBlockIndexes[1] = endIndex;

        } else {
            bigBlockIndexes = new int[threadNum + 1];
            Arrays.fill(bigBlockIndexes, startIndex);
            for (int s = 1; s < threadNum; s++) {
                bigBlockIndexes[s] = startIndex + s * intervalLen;
            }
            bigBlockIndexes[threadNum] = endIndex;
        }

        return bigBlockIndexes;

    }

    public class NoncodingRandomForestGFCTask implements Callable<String> {

        Variant[] variantArray;
        MyRandomForest[] myRandomForestList;
        Map genicMap;
        Set<String> geneSymbSet;
        boolean needVerboseNoncode;
        int start;
        int end;
        int featureNum;

        public NoncodingRandomForestGFCTask(MyRandomForest[] myRandomForestList, Map genicMap, int featureNum, int start, int end, Variant[] variantArray, boolean needVerboseNoncode) {
            this.variantArray = variantArray;
            this.genicMap = genicMap;
            this.needVerboseNoncode = needVerboseNoncode;
            this.start = start;
            this.end = end;
            this.featureNum = featureNum;
            this.myRandomForestList = myRandomForestList;

        }

        @Override
        public String call() throws Exception {
            int funseq2Index = -1;
            for (int i = start; i < end; i++) {
                Variant var = variantArray[i];
                String mostImportantGeneFeature = org.cobi.kggseq.Constants.VAR_FEATURE_NAMES[var.smallestFeatureID];
                int index = (Integer) genicMap.get(mostImportantGeneFeature);
                double[] score = new double[var.scores2.length];
                if (funseq2Index < 0) {
                    funseq2Index = score.length - 3;
                }
                for (int j = 0; j < score.length; j++) {
                    /*
                    if (j == funseq2Index) {
//return back the non-log socre of FunSeq2  
//now the funseq2 socre has been taken log10, so it no need to re-do it
                        score[j] = Math.log10(var.scores2[j]);
                    } else {
                        score[j] = var.scores2[j] + 0.0;
                    }
                     */
                    score[j] = var.scores2[j];
                }

                if (!needVerboseNoncode) {
                    //var.scores = null;
                    var.scores2 = new float[10];
                    for (int j = 0; j < var.scores2.length; j++) {
                        var.scores2[j] = (float) score[score.length - var.scores2.length + j];
                    }
                    //System.arraycopy(score, score.length - var.scores.length, var.scores, 0, var.scores.length);
                }
                double tmpP[];
                try {
                    tmpP = myRandomForestList[index].getClassifyDistribution(score);
                    if (tmpP[0] == 1) {
                        var.setFeatureValue(featureNum, "Y");
                        var.setFeatureValue(featureNum + 1, String.valueOf(tmpP[1]));
                    } else {
                        var.setFeatureValue(featureNum, "N");
                        var.setFeatureValue(featureNum + 1, String.valueOf(tmpP[1]));
                    }
                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                    System.out.println("Randomforest cannot retrieve the performance!!!");
                }
            }
            return "finish";
        }
    }

    public String[] noncodingRandomForestGFC(Chromosome chroms, boolean needProgressionIndicator,
            boolean filterNonDisMut, int needThreadNumber, Boolean[] isReigonList,
            double[] iniScore, String[] currentLineList, int[] fixedPosition,
            BufferedReader[] lineReaderList, int scoreIndexNum, MyRandomForest[][] myRandomForestList,
            Map genicMap, boolean needVerboseNoncode,
            int featureNum, int chromIndex, FiltrationSummarySet dbNoncodePred91) throws Exception {
        String zeroLabel = ".";
        String oneLabel = "Y";
        String missingLabel = "?";
        ExecutorService executor = Executors.newFixedThreadPool(needThreadNumber);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(executor);
        int varLineBufferCounter;
        int bufferSize = 10000 * needThreadNumber;
        long lineCounter = 0;
        // int bufferSize = 5;
        Variant[] parseVariantArray = new Variant[bufferSize];
        String cells[];
        int localIndex = 0;
        boolean loopAgain = true;
        int fileLineOutNum = 0;
        double[] score = null;
        varLineBufferCounter = 0;
        List<Variant> tempVarList = new ArrayList<Variant>();

        int totalVarNum = 0;
        int counterDis = 0;
        int counterCon = 0;

        boolean continueNextLoci;
        int localPosition;
        boolean hasReadNewRow[] = new boolean[isReigonList.length];
        Arrays.fill(hasReadNewRow, true);

        String[] currentChrom = new String[isReigonList.length];
        int[] currentStartPos = new int[isReigonList.length];
        int[] currentEndPos = new int[isReigonList.length];

        int localListSize = chroms.variantList.size();
        int startPosition, endPosition;

        if (needProgressionIndicator) {
            //   System.out.print("Parsing Chrom" + STAND_CHROM_NAMES[chromIndex] + ", ");
        }

        String[][] cellsTmpStorageList = new String[isReigonList.length][];
        boolean initializeList[] = new boolean[isReigonList.length];
        Arrays.fill(initializeList, false);

        while (loopAgain) {
            lineCounter++;
            if (needProgressionIndicator && lineCounter % 100000 == 0) {
                String prog = String.valueOf(lineCounter);
                System.out.print(prog);
                char[] backSpaces = new char[prog.length()];
                //  Arrays.fill(backSpaces, '\b');
                //  System.out.print(backSpaces);
            }
            if (fileLineOutNum == isReigonList.length) {
                break;
            }
            continueNextLoci = true;
            if (localListSize <= localIndex) {
                break;
            }

            Variant var = chroms.variantList.get(localIndex);
            localPosition = var.refStartPosition;

            for (int j = 0; j < isReigonList.length; j++) {
                if (hasReadNewRow[j]) {
                    if (isReigonList[j]) {
                        if (currentLineList[j] == null) {
                            continue;
                        }
                        cells = Util.tokenize(currentLineList[j], '\t', 2);
                        currentChrom[j] = cells[0];
                        currentStartPos[j] = Util.parseInt(cells[1]);
                        currentEndPos[j] = Util.parseInt(cells[2]);
                    } else {
                        if (currentLineList[j] == null) {
                            continue;
                        }
                        cells = Util.tokenize(currentLineList[j], '\t', 1);
                        currentChrom[j] = cells[0];
                        currentStartPos[j] = Util.parseInt(cells[1]);
                    }
                    if (!initializeList[j]) {
                        cells = Util.tokenize(currentLineList[j], '\t');
                        cellsTmpStorageList[j] = new String[cells.length];
                        initializeList[j] = true;
                    }
                }

                if (!STAND_CHROM_NAMES[chromIndex].equals(currentChrom[j])) {
                    int anchorIndex = 0;
                    for (int j2 = 0; j2 < STAND_CHROM_NAMES.length; j2++) {
                        if (STAND_CHROM_NAMES[j2].equals(currentChrom[j])) {
                            anchorIndex = j2;
                            break;
                        }
                    }

                    if (anchorIndex > chromIndex) {
                        continue;
                    } else if (anchorIndex < chromIndex) {
                        continueNextLoci = false;
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        hasReadNewRow[j] = true;
                        continue;
                    }
                }
                if (isReigonList[j]) {
                    startPosition = currentStartPos[j];
                    endPosition = currentEndPos[j];
                    if (localPosition >= endPosition) {
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        continueNextLoci = false;
                        hasReadNewRow[j] = true;
                    } else if (localPosition >= startPosition) {
                        hasReadNewRow[j] = false;
                        if (score == null) {
                            score = new double[scoreIndexNum];
                            System.arraycopy(iniScore, 0, score, 0, iniScore.length);
                        }
//                        cells = Util.tokenize(currentLineList[j], '\t');
                        tokenize(currentLineList[j], '\t', cellsTmpStorageList[j]);
                        cells = cellsTmpStorageList[j];
                        for (int k = 3; k < cells.length; k++) {
                            if (cells[k].equals(oneLabel)) {
                                score[k - 3 + fixedPosition[j]] = 1.0;
                            } else if (cells[k].equals(zeroLabel)) {
                                score[k - 3 + fixedPosition[j]] = 0.0;
                            } else {
                                score[k - 3 + fixedPosition[j]] = Util.parseFloat(cells[k]);
                            }
                        }
                    }
                } else {
                    int position = currentStartPos[j];
                    if (position < localPosition) {
                        continueNextLoci = false;
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        hasReadNewRow[j] = true;
                    } else if (position == localPosition) {
                        if (score == null) {
                            score = new double[scoreIndexNum];
                            System.arraycopy(iniScore, 0, score, 0, iniScore.length);
                        }
//                        cells = Util.tokenize(currentLineList[j], '\t');

                        tokenize(currentLineList[j], '\t', cellsTmpStorageList[j]);
                        cells = cellsTmpStorageList[j];
                        for (int k = 2; k < cells.length; k++) {
                            if (cells[k].equals(oneLabel)) {
                                score[k - 2 + fixedPosition[j]] = 1.0;
                            } else if (cells[k].equals(zeroLabel)) {
                                score[k - 2 + fixedPosition[j]] = 0.0;
                            } else if (cells[k].equals(missingLabel)) {
                                score[k - 2 + fixedPosition[j]] = Double.NaN;
                            } else {
                                score[k - 2 + fixedPosition[j]] = Util.parseFloat(cells[k]);
                            }
                        }
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        hasReadNewRow[j] = true;
                    } else {
                        hasReadNewRow[j] = false;
                    }
                }
            }
            if (continueNextLoci || fileLineOutNum == isReigonList.length) {
                localIndex++;
                if (score != null) {
                    String mostImportantGeneFeature = org.cobi.kggseq.Constants.VAR_FEATURE_NAMES[var.smallestFeatureID];
                    if (genicMap.containsKey(mostImportantGeneFeature)) {
                        var.scores2 = new float[score.length];
                        for (int k = 0; k < score.length; k++) {
                            var.scores2[k] = (float) score[k];
                        }
                        parseVariantArray[varLineBufferCounter++] = var;
                        if (varLineBufferCounter >= bufferSize) {
                            int[] blocks = partitionEvenBlock(needThreadNumber, 0, varLineBufferCounter);
                            int blockNum = blocks.length - 1;
                            int runningThread = 0;
                            for (int s = 0; s < blockNum; s++) {
                                NoncodingRandomForestGFCTask task = new NoncodingRandomForestGFCTask(myRandomForestList[s], genicMap, featureNum, blocks[s], blocks[s + 1], parseVariantArray, needVerboseNoncode);
                                serv.submit(task);
                                runningThread++;
                            }
                            for (int s = 0; s < runningThread; s++) {
                                Future<String> task = serv.take();
                                String infor = task.get();
                                // System.out.println(infor);
                            }

                            for (int s = 0; s < varLineBufferCounter; s++) {
                                var = parseVariantArray[s];
                                if (var.featureValues[featureNum] == null) {
                                    if (filterNonDisMut) {
                                        tempVarList.add(var);
                                    }
                                } else if (var.featureValues[featureNum].equals("Y")) {
                                    if (filterNonDisMut) {
                                        tempVarList.add(var);
                                    }
                                    counterDis += 1;
                                } else {
                                    counterCon += 1;
                                }
                            }
                            varLineBufferCounter = 0;
                        }
                    } else {
                        tempVarList.add(var);
                        var.setFeatureValue(featureNum, null);
                        var.setFeatureValue(featureNum + 1, null);
                    }
                    score = null;
                } else {
                    tempVarList.add(var);
                    var.setFeatureValue(featureNum, null);
                    var.setFeatureValue(featureNum + 1, null);
                }
            }
        }

        if (varLineBufferCounter > 0) {
            int[] blocks = partitionEvenBlock(needThreadNumber, 0, varLineBufferCounter);
            int blockNum = blocks.length - 1;
            int runningThread = 0;
            for (int s = 0; s < blockNum; s++) {
                serv.submit(new NoncodingRandomForestGFCTask(myRandomForestList[s], genicMap, featureNum, blocks[s], blocks[s + 1], parseVariantArray, needVerboseNoncode));
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future task = serv.take();
                String infor = (String) task.get();
                // System.out.println(infor);
            }
            for (int s = 0; s < varLineBufferCounter; s++) {
                Variant var = parseVariantArray[s];
                if (var.featureValues[featureNum] == null) {
                    if (filterNonDisMut) {
                        tempVarList.add(var);
                    }
                } else if (var.featureValues[featureNum].equals("Y")) {
                    if (filterNonDisMut) {
                        tempVarList.add(var);
                    }
                    counterDis += 1;
                } else {
                    counterCon += 1;
                }
            }
            varLineBufferCounter = 0;
        }

        if (filterNonDisMut) {
            chroms.variantList.clear();
            chroms.setHasNotOrderVariantList(true);
            chroms.variantList.addAll(tempVarList);
            totalVarNum += tempVarList.size();
            tempVarList.clear();
            chroms.buildVariantIndexMap();
        }

        dbNoncodePred91.increaseCount(0, counterDis);
        dbNoncodePred91.increaseCount(1, counterCon);
        dbNoncodePred91.increaseCount(2, totalVarNum);

        executor.shutdown();

        if (needProgressionIndicator) {
            //  System.out.println("finished");
        }

        return currentLineList;
//			genome.buildVariantIndexMapOnChromosomes();
//			StringBuilder info = new StringBuilder("The number of predicted disease-causal and non-disease-causal dependentVariants are " + counterDis + "(#gene " + geneSymbSet.size()
//				+ ") and " + counterCon + " among " + genome.getVarNum() + " dependentVariants on the genome according to the Random Forests prediction model");
        // info.append(" trained by ExoVar dataset (http://pmglab.top/kggseq/download/ExoVar.xls).");
        // info.append(" trained by COSMIC dataset (http://cancer.sanger.ac.uk/cancergenome/projects/cosmic/).");
//			LOG.info(info);

//			if (filterNonDisMut) {
//				genome.setVarNum(totalVarNum);
//				info.delete(0, info.length());
//				info.append(totalVarNum).append(" variant(s) are retained after filtered by the disease mutation prediction.");
//				LOG.info(info);
//			}
    }

    public String[] noncodingRandomForestGFRegions(Chromosome chroms, boolean needProgressionIndicator,
            boolean filterNonDisMut, int needThreadNumber, Boolean[] isReigonList,
            double[] iniScore, String[] currentLineList, int[] fixedPosition,
            BufferedReader[] lineReaderList, int scoreIndexNum, MyRandomForest[][] myRandomForestList,
            Map genicMap, boolean needVerboseNoncode,
            int featureNum, int chromIndex, FiltrationSummarySet dbNoncodePred91) throws Exception {
        String zeroLabel = ".";
        String oneLabel = "Y";
        String missingLabel = "?";
        ExecutorService executor = Executors.newFixedThreadPool(needThreadNumber);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(executor);
        int varLineBufferCounter;
        int bufferSize = 10000 * needThreadNumber;
        long lineCounter = 0;
        // int bufferSize = 5;
        Variant[] parseVariantArray = new Variant[bufferSize];
        String cells[];
        int localIndex = 0;
        boolean loopAgain = true;
        int fileLineOutNum = 0;
        double[] score = null;
        varLineBufferCounter = 0;
        List<Variant> tempVarList = new ArrayList<Variant>();

        int totalVarNum = 0;
        int counterDis = 0;
        int counterCon = 0;

        boolean continueNextLoci;
        int localPosition;
        boolean hasReadNewRow[] = new boolean[isReigonList.length];
        Arrays.fill(hasReadNewRow, true);

        String[] currentChrom = new String[isReigonList.length];
        int[] currentStartPos = new int[isReigonList.length];
        int[] currentEndPos = new int[isReigonList.length];

        int localListSize = chroms.variantList.size();
        int startPosition, endPosition;

        String[][] cellsTmpStorageList = new String[isReigonList.length][];
        boolean initializeList[] = new boolean[isReigonList.length];
        Arrays.fill(initializeList, false);
        boolean allNA = true;
        while (loopAgain) {
            lineCounter++;
            if (fileLineOutNum == isReigonList.length) {
                break;
            }
            continueNextLoci = true;
            if (localListSize <= localIndex) {
                break;
            }

            Variant var = chroms.variantList.get(localIndex);
            localPosition = var.refStartPosition;

            for (int j = 0; j < isReigonList.length; j++) {
                if (hasReadNewRow[j]) {
                    if (isReigonList[j]) {
                        if (currentLineList[j] == null) {
                            continue;
                        }
                        cells = Util.tokenize(currentLineList[j], '\t', 2);
                        currentChrom[j] = cells[0];
                        currentStartPos[j] = Util.parseInt(cells[1]);
                        currentEndPos[j] = Util.parseInt(cells[2]);
                    } else {
                        if (currentLineList[j] == null) {
                            continue;
                        }
                        cells = Util.tokenize(currentLineList[j], '\t', 2);
                        currentChrom[j] = cells[0];
                        currentStartPos[j] = Util.parseInt(cells[2]);
                    }
                    if (!initializeList[j]) {
                        cells = Util.tokenize(currentLineList[j], '\t');
                        cellsTmpStorageList[j] = new String[cells.length];
                        initializeList[j] = true;
                    }
                }

                if (!STAND_CHROM_NAMES[chromIndex].equals(currentChrom[j])) {
                    int anchorIndex = 0;
                    for (int j2 = 0; j2 < STAND_CHROM_NAMES.length; j2++) {
                        if (STAND_CHROM_NAMES[j2].equals(currentChrom[j])) {
                            anchorIndex = j2;
                            break;
                        }
                    }

                    if (anchorIndex > chromIndex) {
                        continue;
                    } else if (anchorIndex < chromIndex) {
                        continueNextLoci = false;
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        hasReadNewRow[j] = true;
                        continue;
                    }
                }
                //only consider regions
                if (isReigonList[j]) {
                    startPosition = currentStartPos[j];
                    endPosition = currentEndPos[j];
                    if (localPosition >= endPosition) {
                        if ((currentLineList[j] = lineReaderList[j].readLine()) == null) {
                            fileLineOutNum += 1;
                        }
                        continueNextLoci = false;
                        hasReadNewRow[j] = true;
                    } else if (localPosition >= startPosition) {
                        hasReadNewRow[j] = false;
                        if (score == null) {
                            score = new double[scoreIndexNum];
                            System.arraycopy(iniScore, 0, score, 0, iniScore.length);
                        }
//                        cells = Util.tokenize(currentLineList[j], '\t');
                        tokenize(currentLineList[j], '\t', cellsTmpStorageList[j]);
                        cells = cellsTmpStorageList[j];
                        for (int k = 3; k < cells.length; k++) {
                            if (cells[k].equals(oneLabel)) {
                                score[k - 3 + fixedPosition[j]] = 1.0;
                            } else if (cells[k].equals(zeroLabel)) {
                                score[k - 3 + fixedPosition[j]] = 0.0;
                            } else {
                                score[k - 3 + fixedPosition[j]] = Util.parseFloat(cells[k]);
                            }
                        }
                    }
                }
            }

            String mostImportantGeneFeature = org.cobi.kggseq.Constants.VAR_FEATURE_NAMES[var.smallestFeatureID];
            if (continueNextLoci || fileLineOutNum == isReigonList.length) {
                localIndex++;
                if (genicMap.containsKey(mostImportantGeneFeature)) {
                    if (score != null) {
                        float[] tmpScores = Arrays.copyOf(var.scores2, var.scores2.length);
                        var.scores2 = new float[score.length + tmpScores.length];
                        for (int k = 0; k < score.length; k++) {
                            var.scores2[k] = (float) score[k];
                        }
                        System.arraycopy(tmpScores, 0, var.scores2, score.length, tmpScores.length);
                    } else {
                        allNA = true;
                        for (int i = 0; i < var.scores2.length; i++) {
                            if (!Float.isNaN(var.scores2[i])) {
                                allNA = false;
                                break;
                            }
                        }

                        if (needVerboseNoncode) {
                            float[] tmpScores = Arrays.copyOf(var.scores2, var.scores2.length);
                            var.scores2 = new float[scoreIndexNum + tmpScores.length];
                            //Arrays.fill(var.scores2, Float.NaN);
                            Arrays.fill(var.scores2, 0);
                            System.arraycopy(tmpScores, 0, var.scores2, scoreIndexNum, tmpScores.length);
                        }

                        if (allNA) {
                            tempVarList.add(var);
                            var.setFeatureValue(featureNum, null);
                            var.setFeatureValue(featureNum + 1, null);
                            continue;
                        }
                    }
                    parseVariantArray[varLineBufferCounter++] = var;
                    if (varLineBufferCounter >= bufferSize) {
                        int[] blocks = partitionEvenBlock(needThreadNumber, 0, varLineBufferCounter);
                        int blockNum = blocks.length - 1;
                        int runningThread = 0;
                        for (int s = 0; s < blockNum; s++) {
                            NoncodingRandomForestGFCTask task = new NoncodingRandomForestGFCTask(myRandomForestList[s], genicMap, featureNum, blocks[s], blocks[s + 1], parseVariantArray, needVerboseNoncode);
                            serv.submit(task);
                            runningThread++;
                        }
                        for (int s = 0; s < runningThread; s++) {
                            Future<String> task = serv.take();
                            String infor = task.get();
                            // System.out.println(infor);
                        }

                        for (int s = 0; s < varLineBufferCounter; s++) {
                            var = parseVariantArray[s];
                            if (var.featureValues[featureNum] == null) {
                                if (filterNonDisMut) {
                                    tempVarList.add(var);
                                }
                            } else if (var.featureValues[featureNum].equals("Y")) {
                                if (filterNonDisMut) {
                                    tempVarList.add(var);
                                }
                                counterDis += 1;
                            } else {
                                counterCon += 1;
                            }

                            //remove the epigenomic scores from scores2
                            if (!needVerboseNoncode && var.scores2.length > 10) {
                                float[] tmpScores = Arrays.copyOf(var.scores2, 10);
                                var.scores2 = new float[scoreIndexNum + tmpScores.length];
                                //Arrays.fill(var.scores2, Float.NaN);
                                Arrays.fill(var.scores2, 0);
                                System.arraycopy(tmpScores, 0, var.scores2, scoreIndexNum, tmpScores.length);
                            }
                        }
                        varLineBufferCounter = 0;
                    }
                } else {
                    tempVarList.add(var);
                    var.setFeatureValue(featureNum, null);
                    var.setFeatureValue(featureNum + 1, null);

                    // var.scores2 = new float[scoreIndexNum + var.scores2.length];
                    // Arrays.fill(var.scores2, Float.NaN);
                }
                score = null;
            }
        }

        if (varLineBufferCounter > 0) {
            int[] blocks = partitionEvenBlock(needThreadNumber, 0, varLineBufferCounter);
            int blockNum = blocks.length - 1;
            int runningThread = 0;
            for (int s = 0; s < blockNum; s++) {
                serv.submit(new NoncodingRandomForestGFCTask(myRandomForestList[s], genicMap, featureNum, blocks[s], blocks[s + 1], parseVariantArray, needVerboseNoncode));
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future task = serv.take();
                String infor = (String) task.get();
                // System.out.println(infor);
            }
            for (int s = 0; s < varLineBufferCounter; s++) {
                Variant var = parseVariantArray[s];
                if (var.featureValues[featureNum] == null) {
                    if (filterNonDisMut) {
                        tempVarList.add(var);
                    }
                } else if (var.featureValues[featureNum].equals("Y")) {
                    if (filterNonDisMut) {
                        tempVarList.add(var);
                    }
                    counterDis += 1;
                } else {
                    counterCon += 1;
                }

                //remove the epigenomic scores from scores2
                if (!needVerboseNoncode && var.scores2.length > 10) {
                    float[] tmpScores = Arrays.copyOf(var.scores2, 10);
                    var.scores2 = new float[scoreIndexNum + tmpScores.length];
                    //Arrays.fill(var.scores2, Float.NaN);
                    Arrays.fill(var.scores2, 0);
                    System.arraycopy(tmpScores, 0, var.scores2, scoreIndexNum, tmpScores.length);
                }
            }
            varLineBufferCounter = 0;
        }

        if (filterNonDisMut) {
            chroms.variantList.clear();
            chroms.setHasNotOrderVariantList(true);
            chroms.variantList.addAll(tempVarList);
            totalVarNum += tempVarList.size();
            tempVarList.clear();
            chroms.buildVariantIndexMap();
        }

        dbNoncodePred91.increaseCount(0, counterDis);
        dbNoncodePred91.increaseCount(1, counterCon);
        dbNoncodePred91.increaseCount(2, totalVarNum);

        executor.shutdown();

        return currentLineList;
    }

    private class NonCodingPredicLJTask extends Task implements Callable<String> {

        List<Variant> varList;
        Bayes bayesPredictor;
        int startFeatureNum;
        int[] effeIndexes;
        double[] baye1NonCodingPredic;
        double[] baye2NonCodingPredic;
        String chromName;
        boolean doCellType;

        public NonCodingPredicLJTask(List<Variant> varList, Bayes bayesPredictor, int startFeatureNum, int[] effeIndexes,
                double[] baye1NonCodingPredic, double[] baye2NonCodingPredic, String chromName, boolean docellType) {
            this.varList = varList;
            this.bayesPredictor = bayesPredictor;
            this.startFeatureNum = startFeatureNum;
            this.effeIndexes = effeIndexes;
            this.baye1NonCodingPredic = baye1NonCodingPredic;
            this.baye2NonCodingPredic = baye2NonCodingPredic;
            this.chromName = chromName;
            this.doCellType = docellType;
        }

        @Override
        public String call() throws Exception {
            int localListSize = varList.size();
            float cell_p;
            int[] intervalSearchIndexes = new int[9];
            //assume all dependentVariants are on the same chromsome
            List<int[]> posList = bayesPredictor.cellSpecificScoresPostions.get(chromName);
            Arrays.fill(intervalSearchIndexes, 0);

            if (doCellType && posList == null) {
                for (int i = 0; i < localListSize; i++) {
                    Variant var = varList.get(i);
                    var.setFeatureValue(startFeatureNum, ".");
                    var.setFeatureValue(startFeatureNum + 1, ".");
                    var.setFeatureValue(startFeatureNum + 2, ".");
                    var.setFeatureValue(startFeatureNum + 3, ".");
                }
                return "";
            }

            List<ArrayList<double[]>> scoreList = bayesPredictor.cellTypeScores.get(chromName);
            for (int i = 0; i < localListSize; i++) {
                Variant var = varList.get(i);
                double[] scores = bayesPredictor.getBayesScoreCompsit(var.scores2, effeIndexes, baye1NonCodingPredic, baye2NonCodingPredic);
                if (Double.isNaN(scores[0])) {
                    var.setFeatureValue(startFeatureNum, ".");
                } else {
                    var.setFeatureValue(startFeatureNum, String.valueOf(scores[0]));
                }
                //cell-type specific
                if (doCellType) {
                    cell_p = bayesPredictor.getCellSpecificScore(posList, scoreList, var.refStartPosition, intervalSearchIndexes);
                    //sb.append(cell_p + "\t" + composite_p * cell_p / 0.5); 
                    if (Double.isNaN(scores[1])) {
                        var.setFeatureValue(startFeatureNum + 1, ".");
                        var.setFeatureValue(startFeatureNum + 2, ".");
                        var.setFeatureValue(startFeatureNum + 3, ".");
                    } else {
                        var.setFeatureValue(startFeatureNum + 1, String.valueOf(scores[1]));
                        if (Float.isNaN(cell_p)) {
                            var.setFeatureValue(startFeatureNum + 2, ".");
                            var.setFeatureValue(startFeatureNum + 3, ".");
                        } else {
                            var.setFeatureValue(startFeatureNum + 2, String.valueOf(cell_p));
                            var.setFeatureValue(startFeatureNum + 3, String.valueOf(cell_p * scores[1] / 0.5));
                        }
                    }

                } else if (Double.isNaN(scores[1])) {
                    var.setFeatureValue(startFeatureNum + 1, ".");
                } else {
                    var.setFeatureValue(startFeatureNum + 1, String.valueOf(scores[1]));
                }
            }
            return "";
        }
    }

    public void noncodingCompositPredictionMultiThread(Chromosome chrom, int[] effeIndexes,
            Bayes bayesPredictor, int startFeatureNum, int threadNum, double[] baye1NonCodingPredic,
            double[] baye2NonCodingPredic, boolean calCellType) {
        List<Variant> varList = chrom.variantList;

        if (varList.isEmpty()) {
            return;
        }

        String currentLine = null;
        try {
            // System.out.println(" Chromosome " + chromosome.getName() + " " + rsFile.getName());
            // Options.REF_CHROM_NAMES[t]);
            int varSize = varList.size();
            int[] bounderies = partitionEvenBlock(varSize, threadNum);
            int actualThreadNum = bounderies.length - 1;

            ExecutorService exec = Executors.newFixedThreadPool(actualThreadNum);
            final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
            int runningThread = 0;

            for (int f = 1; f < bounderies.length; f++) {
                NonCodingPredicLJTask varTaks = new NonCodingPredicLJTask(varList.subList(bounderies[f - 1], bounderies[f]), bayesPredictor, startFeatureNum, effeIndexes,
                        baye1NonCodingPredic, baye2NonCodingPredic, chrom.getName(), calCellType) {
                    @Override
                    protected void fireTaskComplete() {

                    }
                };
                serv.submit(varTaks);
                runningThread++;
            }

            for (int s = 0; s < runningThread; s++) {
                Future<String> task = serv.take();
                String infor = task.get();
                // System.out.println(infor);
            }
            exec.shutdown();

        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    class RiskPredictionRandomForestTask extends Task implements Callable<String> {

        MyRandomForest[] myRandomForest;
        List<Variant> varList;
        int featureNum;

        public RiskPredictionRandomForestTask(MyRandomForest[] myRandomForest, List<Variant> varList, int featureNum) {
            this.myRandomForest = myRandomForest;
            this.varList = varList;
            this.featureNum = featureNum;
        }

        /*
    @Override
    public String call() throws Exception {
      double tmpP[];
      String indexStr = myRandomForest.getName();
      indexStr = indexStr.substring(0, indexStr.indexOf('@'));
      String[] predictors = indexStr.split("-");
      double[] scores = new double[predictors.length];
      boolean allMissing = true; 
      for (Variant var : varList) {
        //ingore intergenic dependentVariants
        if (var.smallestFeatureID >= 15) {
          var.setFeatureValue(featureNum, null);
          var.setFeatureValue(featureNum + 1, null);
          continue;
        }

        if (var.scores1 != null) {
          Arrays.fill(scores, Double.NaN);
          allMissing = true;
          for (int j = 0; j < scores.length; j++) {
            if (!Float.isNaN(var.scores1[j])) {
              scores[j] = var.scores1[j];
              allMissing = false;
            }
          }
          if (allMissing) {
            var.setFeatureValue(featureNum, null);
            var.setFeatureValue(featureNum + 1, null);
            continue;
          }

          tmpP = myRandomForest.getClassifyDistribution(scores);
          if (tmpP[0] == 1) {
            var.setFeatureValue(featureNum, "Y");
            var.setFeatureValue(featureNum + 1, String.valueOf(tmpP[1]));
          } else {
            var.setFeatureValue(featureNum, "N");
            var.setFeatureValue(featureNum + 1, String.valueOf(tmpP[1]));
          }
        } else {
          // keep varaint have no risk scores which may be safer                
          var.setFeatureValue(featureNum, null);
          var.setFeatureValue(featureNum + 1, null);
        }
      }
      return "";
    }
  }
         */
        @Override
        public String call() throws Exception {
            double tmpP[];
            String indexStr = myRandomForest[0].getName();
            indexStr = indexStr.substring(0, indexStr.indexOf('@'));
            String[] predictors = indexStr.split("-");
            double[] scores = new double[predictors.length];
            boolean allMissing = true;
            double[] weights = new double[myRandomForest.length];
            double doubleSum = 0, doubleSum1 = 0;
            for (int i = 0; i < weights.length; i++) {
                weights[i] = myRandomForest[i].getAuc();
                doubleSum += weights[i];
            }
            for (int i = 0; i < weights.length; i++) {
                weights[i] = weights[i] / doubleSum;
            }

            for (Variant var : varList) {
                //ingore intergenic dependentVariants
                if (var.smallestFeatureID >= 15) {
                    var.setFeatureValue(featureNum, null);
                    var.setFeatureValue(featureNum + 1, null);
                    continue;
                }

                if (var.scores1 != null) {
                    Arrays.fill(scores, Double.NaN);
                    allMissing = true;
                    for (int j = 0; j < scores.length; j++) {
                        if (!Float.isNaN(var.scores1[j])) {
                            scores[j] = var.scores1[j];
                            allMissing = false;
                        }
                    }
                    if (allMissing) {
                        var.setFeatureValue(featureNum, null);
                        var.setFeatureValue(featureNum + 1, null);
                        continue;
                    }
                    doubleSum = 0;
                    doubleSum1 = 0;
                    // for (int j = 0; j < scores.length; j++) System.out.println(scores[j]);
                    for (int i = 0; i < weights.length; i++) {
                        tmpP = myRandomForest[i].getClassifyDistribution(scores);
                        if (tmpP[0] == 1) {
                            doubleSum += weights[i];
                        } else {
                            doubleSum -= weights[i];
                        }
                        doubleSum1 += weights[i] * tmpP[1];
                        //  System.out.println(weights[j] + "\t" + tmpP[1]);
                    }

                    if (doubleSum >= 0) {
                        var.setFeatureValue(featureNum, "Y");
                        var.setFeatureValue(featureNum + 1, String.valueOf(doubleSum1));
                    } else {
                        var.setFeatureValue(featureNum, "N");
                        var.setFeatureValue(featureNum + 1, String.valueOf(doubleSum1));
                    }
                } else {
                    // keep varaint have no risk scores which may be safer                
                    var.setFeatureValue(featureNum, null);
                    var.setFeatureValue(featureNum + 1, null);
                }
            }
            return "";
        }
    }

    public void riskPredictionRandomForest(Chromosome chromosome, MyRandomForest[][] myRandomForest, int maxThreadNum,
            boolean filterNonDisMut, FiltrationSummarySet dbNSFPMendelPred) throws Exception {
        int totalVarNum = 0;
        int counterDis = 0;
        int counterCon = 0;

        // zhicheng
        // System.out.println(myRandomForest.getName());
        List<Variant> keptVarList = new ArrayList<Variant>();
        int featureNum = dbNSFPMendelPred.getAvailableFeatureIndex();
        if (chromosome == null || chromosome.variantList.isEmpty()) {
            return;
        }

        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        int varNum = chromosome.variantList.size();

        int[] blocks = org.cobi.util.thread.Util.partitionEvenBlock(maxThreadNum, 0, varNum);
        int blockNum = blocks.length - 1;
        runningThread = 0;
        for (int s = 0; s < blockNum; s++) {
            RiskPredictionRandomForestTask task = new RiskPredictionRandomForestTask(myRandomForest[s], chromosome.variantList.subList(blocks[s], blocks[s + 1]), featureNum);
            serv.submit(task);
            runningThread++;
        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            //  System.out.println(infor);
        }

        exec.shutdown();

        Set<String> geneSymbSet = new HashSet<String>();
        for (Variant var : chromosome.variantList) {
            if (var.featureValues[featureNum] == null) {
                if (filterNonDisMut) {
                    keptVarList.add(var);
                }
                continue;
            } else if (var.featureValues[featureNum].equals("Y")) {
                if (filterNonDisMut) {
                    keptVarList.add(var);
                }
                if (var.geneSymb != null) {
                    geneSymbSet.add(var.geneSymb);
                }
                counterDis += 1;
            } else {
                counterCon += 1;
                if (var.smallestFeatureID != 6) {
                    keptVarList.add(var);
                }
            }
        }

        if (filterNonDisMut) {
            chromosome.variantList.clear();
            chromosome.variantList.addAll(keptVarList);
            totalVarNum += keptVarList.size();
            keptVarList.clear();
        }
        chromosome.buildVariantIndexMap();
        dbNSFPMendelPred.increaseCount(0, counterDis);
        dbNSFPMendelPred.increaseCount(1, geneSymbSet.size());
        dbNSFPMendelPred.increaseCount(2, counterCon);
        dbNSFPMendelPred.increaseCount(3, totalVarNum);
    }

    public void matchTrioSet(List<Individual> subjectIDList, List<int[]> triosIDList) throws Exception {
        for (int i = 0; i < subjectIDList.size(); i++) {
            Individual indiv0 = subjectIDList.get(i);
            if (indiv0.getDadID().equals("0") && indiv0.getMomID().equals("0")) {
                continue;
            }

            int[] setIDs = new int[3];
            setIDs[0] = i;
            setIDs[1] = -9;
            setIDs[2] = -9;

            for (int t = 0; t < subjectIDList.size(); t++) {
                // child father mother ids
                if (!subjectIDList.get(t).getFamilyID().equals(indiv0.getFamilyID())) {
                    continue;
                }
                if (subjectIDList.get(t).getIndividualID().equals(indiv0.getDadID())) {
                    setIDs[1] = t;
                } else if (subjectIDList.get(t).getIndividualID().equals(indiv0.getMomID())) {
                    setIDs[2] = t;
                }
                if (setIDs[0] != -9 && setIDs[1] != -9 && setIDs[2] != -9) {
                    break;
                }
            }

            // at least one parent is needed
            if (setIDs[0] != -9 && (setIDs[1] != -9 || setIDs[2] != -9)) {
                triosIDList.add(setIDs);
            }
        }
    }

    public void summarizeSomaticVarPerGene(Chromosome chromosome, int somatNumIndex, int readInfoIndex, Set<Byte> dependentGeneFeature, Set<Byte> independentGeneFeature, int scoreIndex, double scoreCutOff) throws Exception {
        List<Gene> geneList = chromosome.geneList;
        String evenInfor = null;
        int somatEvents = 0;
        Map<String, double[]> geneMutNum = new HashMap<String, double[]>();
        Map<String, StringBuilder> geneReadsTestInfo = new HashMap<String, StringBuilder>();
        Set<String> availableGeneSet = new HashSet<String>();
        String[] somatEventStr = null;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();

        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, int[]> geneVarNum = new HashMap<String, int[]>();
        int[] varNum;
        int scoreCut = 0;
        String scoreS;

        boolean missingScore = false;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            if (somatNumIndex >= 0) {
                evenInfor = var.getFeatureValues()[somatNumIndex];
                if (evenInfor == null) {
                    somatEvents = 0;
                } else {
                    somatEventStr = Util.tokenize(evenInfor, ' ');
                    if (somatEventStr != null && somatEventStr.length > 0) {
                        somatEvents = (Util.parseInt(somatEventStr[0]));
                    }
                }
            }
            sb.delete(0, sb.length());

            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            scoreCut = 0;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreCut = (int) Math.floor(Double.parseDouble(scoreS) / scoreCutOff);
                    scoreCut++;
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarNum.clear();
                extractAllGeneVarsByFeatures(geneVarNum, sb, dependentGeneFeature, independentGeneFeature);

                if (!geneVarNum.isEmpty()) {
                    for (Map.Entry<String, int[]> item : geneVarNum.entrySet()) {
                        geneSymb = item.getKey();
                        varNum = geneVarNum.get(geneSymb);

                        if (((varNum[0] > 0) || (varNum[1] > 0)) && !availableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            availableGeneSet.add(geneSymb);
                        }

                        double[] alleleNums = geneMutNum.get(geneSymb);
                        if (alleleNums == null) {
                            alleleNums = new double[8];
                            Arrays.fill(alleleNums, 0);
                            geneMutNum.put(geneSymb, alleleNums);
                        }
                        //give a priority to dependentNum
                        if (varNum[0] > 0) {
                            //as giving a priority to dependentNum may produce bias, we can limit this by
                            if (varNum[0] > varNum[1]) {
                                alleleNums[0] += somatEvents;
                                if (!missingScore) {
                                    alleleNums[2] += somatEvents * scoreCut;
                                    alleleNums[3] += scoreCut;
                                    alleleNums[4]++;
                                } else {
                                    //missing score allele
                                    alleleNums[5] += somatEvents;
                                }
                            }
                        } else if (varNum[1] > 0) {
                            alleleNums[1] += somatEvents;
                        }

                        if (readInfoIndex >= 0) {
                            StringBuilder tesInfo = geneReadsTestInfo.get(geneSymb);
                            if (tesInfo == null) {
                                tesInfo = new StringBuilder();
                                geneReadsTestInfo.put(geneSymb, tesInfo);
                            }
                            String readInfo = var.getFeatureValues()[readInfoIndex];
                            if (readInfo != null) {
                                tesInfo.append(readInfo);
                                tesInfo.append('|');
                                String[] readInfos = readInfo.split("[|]");
                                for (String readS : readInfos) {
                                    index = readS.lastIndexOf(':');
                                    if (index < 0) {
                                        continue;
                                    }
                                    // System.out.println(readS);
                                    double or = Double.parseDouble(readS.substring(index + 1));
                                    // or = Math.log(or);
                                    if (varNum[0] > 0) {
                                        alleleNums[6] += or;
                                    } else if (varNum[1] > 0) {
                                        alleleNums[7] += or;
                                    }
                                }
                            }
                        }
                    }

                }

            }

        }

        availableGeneSet.clear();

        for (Gene gene : geneList) {
            double[] geneScore = geneMutNum.get(gene.geneSymb);

            if (geneScore == null) {
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
            } else {
                gene.addFeatureValue(String.valueOf(geneScore[0]));
                gene.addFeatureValue(String.valueOf(geneScore[1]));
                scoreCut = (int) Math.round(geneScore[3] / geneScore[4]);
                if (scoreCut == 0) {
                    scoreCut = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[2] + geneScore[5] * scoreCut));
                gene.addFeatureValue(String.valueOf(geneScore[4]));
                gene.addFeatureValue(String.valueOf(geneScore[5]));

            }
            sb = geneReadsTestInfo.get(gene.geneSymb);
            if (sb == null) {
                gene.addFeatureValue("");
            } else {
                gene.addFeatureValue(sb.toString());
            }
        }
    }

    public void summarizeMinIDSomaticVarPerGene(Chromosome chromosome, int somatNumIndex, Set<Byte> dependentGeneFeature, Set<Byte> independentGeneFeature, int scoreIndex) throws Exception {
        List<Gene> geneList = chromosome.geneList;
        String evenInfor = null;
        int somatEvents = 0;
        Map<String, DoubleArrayList> geneDepMutScoreMap = new HashMap<String, DoubleArrayList>();
        Map<String, DoubleArrayList> geneIndepMutScoreMap = new HashMap<String, DoubleArrayList>();

        Set<String> allAvailableGeneSet = new HashSet<String>();
        String[] somatEventStr = null;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();

        int index;
        String geneSymb = null, feature = null;
        Byte featureID;

        Set<Byte> varNum;
        double scoreVal = 0;
        String scoreS;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<String, Set<Byte>>();
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();
        boolean needSubIntron = false;
        int dependentSubIntron = Integer.MAX_VALUE;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }

        boolean missingScore = false;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            if (somatNumIndex >= 0) {
                evenInfor = var.getFeatureValues()[somatNumIndex];
                if (evenInfor == null) {
                    somatEvents = 0;
                } else {
                    somatEventStr = Util.tokenize(evenInfor, ' ');
                    if (somatEventStr != null && somatEventStr.length > 0) {
                        somatEvents = (Util.parseInt(somatEventStr[0]));
                    }
                }
            }

            sb.delete(0, sb.length());

            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            scoreVal = Double.NaN;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreVal = Double.parseDouble(scoreS);
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarIDMap.clear();
                extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                if (!geneVarIDMap.isEmpty()) {
                    for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                        geneSymb = item.getKey();
                        varNum = item.getValue();
                        tmpSet1.clear();
                        tmpSet1.addAll(varNum);

                        tmpSet2.clear();
                        tmpSet2.addAll(varNum);

                        if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                            continue;
                        }

                        if (!allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        //give a priority to dependentNum
                        if (!tmpSet1.isEmpty()) {
                            DoubleArrayList alleleNumsScore = geneDepMutScoreMap.get(geneSymb);
                            //as giving a priority to dependentNum may produce bias, we can limit this by 
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneDepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            alleleNumsScore.add(somatEvents);
                            alleleNumsScore.add(scoreVal);

                        } else if (!tmpSet2.isEmpty()) {
                            DoubleArrayList alleleNumsScore = geneIndepMutScoreMap.get(geneSymb);
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneIndepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            alleleNumsScore.add(somatEvents);
                            alleleNumsScore.add(scoreVal);
                        }
                    }
                }
            }
        }
        allAvailableGeneSet.clear();

        for (Gene gene : geneList) {
            DoubleArrayList geneScore = geneDepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setDepMutScore(geneScore);
            }
            geneScore = geneIndepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setIndepMutScores(geneScore);
            }
        }
    }

    public void summarizeMinIDSomaticVarPerRegion(Chromosome chromosome, int somatNumIndex, Set<Byte> dependentGeneFeature, Set<Byte> independentGeneFeature, int scoreIndex) throws Exception {
        List<Gene> regionList = chromosome.geneList;
        String evenInfor = null;
        int somatEvents = 0;
        Map<String, DoubleArrayList> regionDepMutScoreMap = new HashMap<String, DoubleArrayList>();
        Map<String, DoubleArrayList> geneIndepMutScoreMap = new HashMap<String, DoubleArrayList>();

        Set<String> allAvailableRegionSet = new HashSet<String>();
        String[] somatEventStr = null;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();

        int index;
        String geneSymb = null, feature = null;
        Byte featureID;

        Set<Byte> varNum;
        double scoreVal = 0;
        String scoreS;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<String, Set<Byte>>();
        boolean needSubIntron = false;
        int dependentSubIntron = Integer.MAX_VALUE;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }

        String chromName = chromosome.getName();
        boolean missingScore = false, dependentGeneFeatureValid = false, independentGeneFeatureValid = false;
        int windowLen = 5000, regionStart = -1;
        boolean needSelectType = (!dependentGeneFeature.isEmpty() || !independentGeneFeature.isEmpty());
        DoubleArrayList alleleNumsScoreDep = null, alleleNumsScoreIndep = null;
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();

        String regionLabel = null;
        for (Variant var : chromosome.variantList) {
            if (somatNumIndex >= 0) {
                evenInfor = var.getFeatureValues()[somatNumIndex];
                if (evenInfor == null) {
                    somatEvents = 0;
                } else {
                    somatEventStr = Util.tokenize(evenInfor, ' ');
                    if (somatEventStr != null && somatEventStr.length > 0) {
                        somatEvents = (Util.parseInt(somatEventStr[0]));
                    }
                }
            }
            scoreVal = Double.NaN;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreVal = Double.parseDouble(scoreS);
                    missingScore = false;
                }
            }
            if (needSelectType) {
                sb.delete(0, sb.length());
                geneFeatureAnnot = var.getRefGeneAnnot();
                if (geneFeatureAnnot != null) {
                    sb.append(geneFeatureAnnot).append(';');
                }
                geneFeatureAnnot = var.getgEncodeAnnot();
                if (geneFeatureAnnot != null) {
                    sb.append(geneFeatureAnnot).append(';');
                }
                geneFeatureAnnot = var.getKnownGeneAnnot();
                if (geneFeatureAnnot != null) {
                    sb.append(geneFeatureAnnot).append(';');
                }
                geneFeatureAnnot = var.getEnsemblGeneAnnot();
                if (geneFeatureAnnot != null) {
                    sb.append(geneFeatureAnnot).append(';');
                }
                if (sb.length() > 0) {
                    geneVarIDMap.clear();
                    extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                    dependentGeneFeatureValid = false;
                    independentGeneFeatureValid = false;
                    if (!geneVarIDMap.isEmpty()) {
                        for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                            geneSymb = item.getKey();
                            varNum = item.getValue();

                            tmpSet1.clear();
                            tmpSet1.addAll(varNum);

                            tmpSet2.clear();
                            tmpSet2.addAll(varNum);

                            if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                                continue;
                            }

                            if (!tmpSet1.isEmpty()) {
                                dependentGeneFeatureValid = true;
                            } else if (!tmpSet2.isEmpty()) {
                                independentGeneFeatureValid = true;
                            }
                        }
                    }
                }
            }
            if (regionStart < 0 || var.refStartPosition - regionStart > windowLen) {
                regionStart = var.refStartPosition;
                regionLabel = chromName + ":" + regionStart + "-" + windowLen;
                alleleNumsScoreDep = new DoubleArrayList();
                regionDepMutScoreMap.put(regionLabel, alleleNumsScoreDep);

                if (!allAvailableRegionSet.contains(regionLabel)) {
                    regionList.add(new Gene(regionLabel));
                    allAvailableRegionSet.add(regionLabel);
                }
            }
            if (needSelectType) {
                if (dependentGeneFeatureValid) {
                    alleleNumsScoreDep.add(somatEvents);
                    alleleNumsScoreDep.add(scoreVal);
                }
                if (independentGeneFeatureValid) {
                    alleleNumsScoreIndep = geneIndepMutScoreMap.get(regionLabel);
                    if (alleleNumsScoreIndep == null) {
                        alleleNumsScoreIndep = new DoubleArrayList();
                        geneIndepMutScoreMap.put(geneSymb, alleleNumsScoreIndep);
                    }
                    alleleNumsScoreDep.add(somatEvents);
                    alleleNumsScoreDep.add(scoreVal);
                }
            } else {
                alleleNumsScoreDep.add(somatEvents);
                alleleNumsScoreDep.add(scoreVal);
            }

        }
        allAvailableRegionSet.clear();

        for (Gene gene : regionList) {
            DoubleArrayList geneScore = regionDepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setDepMutScore(geneScore);
            }
            geneScore = geneIndepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setIndepMutScores(geneScore);
            }
        }

    }

    public void summarizeAltVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, int dependentSubIntron, Set<Byte> independentGeneFeature,
            int scoreIndex, double mafCut, double scoreCutOff) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Map<String, double[]> geneMutNum = new HashMap<String, double[]>();
        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, int[]> geneVarNum = new HashMap<String, int[]>();
        int[] varNum;
        int scoreCut = 0, intronID;
        String scoreS, idString;
        boolean needSubIntron = false;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }
        boolean missingScore = false;

        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            scoreCut = 0;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreCut = (int) Math.floor(Double.parseDouble(scoreS) / scoreCutOff);
                    scoreCut++;
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarNum.clear();
                extractAllGeneVarsByFeatures(geneVarNum, sb, dependentGeneFeature, independentGeneFeature);

                if (!geneVarNum.isEmpty()) {
                    for (Map.Entry<String, int[]> item : geneVarNum.entrySet()) {
                        geneSymb = item.getKey();

                        varNum = geneVarNum.get(geneSymb);

                        if (((varNum[0] > 0) || (varNum[1] > 0)) && !allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        double[] alleleNums = geneMutNum.get(geneSymb);
                        if (alleleNums == null) {
                            alleleNums = new double[12];
                            Arrays.fill(alleleNums, 0);
                            geneMutNum.put(geneSymb, alleleNums);
                        }
                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        if (varNum[0] > 0) {
                            //reponse var, explanary, response score
                            //as giving a priority to dependentNum may produce bias, we can limit this by
                            if (varNum[0] > varNum[1]) {
                                //this is to count the case unique dependentVariants
                                //if (hetUnaff == 0 && homUnaff == 0) 
                                {
                                    maf1 = (0.5 * hetAff + homAff) / totalAff;
                                    if (maf1 <= mafCut) {
                                        //for cases
                                        alleleNums[0] += (hetAff + 2 * homAff);
                                        if (!missingScore) {

                                            alleleNums[2] += (hetAff + 2 * homAff) * scoreCut;
                                            alleleNums[3] += scoreCut;
                                            alleleNums[4]++;
                                        } else {
                                            //missing score allele
                                            alleleNums[5] += (hetAff + 2 * homAff);
                                        }

                                    }

                                }

                                maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                                //for controls
                                if (maf2 <= mafCut) {
                                    alleleNums[6] += (hetUnaff + 2 * homUnaff);
                                    if (!missingScore) {
                                        alleleNums[8] += (hetUnaff + 2 * homUnaff) * scoreCut;
                                        alleleNums[9] += scoreCut;
                                        alleleNums[10]++;
                                    } else {
                                        //missing score allele
                                        alleleNums[11] += (hetUnaff + 2 * homUnaff);
                                    }
                                }

                            }
                        } else if (varNum[1] > 0) {
                            alleleNums[1] += (hetAff + 2 * homAff);
                            alleleNums[7] += (hetUnaff + 2 * homUnaff);
                        }
                    }
                }
            }
            geneSet.clear();
        }

        allAvailableGeneSet.clear();

        // double[] alleleNums = regionDepMutScoreMap.get("KMT2D");
        for (Gene gene : geneList) {
            double[] geneScore = geneMutNum.get(gene.geneSymb);

            if (geneScore == null) {
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
            } else {
                //cases
                gene.addFeatureValue(String.valueOf(geneScore[0]));
                gene.addFeatureValue(String.valueOf(geneScore[1]));
                //get average score
                scoreCut = (int) Math.round(geneScore[3] / geneScore[4]);
                if (scoreCut == 0) {
                    scoreCut = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[2] + geneScore[5] * scoreCut));
                //controls
                gene.addFeatureValue(String.valueOf(geneScore[6]));
                gene.addFeatureValue(String.valueOf(geneScore[7]));
                //get average score
                scoreCut = (int) Math.round(geneScore[9] / geneScore[10]);
                if (scoreCut == 0) {
                    scoreCut = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[8] + geneScore[11] * scoreCut));
            }
        }
        geneMutNum.clear();
    }

    public void summarizeMinIDAltVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, int dependentSubIntron, Set<Byte> independentGeneFeature,
            int scoreIndex, double mafCutMin, double mafCutMax, double scoreCutOff) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Map<String, double[]> geneMutNum = new HashMap<String, double[]>();
        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<String, Set<Byte>>();
        Set<Byte> varNum;
        int scoreBin = 0, intronID;
        String scoreS, idString;
        boolean needSubIntron = false;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }
        boolean missingScore = false;
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            scoreBin = 1;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreBin = (int) Math.floor(Double.parseDouble(scoreS) / scoreCutOff);
                    scoreBin++;
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarIDMap.clear();
                extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                if (!geneVarIDMap.isEmpty()) {
                    for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                        geneSymb = item.getKey();
                        varNum = item.getValue();
                        tmpSet1.clear();
                        tmpSet1.addAll(varNum);

                        tmpSet2.clear();
                        tmpSet2.addAll(varNum);

                        if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                            continue;
                        }
                        if (!allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        double[] alleleNums = geneMutNum.get(geneSymb);
                        if (alleleNums == null) {
                            alleleNums = new double[12];
                            Arrays.fill(alleleNums, 0);
                            geneMutNum.put(geneSymb, alleleNums);
                        }
                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        if (!tmpSet1.isEmpty()) {
                            //reponse var, explanary, response score
                            //as giving a priority to dependentNum may produce bias, we can limit this by

                            //if (hetUnaff == 0 && homUnaff == 0) 
                            {
                                maf1 = (0.5 * hetAff + homAff) / totalAff;
                                if (maf1 >= mafCutMin && maf1 <= mafCutMax) {
                                    //for cases
                                    alleleNums[0] += (hetAff + 2 * homAff);
                                    if (!missingScore) {

                                        alleleNums[2] += (hetAff + 2 * homAff) * scoreBin;
                                        //total scores
                                        alleleNums[3] += scoreBin;
                                        //counts
                                        alleleNums[4]++;
                                    } else {
                                        //missing score allele
                                        alleleNums[5] += (hetAff + 2 * homAff);
                                    }

                                }

                            }

                            maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                            //for controls
                            if (maf2 >= mafCutMin && maf2 <= mafCutMax) {
                                alleleNums[6] += (hetUnaff + 2 * homUnaff);
                                if (!missingScore) {
                                    alleleNums[8] += (hetUnaff + 2 * homUnaff) * scoreBin;
                                    //total scores
                                    alleleNums[9] += scoreBin;
                                    //counts
                                    alleleNums[10]++;
                                } else {
                                    //missing score allele
                                    alleleNums[11] += (hetUnaff + 2 * homUnaff);
                                }
                            }
                        } else if (!tmpSet2.isEmpty()) {
                            alleleNums[1] += (hetAff + 2 * homAff);
                            alleleNums[7] += (hetUnaff + 2 * homUnaff);
                        }
                    }
                }
            }
            geneSet.clear();
        }

        allAvailableGeneSet.clear();

        // double[] alleleNums = regionDepMutScoreMap.get("KMT2D");
        for (Gene gene : geneList) {
            double[] geneScore = geneMutNum.get(gene.geneSymb);

            if (geneScore == null) {
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
            } else {
                //cases
                gene.addFeatureValue(String.valueOf(geneScore[0]));
                gene.addFeatureValue(String.valueOf(geneScore[1]));
                //get average score
                scoreBin = (int) Math.round(geneScore[3] / geneScore[4]);
                if (scoreBin == 0) {
                    scoreBin = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[2] + geneScore[5] * scoreBin));
                //controls
                gene.addFeatureValue(String.valueOf(geneScore[6]));
                gene.addFeatureValue(String.valueOf(geneScore[7]));
                //get average score
                scoreBin = (int) Math.round(geneScore[9] / geneScore[10]);
                if (scoreBin == 0) {
                    scoreBin = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[8] + geneScore[11] * scoreBin));
            }
        }
        geneMutNum.clear();
    }

    private void extractAllGeneFeatures(Map<String, Set<Byte>> geneVarIDMap, StringBuilder sb, boolean needSubIntron, int dependentSubIntron) {
        int index, intronID;
        String geneSymb, feature, idString;
        Byte featureID;
        Set<Byte> varType;
        String[] items = Util.tokenize(sb.substring(0, sb.length() - 1), ';');
        for (String item : items) {
            index = item.indexOf(':');
            if (index > 0) {
                geneSymb = item.substring(0, index);
            } else {
                continue;
            }

            index = item.lastIndexOf(':');
            if (index > 0) {
                feature = item.substring(index + 1);
            } else {
                continue;
            }

            featureID = geneFeatureMap.get(feature);
            if (featureID == null) {
                if (feature.startsWith("intron")) {
                    featureID = 11;
                    if (needSubIntron) {
                        idString = feature.substring(6);
                        intronID = Integer.MAX_VALUE;
                        if (idString.length() > 0) {
                            intronID = Integer.parseInt(idString);
                        }
                        if (intronID > dependentSubIntron) {
                            continue;
                        }
                    }
                } else if (feature.endsWith("acceptor") || feature.endsWith("donor")) {
                    featureID = 5;
                } else {
                    //LOG.warn("Unknown feature: " + feature);
                    continue;
                }
            }

            varType = geneVarIDMap.get(geneSymb);
            if (varType == null) {
                //0. dependentVarNum 1. IndependentVarNum 
                varType = new HashSet<>();
                varType.add(featureID);

                geneVarIDMap.put(geneSymb, varType);
            } else {
                varType.add(featureID);
//                //record the min ID
//                if (varType[0] > featureID) {                   
//                    varType[0] = featureID;
//                }
//to identify more sevever variants
//record the max ID
//                if (varType[0] < featureID) {                   
//                    varType[0] = featureID;
//                }
            }
        }//all transcripts
    }

    private void extractAllGeneVarsByFeatures(Map<String, int[]> geneVarNum, StringBuilder sb, Set<Byte> dependentGeneFeature, Set<Byte> independentGeneFeature) {
        int index;
        String geneSymb, feature = null;
        Byte featureID;
        int[] varNum;
        String[] items = Util.tokenize(sb.substring(0, sb.length() - 1), ';');
        for (String item : items) {
            index = item.indexOf(':');
            if (index > 0) {
                geneSymb = item.substring(0, index);
            } else {
                continue;
            }

            index = item.lastIndexOf(':');
            if (index > 0) {
                feature = item.substring(index + 1);
            }

            featureID = geneFeatureMap.get(feature);
            if (featureID == null) {
                if (feature.startsWith("intron")) {
                    featureID = 11;
                } else if (feature.endsWith("acceptor") || feature.endsWith("donor")) {
                    featureID = 5;
                } else {
                    //LOG.warn("Unknown feature: " + feature);
                }
            }

            if (dependentGeneFeature.contains(featureID)) {
                // only do it for missense dependentVariants; many stop loss
                // dependentVariants have no proection at loss of function
                // dependentVariants
                varNum = geneVarNum.get(geneSymb);
                if (varNum == null) {
                    //0. dependentVarNum 1. IndependentVarNum 2. functionalScore
                    varNum = new int[2];
                    Arrays.fill(varNum, 0);
                    geneVarNum.put(geneSymb, varNum);
                }

                varNum[0]++;
            } else if (independentGeneFeature != null && independentGeneFeature.contains(featureID)) {
                varNum = geneVarNum.get(geneSymb);
                if (varNum == null) {
                    varNum = new int[2];
                    Arrays.fill(varNum, 0);
                    geneVarNum.put(geneSymb, varNum);
                }
                varNum[1]++;
            }
        }//all transcripts
    }

    public void summarizeMinIDAltAllVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, int dependentSubIntron, Set<Byte> independentGeneFeature,
            int scoreIndex, double mafCutMin, double mafCutMax, double minCCFreqRatio, boolean protectiveEff) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<>();
        Set<Byte> varType;
        int scoreBin = 0, intronID;
        String scoreS, idString;
        boolean needSubIntron = false;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }
        boolean missingScore = false;
        Map<String, DoubleArrayList> geneDepMutScoreMap = new HashMap<String, DoubleArrayList>();
        //for three types missense lof and indel
        Map<String, int[]> geneDepMutTypeCountMap = new HashMap<String, int[]>();
        Map<String, DoubleArrayList> geneIndepMutScoreMap = new HashMap<String, DoubleArrayList>();
        double score;

        Map<String, IntArrayList> geneChromVarIDMap = new HashMap<>();
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();
        ///indel lof and missese
        int[] typeCounts = null;
        int maxSub = 0;
        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            if ((hetAff + homAff) == 0 && (hetUnaff + homUnaff) == 0) {

                continue;
            }
            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            scoreBin = 1;
            missingScore = true;
            score = Double.NaN;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    score = Double.parseDouble(scoreS);
                    scoreBin++;
                    missingScore = false;
                }
            }

           
            if (sb.length() > 0) {
                geneVarIDMap.clear();
                extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                if (!geneVarIDMap.isEmpty()) {
                    for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                        geneSymb = item.getKey();
                        varType = item.getValue();

                        tmpSet1.clear();
                        tmpSet1.addAll(varType);

                        tmpSet2.clear();
                        tmpSet2.addAll(varType);

                        if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                            continue;
                        }

                        if (!allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        //if (hetUnaff == 0 && homUnaff == 0) 
                        {
                            maf1 = (0.5 * hetAff + homAff) / totalAff;
                            if (maf1 < mafCutMin || maf1 > mafCutMax) {
                                //for cases
                                continue;
                            }

                        }
                        if (maxSub < totalAff) {
                            maxSub = (int) totalAff;
                        }
                        maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                        //for controls
                        if (maf2 < mafCutMin || maf2 > mafCutMax) {
                            continue;
                        }
// if(geneSymb.equals("SYNE1")){
//    System.out.println(var.refStartPosition+"\t"+var.getRefAllele()+"\t"+var.getAltAllele(0)+"\t"+sb.toString());
// }
                        //give a priority to dependentNum
                        if (!tmpSet1.isEmpty()) {
                            DoubleArrayList alleleNumsScore = geneDepMutScoreMap.get(geneSymb);
                            //as giving a priority to dependentNum may produce bias, we can limit this by 
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneDepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            typeCounts = geneDepMutTypeCountMap.get(geneSymb);
                            if (typeCounts == null) {
                                typeCounts = new int[3];
                                geneDepMutTypeCountMap.put(geneSymb, typeCounts);
                            }
                            //this is designed for rare variant test by runer. if a variant has sufficient mutations in controls, this would be an un interesting variant
                            if (minCCFreqRatio > 0) {
                                if (!protectiveEff) {
                                    //risk allelles
                                    //maf1 is case freq; maf2 is control freq
                                    if (Double.isNaN(maf2)) {
                                        //no unaffected sample
                                        alleleNumsScore.add(hetAff + 2 * homAff);
                                        alleleNumsScore.add(0);
//                                        if (varType[0] == 1) {
//                                            typeCounts[0] += (hetAff + 2 * homAff);
//                                        } else if (varType[0] <= 5) {
//                                            typeCounts[1] += (hetAff + 2 * homAff);
//                                        } else if (varType[0] == 6) {
//                                            typeCounts[2] += (hetAff + 2 * homAff);
//                                        }

                                        if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                            typeCounts[0] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                            typeCounts[1] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 6)) {
                                            typeCounts[2] += (hetAff + 2 * homAff);
                                        }

                                    } else if (maf1 >= maf2 * minCCFreqRatio) {
                                        alleleNumsScore.add(hetAff + 2 * homAff);
                                        alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                                        if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                            typeCounts[0] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                            typeCounts[1] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 6)) {
                                            typeCounts[2] += (hetAff + 2 * homAff);
                                        }
                                    } else {
                                        //otherwise it will distore the order of the dependentVariants
                                        alleleNumsScore.add(0);
                                        alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                                    }
                                } else {
                                    //protective alleles
                                    //maf1 is case freq; maf2 is control freq
                                    if (totalUnaff == 0) {
                                        //no unaffected sample
                                        alleleNumsScore.add(hetAff + 2 * homAff);
                                        alleleNumsScore.add(0);
                                        if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                            typeCounts[0] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                            typeCounts[1] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 6)) {
                                            typeCounts[2] += (hetAff + 2 * homAff);
                                        }
                                    } else if (maf2 >= maf1 * minCCFreqRatio) {
                                        alleleNumsScore.add(hetAff + 2 * homAff);
                                        alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                                        if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                            typeCounts[0] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                            typeCounts[1] += (hetAff + 2 * homAff);
                                        } else if (tmpSet1.contains((byte) 6)) {
                                            typeCounts[2] += (hetAff + 2 * homAff);
                                        }
                                    } else {
                                        //otherwise it will distore the order of the dependentVariants
                                        alleleNumsScore.add(0);
                                        alleleNumsScore.add(0);
                                    }
                                }

                            } else {
                                alleleNumsScore.add(hetAff + 2 * homAff);
                                alleleNumsScore.add(hetUnaff + 2 * homUnaff);

                                if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                    typeCounts[0] += (hetAff + 2 * homAff);
                                } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                    typeCounts[1] += (hetAff + 2 * homAff);
                                } else if (tmpSet1.contains((byte) 6)) {
                                    typeCounts[2] += (hetAff + 2 * homAff);
                                }
                            }

                            alleleNumsScore.add(score);
                        } else if (!tmpSet2.isEmpty()) {
                            DoubleArrayList alleleNumsScore = geneIndepMutScoreMap.get(geneSymb);
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneIndepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            alleleNumsScore.add(hetAff + 2 * homAff);
                            alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                            alleleNumsScore.add(score);
                        }
                    }
                }

            }
            geneSet.clear();
        }

        allAvailableGeneSet.clear();
        double med, factor = 5, sum;
        int size;
        for (Gene gene : geneList) {
            DoubleArrayList geneScore = geneDepMutScoreMap.get(gene.geneSymb);

            if (geneScore != null) {
                gene.setDepMutScore(geneScore);
            } else {
                continue;
            }

            // try to remove outlier variants
            size = geneScore.size();
            DoubleArrayList counts = new DoubleArrayList();
            for (int i = 0; i < size; i += 3) {
                counts.add(geneScore.getQuick(i));
            }
            counts.quickSort();
            med = Descriptive.median(counts);
            sum = Descriptive.sum(counts);
            med = med * factor;
            for (int i = 0; i < size; i += 3) {
                if (geneScore.getQuick(i) > med) {
                    geneScore.setQuick(i, 0);
                    geneScore.setQuick(i + 1, 0);
                    geneScore.setQuick(i + 2, 0);
                }
            }
            counts.clear();
            int[] varTypeCount = geneDepMutTypeCountMap.get(gene.geneSymb);
            gene.setVarTypeCouts(varTypeCount);
            geneScore = geneIndepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setIndepMutScores(geneScore);
            }

        }

    }

    public void summarizeMinIDAltVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, int dependentSubIntron, Set<Byte> independentGeneFeature,
            int scoreIndex, double mafCutMin, double mafCutMax, double scoreCutOff, Map<String, double[]> geneFrqScores, Set<String> hittedGeneSet, int mafBins) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Map<String, double[]> geneMutNum = new HashMap<String, double[]>();
        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<>();
        Set<Byte> varNum;
        int scoreBin = 0, intronID;
        String scoreS, idString;
        boolean needSubIntron = false;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }
        boolean missingScore = false;
        double centerMaf = mafCutMax;
        double minMAD = centerMaf;
        double maxMAF = centerMaf;
        if (maxMAF > 1) {
            maxMAF = 1;
        }

        double mafSeg = (maxMAF - minMAD) / mafBins;
        double[] mafCutOffs = new double[mafBins];
        for (int k = 0; k < mafBins; k++) {
            mafCutOffs[k] = (minMAD + mafSeg * k);
        }
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();

        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }
            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            scoreBin = 1;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreBin = (int) Math.floor(Double.parseDouble(scoreS) / scoreCutOff);
                    scoreBin++;
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarIDMap.clear();
                extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                if (!geneVarIDMap.isEmpty()) {
                    for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                        geneSymb = item.getKey();
                        varNum = item.getValue();

                        tmpSet1.clear();
                        tmpSet1.addAll(varNum);

                        tmpSet2.clear();
                        tmpSet2.addAll(varNum);

                        if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                            continue;
                        }
                        if (!allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        double[] alleleNums = geneMutNum.get(geneSymb);
                        if (alleleNums == null) {
                            alleleNums = new double[12];
                            Arrays.fill(alleleNums, 0);
                            geneMutNum.put(geneSymb, alleleNums);
                        }
                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        if (!tmpSet1.isEmpty()) {
                            //reponse var, explanary, response score
                            //as giving a priority to dependentNum may produce bias, we can limit this by

                            //if (hetUnaff == 0 && homUnaff == 0) 
                            {
                                maf1 = (0.5 * hetAff + homAff) / totalAff;
                                if (maf1 >= mafCutMin && maf1 <= mafCutMax) {
                                    //for cases
                                    alleleNums[0] += (hetAff + 2 * homAff);
                                    if (!missingScore) {
                                        alleleNums[2] += (hetAff + 2 * homAff) * scoreBin;
                                        alleleNums[3] += scoreBin;
                                        alleleNums[4]++;
                                    } else {
                                        //missing score allele
                                        alleleNums[5] += (hetAff + 2 * homAff);
                                    }

                                }

                            }

                            maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                            //for controls
                            if (maf2 >= mafCutMin && maf2 <= mafCutMax) {
                                alleleNums[6] += (hetUnaff + 2 * homUnaff);
                                if (!missingScore) {
                                    alleleNums[8] += (hetUnaff + 2 * homUnaff) * scoreBin;
                                    alleleNums[9] += scoreBin;
                                    alleleNums[10]++;
                                } else {
                                    //missing score allele
                                    alleleNums[11] += (hetUnaff + 2 * homUnaff);
                                }
                            }

                            double[] itemCell = geneFrqScores.get(geneSymb);
                            if (itemCell == null) {
                                itemCell = new double[mafBins];
                                Arrays.fill(itemCell, 0);
                                geneFrqScores.put(geneSymb, itemCell);
                            }

                            if (maf2 != 0) {
                                for (int k = 0; k < mafBins; k++) {
                                    if (maf2 <= mafCutOffs[k]) {
                                        itemCell[k] += (maf2 * scoreBin);
                                    }
                                }
                            }
                            hittedGeneSet.add(geneSymb);

                        } else if (!tmpSet2.isEmpty()) {
                            alleleNums[1] += (hetAff + 2 * homAff);
                            alleleNums[7] += (hetUnaff + 2 * homUnaff);
                        }
                    }
                }
            }
            geneSet.clear();
        }

        allAvailableGeneSet.clear();

        // double[] alleleNums = regionDepMutScoreMap.get("KMT2D");
        for (Gene gene : geneList) {
            double[] geneScore = geneMutNum.get(gene.geneSymb);

            if (geneScore == null) {
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
            } else {
                //cases
                gene.addFeatureValue(String.valueOf(geneScore[0]));
                gene.addFeatureValue(String.valueOf(geneScore[1]));
                //get average score
                scoreBin = (int) Math.round(geneScore[3] / geneScore[4]);
                if (scoreBin == 0) {
                    scoreBin = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[2] + geneScore[5] * scoreBin));
                //controls
                gene.addFeatureValue(String.valueOf(geneScore[6]));
                gene.addFeatureValue(String.valueOf(geneScore[7]));
                //get average score
                scoreBin = (int) Math.round(geneScore[9] / geneScore[10]);
                if (scoreBin == 0) {
                    scoreBin = 1;
                }
                gene.addFeatureValue(String.valueOf(geneScore[8] + geneScore[11] * scoreBin));
            }
        }
        geneMutNum.clear();
    }

    public void summarizeMinIDAltAllVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, int dependentSubIntron, Set<Byte> independentGeneFeature,
            double mafCutMin, double mafCutMax, int scoreIndex, Set<String> hittedGeneSet, Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double minCCFreqRatio, boolean protectiveEffct) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, Set<Byte>> geneVarIDMap = new HashMap<>();
        Set<Byte> varType;
        int scoreBin = 0, intronID;
        String scoreS, idString;
        double score;
        boolean needSubIntron = false;
        if (dependentSubIntron < Integer.MAX_VALUE) {
            needSubIntron = true;
        }

        Map<String, DoubleArrayList> geneDepMutScoreMap = new HashMap<String, DoubleArrayList>();
        Map<String, DoubleArrayList> geneIndepMutScoreMap = new HashMap<String, DoubleArrayList>();

        Map<String, DoubleArrayList> refGeneVarFreqScoreMapTmp = new HashMap<String, DoubleArrayList>();
        Map<String, int[]> geneDepMutTypeCountMap = new HashMap<String, int[]>();
        ///indel lof and missese
        int[] typeCounts = null;
        Set<Byte> tmpSet1 = new HashSet<>();
        Set<Byte> tmpSet2 = new HashSet<>();

        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            scoreBin = 1;

            score = Double.NaN;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    score = Double.parseDouble(scoreS);
                    scoreBin++;
                }
            }

            if (sb.length() > 0) {
                geneVarIDMap.clear();
                extractAllGeneFeatures(geneVarIDMap, sb, needSubIntron, dependentSubIntron);

                if (!geneVarIDMap.isEmpty()) {
                    for (Map.Entry<String, Set<Byte>> item : geneVarIDMap.entrySet()) {
                        geneSymb = item.getKey();
                        varType = item.getValue();

                        tmpSet1.clear();
                        tmpSet1.addAll(varType);

                        tmpSet2.clear();
                        tmpSet2.addAll(varType);

                        if (!tmpSet1.retainAll(dependentGeneFeature) && !tmpSet2.retainAll(independentGeneFeature)) {
                            continue;
                        }
                        if (!allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        typeCounts = geneDepMutTypeCountMap.get(geneSymb);
                        if (typeCounts == null) {
                            typeCounts = new int[3];
                            geneDepMutTypeCountMap.put(geneSymb, typeCounts);
                        }

                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        if (!tmpSet1.isEmpty()) {
                            //reponse var, explanary, response score
                            //as giving a priority to dependentNum may produce bias, we can limit this by

                            //if (hetUnaff == 0 && homUnaff == 0) 
                            {
                                maf1 = (0.5 * hetAff + homAff) / totalAff;
                                if (maf1 < mafCutMin || maf1 > mafCutMax) {
                                    continue;
                                }

                            }

                            maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                            //for controls 
                            if (maf2 != 0) {
                                if (maf2 < mafCutMin || maf2 > mafCutMax) {
                                    continue;
                                }
                            }

                            DoubleArrayList alleleFreqcore = refGeneVarFreqScoreMapTmp.get(geneSymb);
                            if (alleleFreqcore == null) {
                                alleleFreqcore = new DoubleArrayList();
                                refGeneVarFreqScoreMapTmp.put(geneSymb, alleleFreqcore);
                            }
                            if (maf2 > 0) {
                                alleleFreqcore.add(maf2);
                                alleleFreqcore.add(score);
                            }
                            //this is designed for rare variant test by runer. if a variant has sufficient mutations in controls, this would be an uninteresting variant
                            if (minCCFreqRatio > 0) {
                                if (!protectiveEffct) {
                                    //risk effect 
                                    //maf1 is for cases and maf2 is for controls
                                    if (maf1 < maf2 * minCCFreqRatio) {
                                        continue;
                                    }
                                } else {
                                    //protected effect
                                    if (maf2 < maf1 * minCCFreqRatio) {
                                        continue;
                                    }
                                }
                            }
                            hittedGeneSet.add(geneSymb);
                            DoubleArrayList alleleNumsScore = geneDepMutScoreMap.get(geneSymb);
                            //as giving a priority to dependentNum may produce bias, we can limit this by 
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneDepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            //for cases and controls
                            alleleNumsScore.add(hetAff + 2 * homAff);
                            alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                            alleleNumsScore.add(score);

                            if (tmpSet1.contains((byte) 0) || tmpSet1.contains((byte) 1)) {
                                typeCounts[0] += (hetAff + 2 * homAff);
                            } else if (tmpSet1.contains((byte) 2) || tmpSet1.contains((byte) 3) || tmpSet1.contains((byte) 4) || tmpSet1.contains((byte) 5)) {
                                typeCounts[1] += (hetAff + 2 * homAff);
                            } else if (tmpSet1.contains((byte) 6)) {
                                typeCounts[2] += (hetAff + 2 * homAff);
                            }

                        } else if (!tmpSet2.isEmpty()) {
                            DoubleArrayList alleleNumsScore = geneIndepMutScoreMap.get(geneSymb);
                            if (alleleNumsScore == null) {
                                alleleNumsScore = new DoubleArrayList();
                                geneIndepMutScoreMap.put(geneSymb, alleleNumsScore);
                            }
                            alleleNumsScore.add(hetAff + 2 * homAff);
                            alleleNumsScore.add(hetUnaff + 2 * homUnaff);
                            alleleNumsScore.add(score);
                        }
                    }
                }
            }
            geneSet.clear();
        }

        allAvailableGeneSet.clear();

        if (scoreIndex >= 0) {

            int size, naNum;

            //remove genes with all NA scores because it can introduce biases
            for (Map.Entry<String, DoubleArrayList> item : refGeneVarFreqScoreMapTmp.entrySet()) {
                DoubleArrayList alleleNumsScore = item.getValue();

                size = alleleNumsScore.size();
                naNum = 0;
                for (int i = 0; i < size; i += 2) {
                    if (Double.isNaN(alleleNumsScore.getQuick(i + 1))) {
                        naNum++;
                    }
                }
                if (naNum >= (size * 9 / 20)) {
                    continue;
                }
                refGeneVarFreqScoreMap.put(item.getKey(), alleleNumsScore);
            }
            refGeneVarFreqScoreMapTmp.clear();

        }

        double med, factor = 10;
        int size;
         DoubleArrayList counts = new DoubleArrayList();
        for (Gene gene : geneList) {

            DoubleArrayList geneScore = geneDepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setDepMutScore(geneScore);
            }else{
                continue;
            }

            // try to remove outlier variants
            size = geneScore.size();
           counts.clear();
            for (int i = 0; i < size; i += 3) {
                counts.add(geneScore.getQuick(i));
            }
            counts.quickSort();
            med = Descriptive.median(counts);
            med = med * factor;
            for (int i = 0; i < size; i += 3) {
                if (geneScore.getQuick(i) > med) {
                    geneScore.setQuick(i, 0);
                    geneScore.setQuick(i + 1, 0);
                    geneScore.setQuick(i + 2, 0);
                }
            }
            counts.clear();

            int[] varTypeCount = geneDepMutTypeCountMap.get(gene.geneSymb);
            gene.setVarTypeCouts(varTypeCount);

            geneScore = geneIndepMutScoreMap.get(gene.geneSymb);
            if (geneScore != null) {
                gene.setIndepMutScores(geneScore);
            }
        }
    }

    public void summarizeAltVarPerGene(Chromosome chromosome, Set<Byte> dependentGeneFeature, Set<Byte> independentGeneFeature, int scoreIndex, double mafCut, double[] scoreCutOffs) throws Exception {
        List<Gene> geneList = chromosome.geneList;

        Map<String, double[]> geneMutNum = new HashMap<String, double[]>();
        Set<String> allAvailableGeneSet = new HashSet<String>();
        int hetAff = 0, homAff = 0;
        int hetUnaff = 0, homUnaff = 0;
        double totalUnaff = 0, totalAff = 0;
        double maf1 = 0, maf2 = 0;
        String geneFeatureAnnot;
        StringBuilder sb = new StringBuilder();
        Set<String> geneSet = new HashSet<String>();
        int index;
        String geneSymb = null, feature = null;
        Byte featureID;
        Map<String, int[]> geneVarNum = new HashMap<String, int[]>();
        int[] varNum;
        int scoreCut = 0;
        String scoreS;
        double scoreValue;

        boolean missingScore = false;

        for (Variant var : chromosome.variantList) {
            if (var.geneSymb == null) {
                continue;
            }

            sb.delete(0, sb.length());
            geneFeatureAnnot = var.getRefGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getgEncodeAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getKnownGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }
            geneFeatureAnnot = var.getEnsemblGeneAnnot();
            if (geneFeatureAnnot != null) {
                sb.append(geneFeatureAnnot).append(';');
            }

            totalAff = var.getAffectedRefHomGtyNum() + var.getAffectedHetGtyNum() + var.getAffectedAltHomGtyNum();
            totalUnaff = var.getUnaffectedRefHomGtyNum() + var.getUnaffectedHetGtyNum() + var.getUnaffectedAltHomGtyNum();

            hetAff = var.getAffectedHetGtyNum();
            hetUnaff = var.getUnaffectedHetGtyNum();
            //if it is two large
            if (var.getAffectedRefHomGtyNum() > var.getAffectedAltHomGtyNum()) {
                homAff = var.getAffectedAltHomGtyNum();
            } else {
                homAff = var.getAffectedRefHomGtyNum();
            }
            if (var.getUnaffectedRefHomGtyNum() > var.getUnaffectedAltHomGtyNum()) {
                homUnaff = var.getUnaffectedAltHomGtyNum();
            } else {
                homUnaff = var.getUnaffectedRefHomGtyNum();
            }

            scoreCut = 0;
            missingScore = true;
            if (scoreIndex >= 0) {
                scoreS = var.getFeatureValues()[scoreIndex];
                if (scoreS != null && !scoreS.equals(".")) {
                    scoreValue = Double.parseDouble(scoreS);
                    scoreCut = Arrays.binarySearch(scoreCutOffs, scoreValue);
                    if (scoreCut < 0) {
                        scoreCut = -scoreCut;
                    } else {
                        scoreCut++;
                    }
                    missingScore = false;
                }
            }

            if (sb.length() > 0) {
                geneVarNum.clear();
                extractAllGeneVarsByFeatures(geneVarNum, sb, dependentGeneFeature, independentGeneFeature);

                if (!geneVarNum.isEmpty()) {
                    for (Map.Entry<String, int[]> item : geneVarNum.entrySet()) {
                        geneSymb = item.getKey();

                        varNum = geneVarNum.get(geneSymb);

                        if (((varNum[0] > 0) || (varNum[1] > 0)) && !allAvailableGeneSet.contains(geneSymb)) {
                            geneList.add(new Gene(geneSymb));
                            allAvailableGeneSet.add(geneSymb);
                        }

                        double[] alleleNums = geneMutNum.get(geneSymb);
                        if (alleleNums == null) {
                            alleleNums = new double[12];
                            Arrays.fill(alleleNums, 0);
                            geneMutNum.put(geneSymb, alleleNums);
                        }
                        //give a priority to dependentNum
                        //dependent a
                        //alignment from cases to controls
                        if (varNum[0] > 0) {
                            //reponse var, explanary, response score
                            //as giving a priority to dependentNum may produce bias, we can limit this by
                            if (varNum[0] > varNum[1]) {
                                //this is to count the case unique dependentVariants
                                //if (hetUnaff == 0 && homUnaff == 0) 
                                {
                                    maf1 = (0.5 * hetAff + homAff) / totalAff;
                                    if (maf1 <= mafCut) {
                                        //for cases
                                        alleleNums[0] += (hetAff + 2 * homAff);
                                        if (!missingScore) {

                                            alleleNums[2] += (hetAff + 2 * homAff) * scoreCut;
                                            alleleNums[3] += scoreCut;
                                            alleleNums[4]++;
                                        } else {
                                            //missing score allele
                                            alleleNums[5] += (hetAff + 2 * homAff);
                                        }
                                    }
                                }

                                maf2 = (0.5 * hetUnaff + homUnaff) / totalUnaff;
                                //for controls
                                if (maf2 <= mafCut) {
                                    alleleNums[6] += (hetUnaff + 2 * homUnaff);
                                    if (!missingScore) {
                                        alleleNums[8] += (hetUnaff + 2 * homUnaff) * scoreCut;
                                        alleleNums[9] += scoreCut;
                                        alleleNums[10]++;
                                    } else {
                                        //missing score allele
                                        alleleNums[11] += (hetUnaff + 2 * homUnaff);
                                    }
                                }

                            }
                        } else if (varNum[1] > 0) {
                            alleleNums[1] += (hetAff + 2 * homAff);
                            alleleNums[7] += (hetUnaff + 2 * homUnaff);
                        }
                    }
                }
            }
            geneSet.clear();
        }
        allAvailableGeneSet.clear();

        // double[] alleleNums = regionDepMutScoreMap.get("KMT2D");
        for (Gene gene : geneList) {
            double[] geneScore = geneMutNum.get(gene.geneSymb);

            if (geneScore == null) {
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
                gene.addFeatureValue(".");
            } else {
                //cases
                gene.addFeatureValue(String.valueOf(geneScore[0]));
                gene.addFeatureValue(String.valueOf(geneScore[1]));
                //get average score
                scoreCut = (int) Math.round(geneScore[3] / geneScore[4]);
                gene.addFeatureValue(String.valueOf(geneScore[2] + geneScore[5] * scoreCut));
                //controls
                gene.addFeatureValue(String.valueOf(geneScore[6]));
                gene.addFeatureValue(String.valueOf(geneScore[7]));
                //get average score
                scoreCut = (int) Math.round(geneScore[9] / geneScore[10]);
                gene.addFeatureValue(String.valueOf(geneScore[8] + geneScore[11] * scoreCut));
            }
        }
        geneMutNum.clear();
    }

    public void riskPredictionRareDiseaseAllBest(Chromosome chromosome, List<CombOrders> combOrderList, int bestModelNum, boolean filterNonDisMut, List<String> names, int maxThreadNum, FiltrationSummarySet dbNSFPMendelPred) throws Exception {
        // humvar predict
        double[] priors = new double[]{0.05, 0.01, 0.0001};
        double[] mafBins = new double[]{0.01, 0.02, 0.03};

        Set<String> geneSymbSet = new HashSet<String>();

        int counterDis = 0;
        int counterCon = 0;

        double sum = 0;
        RegressionParams tmpRP = null;
        RegressionParams bestRP = null;

        double tmpP, bestP;
        StringBuilder tmpStrB = new StringBuilder();
        boolean isDeleteriousness = false;
        List<Integer> bestPParamIndexes = new ArrayList<Integer>();
        int geneFeatureNum = dbNSFPMendelPred.getAvailableFeatureIndex();

        if (chromosome == null) {
            return;
        }
        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int varNum = chromosome.variantList.size();

        int[] blocks = org.cobi.util.thread.Util.partitionEvenBlock(maxThreadNum, 0, varNum);
        int blockNum = blocks.length - 1;
        int runningThread = 0;
        for (int s = 0; s < blockNum; s++) {
            RiskPredictionLogisticTask task = new RiskPredictionLogisticTask(combOrderList, bestModelNum, names, chromosome.variantList.subList(blocks[s], blocks[s + 1]), geneFeatureNum);
            serv.submit(task);
            runningThread++;
        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            //  System.out.println(infor);
        }

        exec.shutdown();
        List<Variant> keptVarList = new ArrayList<Variant>();
        int totalVarNum = 0;
        for (Variant var : chromosome.variantList) {
            if (var.featureValues[geneFeatureNum + 1] == null) {
                if (filterNonDisMut) {
                    keptVarList.add(var);
                }
            } else if (var.featureValues[geneFeatureNum + 1].equals("Y")) {
                counterDis++;
                if (filterNonDisMut) {
                    keptVarList.add(var);
                }
                if (var.geneSymb != null) {
                    geneSymbSet.add(var.geneSymb);
                }

            } else {
                // noly filter out it for missense dependentVariants
                if (var.smallestFeatureID != 6) {
                    keptVarList.add(var);
                }
                counterCon++;
            }
        }

        if (filterNonDisMut) {
            chromosome.variantList.clear();
            chromosome.variantList.addAll(keptVarList);
            totalVarNum = keptVarList.size();
            keptVarList.clear();
            chromosome.buildVariantIndexMap();
        }

        dbNSFPMendelPred.increaseCount(0, counterDis);
        dbNSFPMendelPred.increaseCount(1, geneSymbSet.size());
        dbNSFPMendelPred.increaseCount(2, counterCon);
        dbNSFPMendelPred.increaseCount(3, totalVarNum);

    }

    public void dbscSNV(Chromosome chromosome, AnnotationSummarySet dbScSNV, boolean needProgressionIndicator) {
        indexChrom = 0;
        indexPosition = 1;
        indexREF = 2;
        indexALT = 3;
        int indexAda = 4;
        List<Variant> varList = chromosome.variantList;
        int chrID = chromosome.getId();
        BufferedReader br = dbScSNV.getBr();
        StringBuilder newLine = dbScSNV.getLastLine();

        if (varList.isEmpty()) {
            return;
        }
        int feautreNum = dbScSNV.getAvailableFeatureIndex();

        //No matched SNPs means null 
        String missingVal = ".";
        for (Variant var : varList) {
            var.setFeatureValue(feautreNum, missingVal);
        }
        String currentLine = null;
        try {
            String varChrom = chromosome.getName();
            int maxColNum = indexChrom;
            maxColNum = Math.max(maxColNum, indexPosition);
            maxColNum = Math.max(maxColNum, indexREF);
            maxColNum = Math.max(maxColNum, indexALT);
            maxColNum = Math.max(maxColNum, indexAda);

            int lineCounter = 0;

            int filePosition = -1;
            StringBuilder tmpBuffer = new StringBuilder();
            String ref;
            String alt;
            String mafStr = null;
            float score;
            String[] alts;
            String[] mafStrs;
            int[] varIndex = null;

            char[] backSpaces = null;
            int delNum = 0;
            int existVarNum = 0;
            StringBuilder sb = new StringBuilder();
            boolean hitOnce = false;

            String[] cells = null;
            if (newLine.length() == 0) {
                currentLine = br.readLine();
                if (currentLine == null) {
                    return;
                }
            } else {
                currentLine = newLine.toString();
                newLine.delete(0, newLine.length());
            }
            int fileChrID;
            do {
                /*
                 if (currentLine.indexOf("BP") >= 0 || currentLine.indexOf("bp") >= 0) {
                 continue;
                 }*/
                lineCounter++;
                if (needProgressionIndicator && lineCounter % 50000 == 0) {
                    String prog = String.valueOf(lineCounter);
                    System.out.print(prog);
                    backSpaces = new char[prog.length()];
                    Arrays.fill(backSpaces, '\b');
                    System.out.print(backSpaces);
                }

                //StringTokenizer st = new StringTokenizer(currentLine.trim());
                cells = Util.tokenize(currentLine, '\t');
                if (cells.length < 2) {
                    cells = Util.tokenizeIngoreConsec(currentLine, ' ');
                }
                //initialize varaibles

                mafStrs = null;

                fileChrID = chromNameIndexMap.get(cells[indexChrom]);
                if (chrID < fileChrID) {
                    newLine.append(currentLine);
                    break;
                } else if (chrID > fileChrID) {
                    continue;
                }
                filePosition = Util.parseInt(cells[indexPosition]);
                ref = cells[indexREF];
                alt = cells[indexALT];
                if (cells.length > indexAda) {
                    mafStr = cells[indexAda];
                }

                alts = alt.split("N");
                if (mafStr != null) {
                    mafStrs = mafStr.split(",", -1);
                }

                //  System.err.println(currentLine);
                hitOnce = false;
                int tmpPos = 0;
                //once the variant is in db, it at least has a zero freq
                for (int s = 0; s < alts.length; s++) {
                    if (alts[s] == null || alts[s].isEmpty()) {
                        continue;
                    }
                    score = Float.NaN;
                    if (mafStrs != null && s < mafStrs.length) {
                        //this missing score is denoted by .
                        if (mafStrs[s] != null && !mafStrs[s].isEmpty() && !mafStrs[s].equals(".")) {
                            score = Util.parseFloat(mafStrs[s]);
                        }
                    }
                    tmpPos = filePosition;

                    alt = alts[s];

                    varIndex = chromosome.lookupVariantIndexes(tmpPos);
                    if (varIndex == null) {
                        continue;
                    }

                    // System.out.println(fileChr);
                    for (int index : varIndex) {
                        Variant var = varList.get(index);
                        if (var.isIndel) {
                            continue;
                        } else {
                            String[] altAlleles = var.getAltAlleles();
                            for (String str : altAlleles) {
                                if (str.charAt(0) == alt.charAt(0)) {
                                    hitOnce = true;
                                    if (Float.isNaN(score)) {
                                        var.setFeatureValue(feautreNum, ".");
                                    } else {
                                        var.setFeatureValue(feautreNum, String.valueOf(score));
                                    }
                                    break;
                                }
                            }
                        }

                    }
                }
                if (hitOnce) {
                    existVarNum++;
                }
            } while ((currentLine = br.readLine()) != null);

            dbScSNV.setLeftNum(existVarNum + dbScSNV.getLeftNum());
            dbScSNV.setAnnotNum(existVarNum + dbScSNV.getAnnotNum());
            dbScSNV.setTotalNum(lineCounter + dbScSNV.getTotalNum());
            if (needProgressionIndicator) {
                backSpaces = new char[7];
                Arrays.fill(backSpaces, '\b');
                System.out.print(backSpaces);
            }
        } catch (Exception ex) {
            if (currentLine != null) {
                System.err.println("Errors in a row: " + currentLine);
            }
            ex.printStackTrace();
        }
    }

    public void geneFeatureAnnot(List<Variant> variantList, int chrID, ReferenceGenome refGenome, Set<Byte> featureInSet, int featureNum, int maxThreadNum) throws Exception {
        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        int varNum = variantList.size();

        int[] blocks = org.cobi.util.thread.Util.partitionEvenBlock(maxThreadNum, 0, varNum);
        int blockNum = blocks.length - 1;
        for (int s = 0; s < blockNum; s++) {
            GeneFeatureAnnotTask task = new GeneFeatureAnnotTask(variantList.subList(blocks[s], blocks[s + 1]), chrID, refGenome, featureInSet, featureNum);
            serv.submit(task);
            runningThread++;
        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            //  System.out.println(infor);
        }

        exec.shutdown();
    }

    public List<Variant> contextBasedAnnotionThread(Chromosome chromosome, boolean isPhased, Map<String, RefGene> mergedGeneCodingRegions,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlSetID, int contextDis, int maxThreadNum) throws Exception {

        ExecutorService exec = Executors.newFixedThreadPool(maxThreadNum);
        final CompletionService<String> serv = new ExecutorCompletionService<String>(exec);
        int runningThread = 0;
        List<Variant> variantList = chromosome.variantList;
        int varNum = variantList.size();

        int[] blocks = org.cobi.util.thread.Util.partitionEvenBlock(maxThreadNum, 0, varNum);
        int blockNum = blocks.length - 1;
        for (int s = 0; s < blockNum; s++) {
            GeneFeaturecContextAnnotTask task = new GeneFeaturecContextAnnotTask();
            serv.submit(task);
            runningThread++;
        }

        for (int s = 0; s < runningThread; s++) {
            Future<String> task = serv.take();
            String infor = task.get();
            //  System.out.println(infor);
        }

        exec.shutdown();
        return null;
    }

    private class GeneFeaturecContextAnnotTask extends Task implements Callable<String> {

        @Override
        public String call() throws Exception {
            return null;
        }

    }

    public List<Variant> contextBasedAnnotion(Chromosome chromosome, boolean isPhased, Map<String, RefGene> mergedGeneCodingRegions,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlSetID, int contextDis) throws Exception {
//check the conscecutive mutation
        List<Variant> variantList = chromosome.variantList;
        int varSize = variantList.size();
        String[] cells;
        String label;

        Variant var, var1 = null;
        int alleleNum, base, subID, startIndex;
        boolean[] bits = new boolean[32];

        Map<String, Integer> newAlleleSet = new HashMap<String, Integer>();
        Map<Integer, String> alleleIDSet = new HashMap<Integer, String>();
        int allleNum = 0;

        StringBuilder tmpAlleles1 = new StringBuilder();
        StringBuilder tmpAlleles2 = new StringBuilder();
        StringBuilder tmpBuilder = new StringBuilder();
        int altNum1, altNum2;

        int indivSize = pedEncodeGytIDMap.length;

        String str;

        List<Variant> newVariantList = new ArrayList<Variant>();
        Set<String> availableVariantsID = new HashSet<String>();

        VCFParseTaskFast vcfPaseTaks = new VCFParseTaskFast(0);
        int[] encodeGtyID = new int[indivSize * 2];
        vcfPaseTaks.setGenotypesAndSubjects(null, null, encodeGtyID, encodeGtyID);
        int[] newGtyArray = new int[indivSize * 2];
        for (int i = 0; i < newGtyArray.length; i++) {
            newGtyArray[i] = i;
        }
        List<Variant> tmpVarList = new ArrayList<Variant>();
        vcfPaseTaks.setGtys(newGtyArray);
        //assume the genotypes is phased 
        vcfPaseTaks.setIsPhased(true);
        vcfPaseTaks.setTotalPedSubjectNum(indivSize);

        vcfPaseTaks.setGenotypesAndSubjects(pedEncodeGytIDMap, caeSetID, controlSetID);
        vcfPaseTaks.prepareFewTempVariables();

        int[] gtys;
        IntArrayList allEffectiveIndex = new IntArrayList();
        int dis1;
        boolean noMissingGty = false;

        for (int i = 0; i < varSize; i++) {
            var = variantList.get(i);
            str = var.geneSymb;
            if (str == null) {
                tmpVarList.add(var);
                continue;
            }
            //only consider non-synomouse variants bevaus there are no sequences available for inference
            if (var.smallestFeatureID > 7 || var.smallestFeatureID < 2) {
                tmpVarList.add(var);
                continue;
            }
            if (var.isIndel) {
                tmpVarList.add(var);
                continue;
            }
            allEffectiveIndex.add(i);
        }

        List<IntArrayList> listConsecutiveIndexes = new ArrayList<IntArrayList>();
        IntArrayList consecutiveIndexes = null;
        varSize = allEffectiveIndex.size();
        boolean hasNewList = false;
        int lastPos = 0, ii = 0, startI;
        for (startI = 1; startI < varSize; startI++) {
            hasNewList = false;
            do {
                dis1 = variantList.get(allEffectiveIndex.getQuick(startI)).refStartPosition - variantList.get(allEffectiveIndex.getQuick(startI - 1)).refStartPosition;
                if (dis1 <= contextDis) {
                    if (hasNewList) {
                        consecutiveIndexes.add(allEffectiveIndex.getQuick(startI));
                        ii++;
                    } else {
                        consecutiveIndexes = new IntArrayList();
                        consecutiveIndexes.add(allEffectiveIndex.getQuick(startI - 1));
                        consecutiveIndexes.add(allEffectiveIndex.getQuick(startI));
                        hasNewList = true;
                        listConsecutiveIndexes.add(consecutiveIndexes);
                        ii += 2;
                    }
                    startI++;
                    if (startI >= varSize) {
                        break;
                    }
                } else {
                    if (!hasNewList) {
                        tmpVarList.add(variantList.get(allEffectiveIndex.getQuick(startI - 1)));
                    }
                    break;
                }
            } while (true);
        }
        if (!hasNewList) {
            tmpVarList.add(variantList.get(allEffectiveIndex.getQuick(startI - 1)));
        }
        int listSize = listConsecutiveIndexes.size();
        if (listSize == 0) {
            return null;
        }

        for (int i = 0; i < listSize; i++) {
            consecutiveIndexes = listConsecutiveIndexes.get(i);
            varSize = consecutiveIndexes.size();
//            if(variantList.get(consecutiveIndexes.getQuick(0)).refStartPosition==97755996){
//                int ssss=0;
//            }

            tmpAlleles1.delete(0, tmpAlleles1.length());
            for (int k = 0; k < varSize; k++) {
                var = variantList.get(consecutiveIndexes.getQuick(k));
                if (k > 0) {
                    dis1 = var.refStartPosition - lastPos;
                    dis1--;
                    if (dis1 > 0) {
                        for (int r = 0; r < dis1; r++) {
                            tmpAlleles1.append('.');
                        }
                    }
                    lastPos = var.refStartPosition + dis1;
                    tmpAlleles1.append(var.getRefAllele());

                } else {
                    tmpAlleles1.append(var.getRefAllele());
                    lastPos = var.refStartPosition;
                }

            }

            newAlleleSet.clear();
            alleleIDSet.clear();
            allleNum = 0;
            //save the reference of 
            newAlleleSet.put(tmpAlleles1.toString(), allleNum);
            alleleIDSet.put(allleNum, tmpAlleles1.toString());

            Arrays.fill(newGtyArray, -1);
            for (int j = 0; j < indivSize; j++) {
                subID = j;
                altNum1 = 0;
                altNum2 = 0;
                tmpAlleles1.delete(0, tmpAlleles1.length());
                tmpAlleles2.delete(0, tmpAlleles2.length());

                noMissingGty = true;
                //ensure each indivudal has the consecutive genotypes
                for (int k = 0; k < varSize; k++) {
                    var = variantList.get(consecutiveIndexes.getQuick(k));
                    if (k > 0) {
                        dis1 = var.refStartPosition - lastPos;
                        dis1--;
                        if (dis1 > 0) {
                            for (int r = 0; r < dis1; r++) {
                                tmpAlleles1.append('.');
                                tmpAlleles2.append('.');
                            }
                            lastPos = var.refStartPosition + dis1;
                        } else {
                            lastPos = var.refStartPosition;
                        }
                    } else {
                        lastPos = var.refStartPosition;
                    }

                    alleleNum = var.getAltAlleles().length + 1;
                    if (isPhased) {
                        base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
                    } else {
                        base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
                    }
                    if (var.compressedGtyNum >= 0) {
                        startIndex = subID;
                        if (var.compressedGtyNum > 0) {
                            for (int t = 0; t < base; t++) {
                                if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                    bits[t] = false;
                                } else if (startIndex < var.compressedGty[0]) {
                                    bits[t] = false;
                                } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                    bits[t] = true;
                                } else if (startIndex == var.compressedGty[0]) {
                                    bits[t] = true;
                                } else {
                                    bits[t] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                                }
                                startIndex += indivSize;
                            }
                        } else if (var.compressedGtyNum == 0) {
                            Arrays.fill(bits, 0, base, false);
                        }
                        if (isPhased) {
                            gtys = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                        } else {
                            gtys = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                        }
                    } else if (isPhased) {
                        gtys = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, indivSize);
                    } else {
                        gtys = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, indivSize);
                    }
                    if (gtys == null) {
                        tmpAlleles1.append('.');
                        tmpAlleles2.append('.');
                        noMissingGty = false;
                        continue;
                    }

                    if (gtys[0] == 0) {
                        tmpAlleles1.append(var.getRefAllele());
                    } else {
                        altNum1++;
                        tmpAlleles1.append(var.getAltAlleles()[gtys[0] - 1]);
                    }

                    if (gtys[1] == 0) {
                        tmpAlleles2.append(var.getRefAllele());
                    } else {
                        altNum2++;
                        tmpAlleles2.append(var.getAltAlleles()[gtys[1] - 1]);
                    }
                }

                // if (altNum1 > 1 || altNum2 > 1)
                if (noMissingGty) {
                    Integer alleleId = newAlleleSet.get(tmpAlleles1.toString());
                    if (alleleId == null) {
                        allleNum++;
                        newAlleleSet.put(tmpAlleles1.toString(), allleNum);
                        alleleIDSet.put(allleNum, tmpAlleles1.toString());
                        alleleId = allleNum;
                    }
                    newGtyArray[j << 1] = alleleId;

                    alleleId = newAlleleSet.get(tmpAlleles2.toString());
                    if (alleleId == null) {
                        allleNum++;
                        newAlleleSet.put(tmpAlleles2.toString(), allleNum);
                        alleleIDSet.put(allleNum, tmpAlleles2.toString());
                        alleleId = allleNum;
                    }
                    newGtyArray[(j << 1) + 1] = alleleId;
                }
            }

            var = variantList.get(consecutiveIndexes.getQuick(0));

            label = var.refStartPosition + ":" + alleleIDSet.get(0);
            String[] alleles = new String[alleleIDSet.size() - 1];
            for (int t = 0; t < alleles.length; t++) {
                alleles[t] = alleleIDSet.get(t + 1);
                label += (":" + alleles[t]);

            }
            if (availableVariantsID.contains(label)) {
                continue;
            }
            Variant newVar = new Variant(var.refStartPosition, alleleIDSet.get(0), alleles);

            availableVariantsID.add(label);
            newVariantList.add(newVar);

            vcfPaseTaks.countAllles(newVar);
            vcfPaseTaks.encodeGenotype(newVar, alleles.length + 1);

        }
        variantList.clear();
        variantList.addAll(tmpVarList);
        tmpVarList.clear();

        return newVariantList;
    }

    public List<Variant> contextBasedAnnotion0(Chromosome chromosome, boolean isPhased, Map<String, RefGene> mergedGeneCodingRegions,
            int[] pedEncodeGytIDMap, int[] caeSetID, int[] controlSetID, int contextDis) throws Exception {
//check the conscecutive mutation
        List<Variant> variantList = chromosome.variantList;
        int varSize = variantList.size();
        String[] cells;
        String label;
        Map<String, IntArrayList> mappedVariants = new HashMap<String, IntArrayList>();
        IntArrayList poss;
        Variant var, var1;
        int alleleNum, base, subID, startIndex;
        boolean[] bits = new boolean[32];

        Set<String> consecutivePoss = new HashSet<String>();
        Map<String, Integer> newAlleleSet = new HashMap<String, Integer>();
        Map<Integer, String> alleleIDSet = new HashMap<Integer, String>();
        int allleNum = 0;

        StringBuilder tmpAlleles1 = new StringBuilder();
        StringBuilder tmpAlleles2 = new StringBuilder();
        StringBuilder tmpBuilder = new StringBuilder();
        int altNum1, altNum2;

        int startBound, endBound;
        int indivSize = pedEncodeGytIDMap.length;

        Set<String> geneSet = new HashSet<String>();
        List<String> geneList = new ArrayList<String>();
        String str;
        int[] indexes = new int[2];
        List<Variant> newVariantList = new ArrayList<Variant>();
        Set<String> availableVariantsID = new HashSet<String>();
        boolean hasConsecutiveVar = false;
        int tmpLen = 0;
        VCFParseTaskFast vcfPaseTaks = new VCFParseTaskFast(0);
        int[] encodeGtyID = new int[indivSize * 2];
        vcfPaseTaks.setGenotypesAndSubjects(null, null, encodeGtyID, encodeGtyID);
        int[] newGtyArray = new int[indivSize * 2];
        for (int i = 0; i < newGtyArray.length; i++) {
            newGtyArray[i] = i;
        }
        vcfPaseTaks.setGtys(newGtyArray);
        //assume the genotypes is phased 
        vcfPaseTaks.setIsPhased(true);
        vcfPaseTaks.setTotalPedSubjectNum(indivSize);

        vcfPaseTaks.setGenotypesAndSubjects(pedEncodeGytIDMap, caeSetID, controlSetID);
        vcfPaseTaks.prepareFewTempVariables();

        int[] gtys;
        for (int i = 0; i < varSize; i++) {
            str = variantList.get(i).geneSymb;
            if (str == null || geneSet.contains(str)) {
                continue;
            }
            geneSet.add(str);
            //keep the order 
            geneList.add(str);
        }
        geneSet.clear();

        availableVariantsID.clear();
        newVariantList.clear();
        // search the region in genes
        for (String geneSyb : geneList) {
            RefGene mgeneExons = mergedGeneCodingRegions.get(geneSyb);
            if (mgeneExons == null) {
                continue;
            }
            List<SeqSegment> segs = mgeneExons.getMergedSegments();
            int boundNum = segs.size();
            if (boundNum == 0) {
                continue;
            }

            //it should be reversed
            if (segs.get(0).getStart() >= segs.get(boundNum - 1).getStart()) {
                startBound = segs.get(boundNum - 1).getStart();
                endBound = segs.get(0).getEnd();

            } else {
                startBound = segs.get(0).getStart();
                endBound = segs.get(boundNum - 1).getEnd();
            }
            chromosome.lookupVariantByRegions(startBound, endBound, indexes);

            mappedVariants.clear();
            int pos1, index1;
            String posStr;
            //search consecutive dependentVariants in a gene for the first round
            for (int j = indexes[0]; j < indexes[1]; j++) {
                var1 = variantList.get(j);

                //ignore Indel for the time being
                if (var1.isIndel) {
                    continue;
                }
                String s1 = var1.getRefGeneAnnot();
                if (s1 == null) {
                    continue;
                }

                tmpAlleles1.append(var1.getRefAllele());
                String[] trasncripts = s1.split(";");
                for (String trasncript : trasncripts) {
                    cells = trasncript.split(":");
                    if (cells.length < 4) {
                        continue;
                    }
                    //consider non-synonymous dependentVariants
                    if (cells.length > 6 && cells[6].equals("nonframeshift")) {
                        label = cells[1] + ":" + cells[5] + ":" + cells[6];
                        poss = mappedVariants.get(label);
                        if (poss == null) {
                            poss = new IntArrayList();
                            mappedVariants.put(label, poss);
                        }
                        poss.add(j);
                    } else if (cells.length > 3 && cells[3].startsWith("p.")) {
                        label = cells[1] + ":" + cells[3].substring(2, cells[3].length() - 1);
                        poss = mappedVariants.get(label);
                        if (poss == null) {
                            poss = new IntArrayList();
                            mappedVariants.put(label, poss);
                        }
                        poss.add(j);
                    } else if ((cells.length > 4) && (cells[4].endsWith("acceptor") || cells[4].endsWith("donor"))) {
                        posStr = cells[2].substring(2, cells[2].length() - 3);
                        index1 = posStr.indexOf('-', 1);
                        if (index1 < 0) {
                            index1 = posStr.indexOf('+', 1);
                            if (index1 > 0) {
                                pos1 = Integer.parseInt(posStr.substring(0, index1));
                                label = cells[1] + ":" + pos1 + "+";
                                poss = mappedVariants.get(label);
                                if (poss == null) {
                                    poss = new IntArrayList();
                                    mappedVariants.put(label, poss);
                                }
                                poss.add(j);
                            }
                        } else {
                            pos1 = Integer.parseInt(posStr.substring(0, index1));
                            label = cells[1] + ":" + pos1 + "-";
                            poss = mappedVariants.get(label);
                            if (poss == null) {
                                poss = new IntArrayList();
                                mappedVariants.put(label, poss);
                            }
                            poss.add(j);
                        }

                    }
                }
            }
            consecutivePoss.clear();

            int ii = 0;
            int totalInDe = 0;
            int startI, endI;
            //search consecutive dependentVariants in a gene for the second round when genotypes are considered
            for (Map.Entry<String, IntArrayList> item : mappedVariants.entrySet()) {
                poss = item.getValue();
                if (poss.size() < 2) {
                    continue;
                }
                poss.quickSort();
                varSize = poss.size() - 1;
                if (item.getKey().endsWith("nonframeshift")) {
                    startI = 0;
                    endI = startI;
                    while (endI < varSize) {
                        endI++;
                        if (variantList.get(poss.getQuick(endI)).refStartPosition - variantList.get(poss.getQuick(startI)).refStartPosition > contextDis) {
                            if (endI - startI > 1) {
                                for (int t = startI; t < endI; t++) {
                                    tmpBuilder.append(poss.getQuick(t));
                                    tmpBuilder.append(":");
                                }
                                tmpBuilder.append("nonframeshift");
                                consecutivePoss.add(tmpBuilder.toString());
                                tmpBuilder.delete(0, tmpBuilder.length());
                            }
                        } else {
                            startI = endI;
                        }
                    }

                } else {
                    for (int t = 0; t < poss.size(); t++) {
                        tmpBuilder.append(poss.getQuick(t));
                        tmpBuilder.append(":");
                    }
                    consecutivePoss.add(tmpBuilder.substring(0, tmpBuilder.length() - 1));
                    tmpBuilder.delete(0, tmpBuilder.length());
                }

            }

//only consider the potentiall effective sites 
            Arrays.fill(newGtyArray, -1);

            for (String item : consecutivePoss) {
                cells = item.split(":");
                varSize = cells.length;

                if (item.endsWith("nonframeshift")) {
                    varSize--;
                }
                int[] newPoss = new int[varSize];
                for (int j = 0; j < varSize; j++) {
                    newPoss[j] = Integer.parseInt(cells[j]);
                }
                tmpAlleles1.delete(0, tmpAlleles1.length());
                // if this is insertion or deletion
                if (item.endsWith("nonframeshift")) {
                    totalInDe = 0;
                    for (int k = 0; k < varSize; k++) {
                        String tmpStr = variantList.get(newPoss[k]).getAltAllele(0);
                        for (int i = tmpStr.length() - 1; i >= 0; i--) {
                            if (tmpStr.charAt(i) == '-') {
                                totalInDe--;
                            } else if (tmpStr.charAt(i) == '+') {
                                totalInDe++;
                            }
                        }
                    }
                    //it converted into frameshift
                    //I found it is difficult now
                    if (totalInDe % 3 == 0) {

                    }

                } else {
                    var = variantList.get(newPoss[0]);

                    tmpAlleles1.append(var.getRefAllele());
                    for (int k = 1; k < varSize; k++) {
                        tmpLen = variantList.get(newPoss[k]).refStartPosition - variantList.get(newPoss[k - 1]).refStartPosition;
                        ii = 1;

                        //fill identical variant
                        while (ii < tmpLen) {
                            tmpAlleles1.append('.');
                            ii++;
                        }
                        var = variantList.get(newPoss[k]);
                        tmpAlleles1.append(var.getRefAllele());
                    }
                }

                if (tmpAlleles1.length() > contextDis) {
                    //ingore some too distantly  positions
                    continue;
                }

                newAlleleSet.clear();
                alleleIDSet.clear();
                allleNum = 0;
                //save the reference of 
                newAlleleSet.put(tmpAlleles1.toString(), allleNum);
                alleleIDSet.put(allleNum, tmpAlleles1.toString());
                //check the dependentVariants for each subjecgts              
                hasConsecutiveVar = false;
                for (int j = 0; j < indivSize; j++) {
                    subID = j;
                    altNum1 = 0;
                    altNum2 = 0;
                    tmpAlleles1.delete(0, tmpAlleles1.length());
                    tmpAlleles2.delete(0, tmpAlleles2.length());

                    //ensure each indivudal has the consecutive genotypes
                    for (int k = 0; k < varSize; k++) {
                        var = variantList.get(newPoss[k]);
                        if (k > 0) {
                            tmpLen = variantList.get(newPoss[k]).refStartPosition - variantList.get(newPoss[k - 1]).refStartPosition;
                            ii = 1;
                            //fill identical variant
                            while (ii < tmpLen) {
                                tmpAlleles1.append('.');
                                tmpAlleles2.append('.');
                                ii++;
                            }
                        }

                        alleleNum = var.getAltAlleles().length + 1;
                        if (isPhased) {
                            base = GlobalManager.phasedAlleleBitMap.get(alleleNum);
                        } else {
                            base = GlobalManager.unphasedAlleleBitMap.get(alleleNum);
                        }
                        if (var.compressedGtyNum >= 0) {
                            startIndex = subID;
                            if (var.compressedGtyNum > 0) {
                                for (int t = 0; t < base; t++) {
                                    if (startIndex > var.compressedGty[var.compressedGty.length - 1]) {
                                        bits[t] = false;
                                    } else if (startIndex < var.compressedGty[0]) {
                                        bits[t] = false;
                                    } else if (startIndex == var.compressedGty[var.compressedGty.length - 1]) {
                                        bits[t] = true;
                                    } else if (startIndex == var.compressedGty[0]) {
                                        bits[t] = true;
                                    } else {
                                        bits[t] = (Arrays.binarySearch(var.compressedGty, startIndex) >= 0);
                                    }
                                    startIndex += indivSize;
                                }
                            } else if (var.compressedGtyNum == 0) {
                                Arrays.fill(bits, 0, base, false);
                            }
                            if (isPhased) {
                                gtys = bgp.getPhasedGtyBool(bits, alleleNum, base, subID);
                            } else {
                                gtys = bgp.getUnphasedGtyBool(bits, alleleNum, base, subID);
                            }
                        } else if (isPhased) {
                            gtys = bgp.getPhasedGtyAt(var.encodedGty, alleleNum, base, subID, indivSize);
                        } else {
                            gtys = bgp.getUnphasedGtyAt(var.encodedGty, alleleNum, base, subID, indivSize);
                        }
                        if (gtys == null) {
                            tmpAlleles1.append('.');
                            tmpAlleles2.append('.');
                            continue;
                        }

                        if (gtys[0] == 0) {
                            tmpAlleles1.append(var.getRefAllele());
                        } else {
                            altNum1++;
                            tmpAlleles1.append(var.getAltAlleles()[gtys[0] - 1]);
                        }

                        if (gtys[1] == 0) {
                            tmpAlleles2.append(var.getRefAllele());
                        } else {
                            altNum2++;
                            tmpAlleles2.append(var.getAltAlleles()[gtys[1] - 1]);
                        }
                    }

                    if (altNum1 > 1 || altNum2 > 1) {
                        Integer alleleId = newAlleleSet.get(tmpAlleles1.toString());
                        if (alleleId == null) {
                            allleNum++;
                            newAlleleSet.put(tmpAlleles1.toString(), allleNum);
                            alleleIDSet.put(allleNum, tmpAlleles1.toString());
                            alleleId = allleNum;
                        }
                        newGtyArray[j << 1] = alleleId;

                        alleleId = newAlleleSet.get(tmpAlleles2.toString());
                        if (alleleId == null) {
                            allleNum++;
                            newAlleleSet.put(tmpAlleles2.toString(), allleNum);
                            alleleIDSet.put(allleNum, tmpAlleles2.toString());
                            alleleId = allleNum;
                        }
                        newGtyArray[(j << 1) + 1] = alleleId;
                        hasConsecutiveVar = true;
                    }
                }

                //if some subjects have consecutive dependentVariants
                if (hasConsecutiveVar) {
                    label = variantList.get(newPoss[0]).refStartPosition + ":" + alleleIDSet.get(0);
                    String[] alleles = new String[alleleIDSet.size() - 1];
                    for (int t = 0; t < alleles.length; t++) {
                        alleles[t] = alleleIDSet.get(t + 1);
                        label += (":" + alleles[t]);
                    }
                    if (availableVariantsID.contains(label)) {
                        continue;
                    }
                    Variant newVar = new Variant(variantList.get(newPoss[0]).refStartPosition, alleleIDSet.get(0), alleles);

                    availableVariantsID.add(label);
                    newVariantList.add(newVar);

                    vcfPaseTaks.countAllles(newVar);
                    vcfPaseTaks.encodeGenotype(newVar, alleles.length + 1);

                }

            }
        }
        /*
        for (Variant varT : newVariantList) {
            System.out.print(varT.refStartPosition + " " + varT.getRefAllele());
            for (String aAllele : varT.getAltAlleles()) {
                System.out.print(" " + aAllele);
            }

            for (int t = 0; t < varT.encodedGty.length; t += 2) {
                System.out.print(" " + varT.encodedGty[t] + "|" + varT.encodedGty[t + 1]);
            }
            System.out.println();
        }
         */

        return newVariantList;
    }

    public void geneFeatureAnnot(Chromosome chromosome, int chrID, ReferenceGenome refGenome, Set<Byte> featureInSet, int feautreNum) throws Exception {

        if (refGenome.getName().equals("refgene")) {
            if (chromosome == null) {
                return;
            }
            for (Variant var : chromosome.variantList) {
                GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                // Feature for UniProtFeature
                if (gf.getInfor() == null) {
                    var.setFeatureValue(feautreNum, ".");
                } else {
                    var.setFeatureValue(feautreNum, gf.getInfor());
                }
                var.setRefGeneAnnot(gf.getName());
            }

        } else if (refGenome.getName().equals("gencode")) {
            if (chromosome == null) {
                return;
            }
            for (Variant var : chromosome.variantList) {
                GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                // Feature for UniProtFeature
                if (gf.getInfor() == null) {
                    var.setFeatureValue(feautreNum, ".");
                } else {
                    var.setFeatureValue(feautreNum, gf.getInfor());
                }
                var.setgEncodeAnnot(gf.getName());
            }

        } else if (refGenome.getName().equals("knowngene")) {
            if (chromosome == null) {
                return;
            }
            for (Variant var : chromosome.variantList) {
                GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                // Feature for UniProtFeature
                if (gf.getInfor() == null) {
                    var.setFeatureValue(feautreNum, ".");
                } else {
                    var.setFeatureValue(feautreNum, gf.getInfor());
                }
                var.setKnownGeneAnnot(gf.getName());
            }

        } else if (refGenome.getName().equals("ensembl")) {
            if (chromosome == null) {
                return;
            }
            for (Variant var : chromosome.variantList) {
                GeneFeature gf = refGenome.getVarFeature(STAND_CHROM_NAMES[chrID], var, true, featureInSet);

                // Feature for UniProtFeature
                if (gf.getInfor() == null) {
                    var.setFeatureValue(feautreNum, ".");
                } else {
                    var.setFeatureValue(feautreNum, gf.getInfor());
                }
                var.setEnsemblGeneAnnot(gf.getName());

            }

        }
    }

    class PathwayP {

        double p;
        String pathway;

        public PathwayP(double p, String pathway) {
            this.p = p;
            this.pathway = pathway;
        }
    }

    class PathwayPComparator implements Comparator<PathwayP> {

        @Override
        public int compare(PathwayP arg0, PathwayP arg1) {
            return Double.compare(arg0.p, arg1.p);
        }
    }

    private String[] searchIbdRegions(List<String[]> regionItems, String chrom, int poss) {
        // to do
        String[] region = null;
        for (String[] cells : regionItems) {
            if (cells[0].equals(chrom)) {
                int start = Util.parseInt(cells[1]);
                int end = Util.parseInt(cells[2]);
                if (poss >= start && poss <= end) {
                    region = new String[2];
                    region[0] = "chr" + chrom + ":" + cells[1] + "-" + cells[2];
                    region[1] = String.valueOf(Util.parseInt(cells[2]) - Util.parseInt(cells[1]));
                    break;
                }

            }
        }
        return region;
    }

    public void pubMedIDIdeogramExploreGene(Chromosome chromosome, AnnotationSummarySet ass, List<String> pubmedMeshList, List<String[]> ideogramItems) throws Exception {
        if (!pubmedMeshList.isEmpty() && pubmedMeshList.get(0).equals("ANY")) {
            return;
        }

        NCBIRetriever ncbiRetriever = new NCBIRetriever();
        int account = 1;
        List<String> ideoGrams = null;
        Map<String, String> historyResultMap = new HashMap<String, String>();
        StringBuilder result = new StringBuilder();

        if (chromosome == null) {
            return;
        }

        for (mRNA mrna : chromosome.mRNAList) {
            result.delete(0, result.length());
            ideoGrams = searchIdeogramRegions(ideogramItems, chromosome.getName(), mrna.getStart(), mrna.getEnd());
            for (String reg : ideoGrams) {
                // ignore regions which are two broad
                /*
                 * if (reg.indexOf(".") < 0) { continue; }
                 */
                String pubIDs = historyResultMap.get(reg);
                if (pubIDs == null) {
                    LOG.info(account + ": Searching NCBI PubMed for " + pubmedMeshList.toString() + " and " + reg);
                    while ((pubIDs = ncbiRetriever.pubMedIDESearch(pubmedMeshList, reg)) == null) {
                        // System.out.print("reconnecting...");
                    }
                    // System.out.println(pubIDs);
                    if (pubIDs == null) {
                        pubIDs = "";
                    }
                    historyResultMap.put(reg, pubIDs);
                    account++;
                }
                if (pubIDs.trim().length() > 0) {
                    result.append(reg).append(":[").append(pubIDs).append("] ");
                }
            }
            mrna.addFeatureValue(result.toString());
        }

        ass.setAnnotNum(ass.getAnnotNum() + account);
        ass.setTotalNum(ass.getTotalNum() + chromosome.mRNAList.size());
        ass.setLeftNum(ass.getLeftNum() + chromosome.mRNAList.size() - account);
    }

    private List<String> searchIdeogramRegions(List<String[]> ideogramItems, String chrom, int startPoss, int endPoss) {
        // to do
        List<String> ideoRegions = new ArrayList<String>();
        for (String[] cells : ideogramItems) {
            if (cells[0].equals(chrom)) {
                if (cells[1] != null && cells[1].trim().length() > 0) {
                    int start = Util.parseInt(cells[2]);
                    int end = Util.parseInt(cells[3]);
                    if (startPoss >= start && startPoss <= end) {
                        ideoRegions.add(cells[0] + cells[1]);
                    } else if (endPoss >= start && endPoss <= end) {
                        ideoRegions.add(cells[0] + cells[1]);
                    }
                }
            }
        }
        // normall the detailed region in the latter
        Collections.reverse(ideoRegions);
        return ideoRegions;

    }

    private List<String> searchIdeogramRegions(List<String[]> ideogramItems, String chrom, int poss) {
        // to do
        List<String> ideoRegions = new ArrayList<String>();
        for (String[] cells : ideogramItems) {
            if (cells[0].equals(chrom)) {
                if (cells[1] != null && cells[1].trim().length() > 0) {
                    int start = Util.parseInt(cells[2]);
                    int end = Util.parseInt(cells[3]);
                    if (poss >= start && poss <= end) {
                        ideoRegions.add(cells[0] + cells[1]);
                    }
                }
            }
        }
        // normall the detailed region in the latter
        Collections.reverse(ideoRegions);
        return ideoRegions;

    }

}
