/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.DoubleArrayList;
import cern.jet.stat.Probability;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import org.apache.log4j.Logger;
import org.cobi.kggseq.GlobalManager;
import org.cobi.kggseq.entity.Gene;
import org.cobi.kggseq.entity.ZTNBParamSet;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.stat.SpecifcCalculatorLinear;
import org.cobi.util.stat.StdStats;
import org.cobi.util.thread.Task;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

/**
 *
 * @author limx54
 */
public class TNBRegressionTaskRUNNER extends Task implements Callable<String> {

    private static final Logger LOG = Logger.getLogger(TNBRegressionTaskRUNNER.class);

    List<Gene> orderedAllGenes;
    List<double[]> countsRegList;
    List<String> scoreHeads;
    Map<String, DoubleArrayList> refGeneVarFreqScoreMap;
    boolean noExplanatoryVar;
    double freqCut;
    double scoreBinCut;
    int tn;

    int geneFreqScoreIndex;
    int geneControlVarScoreIndex = -1;
    boolean needInteraction;
    int addedCovNum;
    int orgScoreColStart;
    int orgScoreColEnd;
    int caseControlAlleleCount;
    boolean isOneGene;
    boolean usingLog;
    boolean protectiveEffect;

    List<ZTNBParamSet> paramSetList;

    RConnection rcon;
    int threadID;
    double looseFDR;
    String rHost;
    int rPort;

    public TNBRegressionTaskRUNNER(String rHost, int rPort, Map<String, DoubleArrayList> refGeneVarFreqScoreMap, List<Gene> geneOrder, List<double[]> countsRegList,
            List<String> scoreHeads, boolean noExplanatoryVar, double freqCut, double scoreBinCut, int tn,
            int geneFreqScoreIndex, boolean needInteraction, int orgScoreColStart, int orgScoreColEnd, int addedCovNum, int caseControlAlleleCount,
            boolean isOneGene, boolean usingLog, boolean protectiveEffect, int threadID, double looseFDR) {
        this.orderedAllGenes = geneOrder;
        this.countsRegList = countsRegList;

        this.scoreHeads = scoreHeads;
        this.refGeneVarFreqScoreMap = refGeneVarFreqScoreMap;
        this.noExplanatoryVar = noExplanatoryVar;
        this.freqCut = freqCut;
        this.scoreBinCut = scoreBinCut;
        this.tn = tn;

        this.needInteraction = needInteraction;
        this.addedCovNum = addedCovNum;
        this.orgScoreColStart = orgScoreColStart;
        this.orgScoreColEnd = orgScoreColEnd;

        this.geneFreqScoreIndex = geneFreqScoreIndex;
        this.caseControlAlleleCount = caseControlAlleleCount;
        this.isOneGene = isOneGene;
        this.usingLog = usingLog;
        this.protectiveEffect = protectiveEffect;
        this.threadID = threadID;
        this.looseFDR = looseFDR;
        paramSetList = new ArrayList<ZTNBParamSet>();
        this.rHost = rHost;
        this.rPort = rPort;
    }

    public void setGeneControlVarScoreIndex(int geneControlVarScoreIndex) {
        this.geneControlVarScoreIndex = geneControlVarScoreIndex;
    }

    public List<ZTNBParamSet> getParamSetList() {
        return paramSetList;
    }

    double calcGeneRefAlleleScores(DoubleArrayList da, double maxMAF, double binCut) {
        if (da == null || da.isEmpty()) {
            return 0;
        }
        int size = da.size() / 2;
        double score = 0, avgScore = 0;
        int effectNum = 0;
        //only add frequencey
        if (binCut <= 0) {
            for (int i = 0; i < size; i++) {
                if (Double.isNaN(da.getQuick(i + i))) {
                    continue;
                }
                if (da.getQuick(i + i) > maxMAF) {
                    continue;
                }

                if (Double.isNaN(da.getQuick(i + i + 1))) {
                    score += da.getQuick(i + i);
                } else {
                    score += da.getQuick(i + i);
                }
            }
            return score;
        }
        for (int i = 0; i < size; i++) {
            if (Double.isNaN(da.getQuick(i + i))) {
                continue;
            }
            if (da.getQuick(i + i) > maxMAF) {
                continue;
            }
            if (!Double.isNaN(da.getQuick(i + i + 1))) {
                avgScore += da.getQuick(i + i + 1);
                effectNum++;
            }
        }
        if (effectNum > 0) {
            avgScore = avgScore / effectNum;
        } else {
            //as the scores are normalzied to be 0 and 1.  0.5 is the median
            avgScore = 0.5;
        }

        for (int i = 0; i < size; i++) {
            if (Double.isNaN(da.getQuick(i + i))) {
                continue;
            }
            if (da.getQuick(i + i) > maxMAF) {
                continue;
            }

            if (Double.isNaN(da.getQuick(i + i + 1))) {
                score += da.getQuick(i + i) * avgScore / binCut;
            } else {
                score += da.getQuick(i + i) * da.getQuick(i + i + 1) / binCut;
            }

        }
        return score;
    }

    @Override
    public String call() throws Exception {
        //countsRegList will be updated in the thread
        int geneSize = countsRegList.size();
        List<double[]> countsRegListCopied = new ArrayList<>(geneSize);
        double[] eles;
        for (int i = 0; i < geneSize; i++) {
            eles = countsRegList.get(i);
            countsRegListCopied.add(Arrays.copyOf(eles, eles.length));
        }

        try {
            rcon = new RConnection(rHost, rPort);
            rcon.eval("library(MASS)");
            //rcon.eval("library(countreg)");
            rcon.eval(NegTruncR.codes);
            //rcon.eval("source(\"" + GlobalManager.PLUGIN_PATH + "R/negtrunc.R\")");
            // rcon.eval("library(missForest)");


            /*
      rcon.eval("pack=\"MASS\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://cran.us.r-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
      rcon.eval("pack=\"countreg\";  if (!require(pack,character.only = TRUE, quietly = TRUE))      {        install.packages(pack,dep=TRUE,repos='http://R-Forge.R-project.org');        if(!require(pack,character.only = TRUE)) stop(\"Package not found\")    }");
             */
            int colNum;
            double[] countsMatrix, orgCountsMatrix = null, weights, residuual;
            double mean, sd, mflc, adjGenePValueCutoff = 0.05;
            DoubleArrayList pValues = new DoubleArrayList();

//it is important to use a frequency threshold to control the genome-wide inflation rate
            List<double[]> remainedScoreListInsig = new ArrayList<double[]>();
            List<double[]> scoreListTrunc = new ArrayList<double[]>();

            //assume geneFreqScore is the second score index except for the interaction terms
            int inc = 0;
            double[] v;

            //ignore interaction in the varints
            if (!noExplanatoryVar) {
                orgScoreColStart++;
                orgScoreColEnd++;
            }

            SpecifcCalculatorLinear scl = new SpecifcCalculatorLinear();

            List<String> geneOrderTrunc = new ArrayList<String>();
            List<String> geneOrderInsig = new ArrayList<String>();

            int sigGeneNum = 0;
            int minSampleSize = 500;
            boolean outTest = false;
            BufferedWriter bw = null;

//scoreBinCut=0.1;
            geneSize = countsRegListCopied.size();
            for (int j = 0; j < geneSize; j++) {
                v = countsRegListCopied.get(j);
                v[0] = orderedAllGenes.get(j).getDepVarMutNum(scoreBinCut, caseControlAlleleCount, 3);
            }

            if (geneControlVarScoreIndex >= 0) {
                for (int j = 0; j < geneSize; j++) {
                    v = countsRegListCopied.get(j);
                    // v[geneControlVarScoreIndex] = orderedAllGenes.get(j).getIndepVarMutNum(scoreBinCut, caseControlAlleleCount, 3);
                    v[geneControlVarScoreIndex] = orderedAllGenes.get(j).getIndepVarMutNum(scoreBinCut, caseControlAlleleCount, 3);

                }

            }

            geneSize = countsRegListCopied.size();
            geneOrderTrunc.clear();
            scoreListTrunc.clear();
            for (int j = 0; j < geneSize; j++) {
                v = countsRegListCopied.get(j);
                if (v[0] > tn) {
                    scoreListTrunc.add(v);
                    geneOrderTrunc.add(orderedAllGenes.get(j).geneSymb);
                }
            }
            if (geneOrderTrunc.size() < minSampleSize) {
                String info = "The non-zero mutation counts of genes is  " + geneOrderTrunc.size() + " at truncation point " + tn + ". The analysis of RUNNER is stopped.";
                LOG.info(info);

            }
//tn=0;

//freqCut=0.029999999329447746;
            geneOrderInsig.clear();
            geneOrderInsig.addAll(geneOrderTrunc);
            remainedScoreListInsig.clear();
            remainedScoreListInsig.addAll(scoreListTrunc);
            int nonZero = 0;
            boolean hasProblem = false;
            long time = System.nanoTime();
            orgCountsMatrix = null;
            Set<String> sigGeneSet0 = new HashSet<String>();
            Set<String> sigGeneSet1 = new HashSet<String>();
            int iterNum = 0;
            do {
                geneSize = remainedScoreListInsig.size();
                colNum = remainedScoreListInsig.get(0).length;

                countsMatrix = new double[geneSize * colNum];

                if (outTest) {
                    bw = new BufferedWriter(new FileWriter("testS.txt"));
                    bw.write("Gene\tDepVarScore	RegionLength	EAS	RegionLengthEAS	oe_mis	oe_lof	ExonGC	CtrlVarScore\n");
                }
                nonZero = 0;
                for (int j = 0; j < geneSize; j++) {
                    v = remainedScoreListInsig.get(j);
                    if (isOneGene) {
                        v[geneFreqScoreIndex] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(geneOrderInsig.get(j)), freqCut, scoreBinCut);
                    } else {
                        String[] genes = geneOrderInsig.get(j).split(":");
                        v[geneFreqScoreIndex] = calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[0]), freqCut, scoreBinCut);
                        for (int i = 1; i < genes.length; i++) {
                            v[geneFreqScoreIndex] *= calcGeneRefAlleleScores(refGeneVarFreqScoreMap.get(genes[i]), freqCut, scoreBinCut);

                        }

                    }

                    if (v[geneFreqScoreIndex] != 0) {
                        nonZero++;
                    }

                    if (needInteraction) {
                        inc = 0;
                        for (int i = orgScoreColStart; i < orgScoreColEnd; i++) {
                            for (int t = i + 1; t < orgScoreColEnd; t++) {
                                v[orgScoreColEnd + inc] = v[i] * v[t];

                                inc++;
                            }
                        }
                    }
                    System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);

                    if (outTest) {
                        if (geneOrderInsig.get(j).equals("ABCC1:CDH1")) {
                            int sss = 0;
                        }
                        bw.write(String.valueOf(geneOrderInsig.get(j)));
                        for (int i = 0; i < v.length; i++) {
                            bw.write("\t");
                            bw.write(String.valueOf(v[i]));
                        }
                        bw.write("\n");
                    }

                }
                if (outTest) {
                    System.out.println(freqCut + "\t" + scoreBinCut + "\t" + tn);
                    bw.close();
                }
                //System.out.println(freqCut + "\t" + scoreBinCut + "\t" + tn);
//                            if (nonZero < 100) {
//                                String info = "The non-zero gene frequency score is only " + nonZero + ". The analysis of RUNNER is stopped. Please increase the --rare-allele-freq slightly and re-run kggseq.";
//                                LOG.info(info);
//                                break;
//                            }
                boolean needPCA = false;
                if (needPCA) {
                    geneSize = remainedScoreListInsig.size();
                    colNum = remainedScoreListInsig.get(0).length;
                    countsMatrix = new double[geneSize * colNum];
                    for (int j = 0; j < geneSize; j++) {
                        v = remainedScoreListInsig.get(j);
                        System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                    }
                    rcon.assign("valMat", countsMatrix);
                    rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                    rcon.voidEval("nc<-" + colNum);
                    rcon.voidEval("pca<-prcomp(valMat[,4:nc], scale = TRUE)");
                    rcon.voidEval("conDat<-(valMat[,4:nc]%*% pca$rotation)");
                    rcon.voidEval("valMat<-cbind(valMat[,1:3],conDat)");
                    countsMatrix = rcon.eval("t(valMat)").asDoubles();
                    for (int j = 0; j < geneSize; j++) {
                        v = remainedScoreListInsig.get(j);
                        for (int i = 3; i < v.length; i++) {
                            v[i] = countsMatrix[j * v.length + i];
                        }
                    }
                }

                boolean needImput = false;

                boolean hasNA = false;
                if (needImput) {
                    geneSize = remainedScoreListInsig.size();
                    colNum = remainedScoreListInsig.get(0).length;
                    countsMatrix = new double[geneSize * colNum];
                    for (int j = 0; j < geneSize; j++) {
                        v = remainedScoreListInsig.get(j);
                        if (!hasNA) {
                            for (int t = 0; t < v.length; t++) {
                                if (Double.isNaN(v[t])) {
                                    hasNA = true;
                                }
                            }
                        }
                        System.arraycopy(v, 0, countsMatrix, j * v.length, v.length);
                    }
                    if (hasNA) {
                        rcon.assign("valMat", countsMatrix);
                        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");
                        rcon.voidEval("tmpD<-missForest(valMat)$ximp");
                        countsMatrix = rcon.eval("t(tmpD)").asDoubles();
                        for (int j = 0; j < geneSize; j++) {
                            v = remainedScoreListInsig.get(j);
                            for (int i = 3; i < v.length; i++) {
                                v[i] = countsMatrix[j * v.length + i];
                            }
                        }
                    }
                }
                pValues.clear();

                if (orgCountsMatrix == null) {
                    orgCountsMatrix = new double[countsMatrix.length];
                    System.arraycopy(countsMatrix, 0, orgCountsMatrix, 0, countsMatrix.length);
                }
                double[] residueCounter = caculateResidueByR(scoreHeads, countsMatrix, geneSize, colNum, noExplanatoryVar, tn, addedCovNum, orgCountsMatrix);
                if (residueCounter == null || Double.isNaN(residueCounter[0])) {
                    hasProblem = true;
                    break;
                }

                weights = new double[residueCounter.length];
                residuual = new double[residueCounter.length];
                Arrays.fill(weights, Double.NaN);
                scl.iterativeWeighter(residueCounter, weights, residuual, 100);
                mean = StdStats.mean(residueCounter, weights, true);
                sd = StdStats.stddev(residueCounter, weights);

                int geneNum = residueCounter.length;
                double zSc;

                for (int t = 0; t < geneNum; t++) {
                    zSc = (residueCounter[t] - mean) / sd;
                    if (!protectiveEffect) {
                        //one tailed test
                        if (zSc < 0) {
                            zSc = 1 - Probability.normal(zSc);
                        } else {
                            zSc = Probability.normal(-zSc);
                        }
                    } else {
                        if (zSc < 0) {
                            zSc = Probability.normal(zSc);
                        } else {
                            zSc = 1 - Probability.normal(-zSc);
                        }
                    }
                    pValues.add(zSc);
                }

                pValues.quickSort();
                adjGenePValueCutoff = MultipleTestingMethod.benjaminiHochbergFDR(looseFDR, pValues);
//                            //for testing
//                            PValuePainter pvPainter = new PValuePainter(350, 350);
//                            File plotFile = new File("test.qq.png");
//                            List<String> nameList = new ArrayList<String>();
//                            List<DoubleArrayList> pvalueLists = new ArrayList<DoubleArrayList>();
//                            nameList.add("Gene p");
//                            pvalueLists.add(pValues);
//                            pvPainter.drawMultipleQQPlot(pvalueLists, nameList, null, plotFile.getCanonicalPath(), 1E-10);

                geneOrderInsig.clear();
                remainedScoreListInsig.clear();
                sigGeneNum = 0;
                sigGeneSet1.clear();
                for (int i = 0; i < geneNum; i++) {
                    zSc = (residueCounter[i] - mean) / sd;
                    if (!protectiveEffect) {
                        //one tailed test
                        if (zSc < 0) {
                            zSc = 1 - Probability.normal(zSc);
                        } else {
                            zSc = Probability.normal(-zSc);
                        }
                    } else {
                        if (zSc < 0) {
                            zSc = Probability.normal(zSc);
                        } else {
                            zSc = 1 - Probability.normal(-zSc);
                        }
                    }
                    if (zSc <= adjGenePValueCutoff) {
                        sigGeneNum++;
                        sigGeneSet1.add(geneOrderTrunc.get(i));
                        continue;
                    }

                    remainedScoreListInsig.add(scoreListTrunc.get(i));
                    geneOrderInsig.add(geneOrderTrunc.get(i));

                }
                if (sigGeneSet0.equals(sigGeneSet1) || sigGeneSet0.size() >= sigGeneSet1.size()) {
                    break;
                }
                iterNum++;
                if (iterNum > 3) {
                    // break;
                }
                if (remainedScoreListInsig.size() < minSampleSize) {
                    String info = "The non-zero mutation counts of genes is  " + scoreListTrunc.size() + ". The analysis of RUNNER is stopped.";
                    LOG.info(info);
                    break;
                }
                sigGeneSet0.clear();
                sigGeneSet0.addAll(sigGeneSet1);

            } while (true);

            if (!hasProblem) {
                //// mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues, totalGeneNum)                            
                mflc = MultipleTestingMethod.MLFC(adjGenePValueCutoff, pValues);
                // mflc = MultipleTestingMethod.caculateInflationFactorDiff(adjGenePValueCutoff, pValues);
                //aic = rcon.eval("AIC(m1)").asDouble();

                paramSetList.add(new ZTNBParamSet(scoreBinCut, sigGeneNum, mflc, freqCut, tn));
                // System.out.println(scoreBinCut + "\t" +freqCut + "\t" + tn + "\t" + mflc+"\t"+sigGeneNum);

                time = System.nanoTime() - time;
                time = time / 1000000000;
                long min = time / 60;
                long sec = time % 60;
               LOG.info("Elapsed time: " + min + " min. " + sec + " sec. BinLen: " + scoreBinCut + " Truncation: " + tn + " FreqCut: " + freqCut + " MLFC: " + mflc + " Num:" + geneSize);

            }

        } catch (RserveException | InterruptedException | REXPMismatchException e1) {
            LOG.error("Errors at scoreBinCut " + scoreBinCut + ", truncation point " + tn + ", freqCut " + freqCut + "!");
            //System.out.println(freqCut + "\t" + scoreBinCut + "\t" + tn);
            e1.printStackTrace();

        }
        if (rcon != null) {
            rcon.close();
        }
        countsRegListCopied.clear();;
        fireTaskComplete();
        return "finished";
    }

    public double[] caculateResidueByR(List<String> scoreHeads, double[] countsMatrix, int geneSize, int colNum, boolean noExplanatoryVar,
            int trunc, int addedCovNum, double[] orgCountsMatrix) throws Exception {
        StringBuilder sb = new StringBuilder();

        String strPrefix = "genemutetest" + threadID;
        rcon.assign("valMat", countsMatrix);
        rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

        rcon.voidEval(strPrefix + "<-data.frame(valMat);");
        // rcon.voidEval("m1 <- zerotrunc(valMat[,1] ~ valMat[,2] + valMat[,3] + valMat[,4] +valMat[,5] +valMat[,6], dist=\"negbin\")");
        String dataFrameNames;
        sb.delete(0, sb.length());
        if (noExplanatoryVar) {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\"");
        } else {
            sb.append("colnames(").append(strPrefix).append(") <- c(\"DepVarScore\",\"IndepVar\"");
        }
        int orgScoreNum = scoreHeads.size() - addedCovNum;
        for (int i = 0; i < orgScoreNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i)).append("\"");
        }

        if (needInteraction) {
            for (int i = 0; i < orgScoreNum; i++) {
                for (int j = i + 1; j < orgScoreNum; j++) {
                    sb.append(",\"").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j)).append("\"");
                }
            }
        }

        for (int i = 0; i < addedCovNum; i++) {
            sb.append(",\"").append(scoreHeads.get(i + orgScoreNum)).append("\"");
        }
        if (geneControlVarScoreIndex >= 0) {
            sb.append(",\"CtrlVarScore\"");
        }
        sb.append(")");
        dataFrameNames = sb.toString();

        // System.out.println(sb);
        rcon.voidEval(sb.toString());
        if (usingLog) {
            rcon.voidEval(strPrefix + "[" + strPrefix + " <=0] <- 1E-6");
            rcon.voidEval("len<-dim(" + strPrefix + ")[2]");
            rcon.voidEval(strPrefix + "[,seq(2,len)] <- log(" + strPrefix + "[,seq(2,len)])");
            // rcon.voidEval(strPrefix + "[,seq(len,len)] <- log(" + strPrefix + "[,seq(len,len)])");
        }

        sb.delete(0, sb.length());
        int orgScoreHeadSize = scoreHeads.size() - addedCovNum;

        //dist = c("poisson", "negbin", "geometric")
        //zerotrunc  dist
        if (noExplanatoryVar) {
            sb.append("m1 <- zerotrunc(DepVarScore ~ ");
            sb.append(scoreHeads.get(0));
            for (int i = 1; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }
        } else {
            sb.append("m1 <- zerotrunc(DepVarScore ~ IndepVar ");
            for (int i = 0; i < orgScoreNum; i++) {
                sb.append("+").append(scoreHeads.get(i));
            }

        }

        //sb.append("m1 <- glm(DepVarScore ~ IndepVar + AvgRegionLen");
        if (needInteraction) {
            for (int i = 0; i < orgScoreHeadSize; i++) {
                for (int j = i + 1; j < orgScoreHeadSize; j++) {
                    sb.append("+").append(scoreHeads.get(i)).append("_").append(scoreHeads.get(j));

                }
            }
        }
        for (int i = 0; i < addedCovNum; i++) {
            sb.append("+").append(scoreHeads.get(i + orgScoreNum));
        }

        if (geneControlVarScoreIndex >= 0) {
            sb.append("+ CtrlVarScore");
        }

        // sb.append(", data = ").append(strPrefix).append(",family=\"poisson\")");
        // sb.append(", data = ").append(strPrefix).append(", dist=\"negbin\")");
        sb.append(", data = ").append(strPrefix).append(", dist=\"negbin-extended\", truncPoint=" + trunc + ")");

        double[] residueCounter = null;
        try {
            //System.out.println(sb);
            rcon.voidEval(sb.toString());

            //  System.out.println(sb);
//            String logTxt = rcon.eval("summarySimple.zerotrunc(m1)").asString(); //
//            System.out.println(logTxt);
            // double[] residueCounter = rcon.eval("resid(m1,\"pearson\")").asDoubles();
            // double[] residueCounter = rcon.eval("residuals(m1,type = \"deviance\")").asDoubles();
            if (orgCountsMatrix != null) {
                geneSize = orgCountsMatrix.length / colNum;
                strPrefix = "genemutetest" + threadID;
                rcon.assign("valMat", orgCountsMatrix);
                rcon.voidEval("valMat<-matrix(valMat, nrow=" + geneSize + ", ncol=" + colNum + ", byrow = TRUE)");

                rcon.voidEval(strPrefix + "<-data.frame(valMat);");
                 
                rcon.voidEval(dataFrameNames);
                residueCounter = rcon.eval("residuals.zrnbFull(m1, " + strPrefix + ", truncPoint=" + trunc + ")").asDoubles();
            } else {
                residueCounter = rcon.eval("residuals(m1,type = \"deviance\", truncPoint=" + trunc + ")").asDoubles();
            }
        } catch (RserveException ex) {

//            BufferedWriter bw = new BufferedWriter(new FileWriter("testS.txt"));
//            bw.write("DepVarScore	RegionLength	EAS	RegionLengthEAS	oe_mis	oe_lof	ExonGC	CtrlVarScore\n");
//
//            for (int j = 0; j < geneSize; j++) {
//                bw.write(String.valueOf(countsMatrix[j * colNum]));
//                for (int i = 1; i < colNum; i++) {
//                    bw.write("\t");
//                    bw.write(String.valueOf(countsMatrix[j * colNum + i]));
//                }
//                bw.write("\n");
//            }
//            bw.close();
//            ex.printStackTrace();
        }
        return residueCounter;
    }

}
