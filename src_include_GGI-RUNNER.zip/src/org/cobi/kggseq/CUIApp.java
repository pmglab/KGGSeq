/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.FloatArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import htsjdk.samtools.util.BlockCompressedOutputStream;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPOutputStream;
import javax.swing.JFrame;

import org.apache.log4j.Logger;
import static org.cobi.kggseq.Constants.VAR_FEATURE_NAMES;

import org.cobi.bayes.Bayes;
import static org.cobi.kggseq.GlobalManager.PLUGIN_PATH;
import org.cobi.kggseq.controller.BinaryGtyProcessor;
import org.cobi.kggseq.controller.CandidateGeneExtender;
import org.cobi.kggseq.controller.GeneAnnotator;
import org.cobi.kggseq.controller.GeneRegionParser;
import org.cobi.kggseq.controller.GeneSetExplorer;
import org.cobi.kggseq.controller.LinkageFileParser;
import org.cobi.kggseq.controller.PileupFormatParser;
import org.cobi.kggseq.controller.SimpleFormatParser;
import org.cobi.kggseq.controller.VariantAnnotator;
import org.cobi.kggseq.controller.VariantFilter;
import org.cobi.kggseq.dialog.PlotShowFrame;
import org.cobi.kggseq.entity.AnnotationSummarySet;
import org.cobi.kggseq.entity.CNVRegionParser;
import org.cobi.kggseq.entity.Chromosome;
import org.cobi.kggseq.entity.CombOrderComparator;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.FiltrationSummarySet;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.Individual;
import org.cobi.kggseq.entity.PPIGraph;
import org.cobi.kggseq.entity.GeneSet;
import org.cobi.kggseq.entity.ReferenceGenome;
import org.cobi.kggseq.entity.RegressionParams;
import org.cobi.kggseq.entity.Variant;
import org.cobi.kggseq.controller.Phenolyzer;
import org.cobi.kggseq.controller.RVTest;
import org.cobi.kggseq.controller.SKAT;
import org.cobi.kggseq.controller.SequenceRetriever;
import org.cobi.kggseq.controller.VCFParserFast;
import org.cobi.kggseq.entity.RefGene;
import org.cobi.kggseq.entity.ReferenceGenome;
import org.cobi.randomforests.MyRandomForest;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.net.NetUtils;
import org.cobi.util.plot.HistogramPainter;
import org.cobi.util.plot.PValuePainter;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.text.LocalExcelFile;
import org.cobi.util.text.LocalFile;
import org.cobi.util.text.Util;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

/**
 *
 * @author mxli
 */
public class CUIApp implements Constants {

    Options options;
    private static final Logger LOG = Logger.getLogger(CUIApp.class);

    public CUIApp(Options options) throws Exception {
        this.options = options;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String headInfor = "@----------------------------------------------------------@\n" + "|        " + PREL + "        |     v" + PVERSION + "     |   " + PDATE + "     |\n"
                + "|----------------------------------------------------------|\n" + "|  (C) 2011 Miaoxin Li,  limx54@gmail.com                  |\n"
                + "|----------------------------------------------------------|\n" + "|  For documentation, citation & bug-report instructions:  |\n"
                + "|              http://grass.cgs.hku.hk/kggseq              |\n" + "@----------------------------------------------------------@";

        long time = System.nanoTime();
        Options option = new Options();
        try {
            if (args.length == 1 && !args[0].startsWith("--")) {
                option.readOptions(args[0]);
            } else if (args.length >= 1) {
                option.readOptions(args);
            } else {
                System.out.println("Usage: java -Xmx1g -jar kggseq.jar param.txt\n Or:  java -Xmx1g -jar kggseq.jar [options] ...");
                return;
            }

            String param = option.parseOptions();
            // System.out.println(headInfor);
            LOG.info("\n" + headInfor + "\nEffective settings :\n" + param);
            GlobalManager.detectOS();
            // final int INIT_PROBLEM = 0, WINDOWS = 1, UNIX = 2, POSIX_UNIX = 3, OTHER = 4;
            if (GlobalManager.osCode != 2) {
                if (option.rvtestGene || option.rvtestGeneset || option.rvtestVar) {
                    String infor = "Sorry, association analysis by RVTests can only run on Unix or Linux Or Mac OS!";
                    LOG.fatal(infor);
                    TimeUnit.SECONDS.sleep(1);
//                    System.exit(1);
                }
                if (option.phenolyzer) {
                    String infor = "Sorry, \'--phenolyzer-prediction\' can only run on Unix or Linux Or Mac OS!";
                    LOG.fatal(infor);
                    TimeUnit.SECONDS.sleep(1);
                    System.exit(1);
                }
            }

            GlobalManager.initiateVariables(option.refGenomeVersion, GlobalManager.osCode, option.resourceFolder, option.maxGtyAlleleNum);
            if (option.needRconnection) {
                RConnection rcon = null;
                try {

                    String[] packges = {"MASS", "mvtnorm", "tmvtnorm", "SKAT", "snow", "stats"};
                    System.out.println("You may have to install the following R packages by the script in R interactive interface by your system administrators:");
                    for (String pack : packges) {
                        System.out.println("  install.packages('" + pack + "', dep=TRUE,repos='http://cran.us.r-project.org')");
                    }

                    System.out.println("  install.packages('countreg', dep=TRUE,repos='http://R-Forge.R-project.org')");
                    System.out.println("  install.packages(\"Rserve\", \"Rserve_1.8-6.tgz\", \"http://www.rforge.net/\")");

                    rcon = new RConnection();
                } catch (RserveException | NoSuchMethodError ex) {
                    //RserveException
                    if (ex.getMessage().contains("Cannot connect") || ex.getMessage().contains("REngine")) {

                        // System.out.println(ex.getMessage() + "\t" +
                        // ex.getRequestReturnCode() + "\t" +
                        // ex.getRequestErrorDescription());
                        String infor = "Please open your R and type the following commands to allow kggseq to use it:\npack=\"Rserve\";\n"
                                + "if (!require(pack,character.only = TRUE, quietly = TRUE))   { install.packages(pack,dep=TRUE,repos=\'http://cran.us.r-project.org\');   if(!require(pack,character.only = TRUE)) stop(\"Package not found\")   }\n"
                                + "library(\"Rserve\");\nRserve(debug = FALSE, port = 6311, args = NULL)\n"
                                + "\nOR type this command without openning your R: \nR CMD Rserve";
                        //Or  R CMD Rserve

                        LOG.fatal(infor);
                        TimeUnit.SECONDS.sleep(1);
                    }
                    System.exit(1);
                } finally {
                    if (rcon != null) {
                        rcon.close();
                    }
                }
            }

            if (option.needInternetChecking) {
                GlobalManager.checkConnection();
                if (!option.noLibCheck) {
                    if (GlobalManager.isConnectInternet) {
                        if (NetUtils.checkLibFileVersion(option.libUpdate)) {
                            return;
                        } else if (args.length == 1 && args[0].equals("--lib-update")) {
                            String infor = "Your KGGSeq has already been the latest version!";
                            System.out.println(infor);
                            return;
                        }
                    }
                }

                if (GlobalManager.isConnectInternet) {
                    if (option.phenolyzer) {
                        String strURL = "https://github.com/WGLab/phenolyzer/archive/master.zip";
                        NetUtils.checkInstallPhenolyzer(strURL, new File(PLUGIN_PATH + "phenolyzer-master.zip"), option.libUpdate);
                    }

                    if (option.rvtestGene || option.rvtestGeneset || option.rvtestVar) {
                        boolean needMake1 = false, needMake2 = false;
                        String strURL;
                        /*
                      strURL = "https://github.com/samtools/tabix/archive/master.zip";
                    needMake1 = NetUtils.checkInstallCpp(strURL, new File(PLUGIN_PATH + "tabix-master.zip"));
                         */

                        strURL = "https://github.com/zhanxw/rvtests/archive/master.zip";
                        needMake2 = NetUtils.checkInstallCpp(strURL, new File(PLUGIN_PATH + "rvtests-master.zip"), option.libUpdate);
                        if (needMake1 || needMake2) {
                            System.exit(1);
                        }
                    }
                }

                if (option.resCheck) {
                    if (GlobalManager.isConnectInternet) {
                        NetUtils.checkLatestResource(option);
                    }
                } else if (GlobalManager.isConnectInternet) {
                    // must check avaible resources
                    NetUtils.checkResourceList(option);
                }
            }

            CUIApp main = new CUIApp(option);
            File tmpFloder = new File(option.outputFileName + "KGGSeqTMP");
            tmpFloder.mkdirs();
            System.setProperty("java.io.tmpdir", tmpFloder.getCanonicalPath());

            main.process();

            LocalFileFunc.delAll(tmpFloder);

            if (option.hasTmpPedFile) {
                File f = new File(option.pedFile);
                f.delete();
            }
            time = System.nanoTime() - time;
            time = time / 1000000000;
            long min = time / 60;
            long sec = time % 60;
            LOG.info("Elapsed time: " + min + " min. " + sec + " sec.");
            if (option.needLog) {
                String info = "The log information is saved in " + option.outputFileName + ".log" + "\n\n";
                LOG.info(info);
            }
//            LOG.info("\n\n");
            Toolkit.getDefaultToolkit().beep();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void showPlots(final File[] plotFiles) {
        if (!GraphicsEnvironment.isHeadless()) {
            java.awt.EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    PlotShowFrame psf = new PlotShowFrame();
                    psf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    for (final File file : plotFiles) {
                        if (file == null) {
                            continue;
                        }
                        psf.insertImage2PlottingPane(file);
                    }
                    psf.setVisible(true);
                }
            });
        } else {
            String info = "But no avaible graphics environment to present the figure(s) here!";
            LOG.info(info);
        }
    }

    public void process() throws Exception {
        Genome uniqueGenome = null;
        Set<String> caseSet = null;
        Set<String> controlSet = null;
        Set<String> unkownSet = null;
        List<Individual> subjectList = new ArrayList<Individual>();
        int[] caeSetID = new int[0], controlSetID = new int[0];
        int[] pedEncodeGytIDMap = null;
        boolean needGty = false;
        File finalFilteredInFile = null;
        GeneAnnotator geneAnnotor = new GeneAnnotator();
        boolean hasControls = false;

        IntArrayList allEffectIndivIDs = new IntArrayList();
        VCFParserFast vsParser = new VCFParserFast();
        // OpenLongObjectHashMap wahBit = null;
        //OpenLongObjectHashMap wahBitGeneset = new OpenLongObjectHashMap();
        int maxEffectiveColVCF;
        boolean[] origionallySorted = new boolean[1];
        int[] maxThreadID = new int[1];
        boolean hasChrLabel;

        //  VCFParserFast vsParser = new VCFParserFast();
        //  VCFParser vsParser = new VCFParser();
        try {
            String geneSetDBAnaFile = null;
            Map<String, GeneSet> dbPathwaySet = null;
            if (options.geneSetDB != null) {
                geneSetDBAnaFile = options.PUBDB_FILE_MAP.get(options.geneSetDB);
                geneSetDBAnaFile = GlobalManager.RESOURCE_PATH + "/" + geneSetDBAnaFile;
                GeneSetExplorer genesetExplor = new GeneSetExplorer(geneSetDBAnaFile);
                genesetExplor.loadGSEAGeneSets(options.genesetSizeMin, options.genesetSizeMax);
                dbPathwaySet = genesetExplor.getGeneSetSet();
            } else if (options.geneSetTestFile != null) {
                geneSetDBAnaFile = options.geneSetTestFile;
                GeneSetExplorer genesetExplor = new GeneSetExplorer(geneSetDBAnaFile);
                genesetExplor.loadGSEAGeneSets(options.genesetSizeMin, options.genesetSizeMax);
                dbPathwaySet = genesetExplor.getGeneSetSet();
            }

            if (!options.scoreDBLableList.isEmpty()) {
                for (String dbLabelName : options.scoreDBLableList) {
                    if (dbLabelName.equals("dbncfp_all")) {
                        String annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_all_SNV_dbNCFP.gz";
                        File annFile = new File(annNCFPPath);
                        if (!annFile.exists()) {
                            String infor = "The resource file " + annFile.getCanonicalPath() + " does not exist! Please manually download the file from ftp://jjwanglab.org/MX/score/ANN/" + annFile.getName() + " by efficient tools (e.g. FileZilla).";
                            throw new Exception(infor);
                        }
                        //Very RAM comsumming part, we do it at the very begining 
                        BGZFInputStream bfIndexes = new BGZFInputStream(annFile.getCanonicalPath(), options.threadNum, true);
                        if (!bfIndexes.checkIndex()) {
                            LOG.info("Building index file for " + annFile.getName() + ". It may take a while ...");
                            bfIndexes.adjustPos();
                            bfIndexes.buildIndex(annFile.getCanonicalPath(), 0, 1, false);
                        }
                    }
                }
            }

            Map<String, List<Variant>> genesetVars = new HashMap<String, List<Variant>>();
            //assigne variants into genes and pathways
            Map<String, List<Variant>> geneVars = new HashMap<String, List<Variant>>();
            Map<String, double[]> allDoubleHitGeneScoresMap = new HashMap<String, double[]>();
            Map<String, double[]> chromDoubleHitGeneScoresMap = null;
            boolean[] hasGty = new boolean[1];
            if (options.command != null && options.command.endsWith("--make-filter")) {
                // a special function to more efficiently generate reference
                // variants as filters in the future
                // --make-filter --no-gty-vcf-file
                // ESP5400.snps.vcf/ESP5400.chr_CHROM_.snps.vcf --buildver-in hg19
                // --out hg19_ESP5400.snps.txt --buildver-out hg19
                if (options.inputFormat.equals("--no-gty-vcf-file") || options.inputFormat.equals("--vcf-file")) {
                    uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                            options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                            options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, -9, -9, -9, -9, -9, -9, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                            options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, false, false, false, false, false, false, null, null, null, null, null, null, options.groupTags, hasGty);

                    File localFileFiler = new File(options.outputFileName + ".kggseq.filter.txt");
                    LOG.info("Prepare annotation resources from local VCF file(s)...");
                    // altLocalFilterFiles.add(localFileFiler);
                    // gtyCorrdiates used to keep the sequential order
                    BufferedWriter annovarFilteredInFileWriter = null;
                    if (options.outGZ) {
                        GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                        annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                    } else {
                        annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                    }
                    Chromosome[] chromosomes = uniqueGenome.getChromosomes();

                    for (int chromID = 0; chromID < chromosomes.length; chromID++) {
                        uniqueGenome.loadVariantFromDisk(chromID, false, origionallySorted, maxThreadID);
                        List<Variant> chromosomeVar = chromosomes[chromID].variantList;
                        if (chromosomeVar == null || chromosomeVar.isEmpty()) {
                            continue;
                        }
                        uniqueGenome.export2ANNOVARAnnot(annovarFilteredInFileWriter, chromID);
                        chromosomes[chromID].variantList.clear();
                    }
                    annovarFilteredInFileWriter.close();
                    uniqueGenome.removeTempFileFromDisk();
                    String infor = "The VCF filtration data have been converted into a standard filtration dataset of kggseq, "
                            + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                            + " \', which is faster!\n\n";
                    LOG.info(infor);

                } else {
                    String infor = "Sorry, --make-filter currently only supports VCF format! Please specify it by \'--vcf-file path/to/file\'";
                    throw new Exception(infor);
                }
                return;
            }

            if (options.localFilterVCFFileNames != null || options.localHardFilterVCFFileNames != null) {
                List<String> allFiles = new ArrayList<String>();
                if (options.localFilterVCFFileNames != null) {
                    allFiles.addAll(Arrays.asList(options.localFilterVCFFileNames));
                }
                if (options.localHardFilterVCFFileNames != null) {
                    allFiles.addAll(Arrays.asList(options.localHardFilterVCFFileNames));
                }
                for (String localFilterFileName : allFiles) {
                    File localFileFiler = new File(localFilterFileName + ".kggseq.filter.txt");
                    LOG.info("Prepare annotation resources from local VCF file(s)...");
                    // altLocalFilterFiles.add(localFileFiler);
                    // gtyCorrdiates used to keep the sequential order
                    uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName + File.separator + localFileFiler.getName(), options.threadNum, null, localFilterFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                            options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                            options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, -9, -9, -9, -9, -9, -9, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                            options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, false, false, false, false, false, false, null, null, null, null, null, null, options.groupTags, hasGty);

                    BufferedWriter annovarFilteredInFileWriter = null;
                    if (options.outGZ) {
                        GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                        annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                    } else {
                        annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                    }
                    Chromosome[] chromosomes = uniqueGenome.getChromosomes();
                    for (int chromID = 0; chromID < chromosomes.length; chromID++) {
                        uniqueGenome.loadVariantFromDisk(chromID, false, origionallySorted, maxThreadID);
                        List<Variant> chromosomeVar = chromosomes[chromID].variantList;
                        if (chromosomeVar == null || chromosomeVar.isEmpty()) {
                            continue;
                        }
                        uniqueGenome.export2ANNOVARAnnot(annovarFilteredInFileWriter, chromID);
                        chromosomes[chromID].variantList.clear();
                    }
                    annovarFilteredInFileWriter.close();
                    uniqueGenome.removeTempFileFromDisk();
                    String infor = "The VCF filtration data " + localFilterFileName + " have been converted into a standard filtration dataset of kggseq, "
                            + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                            + " \', which is faster!\n\n";
                    LOG.info(infor);
                    //  varFilter.markByANNOVARefFormat(uniqueGenome, localFileFiler.getCanonicalPath(), localFileFiler.getName(), options.needProgressionIndicator);
                }
            }

            if (options.localHardFilterNoGtyVCFFileNames != null || options.localFilterNoGtyVCFFileNames != null) {//To be discussed. 
                List<String> allFiles = new ArrayList<String>();
                if (options.localFilterNoGtyVCFFileNames != null) {
                    allFiles.addAll(Arrays.asList(options.localFilterNoGtyVCFFileNames));
                }
                if (options.localHardFilterNoGtyVCFFileNames != null) {
                    allFiles.addAll(Arrays.asList(options.localHardFilterNoGtyVCFFileNames));
                }
                for (String localFilterFileName : allFiles) {
                    File localFileFiler = new File(localFilterFileName + ".kggseq.filter.txt");
                    LOG.info("Prepare annotation resources from local VCF file(s) with no genotype ...");
                    //  altLocalFilterFiles.add(localFileFiler);
                    // gtyCorrdiates used to keep the sequential order
                    uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName + File.separator + localFileFiler.getName(), options.threadNum, null, localFilterFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                            options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                            options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                            options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, false, options.isVCFOut || options.isVCFOutFilterd, options.isSimpleVCFOut || options.isVCFOut || options.isVCFOutFilterd, true, options.forced2Unphased, subjectList, allEffectIndivIDs, null, null,
                            options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);

                    BufferedWriter annovarFilteredInFileWriter = null;
                    if (options.outGZ) {
                        GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                        annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                    } else {
                        annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                    }
                    Chromosome[] chromosomes = uniqueGenome.getChromosomes();
                    for (int chromID = 0; chromID < chromosomes.length; chromID++) {
                        uniqueGenome.loadVariantFromDisk(chromID, false, origionallySorted, maxThreadID);
                        List<Variant> chromosomeVar = chromosomes[chromID].variantList;
                        if (chromosomeVar == null || chromosomeVar.isEmpty()) {
                            continue;
                        }
                        uniqueGenome.export2ANNOVARAnnot(annovarFilteredInFileWriter, chromID);

                        chromosomes[chromID].variantList.clear();
                    }
                    annovarFilteredInFileWriter.close();
                    uniqueGenome.removeTempFileFromDisk();
                    String infor = "The VCF filtration data " + localFilterFileName + " have been converted into a standard filtration dataset of kggseq, "
                            + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                            + " \', which is faster!\n\n";
                    LOG.info(infor);
                    //  varFilter.markByANNOVARefFormat(uniqueGenome, localFileFiler.getCanonicalPath(), localFileFiler.getName(), options.needProgressionIndicator);
                }
            }

            if (options.inputFormat.endsWith("--vcf-file")) {
                // if pedigree file is specified options.indivPhenos will be
                // ignored
                if (options.pedFile != null) {
                    LinkageFileParser linkPedParser = new LinkageFileParser();
                    linkPedParser.readPedigreeOnly(options.pedFile, subjectList, options.useCompositeSubjectID, options.phenotypeColID, options.pheItem);
                    caseSet = new HashSet<String>();
                    controlSet = new HashSet<String>();
                    unkownSet = new HashSet<String>();

                    for (Individual indiv : subjectList) {
                        switch (indiv.getAffectedStatus()) {
                            case 1:
                                controlSet.add(indiv.getLabelInChip());
                                break;
                            case 2:
                                caseSet.add(indiv.getLabelInChip());
                                break;
                            default:
                                unkownSet.add(indiv.getLabelInChip());
                                break;
                        }
                    }
                } /*
                 * else if
                 * (options.genetModel.equals("--compound-heterozygosity")
                 * && options.pedFile == null) { throw new Exception(
                 * "Please sepcify the relationship of subjects  by \'--ped-file path/to/pedigree/file\' for compound heterozygosity model checking!"
                 * ); }
                 */ else if (options.indivPhenos != null) {
                    caseSet = new HashSet<String>();
                    controlSet = new HashSet<String>();
                    unkownSet = new HashSet<String>();
                    for (String indivID : options.indivPhenos) {
                        String label = indivID.substring(0, indivID.indexOf(':'));
                        String d = indivID.substring(indivID.indexOf(":") + 1);
                        Individual indiv = new Individual();
                        switch (d.charAt(0)) {
                            case '1':
                                controlSet.add(label);
                                break;
                            case '2':
                                caseSet.add(label);
                                break;
                            default:
                                unkownSet.add(label);
                                break;
                        }
                        indiv.setLabelInChip(label);
                        indiv.setFamilyID(label);
                        indiv.setIndividualID(label);
                        indiv.setDadID("0");
                        indiv.setMomID("0");
                        indiv.setAffectedStatus(d.charAt(0) - '0');
                        subjectList.add(indiv);
                        double[] traits = new double[1];
                        traits[0] = indiv.getAffectedStatus();
                        indiv.setTraits(traits);
                    }
                }
                if (options.varAssoc) {
                    if (caseSet.isEmpty() || controlSet.isEmpty()) {
                        String infor = ("Sorry, the option of '--var-assoc' only works for case/control sample!");
                        throw new Exception(infor);
                    }
                }
                if (options.pedFile != null || options.indivPhenos != null) {
                    if (caseSet.isEmpty() && controlSet.isEmpty()) {
                        String infor = ("All subjects in phenotype or pedigree file have unknown disease status.\n"
                                + "    Please specify the clear disease status for AT LEAST one subject!!");
                        // throw new Exception(infor);
                    }
                }

                if (options.isPlinkPedOut || options.isPlinkBedOut || options.isBinaryGtyOut || options.isSimpleVCFOut || options.calcLD || options.ldPruning) {
                    needGty = true;
                } else if (options.sampleGtyHardFilterCode != null) {
                    for (int i = 0; i < 9; i++) {
                        if (options.sampleGtyHardFilterCode.contains(String.valueOf(i))) {
                            needGty = true;
                            break;
                        }
                    }
                } else if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
                    needGty = true;
                } else if (options.doubleHitGenePhasedFilter || options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
                    needGty = true;
                } else if (options.skatGene || options.skatGeneset || (dbPathwaySet != null && !dbPathwaySet.isEmpty())) {
                    needGty = true;
                } else if (options.overlappedGeneFilter) {
                    needGty = true;
                } else if (options.contextAnnotGFDis > 0) {
                    needGty = true;
                }

                boolean needReadsInfor = false;
                // options.sampleVarHardFilterCode
                if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("7") || options.sampleGtyHardFilterCode.contains("8"))) {
                    needReadsInfor = true;
                }
                pedEncodeGytIDMap = new int[subjectList.size()];
                int sizeIndiv = subjectList.size();
                IntArrayList caeSetID1 = new IntArrayList();
                IntArrayList controlSetID1 = new IntArrayList();
                for (int i = 0; i < sizeIndiv; i++) {
                    if (subjectList.get(i).getAffectedStatus() == 2) {
                        caeSetID1.add(i);
                    } else if (subjectList.get(i).getAffectedStatus() == 1) {
                        controlSetID1.add(i);
                    }
                }
                if (!caeSetID1.isEmpty()) {
                    caeSetID = new int[caeSetID1.size()];
                    for (int i = 0; i < caeSetID.length; i++) {
                        caeSetID[i] = caeSetID1.getQuick(i);
                    }
                }

                if (!controlSetID1.isEmpty()) {
                    controlSetID = new int[controlSetID1.size()];
                    for (int i = 0; i < controlSetID.length; i++) {
                        controlSetID[i] = controlSetID1.getQuick(i);
                    }
                }

                // gtyCorrdiates used to keep the sequential order
                uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                        options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, needReadsInfor, options.isVCFOut || options.isVCFOutFilterd, options.isSimpleVCFOut || options.isVCFOut || options.isVCFOutFilterd, false, options.forced2Unphased, subjectList, allEffectIndivIDs,
                        caeSetID, controlSetID, options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);
                pedEncodeGytIDMap = vsParser.getPedEncodeGytIDMap();
                /*
                 * if (!subjectMap.isEmpty()) { FileOutputStream objFOut =
                 * new FileOutputStream(outName + ".gty.obj");
                 * BufferedOutputStream objOBfs = new
                 * BufferedOutputStream(objFOut); ObjectOutputStream
                 * localObjOut = new ObjectOutputStream(objOBfs);
                 * 
                 * localObjOut.writeObject(subjectMap); localObjOut.flush();
                 * localObjOut.close(); objOBfs.flush(); objOBfs.close();
                 * objFOut.close(); }
                 */
            } else if (options.inputFormat.endsWith("--maf-file")) {
                SimpleFormatParser pileParser = new SimpleFormatParser();
                uniqueGenome = pileParser.readCancerGenomeVariantFormat(options.outputFileName, options.inputFileName, options.needProgressionIndicator);
            } else if (options.inputFormat.endsWith("--no-gty-vcf-file")) {
                // gtyCorrdiates used to keep the sequential order
                uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                        options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, false, false, false, true, options.forced2Unphased, subjectList, allEffectIndivIDs, null, null, options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);
            } else if (options.inputFormat.endsWith("--ked-file")) {
                BinaryGtyProcessor bgp = new BinaryGtyProcessor(options.inputFileName);
                bgp.readPedigreeFile(subjectList);
                int[] counts = new int[3];
                Arrays.fill(counts, 0);
                uniqueGenome = bgp.readVariantsMapFile(counts);

                caseSet = new HashSet<String>();
                controlSet = new HashSet<String>();
                unkownSet = new HashSet<String>();
                //In the out put of ked, the genotypes are filled according to the order of subjects in the pedigree file
                pedEncodeGytIDMap = new int[subjectList.size()];
                for (int i = 0; i < pedEncodeGytIDMap.length; i++) {
                    pedEncodeGytIDMap[i] = i;
                }
                for (Individual indiv : subjectList) {
                    indiv.setHasGenotypes(true);
                    if (indiv.getAffectedStatus() == 1) {
                        controlSet.add(indiv.getLabelInChip());
                    } else if (indiv.getAffectedStatus() == 2) {
                        caseSet.add(indiv.getLabelInChip());
                    }
                }
                if (options.isPlinkPedOut || options.isPlinkBedOut || options.isBinaryGtyOut || options.isSimpleVCFOut) {
                    needGty = true;
                } else if (options.sampleGtyHardFilterCode != null) {
                    for (int i = 0; i < 9; i++) {
                        if (options.sampleGtyHardFilterCode.contains(String.valueOf(i))) {
                            needGty = true;
                            break;
                        }
                    }
                } else if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
                    needGty = true;
                } else if (options.doubleHitGenePhasedFilter || options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
                    needGty = true;
                } else if (options.contextAnnotGFDis > 0) {
                    needGty = true;
                }

                StringBuilder message = null;
                if (needGty) {
                    message = bgp.readBinaryGenotype(subjectList, uniqueGenome, options.minOBS, options.maxGtyAlleleNum, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel);
                }

                // subject to do something more
                String info = counts[0] + " variant-lines (" + counts[2] + " indels) are scanned in " + options.inputFileName + "; and " + counts[1] + " variants of " + subjectList.size() + " individual(s) are retained for further analysis.";
                LOG.info(message.append(info).append("\n------------------------------------------------------------\n"));
                LOG.info(info);
                uniqueGenome.writeChromsomeToDiskClean();
            } else if (options.inputFormat.endsWith("--annovar-file")) {
                PileupFormatParser pileParser = new PileupFormatParser();
                uniqueGenome = pileParser.readVariantAnnovarFormat(options.inputFileName, options.outputFileName, options.needProgressionIndicator);
                uniqueGenome.writeChromsomeToDiskClean();
            } else if (options.inputFormat.endsWith("--simple-file")) {
                PileupFormatParser pileParser = new PileupFormatParser();
                uniqueGenome = pileParser.readVariantAnnovarFormatSimple(options.inputFileName, options.outputFileName, options.needProgressionIndicator);
                uniqueGenome.writeChromsomeToDiskClean();
            }
            maxEffectiveColVCF = vsParser.getMaxEffectiveColVCF();
            hasChrLabel = vsParser.isHasChrLabel();
            if (controlSetID.length > 0) {
                hasControls = true;
            }
            //-----------------------Annotate variants on each chromsome-------------------------------

            VariantAnnotator varAnnoter = new VariantAnnotator();
            VariantFilter varFilter = new VariantFilter();
            FiltrationSummarySet minMissingQCFilter1 = new FiltrationSummarySet("missingQC", uniqueGenome.getVariantFeatureNum());
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of heterozygous genotypes <" + options.minHetA
                    + " or that of alternative homozygous genotypes <" + options.minHomA + " in cases.");

            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of heterozygous genotypes <" + options.minHetU
                    + " or that of alternative homozygous genotypes <" + options.minHomU + " in controls.");
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of non-null genotypes in cases <" + options.minOBSA + ".");
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of non-null genotypes in controls <" + options.minOBSU + ".");
            minMissingQCFilter1.initiateAMessage(0, "variant(s) are left after filtration according to minimal successful genotype calling rates in patients and healthy individuals.");

            int filterNum = 6;
            boolean[] uniqueFilters = new boolean[2];
            boolean[] genotypeFilters = new boolean[filterNum];
            Arrays.fill(uniqueFilters, false);
            Arrays.fill(genotypeFilters, false);
            boolean filterByModel = false;
            FiltrationSummarySet inheritanceModelFilter2 = null;
            FiltrationSummarySet denovoModelFilter3 = null;
            FiltrationSummarySet doubleHitGeneModelFilter19 = null;
            FiltrationSummarySet doubleHitGeneModelFilter19d1 = null;
            FiltrationSummarySet somaticModelFilter4 = null;
            List<int[]> setSampleIDList = null;
            List<String> setSampleLabelList = new ArrayList<String>();
            String currentLine;

//            AnnotationSummarySet assLFF1=null;
//            if(altLocalFilterFiles!=null && !altLocalFilterFiles.isEmpty()){
//                assLFF1=new AnnotationSummarySet("LocalFileFilter",null,null,0,0,0,uniqueGenome.getVariantFeatureNum());               
//            }
            String hardFilterModel = options.sampleGtyHardFilterCode;
            if (options.sampleGtyHardFilterCode != null && options.sampleGtyHardFilterCode.length() > 0) {
                for (int i = 0; i < filterNum; i++) {
                    String[] cells = options.sampleGtyHardFilterCode.split(",");
                    for (int t = 0; t < cells.length; t++) {
                        int s = Integer.parseInt(cells[t]) - 1;
                        if (s < filterNum) {
                            genotypeFilters[s] = true;
                            filterByModel = true;
                        }
                    }
                }
                //the de novel mutation filltering will be processed seperately
                if (hardFilterModel.indexOf('7') >= 0) {
                    String[] cells = options.sampleGtyHardFilterCode.split(",");
                    hardFilterModel = "";
                    for (String s : cells) {
                        if (s.equals("7")) {
                            continue;
                        }
                        hardFilterModel += s;
                        hardFilterModel += ",";
                    }
                    if (hardFilterModel.length() > 0) {
                        hardFilterModel = hardFilterModel.substring(0, hardFilterModel.length() - 1);
                    }
                }
            }

            if (filterByModel) {
                inheritanceModelFilter2 = new FiltrationSummarySet("InheritanceModel", uniqueGenome.getVariantFeatureNum());
                inheritanceModelFilter2.initiateAMessage(0, "variants are ignored by genotype-based hard-filtering.");
                inheritanceModelFilter2.initiateAMessage(0, "variant(s) are left after filtration according to inheritance mode at genotypes, " + hardFilterModel + ".");
            }

            if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("7"))) {
                denovoModelFilter3 = new FiltrationSummarySet("DenovoModel", uniqueGenome.getVariantFeatureNum());
                setSampleIDList = new ArrayList<int[]>();
                varFilter.matchTrioSet(subjectList, setSampleIDList);
                if (setSampleIDList.isEmpty()) {
                    String infor = "No recognizable trios! To detect de novo mutation, you have to set the parents-child relationsby the tag --ped-file path/to/file!";
                    throw new Exception(infor);
                }
                uniqueGenome.addVariantFeatureLabel("DenovoMutationEvent");
                denovoModelFilter3.initiateAMessage(0, "variant(s) are left after filtration by denovo mutation!");
            }

            if (options.causingNSPredType == 2 || (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8")))) {
                somaticModelFilter4 = new FiltrationSummarySet("SomaticModel", uniqueGenome.getVariantFeatureNum());
            }

            if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8"))) {
                // search somatic mutation between cancer tissue and non-cancer tissues
                if (options.indivPairs == null) {
                    String infor = "To detect somatic mutation, you have to set the tumor sample and non-tumor samples pairs by the tag --indiv-pair tumorIndivID1:normalIndivID1,tumorIndivID2:normalIndivID2";
                    throw new Exception(infor);
                }

                // search somatic mutation between cancer tissue and non-cancer tissues
                // match pairs                
                setSampleIDList = new ArrayList<int[]>();
                varFilter.matchTumorNontumorPair(options.indivPairs, subjectList, setSampleIDList, setSampleLabelList);
                if (setSampleIDList.isEmpty()) {
                    List<String> vcfInds = new ArrayList<String>();
                    List<String> pedIndivs = new ArrayList<String>();
                    for (String pair : options.indivPairs) {
                        String[] invdivs = pair.split(":");
                        vcfInds.add(invdivs[0]);
                        vcfInds.add(invdivs[1]);
                    }

                    for (int t = 0; t < subjectList.size(); t++) {
                        pedIndivs.add(subjectList.get(t).getLabelInChip());
                    }

                    String infor = "No recognizable matched Tumor<->Nontumor pairs!\n"
                            + ("The subject IDs in the specified VCF file(s), " + vcfInds.toString() + " are not indentical to those in the phenotype or pedigree file " + pedIndivs.toString() + "!!");
                    throw new Exception(infor);
                }
                somaticModelFilter4.initiateAMessage(0, "variant(s) are left after filtration by somatic mutations!");
                uniqueGenome.addVariantFeatureLabel("SomaticAltAllele");
                uniqueGenome.addVariantFeatureLabel("TNTRefAltRead,P,OR");
            }

            AnnotationSummarySet assCCUMFV = null;
            if (options.sampleVarHardFilterCode != null) {
                if (options.sampleVarHardFilterCode.equals("case-unique")) {
                    uniqueFilters[0] = true;
                } else if (options.sampleVarHardFilterCode.equals("control-unique")) {
                    uniqueFilters[1] = true;
                }

                if (uniqueFilters[0] || uniqueFilters[1]) {
                    assCCUMFV = new AnnotationSummarySet("casecontrolUniqueModelFilterVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }

            AnnotationSummarySet assHWD = null;
            if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
                assHWD = new AnnotationSummarySet("hwdTestVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            AnnotationSummarySet assSVHF = null;
            DoubleArrayList[] varPArray = null;

            if (options.varAssoc) {
//                List<DoubleArrayList> varPArray = varAnnoter.assocTestVar(uniqueGenome);               
                assSVHF = new AnnotationSummarySet("test filter", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("PValueAllelic");
                uniqueGenome.addVariantFeatureLabel("OddAllelic");
                uniqueGenome.addVariantFeatureLabel("PValueDom");
                uniqueGenome.addVariantFeatureLabel("OddDom");
                uniqueGenome.addVariantFeatureLabel("PValueRec");
                uniqueGenome.addVariantFeatureLabel("OddRec");
                uniqueGenome.addVariantFeatureLabel("PValueGeno");

                varPArray = new DoubleArrayList[4];
                for (int i = 0; i < varPArray.length; i++) {
                    varPArray[i] = new DoubleArrayList();
                }

            }

            AnnotationSummarySet[] varaintDBHardFilterFiles5 = null;
            AnnotationSummarySet[] varaintDBFilterFiles6 = null;
            String[] varaintDBFilterFiles = null;

            int dbFileSize = options.varaintDBLableHardList != null ? options.varaintDBLableHardList.size() : 0;
            if (dbFileSize > 0) {
                varaintDBHardFilterFiles5 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String dbLabelName = options.varaintDBLableHardList.get(i);
                    varaintDBHardFilterFiles5[i] = new AnnotationSummarySet(dbLabelName, LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName)), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }

            dbFileSize = options.varaintDBLableList != null ? options.varaintDBLableList.size() : 0;
            int[][] freqColIndexes = null;
            if (dbFileSize > 0) {
                varaintDBFilterFiles6 = new AnnotationSummarySet[dbFileSize];
                varaintDBFilterFiles = new String[dbFileSize];
                freqColIndexes = new int[dbFileSize][];
                for (int i = 0; i < dbFileSize; i++) {
                    String dbLabelName = options.varaintDBLableList.get(i);
                    if (dbLabelName.startsWith("exac")) {
                        BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("exac"));
                        String rowS = br.readLine();
                        br.close();
                        varaintDBFilterFiles6[i] = new AnnotationSummarySet("exac", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        freqColIndexes[i] = new int[options.exacPopLables.size()];
                        String[] rowSS = rowS.split("\t");
                        for (int k = 0; k < freqColIndexes[i].length; k++) {
                            rowS = options.exacPopLables.get(k);
                            //the populaiton label start at the forth column
                            for (int t = 4; t < rowSS.length; t++) {
                                if (rowS.equals(rowSS[t])) {
                                    freqColIndexes[i][k] = t;
                                    uniqueGenome.addVariantFeatureLabel("altFreq@exac" + rowS);
                                    break;
                                }
                            }
                        }
                        varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("exac");

                    } else if (dbLabelName.startsWith("gadexome")) {
                        BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadexome"));
                        String rowS = br.readLine();
                        br.close();
                        varaintDBFilterFiles6[i] = new AnnotationSummarySet("gnomad.exome", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        freqColIndexes[i] = new int[options.gnomadExomesPopLables.size()];
                        String[] rowSS = rowS.split("\t");
                        for (int k = 0; k < freqColIndexes[i].length; k++) {
                            rowS = options.gnomadExomesPopLables.get(k);
                            //the populaiton label start at the forth column
                            for (int t = 4; t < rowSS.length; t++) {
                                if (rowSS[t].toUpperCase().endsWith(rowS)) {
                                    freqColIndexes[i][k] = t;
                                    uniqueGenome.addVariantFeatureLabel("altFreq@gnomad.exome" + rowS);
                                    break;
                                }
                            }
                        }
                        varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadexome");

                    } else if (dbLabelName.startsWith("gadgenome")) {
                        BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadgenome"));
                        String rowS = br.readLine();
                        br.close();
                        varaintDBFilterFiles6[i] = new AnnotationSummarySet("gnomad.genome", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        freqColIndexes[i] = new int[options.gnomadGenomesPopLables.size()];
                        String[] rowSS = rowS.split("\t");
                        for (int k = 0; k < freqColIndexes[i].length; k++) {
                            rowS = options.gnomadGenomesPopLables.get(k);
                            //the populaiton label start at the forth column
                            for (int t = 4; t < rowSS.length; t++) {
                                if (rowSS[t].toUpperCase().endsWith(rowS)) {
                                    freqColIndexes[i][k] = t;
                                    uniqueGenome.addVariantFeatureLabel("altFreq@gnomad.genome" + rowS);
                                    break;
                                }
                            }
                        }
                        varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadgenome");

                    } else if (dbLabelName.startsWith("ehr")) {
                        varaintDBFilterFiles6[i] = new AnnotationSummarySet("ehr", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        freqColIndexes[i] = new int[1];
                        freqColIndexes[i][0] = 4;
                        uniqueGenome.addVariantFeatureLabel("altFreq@ehr");
                        varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);

                    } else {
                        varaintDBFilterFiles6[i] = new AnnotationSummarySet(dbLabelName, null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        uniqueGenome.addVariantFeatureLabel("altFreq@" + dbLabelName);
                        varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);
                        freqColIndexes[i] = new int[1];
                        freqColIndexes[i][0] = 4;
                    }

                }
            }

            AnnotationSummarySet[] assLocalHardFilterFile5 = null;
            AnnotationSummarySet[] assLocalFilterFile6 = null;

            dbFileSize = options.localHardFilterFileNames != null ? options.localHardFilterFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalHardFilterFile5 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localHardFilterFileNames[i];
                    assLocalHardFilterFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }

            dbFileSize = options.localFilterFileNames != null ? options.localFilterFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalFilterFile6 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localFilterFileNames[i];
                    assLocalFilterFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(strFileName).getName());
                }
            }

            AnnotationSummarySet[] assLocalHardFilterVCFFile5 = null;
            AnnotationSummarySet[] assLocalFilterVCFFile6 = null;

            dbFileSize = options.localHardFilterVCFFileNames != null ? options.localHardFilterVCFFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalHardFilterVCFFile5 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localHardFilterVCFFileNames[i];
                    if (options.outGZ) {
                        strFileName += ".kggseq.filter.txt.gz";
                    } else {
                        strFileName += ".kggseq.filter.txt";
                    }
                    assLocalHardFilterVCFFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }

            dbFileSize = options.localFilterVCFFileNames != null ? options.localFilterVCFFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalFilterVCFFile6 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localFilterVCFFileNames[i];
                    if (options.outGZ) {
                        strFileName += ".kggseq.filter.txt.gz";
                    } else {
                        strFileName += ".kggseq.filter.txt";
                    }
                    assLocalFilterVCFFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(options.localFilterVCFFileNames[i]).getName());
                }
            }

            AnnotationSummarySet[] assLocalHardFilterNoGtyVCFFile5 = null;
            AnnotationSummarySet[] assLocalFilterNoGtyVCFFile6 = null;

            dbFileSize = options.localHardFilterNoGtyVCFFileNames != null ? options.localHardFilterNoGtyVCFFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalHardFilterNoGtyVCFFile5 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localHardFilterNoGtyVCFFileNames[i];
                    if (options.outGZ) {
                        strFileName += ".kggseq.filter.txt.gz";
                    } else {
                        strFileName += ".kggseq.filter.txt";
                    }
                    assLocalHardFilterNoGtyVCFFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }

            dbFileSize = options.localFilterNoGtyVCFFileNames != null ? options.localFilterNoGtyVCFFileNames.length : 0;
            if (dbFileSize > 0) {
                assLocalFilterNoGtyVCFFile6 = new AnnotationSummarySet[dbFileSize];
                for (int i = 0; i < dbFileSize; i++) {
                    String strFileName = options.localFilterNoGtyVCFFileNames[i];
                    if (options.outGZ) {
                        strFileName += ".kggseq.filter.txt.gz";
                    } else {
                        strFileName += ".kggseq.filter.txt";
                    }
                    assLocalFilterNoGtyVCFFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(options.localFilterNoGtyVCFFileNames[i]).getName());
                }
            }

            AnnotationSummarySet assFBAFEM = null;
            AnnotationSummarySet assFBAFIM = null;
            FloatArrayList mafRefList = null;
            if (options.toMAFPlotRef) {
                mafRefList = new FloatArrayList();
            }
            FloatArrayList mafSampleList = null;
            if (options.toMAFPlotSample) {
                mafSampleList = new FloatArrayList();
            }

            if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
                if (options.isAlleleFreqExcMode) {
                    assFBAFEM = new AnnotationSummarySet("filterByAlleleFreqExcModel", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                } else {
                    assFBAFIM = new AnnotationSummarySet("filterByAlleleFreqIncModel", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
            }
            AnnotationSummarySet ldPruningASS = null;
            if (options.ldPruning) {
                ldPruningASS = new AnnotationSummarySet("LDPruning", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
            FiltrationSummarySet geneDBFilter7 = null;
            int[] variantsCounters = null;
            dbFileSize = options.geneDBLabels != null ? options.geneDBLabels.length : 0;
            ReferenceGenome[] referenceGenomes = null;
            int[] availableFeatureSizeForGeneDB = new int[dbFileSize];
            if (dbFileSize > 0) {
                geneDBFilter7 = new FiltrationSummarySet("Gene DB", uniqueGenome.getVariantFeatureNum());

                geneDBFilter7.initiateAMessage(0, " variant(s) are left after filtering by gene features.");
                variantsCounters = new int[VAR_FEATURE_NAMES.length];
                Arrays.fill(variantsCounters, 0);
                referenceGenomes = new ReferenceGenome[dbFileSize];
                File domainFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotDomain.txt.gz");
                GeneRegionParser grp = new GeneRegionParser();
                for (int i = 0; i < dbFileSize; i++) {
                    String geneDBLabel = options.geneDBLabels[i];
                    String dbFileName = options.PUBDB_FILE_MAP.get(geneDBLabel);
                    File idMapFile = null;

                    if (geneDBLabel.equals("gencode")) {
                        idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotEnsemblMap.tab.gz");
                        referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                        uniqueGenome.setGencodeAnnot(true);
                        availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                        uniqueGenome.addVariantFeatureLabel("UniProtFeatureForGEncode");
                    } else if (geneDBLabel.equals("refgene")) {
                        uniqueGenome.setRefSeqAnnot(true);
                        availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                        uniqueGenome.addVariantFeatureLabel("UniProtFeatureForRefGene");
                        idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotRefSeqMap.tab.gz");
                        // unforturately the ucsc file rna fasta file
                        // are not always consistant with the ucsc
                        // chromsome fasta
                        // refGenome =
                        // grp.readRefGeneSeqUcsc(GlobalManager.RESOURCE_PATH
                        // + "/" + dbFileName,
                        // GlobalManager.RESOURCE_PATH + "/" +
                        // "refMrna.fa.gz", geneDBLabel,
                        // options.splicingDis, options.neargeneDis,
                        // domainFile, idMapFile);
                        referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                    } else if (geneDBLabel.equals("ensembl")) {
                        idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotEnsemblMap.tab.gz");
                        referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                        uniqueGenome.setEnsemblAnnot(true);
                        availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                        uniqueGenome.addVariantFeatureLabel("UniProtFeatureForEnsembl");
                    } else if (geneDBLabel.equals("knowngene")) {
                        idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotUCSCKnownGeneMap.tab.gz");
                        referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                        uniqueGenome.setKnownAnnot(true);
                        availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                        uniqueGenome.addVariantFeatureLabel("UniProtFeatureForKnownGene");
                    } else {
                        File dbFile = new File(geneDBLabel);
                        uniqueGenome.setCustomizeAnnot(true);
                        availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                        referenceGenomes[i] = grp.readRefGeneSeq(dbFile.getCanonicalPath(), dbFile.getName(), options.splicingDis, options.neargeneDis, null, null);
                        referenceGenomes[i].setName(dbFile.getName());
                    }
                    referenceGenomes[i].setName(geneDBLabel);
                }
            }
//to summarize 
            int somatNumIndex = -1;
            int readInfoIndex = -1;
            List<String> featureLabels = uniqueGenome.getVariantFeatureLabels();
            for (int i = 0; i < featureLabels.size(); i++) {
                if (featureLabels.get(i).equals("EAS")) //  if (featureLabels.get(i).equals("SomaticAltAllele"))
                {
                    somatNumIndex = i;
                } else if (featureLabels.get(i).equals("TNTRefAltRead,P,OR")) {
                    readInfoIndex = i;
                }
                if (somatNumIndex >= 0 && readInfoIndex >= 0) {
                    break;
                }
            }
            // special consideration for pileup files
            if (somatNumIndex < 0) {
                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("Comments")) {
                        somatNumIndex = i;
                        break;
                    }
                }
            }

            if (somatNumIndex >= 0) {
                uniqueGenome.addGeneFeatureLabel("ResponseVar");
                uniqueGenome.addGeneFeatureLabel("ExplanatoryVar");
                uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScore");
                uniqueGenome.addGeneFeatureLabel("NonsynonymousReadsRatio");
                uniqueGenome.addGeneFeatureLabel("SynonymousReadsRatio");
                if (readInfoIndex > 0) {
                    uniqueGenome.addGeneFeatureLabel("SomatReadsInfor");
                }
            } else {
                uniqueGenome.addGeneFeatureLabel("ResponseVar");
                uniqueGenome.addGeneFeatureLabel("ExplanatoryVar");
                uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScore");
                if (hasControls) {
                    uniqueGenome.addGeneFeatureLabel("ResponseVarControl");
                    uniqueGenome.addGeneFeatureLabel("ExplanatoryVarControl");
                    uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScoreControl");
                }

            }

            FiltrationSummarySet dbNSFPAnnot8 = null;
            FiltrationSummarySet dbNSFPPred9 = null;

            FiltrationSummarySet dbNSFPAnnot8Tmp = null;
            FiltrationSummarySet dbNSFPPred9Tmp = null;

            //zhicheng noncoding
            AnnotationSummarySet dbNoncodePred9d0 = null;
            FiltrationSummarySet dbNoncodePred9d1 = null;

            AnnotationSummarySet dbNoncodePred9d0Tmp = null;
            FiltrationSummarySet dbNoncodePred9d1Tmp = null;

            String resourcePathList[];
            boolean[] resourceTypeIsRegion;
            MyRandomForest[][] myRandomForestList = null;
            Map genicMap = new HashMap<String, Integer>();
            String[] currentLineList = null;
            BufferedReader[] lineReaderList = null;
            Boolean[] isReigonList = null;
            double iniScore[] = null;
            int[] fixedPosition = null;
            int scoreIndexNum = 0;

            // end 
            // LiJun noncoding
            FiltrationSummarySet dbNoncodePred9d2 = null;
            FiltrationSummarySet dbNoncodePred9d2Tmp = null;
            BufferedReader[] lineReaderList9d2 = null;
            Bayes bayesPredictor = new Bayes(GlobalManager.RESOURCE_PATH, options.refGenomeVersion);

            // end
            List<CombOrders> combOrderList = new ArrayList<CombOrders>();
            CombOrders fixedComb = null;
            //MyRandomForest[] myRandomForestsCancer = new MyRandomForest[options.threadNum];
            MyRandomForest[][] myRandomForestsCancer = new MyRandomForest[options.threadNum][];

            // dbNSFP3.0
            // int[] dbNSFP3ScoreIndexes = new int[]{5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
            // int[] dbNSFP3PredicIndex = new int[]{19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
            // dbNSFP3.5
            int[] dbNSFP3ScoreIndexes = new int[]{5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23};
            int[] dbNSFP3PredicIndex = new int[]{24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41};

            String annNCFPPath = null;
            int writenVCFVarNum = 0;
            //String annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/hg19_all_SNV_dbNCFP.gz";

            /*
            final HashMap<String, Double> missingIndex = new HashMap<String, Double>() {
                {
                    put("CADD_cscore", (double) -0.0784622);
                    put("CADD_PHRED", (double) 3.68016);
                    put("DANN_score", (double) 0.291601);
                    put("FunSeq_score", (double) 1);
                    put("FunSeq2_score", (double) 0.287838);
                    put("GWAS3D_score", (double) 2.80186);
                    put("GWAVA_region_score", (double) 0.153309);
                    put("GWAVA_TSS_score", (double) 0.205698);
                    put("GWAVA_unmatched_score", (double) 0.33259);
                    put("SuRFR_score", (double) 9.44965);
                    put("Fathmm_MKL_score", (double) 0.00403947);
                }
            };
             */
            String[] nonCodingPredicLabels = new String[]{"GWAVA.matched", "GWAVA.tss", "GWAVA.unmatched", "CADD.CScore", "DANN", "fathmm-MKL", "FunSeq", "FunSeq2", "GWAS3D", "SuRFR"};
            double[] meanNonCodingPredic = new double[]{0.153309, 0.205698, 0.33259, -0.0784622, 0.291601, 0.00403947, 1, 0.287838, 2.80186, 9.44965};
            double[] baye1NonCodingPredic = new double[]{1.920773254522716, 1.4062755776550864, 8.931983960714861, 1.3731949333636428, 0.6465087024693027, 2.8994079489732445, 1.830225759450194, 0.4278010512234839, 1.3486363708941753, 8.010294623730767};
            double[] baye2NonCodingPredic = new double[]{0.6576249120154963, 0.5844200018958348, 0.8993151817446124, 0.5786271132044547, 0.39265428813083125, 0.743550812562889, 0.6466712958635984, 0.2996223114256015, 0.574221019314591, 0.8890158377988816};
            if (!options.scoreDBLableList.isEmpty()) {
                for (String dbLabelName : options.scoreDBLableList) {
                    if (dbLabelName.equals("dbncfp_known") || dbLabelName.equals("dbncfp_all")) {
                        if (dbLabelName.equals("dbncfp_known")) {
                            annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_known_SNV_dbNCFP.gz";
                        } else {
                            annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_all_SNV_dbNCFP.gz";

                        }
                        String comPath = options.refGenomeVersion + "/" + options.refGenomeVersion + "_funcnote";

                        dbNoncodePred9d0 = new AnnotationSummarySet("noncodeScore", uniqueGenome.getVariantFeatureNum());
                        dbNoncodePred9d0Tmp = new AnnotationSummarySet("noncodeScore", uniqueGenome.getVariantFeatureNum());

                        for (String str : nonCodingPredicLabels) {
                            uniqueGenome.addVariantScore2Label(str);
                        }
                        if (options.ncFuncPred) {
                            dbNoncodePred9d1 = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                            dbNoncodePred9d1Tmp = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                            resourcePathList = new String[]{
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.DNase-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.FAIRE-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Histone.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Tfbs.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_all.footprints.bed.gz.cmp.gz"
                            };
                            resourceTypeIsRegion = new boolean[]{true, true, true, true, true};

                            uniqueGenome.addVariantFeatureLabel("IsComplexDiseasePathogenic");
                            uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                            String genicRegion[] = new String[]{"5UTR", "3UTR", "intronic", "upstream", "downstream", "ncRNA", "intergenic"};
                            for (int i = 0; i < genicRegion.length; i++) {
                                genicMap.put(genicRegion[i], i);
                            }

                            List<String> tmpStringCurrentList = new ArrayList<String>();
                            List<BufferedReader> tmpLineReadersList = new ArrayList<BufferedReader>();
                            List<Boolean> isRegionResource = new ArrayList<Boolean>();

                            for (int i = 0; i < resourcePathList.length; i++) {
                                File rsFile = new File(resourcePathList[i]);
                                if (!rsFile.exists()) {
                                    LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                                    return;
                                } else {
                                    try {
                                        BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                                        tmpLineReadersList.add(lineReader);
                                        isRegionResource.add(resourceTypeIsRegion[i]);
                                        if (resourceTypeIsRegion[i]) {
                                            //The ANN format has no head
                                            tmpStringCurrentList.add(lineReader.readLine());
                                        }
                                    } catch (Exception e) {
                                        // TODO: handle exception
                                        e.printStackTrace();
                                    }
                                }
                            }

                            currentLineList = tmpStringCurrentList.toArray(new String[tmpStringCurrentList.size()]);
                            lineReaderList = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                            isReigonList = isRegionResource.toArray(new Boolean[isRegionResource.size()]);
                            String cells[] = null;
                            String[] currentChrom = new String[isReigonList.length];
                            int[] currentStartPos = new int[isReigonList.length];
                            int[] currentEndPos = new int[isReigonList.length];

                            fixedPosition = new int[isReigonList.length + 1];
                            fixedPosition[0] = 0;
                            List<String> scoreLabels = new ArrayList<String>();
                            int startPosition = 3;
                            for (int i = 0; i < currentLineList.length; i++) {
                                //only consider regions
                                if (isReigonList[i]) {
                                    cells = Util.tokenize(currentLineList[i], '\t');
                                    startPosition = 3;
                                    currentEndPos[i] = Util.parseInt(cells[2]);
                                    for (int j = startPosition; j < cells.length; j++) {
                                        scoreLabels.add(cells[j]);
                                        scoreIndexNum++;
                                    }
                                    fixedPosition[i + 1] = cells.length - startPosition + fixedPosition[i];
                                }
                                currentLineList[i] = lineReaderList[i].readLine();
                            }

                            if (options.needVerboseNoncode) {
                                uniqueGenome.getVariantScore2Labels().addAll(scoreLabels);
                            }
                            scoreLabels.clear();
                            iniScore = new double[scoreIndexNum];

                            Arrays.fill(iniScore, Double.NaN);
                            for (int k = 0; k < fixedPosition.length - 1; k++) {
                                if (isReigonList[k]) {
                                    for (int k2 = fixedPosition[k]; k2 < fixedPosition[k + 1]; k2++) {
                                        iniScore[k2] = 0.0;
                                    }
                                }
                            }
                            myRandomForestList = new MyRandomForest[options.threadNum][];
                            for (int k = 0; k < options.threadNum; k++) {
                                String fileName = GlobalManager.RESOURCE_PATH + "hgmd_model.obj";
                                FileInputStream objFIn = new FileInputStream(fileName);
                                BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                                ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                                myRandomForestList[k] = (MyRandomForest[]) localObjIn.readObject();
                                localObjIn.close();
                                objIBfs.close();
                                objFIn.close();
                            }

                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be complex-disease-pathogenic;");
                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be non-pathogenic according to the Random forest prediction model.");
                            dbNoncodePred9d1.initiateAMessage(0, "variant(s) are left after filtered by the complex disease prediction.");
                        }
                        /*else if (options.ncFuncPred == 1) {
                            dbNoncodePred9d1 = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                            resourcePathList = new String[]{
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.DNase-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.FAIRE-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Histone.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Tfbs.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_all.footprints.bed.gz.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_GWAVA.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_CADD.CScore.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_DANN.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_fathmm-MKL.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_FunSeq.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_FunSeq2.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_GWAS3D.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_SuRFR.gz"
                            };
                            resourceTypeIsRegion = new boolean[]{true, true, true, true, true, false, false, false, false, false, false, false, false};

                            uniqueGenome.addVariantFeatureLabel("IsComplexDiseasePathogenic");
                            uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                            String genicRegion[] = new String[]{"5UTR", "3UTR", "intronic", "upstream", "downstream", "ncRNA", "intergenic"};
                            for (int i = 0; i < genicRegion.length; i++) {
                                genicMap.put(genicRegion[i], i);
                            }

                            List<String> tmpStringCurrentList = new ArrayList<String>();
                            List<BufferedReader> tmpLineReadersList = new ArrayList<BufferedReader>();
                            List<Boolean> isRegionResource = new ArrayList<Boolean>();

                            for (int i = 0; i < resourcePathList.length; i++) {
                                File rsFile = new File(resourcePathList[i]);
                                if (!rsFile.exists()) {
                                    LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                                    return;
                                } else {
                                    try {
                                        BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                                        tmpLineReadersList.add(lineReader);
                                        isRegionResource.add(resourceTypeIsRegion[i]);
                                        tmpStringCurrentList.add(lineReader.readLine());
                                    } catch (Exception e) {
                                        // TODO: handle exception
                                        e.printStackTrace();
                                    }
                                }
                            }

                            currentLineList = tmpStringCurrentList.toArray(new String[tmpStringCurrentList.size()]);
                            lineReaderList = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                            isReigonList = isRegionResource.toArray(new Boolean[isRegionResource.size()]);
                            String cells[] = null;
                            String[] currentChrom = new String[isReigonList.length];
                            int[] currentStartPos = new int[isReigonList.length];
                            int[] currentEndPos = new int[isReigonList.length];

                            fixedPosition = new int[isReigonList.length + 1];
                            fixedPosition[0] = 0;
                            List<String> scoreLabels = new ArrayList<String>();
                            for (int i = 0; i < currentLineList.length; i++) {
                                cells = Util.tokenize(currentLineList[i], '\t');
                                int startPosition = 2;
                                currentChrom[i] = cells[0];
                                currentStartPos[i] = Util.parseInt(cells[1]);
                                if (isReigonList[i]) {
                                    startPosition = 3;
                                    currentEndPos[i] = Util.parseInt(cells[2]);
                                }
                                for (int j = startPosition; j < cells.length; j++) {
                                    scoreLabels.add(cells[j]);
                                    scoreIndexNum++;
                                }
                                fixedPosition[i + 1] = cells.length - startPosition + fixedPosition[i];
                                currentLineList[i] = lineReaderList[i].readLine();
                            }
                            if (options.needVerboseNoncode) {
                                uniqueGenome.getVariantScore1Labels().addAll(scoreLabels);
                            } else {
                                int scoreNum = scoreLabels.size();
                                for (int i = scoreNum - 10; i < scoreNum; i++) {
                                    uniqueGenome.addVariantScore2Label(scoreLabels.get(i));
                                }
                            }
                            scoreLabels.clear();
                            iniScore = new double[scoreIndexNum];

                            Arrays.fill(iniScore, Double.NaN);
                            for (int k = 0; k < fixedPosition.length - 1; k++) {
                                if (isReigonList[k]) {
                                    for (int k2 = fixedPosition[k]; k2 < fixedPosition[k + 1]; k2++) {
                                        iniScore[k2] = 0.0;
                                    }
                                }
                            }
                            myRandomForestList = new MyRandomForest[options.threadNum][];
                            for (int k = 0; k < options.threadNum; k++) {
                                String fileName = GlobalManager.RESOURCE_PATH + "hgmd_model.obj";
                                FileInputStream objFIn = new FileInputStream(fileName);
                                BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                                ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                                myRandomForestList[k] = (MyRandomForest[]) localObjIn.readObject();
                                localObjIn.close();
                                objIBfs.close();
                                objFIn.close();
                            }

                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be complex-disease-pathogenic;");
                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be non-pathogenic according to the Random forest prediction model.");
                            dbNoncodePred9d1.initiateAMessage(0, "variant(s) are left after filtered by the complex disease prediction.");
                        } else */

                        boolean cellTypeSpec = options.cellLineName != null;
                        if (options.ncRegPred) {
                            dbNoncodePred9d2 = new FiltrationSummarySet("noncode Bayes model", uniqueGenome.getVariantFeatureNum());
                            dbNoncodePred9d2Tmp = new FiltrationSummarySet("noncode Bayes model", uniqueGenome.getVariantFeatureNum());
                            // bayesPredictor.changeFeatureNum(options.dbncfpFeatureName);
                            if (cellTypeSpec) {
                                bayesPredictor.changeCellLineName(options.cellLineName);
                            }
                            bayesPredictor.readResource(cellTypeSpec);
                            /*
                            LinkedList<BufferedReader> tmpLineReadersList = new LinkedList<BufferedReader>();
                            comPath = options.refGenomeVersion + "/" + options.refGenomeVersion + "_funcnote_";
                            for (int i = 0; i < options.dbncfpFeatureName.length; i++) {
                                File rsFile = new File(GlobalManager.RESOURCE_PATH + comPath + options.dbncfpFeatureName[i] + ".gz");
                                if (!rsFile.exists()) {
                                    LOG.error(options.dbncfpFeatureName[i] + " does not exist! Scores on this chromosome are ignored!");
                                } else {
                                    try {
                                        BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());;
                                        tmpLineReadersList.add(lineReader);
                                    } catch (Exception e) {
                                        // TODO: handle exception
                                        e.printStackTrace();
                                    }
                                }
                            }
                            for (int i = 0; i < options.dbncfpFeatureName.length; i++) {
                                uniqueGenome.addVariantFeatureLabel(options.dbncfpFeatureName[i]);
                            }
                            lineReaderList9d2 = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                             */
                            uniqueGenome.addVariantFeatureLabel("BF");
                            uniqueGenome.addVariantFeatureLabel("Composite_Prob");
                            if (cellTypeSpec) {
                                uniqueGenome.addVariantFeatureLabel("Cell_Prob");
                                uniqueGenome.addVariantFeatureLabel("Combine_Prob");
                            }
                        }
                    }

                    if (dbLabelName.equals("dbnsfp")) {
                        String dbFileName = options.PUBDB_FILE_MAP.get(dbLabelName);
                        String path = null;
                        boolean existFile = false;
                        for (int s = STAND_CHROM_NAMES.length - 1; s >= 0; s--) {
                            path = GlobalManager.RESOURCE_PATH + "/" + dbFileName + STAND_CHROM_NAMES[s] + ".gz";
                            File f = new File(path);
                            if (f.exists()) {
                                existFile = true;
                                break;
                            }
                        }
                        if (!existFile) {
                            throw new Exception("No dbNSFP resource data available!");
                        }
                        BufferedReader br = LocalFileFunc.getBufferedReader(path);
                        currentLine = br.readLine();
                        String[] cells = currentLine.split("\t");
                        br.close();

                        dbNSFPAnnot8 = new FiltrationSummarySet("dbNSFP", uniqueGenome.getVariantFeatureNum());
                        dbNSFPAnnot8.initiateAMessage(0, "coding nonsynonymous variants are assigned functional prediction scores.");

                        dbNSFPAnnot8Tmp = new FiltrationSummarySet("dbNSFP", uniqueGenome.getVariantFeatureNum());
                        dbNSFPAnnot8Tmp.initiateAMessage(0, "coding nonsynonymous variants are assigned functional prediction scores.");

                        for (int t = 0; t < dbNSFP3ScoreIndexes.length; t++) {
                            uniqueGenome.getScore1Labels().add(cells[dbNSFP3ScoreIndexes[t]]);
                        }
                        for (int t = 0; t < dbNSFP3PredicIndex.length; t++) {
                            uniqueGenome.addVariantFeatureLabel(cells[dbNSFP3PredicIndex[t]]);
                        }
                        if (options.causingNSPredType == 0) {
                            // MendelFilter
                            String logitParamFile = GlobalManager.RESOURCE_PATH + "/mendelcausalrare" + options.dbnsfpVersion + ".param.gz";
                            br = LocalFileFunc.getBufferedReader(logitParamFile);
                            String line = null;

                            CombOrderComparator coc = new CombOrderComparator();
                            // String[] names = {"SLR_test_statistic", "SIFT_score",
                            // "Polyphen2_HDIV_score", "Polyphen2_HVAR_score", "LRT_score",
                            // "MutationTaster_score", "MutationAssessor_score", "FATHMM_score",
                            // "GERP++_NR", "GERP++_RS", "phyloP", "29way_logOdds"};
                            boolean isFixed = false;
                            if (!options.predictExplanatoryVar.startsWith("all") && !options.predictExplanatoryVar.startsWith("best")) {
                                isFixed = true;
                            }
                            float aucCutoff = 0.85f;
                            while ((line = br.readLine()) != null) {
                                if (line.trim().length() == 0) {
                                    continue;
                                }
                                if (line.trim().startsWith("#")) {
                                    continue;
                                }
                                cells = line.split("\t");
                                RegressionParams rp = new RegressionParams();

                                String[] values = cells[1].split(";");
                                rp.coef = new double[values.length];
                                for (int i = 0; i < rp.coef.length; i++) {
                                    rp.coef[i] = Double.parseDouble(values[i]);
                                }
                                rp.sampleCase2CtrRatio = Double.parseDouble(cells[2]);
                                rp.optimalCutoff = Double.parseDouble(cells[3].split(";")[0]);
                                rp.truePositiveRate = Double.parseDouble(cells[3].split(";")[1]);
                                rp.trueNegativeRate = Double.parseDouble(cells[3].split(";")[2]);

                                CombOrders co = new CombOrders(cells[0], Double.parseDouble(cells[4]), rp);
                                if (isFixed) {
                                    if (cells[0].equals(options.predictExplanatoryVar)) {
                                        fixedComb = co;
                                        break;
                                    }
                                } else {
                                    if (co.auc < aucCutoff) {
                                        continue;
                                    }
                                    combOrderList.add(co);
                                }
                            }

                            br.close();
                            Collections.sort(combOrderList, coc);
                            dbNSFPPred9 = new FiltrationSummarySet("dbNSFPMendelPred", uniqueGenome.getVariantFeatureNum());
                            dbNSFPPred9Tmp = new FiltrationSummarySet("dbNSFPMendelPred", uniqueGenome.getVariantFeatureNum());
                            uniqueGenome.addVariantFeatureLabel("DiseaseCausalProb_ExoVarTrainedModel");
                            uniqueGenome.addVariantFeatureLabel("IsRareDiseaseCausal_ExoVarTrainedModel");
                            uniqueGenome.addVariantFeatureLabel("BestCombinedTools:OptimalCutoff:TP:TN");

                            dbNSFPPred9.initiateAMessage(0, "variants (in");
                            dbNSFPPred9.initiateAMessage(0, "genes) are predicted to be disease-causal;");
                            dbNSFPPred9.initiateAMessage(0, "variants are predicted to be non-disease-causal according to the Logistic regression prediction model trained by ExoVar dataset (http://grass.cgs.hku.hk/limx/kggseq/download/ExoVar.xls)");
                            dbNSFPPred9.initiateAMessage(0, "variant(s) are left after filtered by the disease mutation prediction.");

                            dbNSFPPred9Tmp.initiateAMessage(0, "variants (in");
                            dbNSFPPred9Tmp.initiateAMessage(0, "genes) are predicted to be disease-causal;");
                            dbNSFPPred9Tmp.initiateAMessage(0, "variants are predicted to be non-disease-causal according to the Logistic regression prediction model trained by ExoVar dataset (http://grass.cgs.hku.hk/limx/kggseq/download/ExoVar.xls)");
                            dbNSFPPred9Tmp.initiateAMessage(0, "variant(s) are left after filtered by the disease mutation prediction.");

                        } else if (options.causingNSPredType == 2) {
                            for (int s = 0; s < options.threadNum; s++) {
                                try {
                                    File fileName = new File(GlobalManager.RESOURCE_PATH + "/CancerRandomForests" + options.dbnsfpVersion + ".obj");
                                    if (!fileName.exists()) {
                                        throw new Exception("Cannot find data in hard disk!");
                                    }

                                    FileInputStream objFIn = new FileInputStream(fileName);
                                    BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                                    ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                                    myRandomForestsCancer[s] = (MyRandomForest[]) localObjIn.readObject();
                                    localObjIn.close();
                                    objIBfs.close();
                                    objFIn.close();
                                } catch (Exception ex) {
                                    LOG.error(ex);
                                }
                            }
                            // has some unsovled problem
                            /*
                             Kryo kryo = new Kryo();

                             kryo.setReferences(false);
                             kryo.setRegistrationRequired(false);
                             kryo.setInstantiatorStrategy(new StdInstantiatorStrategy());
                             //note: it seems the order of registered classes is very very important                           
                             kryo.register(MyRandomTree.class);
                             kryo.register(MyRandomTree[].class);
                             kryo.register(MyRandomForest.class);

                             Input input = new Input(new FileInputStream(fileName), 1024 * 1024);
                             myRandomForestsCancer = (MyRandomForest) kryo.readObject(input, MyRandomForest.class);
                             input.close();
                             */
                            dbNSFPPred9 = new FiltrationSummarySet("dbNSFPCancerPred", uniqueGenome.getVariantFeatureNum());
                            dbNSFPPred9.initiateAMessage(0, "variants (in");
                            dbNSFPPred9.initiateAMessage(0, "genes) are predicted to be cancer-driver;");
                            dbNSFPPred9.initiateAMessage(0, "variants are predicted to be non-cancer-driver according to a Random Forests prediction model trained by COSMIC dataset (http://cancer.sanger.ac.uk/cancergenome/projects/cosmic/).");
                            dbNSFPPred9.initiateAMessage(0, "variant(s) are left after filtered by the cancer-driver mutation prediction.");

                            uniqueGenome.addVariantFeatureLabel("IsHighMut_COSMICTrainedModel");
                            uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                        }
                    }
                }
            }

            AnnotationSummarySet assGVF10 = null;
            if (options.geneMaxVarPerPerson > 0) {
                assGVF10 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            AnnotationSummarySet assG11 = null;
            AnnotationSummarySet assV12 = null;
            AnnotationSummarySet assPPIG13 = null;
            AnnotationSummarySet assPPIV14 = null;
            AnnotationSummarySet assPWG15 = null;
            AnnotationSummarySet assPWV16 = null;
            PPIGraph ppiTree = null;
            Map<String, GeneSet> mappedPathes = null;
            String ppiDBFile = null;

            if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {
                assG11 = new AnnotationSummarySet("IsCandidateGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("IsCandidateGene");

                assV12 = new AnnotationSummarySet("IsWithinCandidateGene", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("IsWithinCandidateGene");

                String genesetDBFile = null;
                if (options.ppiDB != null) {
                    ppiDBFile = options.PUBDB_FILE_MAP.get("string");

                    ppiTree = new PPIGraph(GlobalManager.RESOURCE_PATH + "/" + ppiDBFile);
                    ppiTree.readPPIItems();
                    assPPIG13 = new AnnotationSummarySet(ppiDBFile, null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                    uniqueGenome.addmRNAFeatureLabel("PPI");

                    assPPIV14 = new AnnotationSummarySet(ppiDBFile, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("PPI");
                }

                if (options.genesetdb != null) {
                    genesetDBFile = options.PUBDB_FILE_MAP.get(options.genesetdb);
                    genesetDBFile = GlobalManager.RESOURCE_PATH + "/" + genesetDBFile;

                    if (genesetDBFile != null) {
                        CandidateGeneExtender candiGeneExtender = new CandidateGeneExtender();
                        candiGeneExtender.setSeedGeneSet(options.candidateGeneSet);
                        candiGeneExtender.loadGeneSetDB(genesetDBFile, 2, 400);
                        mappedPathes = candiGeneExtender.pickRelevantGeneSet();

                        assPWG15 = new AnnotationSummarySet("SharedGeneSet", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                        uniqueGenome.addmRNAFeatureLabel("SharedGeneSet");

                        assPWV16 = new AnnotationSummarySet("SharedGeneSet", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                        uniqueGenome.addVariantFeatureLabel("SharedGeneSet");
                    } else {
                        String info = "The geneset data set name " + options.genesetdb + " does not exist! So the geneset-based prioritization will be ignored!";
                        LOG.warn(info);
                    }
                }
            }

            AnnotationSummarySet assIBS17d1 = null;

            if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                assIBS17d1 = new AnnotationSummarySet("ibs", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("LongestIBSRegion");
                uniqueGenome.addVariantFeatureLabel("LongestIBSRegionLength(bp)");
            }

            AnnotationSummarySet assHRC17d2 = null;

            if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                assHRC17d2 = new AnnotationSummarySet("homozygousRegionCase", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("LongestHomozygosityRegion");
                uniqueGenome.addVariantFeatureLabel("LongestHomozygosityRegionLength(bp)");
            }

            //gene mutation rate test for cancer
            double funcScoreBinLen = 0.3;
            String[] popuNames = null;
            //,"hg19_gnomad.genomes.gene.var.freq.gz","hg19_gnomad.exomes.gene.var.freq.gz" 
            String[] geneCoVarFiles = new String[]{"hg19_1kg.gene.var.freq.gz", "hg19_gnomad.exomes.gene.var.freq.gz"};
            boolean useLocalGeneScore = false;
            if (options.geneVarFreqLabels != null) {
                popuNames = new String[geneCoVarFiles.length];
                if (options.geneVarFreqLabels.toUpperCase().equals("CONTROL")) {
                    popuNames[0] = "CONTROL";
                    if (controlSet == null || controlSet.isEmpty()) {
                        String info = "The '--gene-freq-score control' cannot be specified because no control samples are input!";
                        throw new Exception(info);
                    }
                    useLocalGeneScore = true;
                } else {
                    for (int i = 0; i < geneCoVarFiles.length; i++) {
                        popuNames[i] = options.geneVarFreqLabels.toUpperCase();
                        if (geneCoVarFiles[i].endsWith("gnomad.genomes.gene.var.freq.gz")) {
                            if (popuNames[i].equals("EUR")) {
                                popuNames[i] = "NFE";
                            }
                        }
                    }
                }
            }

            if (options.runnerGeneCoding) {
                funcScoreBinLen = 0.3;
            } else if (options.wrenerGeneNonCoding) {
                if (options.cellLineName == null) {
                    funcScoreBinLen = 0.03;
                } else {
                    funcScoreBinLen = 0.3;
                }
            }
            int mafBins = 20;
            Set<String> hittedGeneSet = new HashSet<String>();
            Map<String, double[]> geneMutationScores = new HashMap<String, double[]>();

            Map<String, double[]> geneFreqScores = new HashMap<String, double[]>();
            Map<String, double[]> localGeneFreqScores = new HashMap<String, double[]>();
            double mafFolder = 1;
            int geneFreqScoreIndex = 0;
            double[] scorePercentiles = new double[]{0.5, 0.8, 0.95, 0.99, 0.999};
            double[] scoreCutoffs = new double[scorePercentiles.length];
            boolean needRegionLen = true;
            if (useLocalGeneScore) {
                // mafBins = 1;
            }
            //no need scores in the regression for up and downstream
            if (options.dependentGeneFeature.contains((byte) 12) || options.dependentGeneFeature.contains((byte) 13)) {
                needRegionLen = false;
            }
            boolean useMinIDForGeneMapping = true;

            // as it is fast, i would prefer to read the lenght always. 
            Map<String, Double> geneLengths = null;
            AnnotationSummarySet assGIS17d3 = null;
            AnnotationSummarySet assGOS17d4 = null;
            Map<String, RefGene> mergedGeneCodingRegions = null;
            if (options.geneDBLabels != null) {
                GeneRegionParser grp = new GeneRegionParser();
                // geneLengths =
                // grp.readRefGeneLength(GlobalManager.RESOURCE_PATH + "/" +
                // options.PUBDB_FILE_MAP.get(options.geneDBLabels[0]),
                // options.splicingDis);
                String[] pathes = new String[options.geneDBLabels.length];
                int ii = 0;
                for (String lbs : options.geneDBLabels) {
                    File f = new File(lbs);
                    if (f.exists()) {
                        pathes[ii] = lbs;
                    } else {
                        pathes[ii] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(lbs);
                    }
                    ii++;
                }
                if (options.contextAnnotGFDis > 0 || (options.simulGeneRegionsGtyNum > 0 && options.doubleHitGeneTriosCasePsudo)) {
                    mergedGeneCodingRegions = new HashMap<String, RefGene>();
                }
                if (options.dependentGeneFeature.contains(11)) {
                    geneLengths = grp.readMergeRefGeneIntronLength(pathes, options.splicingDis, mergedGeneCodingRegions, options.dependentMaxIntronFeature);
                } else {
                    geneLengths = grp.readMergeRefGeneCodingLength(pathes, options.splicingDis, true, mergedGeneCodingRegions);
                }

                // only keep genes in inGeneSet
                if (!options.inGeneSet.isEmpty()) {
                    assGIS17d3 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }

                // only keep genes in outGeneSet
                if (!options.outGeneSet.isEmpty()) {
                    assGOS17d4 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                }
                double[] ss;
                if (needRegionLen) {
                    for (Map.Entry<String, Double> item : geneLengths.entrySet()) {
                        // double[] ss = new double[1 + popuNames.length];
                        ss = new double[2];
                        ss[0] = item.getValue();
                        ss[1] = 0;
                        geneMutationScores.put(item.getKey(), ss);
                    }
                }
                geneFreqScoreIndex = 1;
            }

            List<String[]> regionItems = null;
            AnnotationSummarySet assIBD17d5 = null;
            if (options.ibdFileName != null) {
                int[] indexes = new int[]{0, 1, 2};
                regionItems = new ArrayList<String[]>();
                File ibdFile = new File(options.ibdFileName);
                LocalFile.retrieveData(ibdFile.getCanonicalPath(), regionItems, indexes, "\t");

                assIBD17d5 = new AnnotationSummarySet(options.ibdFileName, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("IBDRegion");
                uniqueGenome.addVariantFeatureLabel("IBDRegionAnnot");
            }

            AnnotationSummarySet dbScSNV18 = null;
            if (options.dbscSNVAnnote) {
                String dbLabelName = "dbscSNV";

                dbScSNV18 = new AnnotationSummarySet("dbscSNV", LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName)), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("ada_score@" + dbLabelName);
                //skip the head line
                dbScSNV18.getBr().readLine();
            }

            Map<String, String> genePubMedID = new HashMap<String, String>();
            String fileName = "HgncGene.txt";
            File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/" + fileName);
            Map<String, String[]> geneNamesMap = varAnnoter.readGeneNames(resourceFile.getCanonicalPath());//time-consuming line. 
            List<String[]> hitDisCountsTriosGenes = null;
            List<String[]> hitDisCounTriosReads = null;

            List<int[]> triosIDList = null;
            IntArrayList effectiveIndivIDsTrios = null;
            Set<String> caseDoubleHitTriosGenes = null;
            Set<String> controlDoubleHitTriosGenes = null;
            int pathogenicPredicIndex = -1;

            if (options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
                hitDisCountsTriosGenes = new ArrayList<String[]>();
                hitDisCounTriosReads = new ArrayList<String[]>();
                doubleHitGeneModelFilter19 = new FiltrationSummarySet("DoubleHitModel", uniqueGenome.getVariantFeatureNum());
                doubleHitGeneModelFilter19.initiateAMessage(0, "variant(s) are left after filtered by the double-hit genes using parents' genotypes.");
                caseDoubleHitTriosGenes = new HashSet<String>();
                controlDoubleHitTriosGenes = new HashSet<String>();
                // cluster counts according to phentoypes
                int indivSize = subjectList.size();

                triosIDList = new ArrayList<int[]>();
                varFilter.matchTrioSet(subjectList, triosIDList);
                if (triosIDList.isEmpty()) {
                    String infor = "No recognizable trios for double-hit gene checking!";
                    LOG.error(infor);
                    return;
                }
                List<int[]> tmpTriosIDList = new ArrayList<int[]>();
                int trioSize = triosIDList.size();
                for (int t = 0; t < 3; t++) {
                    for (int j = 0; j < trioSize; j++) {
                        int[] trio = triosIDList.get(j);
                        Individual mIndiv = subjectList.get(trio[0]);
                        if (mIndiv.getAffectedStatus() == t) {
                            tmpTriosIDList.add(trio);
                        }
                    }
                }
                triosIDList.clear();
                triosIDList.addAll(tmpTriosIDList);
                tmpTriosIDList.clear();

//prepare the output format
                List<String> headActual = new ArrayList<String>();
                headActual.add("Gene");
                headActual.add("PubMed");
                headActual.add("ExonLen");
                List<String> headPhenotype = new ArrayList<String>();
                headPhenotype.add("Disease");
                headPhenotype.add(".");
                headPhenotype.add(".");

                int effectiveIndivSize = 0;
                if (options.doubleHitGeneTriosFilter) {
                    headActual.add("CountHitCase");
                    headPhenotype.add(".");
                    headActual.add("CountHitControl");
                    headPhenotype.add(".");

                } else if (options.doubleHitGeneTriosCasePsudo) {
                    headActual.add("CountHitCase");
                    headActual.add("CountHitPseudoControl");
                    headActual.add("TotalNum");
                    headActual.add("p-Value");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                } else if (options.doubleHitGeneTriosCaseControl) {
                    headActual.add("CountHitCase");
                    headActual.add("TotalNumCase");
                    headActual.add("CountHitControl");
                    headActual.add("TotalNumControl");
                    headActual.add("p-Value");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                    headPhenotype.add(".");
                }

                effectiveIndivIDsTrios = new IntArrayList();
                int setSize = triosIDList.size();
                for (int j = 0; j < setSize; j++) {
                    Individual mIndiv = subjectList.get(triosIDList.get(j)[0]);
                    if (triosIDList.get(j)[0] < 0 || triosIDList.get(j)[1] < 0 || triosIDList.get(j)[2] < 0) {
                        continue;
                    }

                    effectiveIndivIDsTrios.add(j);
                    headActual.add(mIndiv.getLabelInChip());
                    headPhenotype.add(String.valueOf(mIndiv.getAffectedStatus()));
                    effectiveIndivSize++;
                }
                hitDisCountsTriosGenes.add(headActual.toArray(new String[0]));
                hitDisCountsTriosGenes.add(headPhenotype.toArray(new String[0]));
                hitDisCounTriosReads.add(headActual.toArray(new String[0]));
                hitDisCounTriosReads.add(headPhenotype.toArray(new String[0]));

                if (effectiveIndivSize == 0) {
                    String infor = "No valid trios for double-hit gene checking!";
                    LOG.warn(infor);
                    return;
                }

                if (options.doubleHitGeneTriosCaseControl && caeSetID == null) {
                    throw new Exception("No cases for '--double-hit-gene-trio-case-control'!");
                }
                if (options.doubleHitGeneTriosCaseControl && controlSetID == null) {
                    throw new Exception("No controls for '--double-hit-gene-trio-case-control'!");
                }
            }

            List<String[]> doubleHitGenePhasedGenes = null;
            List<String[]> doubleHitGenePhasedReads = null;
            Set<String> caseDoubleHitPhasedGenes = null;
            Set<String> controlDoubleHitPhasedGenes = null;
            if (options.doubleHitGenePhasedFilter) {
                if (caeSetID == null && controlSetID == null) {
                    throw new Exception("'--double-hit-gene-phased-filter' requires case/control phenotype inormation.");
                }
                if (!uniqueGenome.isIsPhasedGty()) {
                    throw new Exception("'--double-hit-gene-phased-filter' does not work for unphased genotyps.");
                }
                doubleHitGeneModelFilter19d1 = new FiltrationSummarySet("DoubleHitModel", uniqueGenome.getVariantFeatureNum());
                doubleHitGeneModelFilter19d1.initiateAMessage(0, "variant(s) are left after filtered by the double-hit genes using phased genotypes.");
                caseDoubleHitPhasedGenes = new HashSet<String>();
                controlDoubleHitPhasedGenes = new HashSet<String>();

                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                        pathogenicPredicIndex = i;
                    }
                    if (pathogenicPredicIndex >= 0) {
                        break;
                    }
                }

                doubleHitGenePhasedGenes = new ArrayList<String[]>();
                doubleHitGenePhasedReads = new ArrayList<String[]>();
                List<String> heads1 = new ArrayList<String>();
                heads1.add("Gene");
                heads1.add("PubMed");
                heads1.add("P");
                heads1.add("CountCtl");
                heads1.add("CountCase");
                List<String> heads2 = new ArrayList<String>();
                heads2.add("Disease");
                heads2.add(".");
                heads2.add(".");
                heads2.add(".");
                heads2.add(".");
                int effectiveIndivSize = 0;

                int caseNum = caeSetID == null ? 0 : caeSetID.length;
                int controlNum = controlSetID == null ? 0 : controlSetID.length;

                for (int j = 0; j < controlNum; j++) {
                    int index = controlSetID[j];
                    Individual mIndiv = subjectList.get(index);
                    heads1.add(mIndiv.getLabelInChip());
                    heads2.add(String.valueOf(mIndiv.getAffectedStatus()));
                    effectiveIndivSize++;
                }

                for (int j = 0; j < caseNum; j++) {
                    int index = caeSetID[j];
                    Individual mIndiv = subjectList.get(index);
                    heads1.add(mIndiv.getLabelInChip());
                    heads2.add(String.valueOf(mIndiv.getAffectedStatus()));
                    effectiveIndivSize++;
                }
                if (effectiveIndivSize == 0) {
                    String infor = "No valid genotype information for double-hit gene checking!";
                    LOG.warn(infor);

                }

                doubleHitGenePhasedGenes.add(heads1.toArray(new String[0]));
                doubleHitGenePhasedGenes.add(heads2.toArray(new String[0]));
                doubleHitGenePhasedReads.add(heads1.toArray(new String[0]));
                doubleHitGenePhasedReads.add(heads2.toArray(new String[0]));
            }

            AnnotationSummarySet assGene20 = null;
            AnnotationSummarySet assVariant20 = null;
            if (options.needAnnotateGene) {
                String fileNameHg = "HgncGene.txt";
                //File resourceFileHg = new File(GlobalManager.RESOURCE_PATH + "/" + fileNameHg);
                assGene20 = new AnnotationSummarySet(fileNameHg, null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("GeneDescription");
                uniqueGenome.addmRNAFeatureLabel("Pseudogenes");

                assVariant20 = new AnnotationSummarySet(fileNameHg, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("GeneDescription");
                uniqueGenome.addVariantFeatureLabel("Pseudogenes");
            }

            AnnotationSummarySet assOmimGene21 = null;
            AnnotationSummarySet assOmimVar21 = null;
            if (options.omimAnnotateGene) {
                //File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/morbidmap.gz");
                assOmimGene21 = new AnnotationSummarySet("morbidmap.gz", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("DiseaseName(s)MIMid");
                uniqueGenome.addmRNAFeatureLabel("GeneMIMid");

                assOmimVar21 = new AnnotationSummarySet("morbidmap.gz", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("DiseaseName(s)MIMid");
                uniqueGenome.addVariantFeatureLabel("GeneMIMid");
            }

            AnnotationSummarySet assTissueSpecGene21 = null;
            AnnotationSummarySet assTissueSpecVar21 = null;
            Map<String, StringBuilder> tissueSpecGeneMap = new HashMap<String, StringBuilder>();
            if (options.tissueSpecAnnot) {
                assTissueSpecGene21 = new AnnotationSummarySet("gene.trans.spc.tissue.txt.gz", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("TissueSpecificExpression(p)");

                assTissueSpecVar21 = new AnnotationSummarySet("gene.trans.spc.tissue.txt.gz", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("TissueWithSpecificExpression");
                tissueSpecGeneMap = geneAnnotor.readTissueSpecficGenes(GlobalManager.RESOURCE_PATH + "/gene.trans.spc.tissue.txt.gz");
            }
            AnnotationSummarySet assSDA22 = null;
            AnnotationSummarySet assSDF22 = null;
            CNVRegionParser grpSD = null;
            ReferenceGenome refGenomeSD = null;
            if (options.superdupAnnotate) {
                grpSD = new CNVRegionParser();
                refGenomeSD = grpSD.readSuperDupRegions(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("superdup"));
                assSDA22 = new AnnotationSummarySet("superdup", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("SuperDupKValue");
            }
            if (options.superdupFilter) {
                grpSD = new CNVRegionParser();
                refGenomeSD = grpSD.readSuperDupRegions(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("superdup"));
                assSDF22 = new AnnotationSummarySet("superdup", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            AnnotationSummarySet assDGV23 = null;
            CNVRegionParser grpDGV = null;
            ReferenceGenome refGenomeDGV = null;
            if (options.dgvcnvAnnotate) {
                grpDGV = new CNVRegionParser();
                refGenomeDGV = grpDGV.readRefCNVSeq(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("dgvcnv"));
                assDGV23 = new AnnotationSummarySet("dgvcnv", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("DGVIDs");
                uniqueGenome.addVariantFeatureLabel("CNVSampleSize");
                uniqueGenome.addVariantFeatureLabel("LossCNV");
                uniqueGenome.addVariantFeatureLabel("GainCNV");
            }

            AnnotationSummarySet assOLGF = null;

            IntArrayList caseSubIDs = new IntArrayList();
            IntArrayList controlSubIDs = new IntArrayList();
            if (options.overlappedGeneFilter) {
                assOLGF = new AnnotationSummarySet("overlappedGeneFilter", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                featureLabels = uniqueGenome.getVariantFeatureLabels();
                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                        pathogenicPredicIndex = i;
                    }
                    if (pathogenicPredicIndex >= 0) {
                        break;
                    }
                }

                int indivSize = subjectList.size();
                for (int j = 0; j < indivSize; j++) {
                    Individual mIndiv = subjectList.get(j);
                    if (mIndiv.getAffectedStatus() == 2) {
                        caseSubIDs.add(j);
                    } else if (mIndiv.getAffectedStatus() == 1) {
                        controlSubIDs.add(j);
                    }
                }
            }

            AnnotationSummarySet assMousePheno = null;

            Map g2MP = null;
            if (options.phenoMouse) {
                assMousePheno = new AnnotationSummarySet("phenotype_mouse", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("MousePhenotypeMGI");
                uniqueGenome.addVariantFeatureLabel("MousePhenotypeIMPC");
                g2MP = new HashMap<String, String[]>();
                geneAnnotor.readMousePhenotype(g2MP);
            }

            AnnotationSummarySet assZebra = null;

            HashMap<String, String> xebraP2Phe = null;
            if (options.zebraFish) {
                assZebra = new AnnotationSummarySet("phenotypeZebra", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("ZebrafishPhenotype");
                xebraP2Phe = new HashMap<String, String>();
                geneAnnotor.readZebrafishPhenotype(xebraP2Phe);
            }

            AnnotationSummarySet assDDD = null;
            HashMap<String, String> dddP2Phe = null;
            File fisher = new File(GlobalManager.RESOURCE_PATH + "/DDG2P.csv.gz");
            if (options.dddPhenotypes) {
                assDDD = new AnnotationSummarySet("phenotypeDDD", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("DDDPhenotype");

                BufferedReader br = LocalFileFunc.getBufferedReader(fisher.getCanonicalPath());
                //skip the headline
                br.readLine();
                br.readLine();

                dddP2Phe = new HashMap<String, String>();
                String strLine;
                while ((strLine = br.readLine()) != null) {
                    String[] strItems = Util.splitCVS(strLine);
                    String pheno = strItems[2] + ";" + strItems[4] + ";" + strItems[7];
                    dddP2Phe.put(strItems[0], pheno);
                }
                br.close();
            }

            AnnotationSummarySet pubmedSearch24_Gene_Ideo = null;
            AnnotationSummarySet pubmedSearch24_Gene = null;
            AnnotationSummarySet pubmedSearch24_Var_Ideo = null;
            AnnotationSummarySet pubmedSearch24_Var = null;
            List<String[]> ideogramItemsGene = new ArrayList<String[]>();
            List<String[]> ideogramItemsVar = new ArrayList<String[]>();

            int driverPredicIndex = -1;
            if (options.searchList != null && !options.searchList.isEmpty()) {
                if (options.pubmedMiningIdeo) {
                    pubmedSearch24_Gene_Ideo = new AnnotationSummarySet("pubmedMiningIdeoGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                    uniqueGenome.addmRNAFeatureLabel("PubMedIDIdeogram");

                    String ideoFileName = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("ideogram");
                    File ideoFile = new File(ideoFileName);
                    if (!ideoFile.exists()) {
                        LOG.error(ideoFile.getCanonicalPath() + " does not exist!!");
                        return;//Or ignore this ?
                    }

                    if (options.refGenomeVersion.equals("hg18")) {
                        int[] indexes = new int[]{0, 1, 2, 5, 6};
                        LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsGene, indexes, "\t");
                        List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                        ideogramItemsTmp.addAll(ideogramItemsGene);
                        ideogramItemsGene.clear();
                        for (String[] item : ideogramItemsTmp) {
                            String[] newItem = new String[4];
                            newItem[0] = item[0];
                            newItem[1] = item[1] + item[2];
                            newItem[2] = item[3];
                            newItem[3] = item[4];
                            ideogramItemsGene.add(newItem);
                        }
                    } else if (options.refGenomeVersion.equals("hg19")) {
                        int[] indexes = new int[]{0, 3, 1, 2};
                        LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsGene, indexes, "\t");
                        List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                        ideogramItemsTmp.addAll(ideogramItemsGene);
                        ideogramItemsGene.clear();
                        for (String[] item : ideogramItemsTmp) {
                            String[] newItem = new String[4];
                            if (item[0].length() > 3) {
                                newItem[0] = item[0].substring(3);//This may be wrong if the chromosome doesn't have chr start. 
                            } else {
                                newItem[0] = item[0];
                            }
                            newItem[1] = item[1];
                            newItem[2] = item[2];
                            newItem[3] = item[3];
                            ideogramItemsGene.add(newItem);
                        }
                    }
                }
                if (options.pubmedMiningGene) {
                    pubmedSearch24_Gene = new AnnotationSummarySet("pubmedMiningGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                    uniqueGenome.addmRNAFeatureLabel("PubMedIDGene");
                }

                if (options.pubmedMiningIdeo) {
                    pubmedSearch24_Var_Ideo = new AnnotationSummarySet("pubmedMiningIdeoVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("PubMedIDIdeogram");

                    String ideoFileName = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("ideogram");
                    File ideoFile = new File(ideoFileName);
                    if (!ideoFile.exists()) {
                        LOG.error(ideoFile.getCanonicalPath() + " does not exist!!");
                        return;//or ignore?
                    }

                    for (int i = 0; i < featureLabels.size(); i++) {
                        if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                            pathogenicPredicIndex = i;
                        }

                        if (driverPredicIndex >= 0) {
                            break;
                        }
                    }

                    if (options.refGenomeVersion.equals("hg18") || options.refGenomeVersion.equals("hg19")) {
                        int[] indexes = new int[]{0, 1, 2, 5, 6};
                        LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsVar, indexes, "\t");
                        List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                        ideogramItemsTmp.addAll(ideogramItemsVar);
                        ideogramItemsVar.clear();
                        for (String[] item : ideogramItemsTmp) {
                            String[] newItem = new String[4];
                            newItem[0] = item[0];
                            newItem[1] = item[1] + item[2];
                            newItem[2] = item[3];
                            newItem[3] = item[4];
                            ideogramItemsVar.add(newItem);
                        }
                    }
                }

                if (options.pubmedMiningGene) {
                    pubmedSearch24_Var = new AnnotationSummarySet("pubmedMiningVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("PubMedIDGene");

                    for (int i = 0; i < featureLabels.size(); i++) {
                        if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                            pathogenicPredicIndex = i;
                        }
                        if (driverPredicIndex >= 0) {
                            break;
                        }
                    }
                }
            }

            AnnotationSummarySet assRSID25 = null;
            OpenIntIntHashMap[] altMapID = null;
            if (options.rsid) {
                String urlT = options.PUBDB_URL_MAP.get("rsid");
                urlT = urlT.substring(urlT.lastIndexOf("/") + 1);
                assRSID25 = new AnnotationSummarySet("RSID", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                File resourceFileRSID = new File(GlobalManager.RESOURCE_PATH + "/" + options.refGenomeVersion + "/" + urlT);
                altMapID = new OpenIntIntHashMap[STAND_CHROM_NAMES.length];
                for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                    altMapID[i] = new OpenIntIntHashMap();
                }
                varAnnoter.readChrPosRs(altMapID, resourceFileRSID);
            }

            AnnotationSummarySet assFS = null;
            SequenceRetriever seqRe = null;
            if (options.flankingSequence > 0) {
                assFS = new AnnotationSummarySet("FlankingSequence", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("FlankingSeq" + options.flankingSequence + "bp");
                seqRe = new SequenceRetriever();
            }

            AnnotationSummarySet assPhenolyzer26 = null;
            Phenolyzer phenolyzer = null;
            HashMap<String, String> hmpPhenolyzer = null;
            if (options.phenolyzer) {
                assPhenolyzer26 = new AnnotationSummarySet("Phenolyzer", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("Phenolyzer_Score");
                phenolyzer = new Phenolyzer(options.searchList, options.outputFileName + "phenolyzer/out");

                phenolyzer.runPhenolyzer();
                phenolyzer.parseResult();
                hmpPhenolyzer = phenolyzer.getHashMap();
            }

            SKAT skat = null;
            DoubleArrayList[] genePVList = null;
            if (options.skatGene || options.skatGeneset) {
                if (subjectList == null | subjectList.isEmpty()) {
                    String info = "No case and control information! Failed in SKAT.";
                    LOG.info(info);
                    options.skatGene = false;
                } else {
                    skat = new SKAT(options.outputFileName, options.skatCutoff, false);
//                    int intParallel = options.threadNum >= 10 ? 10 : options.threadNum;
                    skat.startRCluster(options.threadNum);//Visit R. 

                    int intPhe = -1;
                    if (options.phenotypeColID != null && options.phenotypeColID.containsKey(options.pheItem)) {
                        intPhe = options.phenotypeColID.get(options.pheItem);
                    }

                    double dblPhe[] = skat.getPhenotype(subjectList, options.skatBinary, intPhe);
                    double dblCov[][] = null;
                    if (options.cov) {
                        dblCov = skat.getCovarite(subjectList, options.phenotypeColID, options.covItems);
                    }

                    skat.setPhenotype(dblPhe, dblCov, options.permutePheno);//Visit R. 

//                    if (skatGene.isBoolBinary()) {
                    genePVList = new DoubleArrayList[3];
//                    } else {
//                        genePVList = new DoubleArrayList[2];
//                    }
                    for (int i = 0; i < genePVList.length; i++) {
                        genePVList[i] = new DoubleArrayList();
                    }
                }
            }

            AnnotationSummarySet assPatho27 = null;
            HashMap<String, String[]> hmpPatho = null;
            int intPatho = 0;
            if (options.mendelGenePatho) {
                hmpPatho = new HashMap<String, String[]>();
                assPatho27 = new AnnotationSummarySet("Pathology Gene Pediction:", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                String geneMendelPredFilePath = options.PUBDB_FILE_MAP.get("mendelgene");

                BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + geneMendelPredFilePath);
                String strLine = br.readLine();
                String[] title = strLine.split(",");
                intPatho = 11;

                for (int i = 1; i < intPatho; i++) {
                    uniqueGenome.addVariantFeatureLabel(title[i]);
                }

                while ((strLine = br.readLine()) != null) {
                    String[] items = strLine.split(",");
                    String[] values = new String[intPatho - 1];
                    System.arraycopy(items, 1, values, 0, values.length);
                    hmpPatho.put(items[0], values);
                }
            }

            Map<String, Map<String, Integer>> cosmicGeneMut = null;
            AnnotationSummarySet cosmicDBAnnot28 = null;
            if (options.cosmicAnnotate) {
                fileName = options.PUBDB_FILE_MAP.get("cosmicdb");
                cosmicGeneMut = geneAnnotor.readCosmicGeneAnnotation(GlobalManager.RESOURCE_PATH + "/" + fileName);
                cosmicDBAnnot28 = new AnnotationSummarySet("COSMIC data", uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("COSMICCancerInfo");
            }

            File annovarFilteredInFile = null;
            BufferedWriter annovarFilteredInFileWriter = null;

            if (options.isANNOVAROut) {
                annovarFilteredInFile = new File(options.outputFileName + ".flt.annovar");
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(annovarFilteredInFile.getCanonicalPath() + ".gz"));
                    annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(annovarFilteredInFile));
                }
            }
            BufferedWriter bwGeneVarGroupFile = null;
            if (options.isGeneVarGroupFileOut) {
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".gene.epacts.grp.gz"));
                    bwGeneVarGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    bwGeneVarGroupFile = new BufferedWriter(new FileWriter(options.outputFileName + ".gene.epacts.grp"));
                }
            }

            BufferedWriter bwMapBed = null;
            int[] savedBinnaryBedVar = new int[2];
            savedBinnaryBedVar[0] = 0;
            savedBinnaryBedVar[1] = 0;
            //RandomAccessFile rafBed = null;
            //FileChannel fileBedStream = null;
            BufferedOutputStream fileBedStream = null;
            WritableByteChannel wbcFileBed = null;

            if (options.isPlinkBedOut) {
                BufferedWriter bwPed = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".bim" + ".gz"));
                    bwMapBed = new BufferedWriter(new OutputStreamWriter(gzOut));
                    GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".fam" + ".gz"));
                    bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
                } else {
                    bwMapBed = new BufferedWriter(new FileWriter(options.outputFileName + ".bim"));
                    bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".fam"));
                }
                //bwMapBed = new BufferedWriter(new FileWriter(options.outputFileName + ".bim"));

                //BufferedWriter bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".fam"));
                for (Individual indiv : subjectList) {
                    if (indiv == null) {
                        continue;
                    }
                    savedBinnaryBedVar[1]++;
                    bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                            + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                    bwPed.write("\n");
                }
                bwPed.close();

                File bedFile = new File(options.outputFileName + ".bed");
                if (bedFile.exists()) {
                    bedFile.delete();
                }
                if (options.outGZ) {
                    wbcFileBed = Channels.newChannel(new FileOutputStream(bedFile.getCanonicalPath() + ".gz"));
                    fileBedStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed)));
                    //bwFileChannelBed=new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed))));
                } else {
                    wbcFileBed = Channels.newChannel(new FileOutputStream(bedFile));
                    fileBedStream = new BufferedOutputStream(Channels.newOutputStream(wbcFileBed));
                }

                byte[] byteInfo = new byte[3];
                //|-magic number-
                //01101100 00011011
                byteInfo[0] = (byte) 0x6C;

                byteInfo[1] = (byte) 0x1B;

                //|-mode-| 00000001 (SNP-major)
                //00000001 
                byteInfo[2] = 1;
                fileBedStream.write(byteInfo);

            }

            BufferedWriter bwMapPed = null;
            int[] savedPedVar = new int[2];
            savedPedVar[0] = 0;
            savedPedVar[1] = 0;
            if (options.isPlinkPedOut) {
                BufferedWriter bwPed = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".map" + ".gz"));
                    bwMapPed = new BufferedWriter(new OutputStreamWriter(gzOut));
                    GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ped.p" + ".gz"));
                    bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
                } else {
                    bwMapPed = new BufferedWriter(new FileWriter(options.outputFileName + ".map"));
                    bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".ped.p"));
                }
                //bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".ped.p"));
                for (Individual indiv : subjectList) {
                    if (indiv == null) {
                        continue;
                    }
                    savedPedVar[1]++;
                    bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                            + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                    bwPed.write("\n");
                }
                bwPed.close();
            }

            BufferedOutputStream filelKedStream = null;
            WritableByteChannel rafKed = null;
            BufferedWriter bwMapKed = null;
            int[] savedBinnaryKedVar = new int[2];
            savedBinnaryKedVar[0] = 0;

            if (options.isBinaryGtyOut) {
                File kedFile = null;
                if (options.outGZ) {
                    kedFile = new File(options.outputFileName + ".ked.gz");
                    rafKed = Channels.newChannel(new FileOutputStream(kedFile));
                    filelKedStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(rafKed)));
                    //fileChannelKed = new BufferedOutputStream((Channels.newOutputStream(rafKed)));
                    //   filelKedStream = new BufferedOutputStream(new FileOutputStream(bedMergedFile), 10000);

                } else {
                    kedFile = new File(options.outputFileName + ".ked");
                    rafKed = Channels.newChannel(new FileOutputStream(kedFile));
                    filelKedStream = new BufferedOutputStream((Channels.newOutputStream(rafKed)));
                }

                byte[] head = new byte[3];
                head[0] = (byte) 0x9E;
                head[1] = (byte) 0x82;
                if (uniqueGenome.isIsPhasedGty()) {
                    head[2] = (byte) 0x1;
                } else {
                    head[2] = (byte) 0x0;
                }
                filelKedStream.write(head);

//pedigree 
                BufferedWriter bwPed = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".kam" + ".gz"));
                    bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
                } else {
                    bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".kam"));
                }
                for (Individual indiv : subjectList) {
                    if (indiv == null) {
                        continue;
                    }
                    savedBinnaryKedVar[1]++;
                    bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                            + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                    bwPed.write("\n");
                }
                bwPed.close();

                //bwMapKed = new BufferedWriter(new FileWriter(options.outputFileName + ".kim"));//For isBinaryGtyOut. 
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".kim" + ".gz"));
                    bwMapKed = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    bwMapKed = new BufferedWriter(new FileWriter(options.outputFileName + ".kim"));
                }
            }

            File vcfFilteredInFile = null;
            BlockCompressedOutputStream vcfFilteredInFileWriter = null;
            // BufferedWriter vcfFilteredInFileWriter = null;
            //output VCF data for rvtestGene
            if (options.isVCFOut) {
                vcfFilteredInFile = new File(options.outputFileName + ".flt.vcf.gz");
                vcfFilteredInFileWriter = new BlockCompressedOutputStream(vcfFilteredInFile);
                /*
                if (options.outGZ) {                                  
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(vcfFilteredInFile.getCanonicalPath()));
                    vcfFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                     
                } else {                  
                    vcfFilteredInFile = new File(options.outputFileName + ".flt.vcf");
                    vcfFilteredInFileWriter = new BufferedWriter(new FileWriter(vcfFilteredInFile));                    
                }
                 */
                //vcfFilteredInFileWriter = new BufferedWriter(new FileWriter(vcfFilteredInFile));
                vcfFilteredInFileWriter.write(vsParser.getVcfHead().toString().getBytes());
                vcfFilteredInFileWriter.write("#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT".getBytes());
                for (Individual indiv : subjectList) {
                    if (!indiv.isHasGenotypes()) {
                        continue;
                    }
                    vcfFilteredInFileWriter.write("\t".getBytes());
                    vcfFilteredInFileWriter.write(indiv.getLabelInChip().getBytes());
                }
                vcfFilteredInFileWriter.write("\n".getBytes());
            }

            File simpleVcfFilteredInFile = null;
            BlockCompressedOutputStream simpleVcfFilteredInFileWriter = null;

            if (options.isSimpleVCFOut) {
                simpleVcfFilteredInFile = new File(options.outputFileName + ".flt.simple.vcf.gz");
                simpleVcfFilteredInFileWriter = new BlockCompressedOutputStream(simpleVcfFilteredInFile);
                if (options.inputFormat.endsWith("--ked-file")) {
                    simpleVcfFilteredInFileWriter.write("##fileformat=VCFv4.1\n".getBytes());
                    simpleVcfFilteredInFileWriter.write("##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n".getBytes());
                } else {
                    simpleVcfFilteredInFileWriter.write(vsParser.getVcfHead().toString().getBytes());
                }
                simpleVcfFilteredInFileWriter.write("#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT".getBytes());
                for (Individual indiv : subjectList) {
                    if (!indiv.isHasGenotypes()) {
                        continue;
                    }
                    simpleVcfFilteredInFileWriter.write("\t".getBytes());
                    simpleVcfFilteredInFileWriter.write(indiv.getLabelInChip().getBytes());
                }
                simpleVcfFilteredInFileWriter.write("\n".getBytes());
            }

            boolean needWriteTmp = false;

            BufferedWriter tmpWriter = null;
            if (needWriteTmp) {
                //tmpWriter = new BufferedWriter(new FileWriter(options.outputFileName + ".tmp.maf"));
                //tmpWriter.write("chr	pos	ref_allele	newbase	classification	count\n");
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".tmp.maf.gz"));
                tmpWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
            }

            BufferedWriter finalExportWriter = null;
            if (options.excelOut) {
                if (options.outGZ) {
                    finalFilteredInFile = new File(options.outputFileName + ".flt.xls.gz");
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(finalFilteredInFile.getCanonicalPath()));
                    finalExportWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                    //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), true);
                } else {
                    finalFilteredInFile = new File(options.outputFileName + ".flt.xls");
                    finalExportWriter = new BufferedWriter(new FileWriter(finalFilteredInFile));
                    //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), false);
                }
            } else if (options.outGZ) {
                finalFilteredInFile = new File(options.outputFileName + ".flt.txt.gz");
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(finalFilteredInFile.getCanonicalPath()));
                finalExportWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), true);
            } else {
                finalFilteredInFile = new File(options.outputFileName + ".flt.txt");
                finalExportWriter = new BufferedWriter(new FileWriter(finalFilteredInFile));
                //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), false);
            }

            Genome refhapGenome = null;
            List<Individual> refIndivList = null;
            BufferedWriter mergedBwMap = null;
            BufferedOutputStream mergedFileStream = null;
            WritableByteChannel mergedFileChannel = null;
            int[] coutVar = new int[1];
            int[] intsSPV = new int[2];
            int[] intsIndiv = new int[1];

            if (options.mergeGtyDb != null && (options.isPlinkPedOut || options.isPlinkBedOut)) {
                refIndivList = new ArrayList<Individual>();
                String vcfFilePath = GlobalManager.RESOURCE_PATH + "/" + options.mergeGtyDb + ".chr1.vcf.gz";
                vsParser.extractSubjectIDsVCFInFile(vcfFilePath, refIndivList);

                if (!subjectList.isEmpty() && !refIndivList.isEmpty()) {
                    if (options.isPlinkBedOut) {
                        coutVar[0] = 0;
                        intsIndiv[0] = 0;
                        if (options.outGZ) {
                            GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".merged.bim" + ".gz"));
                            mergedBwMap = new BufferedWriter(new OutputStreamWriter(gzOut));
                        } else {
                            mergedBwMap = new BufferedWriter(new FileWriter(options.outputFileName + ".merged.bim"));
                        }

                        File bedMergedFile = new File(options.outputFileName + ".merged.bed");
                        if (bedMergedFile.exists()) {
                            bedMergedFile.delete();
                        }

                        if (options.outGZ) {
                            mergedFileChannel = Channels.newChannel(new FileOutputStream(bedMergedFile.getCanonicalPath() + ".gz"));
                            mergedFileStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(mergedFileChannel)));
                            //bwFileChannelBed=new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed))));
                        } else {
                            mergedFileChannel = Channels.newChannel(new FileOutputStream(bedMergedFile));
                            mergedFileStream = new BufferedOutputStream(Channels.newOutputStream(mergedFileChannel));
                        }

                        byte[] byteInfo = new byte[3];
                        //|-magic number-
                        //01101100 00011011
                        byteInfo[0] = (byte) 0x6C;

                        byteInfo[1] = (byte) 0x1B;

                        //|-mode-| 00000001 (SNP-major)
                        //00000001 
                        byteInfo[2] = 1;
                        mergedFileStream.write(byteInfo);

                        uniqueGenome.exportPlinkBinaryGtyFam(subjectList, refIndivList, options.outputFileName, intsIndiv, options.outGZ);
                    }

                    if (options.isPlinkPedOut) {
                        intsSPV[0] = 0;
                        intsSPV[1] = 0;
                        if (options.outGZ) {
                            GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".merged.map" + ".gz"));
                            mergedBwMap = new BufferedWriter(new OutputStreamWriter(gzOut));
                        } else {
                            mergedBwMap = new BufferedWriter(new FileWriter(options.outputFileName + ".merged.map"));
                        }
                    }
                }
            }

            BufferedWriter bwLD = null;
            if (options.calcLD) {
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ld" + ".gz"));
                    bwLD = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    bwLD = new BufferedWriter(new FileWriter(options.outputFileName + ".ld"));
                }
            }

            int[] effecIndexVarFreq = null;

            if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                if (popuNames != null) {
                    if (!popuNames[0].equals("CONTROL")) {
                        effecIndexVarFreq = new int[popuNames.length];
                        Arrays.fill(effecIndexVarFreq, -1);

                        for (int i = 0; i < effecIndexVarFreq.length; i++) {
                            String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/hg19/" + geneCoVarFiles[i];
                            BufferedReader br = LocalFileFunc.getBufferedReader(geneCoVarFilePath);
                            String[] cells = br.readLine().split("\t");
                            br.close();
                            for (int j = 0; j < cells.length; j++) {
                                if (popuNames[i].equals(cells[j])) {
                                    effecIndexVarFreq[i] = j;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
//*********************************************************************************************************************************************************************//
//-------------------------------------------------------------------Start to filter or annotate 
            Chromosome[] chromosomes = uniqueGenome.getChromosomes();

            int leftVar = -1;
            boolean needHead = true;
            List<Variant> chromosomeVarAll = new ArrayList<Variant>();
            int finalVarNum = 0;

            //MemoryCounter mc = new MemoryCounter();
            for (int chromID = 0; chromID < chromosomes.length; chromID++) {
                uniqueGenome.loadVariantFromDisk(chromID, needGty, origionallySorted, maxThreadID);//time-consuming part.                  
                if (chromosomes[chromID].variantList == null || chromosomes[chromID].variantList.isEmpty()) {
                    continue;
                }
                if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
                    chromosomeVarAll.addAll(chromosomes[chromID].variantList);
                }

                //More variant QC
                varFilter.sumFilterCaseControlVar(chromosomes[chromID], options.minHetA, options.minHomA, options.minHetU, options.minHomU, options.minOBSA, options.minOBSU, minMissingQCFilter1, mafSampleList);
                if (chromosomes[chromID].variantList.isEmpty()) {
                    //   LOG.info("0 sequence variant(s) are left finally!");
                }

                if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
                    varAnnoter.hweTestVar(chromosomes[chromID], options.hwdPCase, options.hwdPControl, options.hwdPAll, assHWD);
                }
                if (options.superdupFilter) {
                    varFilter.superDupFilter(chromosomes[chromID], assSDF22, refGenomeSD);
                    if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                        LOG.info("0 sequence variant(s) are left finally!");
                        continue;
                    }
                }

                if (referenceGenomes != null) {
                    for (int i = 0; i < referenceGenomes.length; i++) {
                        varAnnoter.geneFeatureAnnot(chromosomes[chromID].variantList, chromID, referenceGenomes[i], options.geneFeatureIn, availableFeatureSizeForGeneDB[i], options.threadNum);
                        // varAnnoter.geneFeatureAnnot(chromosomes[chromID], chromID, referenceGenomes[i], options.geneFeatureIn, availableFeatureSizeForGeneDB[i]);
                    }

                    if (options.contextAnnotGFDis > 0) {
                        List<Variant> newVariantList = varAnnoter.contextBasedAnnotion(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), mergedGeneCodingRegions, pedEncodeGytIDMap, caeSetID, controlSetID, options.contextAnnotGFDis);
                        if (newVariantList.size() > 0) {
                            for (int i = 0; i < referenceGenomes.length; i++) {
                                varAnnoter.geneFeatureAnnot(newVariantList, chromID, referenceGenomes[i], options.geneFeatureIn, availableFeatureSizeForGeneDB[i], options.threadNum);
                            }
                        }
                        chromosomes[chromID].variantList.clear();
                        chromosomes[chromID].variantList.addAll(newVariantList);
                        chromosomes[chromID].setHasNotOrderVariantList(true);
                        chromosomes[chromID].buildVariantIndexMap();
                    }

                    varFilter.geneFeatureFilter(chromosomes[chromID], variantsCounters, options.geneFeatureIn, geneDBFilter7, useMinIDForGeneMapping);

                    if (options.geneDBLabels != null) {
                        if (!options.inGeneSet.isEmpty()) {
                            varFilter.keepGenesInSet(chromosomes[chromID], assGIS17d3, options.inGeneSet);
                        }
                        // only keep genes in outGeneSet
                        if (!options.outGeneSet.isEmpty()) {
                            varFilter.keepGenesOutSet(chromosomes[chromID], assGOS17d4, options.outGeneSet);
                        }
                    }
                }
                if (inheritanceModelFilter2 != null) {
                    varFilter.inheritanceModelFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caeSetID, controlSetID, genotypeFilters, inheritanceModelFilter2);

                }
                if (denovoModelFilter3 != null) {
                    varFilter.devnoMutationFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, controlSetID, setSampleIDList, options.noHomo, denovoModelFilter3);
                }

                if (needGty && options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8"))) {
                    varFilter.somaticMutationFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, controlSetID, setSampleIDList, setSampleLabelList, somaticModelFilter4, options.somatReadsP);

                }

                if (options.sampleVarHardFilterCode != null) {
                    if (uniqueFilters[0] || uniqueFilters[1]) {
                        varAnnoter.casecontrolUniqueModelFilterVar(chromosomes[chromID], assCCUMFV, uniqueFilters);
                    }
                }

                if (varaintDBHardFilterFiles5 != null) {
                    for (int i = 0; i < varaintDBHardFilterFiles5.length; i++) {
                        leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBHardFilterFiles5[i], options.needProgressionIndicator);
                        if (leftVar == 0) {
                            break;
                        }
                        chromosomes[chromID].buildVariantIndexMap();
                    }
                }

                if (varaintDBFilterFiles6 != null) {
                    for (int i = 0; i < varaintDBFilterFiles6.length; i++) {
                        // varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBFilterFiles6[i], options.needProgressionIndicator);
                        String dbLabelName = options.varaintDBLableList.get(i);
                        String filePath = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);
                        if (filePath.endsWith("vcf.gz")) {
                            varAnnoter.markByVCFAlleleFormatThread(filePath, freqColIndexes[i], chromosomes[chromID], varaintDBFilterFiles6[i], options.threadNum);
                        } else {
                            varAnnoter.markByANNOVARefFormatThread(filePath, chromosomes[chromID], varaintDBFilterFiles6[i], options.threadNum);
                        }
                    }
                }

                if (assLocalHardFilterFile5 != null) {
                    for (int i = 0; i < assLocalHardFilterFile5.length; i++) {
                        leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterFile5[i], options.needProgressionIndicator);
                        if (leftVar == 0) {
                            break;
                        }
                        chromosomes[chromID].buildVariantIndexMap();
                    }
                }

                if (assLocalFilterFile6 != null) {
                    for (int i = 0; i < assLocalFilterFile6.length; i++) {
                        varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterFile6[i], options.needProgressionIndicator);
                    }
                }

                if (assLocalHardFilterVCFFile5 != null) {
                    for (int i = 0; i < assLocalHardFilterVCFFile5.length; i++) {
                        leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterVCFFile5[i], options.needProgressionIndicator);
                        if (leftVar == 0) {
                            break;
                        }
                        chromosomes[chromID].buildVariantIndexMap();
                    }
                }

                if (assLocalFilterVCFFile6 != null) {
                    for (int i = 0; i < assLocalFilterVCFFile6.length; i++) {
                        varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterVCFFile6[i], options.needProgressionIndicator);
                    }
                }

                if (assLocalHardFilterNoGtyVCFFile5 != null) {
                    for (int i = 0; i < assLocalHardFilterNoGtyVCFFile5.length; i++) {
                        leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterNoGtyVCFFile5[i], options.needProgressionIndicator);
                        if (leftVar == 0) {
                            break;
                        }
                        chromosomes[chromID].buildVariantIndexMap();

                    }
                }

                if (assLocalFilterNoGtyVCFFile6 != null) {
                    for (int i = 0; i < assLocalFilterNoGtyVCFFile6.length; i++) {
                        varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterNoGtyVCFFile6[i], options.needProgressionIndicator);

                    }
                }

                if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
                    if (options.isAlleleFreqExcMode) {
                        varFilter.filterByAlleleFreqExcModel(chromosomes[chromID], assFBAFEM, options.minAlleleFreqExc, mafRefList);
                    } else {
                        varFilter.filterByAlleleFreqIncModel(chromosomes[chromID], assFBAFIM, options.minAlleleFreqInc, options.maxAlleleFreqInc, mafRefList);
                    }
                }
                if (chromosomes[chromID].variantList.isEmpty()) {
                    continue;
                }
                if (options.varAssoc) {
                    varAnnoter.assocTestVar(chromosomes[chromID], assSVHF, varPArray);
                    if (options.pValueThreshold != -9) {
                        varFilter.filterBy4ModelPValue(chromosomes[chromID], assSVHF, options.pValueThreshold, uniqueGenome);
                    }
                }

                if (options.varGenetScore) {//                    
                    varFilter.genetScoringVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caeSetID, controlSetID, genotypeFilters, inheritanceModelFilter2);
                }

                Chromosome tmpChrom = null;
                if (!useLocalGeneScore) {
                    if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                        String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/hg19/" + geneCoVarFiles[0];

                        tmpChrom = geneAnnotor.readAnnotGeneVarFreq(geneCoVarFilePath, chromID, effecIndexVarFreq[0], 0, effecIndexVarFreq.length, options.dependentGeneFeature, options.dependentMaxIntronFeature, useMinIDForGeneMapping, options.ctType);
                        for (int i = 1; i < geneCoVarFiles.length; i++) {
                            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/hg19/" + geneCoVarFiles[i];
                            geneAnnotor.appendAnnotGeneVarFreq(tmpChrom, geneCoVarFilePath, chromID, effecIndexVarFreq[i], i, effecIndexVarFreq.length, options.dependentGeneFeature);
                        }

                    }
                }

                int scoreIndex = -1;
                if (dbNSFPAnnot8 != null) {
                    String dbLabelName = "dbnsfp";
                    if (options.scoreDBLableList.contains(dbLabelName)) {
                        String dbFileName = options.PUBDB_FILE_MAP.get(dbLabelName);
                        // varAnnoter.readExonicScoreNSFPNucleotideMerge(chromosomes[chromID], GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8, options.needProgressionIndicator);
                        varAnnoter.readExonicScoreNSFPNucleotideMergeMultiThread(chromosomes[chromID], GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8, options.needProgressionIndicator, options.threadNum);

                        if (options.causingNSPredType == 0) {
//riskPredictionRareDiseaseAll(Chromosome chromosome, List<CombOrders> combOrderList, boolean filterNonDisMut, List<String> names, FiltrationSummarySet dbNSFPPred9)
                            if (options.predictExplanatoryVar.startsWith("best")) {
                                varAnnoter.riskPredictionRareDiseaseAllBest(chromosomes[chromID], combOrderList, options.mendelBestModelNum, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), options.threadNum, dbNSFPPred9);
                            } /*else if (options.predictExplanatoryVar.startsWith("best")) {
                                varAnnoter.riskPredictionRareDiseaseBest(chromosomes[chromID], combOrderList, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                            }*/ else {
                                varAnnoter.riskPredictionRareDiseaseFixParam(chromosomes[chromID], fixedComb, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                            }
                            scoreIndex = dbNSFPPred9.getAvailableFeatureIndex();
                        } else if (options.causingNSPredType == 2) {
                            //Chromosome chromosome, MyRandomForest myRandomForestsCancer, boolean filterNonDisMut, FiltrationSummarySet dbNSFPPred9
                            varAnnoter.riskPredictionRandomForest(chromosomes[chromID], myRandomForestsCancer, options.threadNum, options.filterNonDiseaseMut, dbNSFPPred9);
                            scoreIndex = dbNSFPPred9.getAvailableFeatureIndex() + 1;
                        }

                        if (tmpChrom != null) {
                            varAnnoter.readExonicScoreNSFPNucleotideMergeMultiThread(tmpChrom, GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8Tmp, options.needProgressionIndicator, options.threadNum);

                            if (options.causingNSPredType == 0) {
//riskPredictionRareDiseaseAll(Chromosome chromosome, List<CombOrders> combOrderList, boolean filterNonDisMut, List<String> names, FiltrationSummarySet dbNSFPPred9)
                                if (options.predictExplanatoryVar.startsWith("best")) {
                                    varAnnoter.riskPredictionRareDiseaseAllBest(tmpChrom, combOrderList, options.mendelBestModelNum, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), options.threadNum, dbNSFPPred9Tmp);
                                } /*else if (options.predictExplanatoryVar.startsWith("best")) {
                                varAnnoter.riskPredictionRareDiseaseBest(chromosomes[chromID], combOrderList, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                            }*/ else {
                                    varAnnoter.riskPredictionRareDiseaseFixParam(tmpChrom, fixedComb, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9Tmp);
                                }
                            } else if (options.causingNSPredType == 2) {
                                varAnnoter.riskPredictionRandomForest(tmpChrom, myRandomForestsCancer, options.threadNum, options.filterNonDiseaseMut, dbNSFPPred9Tmp);
                            }
                        }

                    }
                }

                if (dbNoncodePred9d0 != null) {
                    varAnnoter.readNocodeScoreNucleotideMultiThread(annNCFPPath, chromosomes[chromID], dbNoncodePred9d0, options.threadNum, 2);
                    if (tmpChrom != null) {
                        varAnnoter.readNocodeScoreNucleotideMultiThread(annNCFPPath, tmpChrom, dbNoncodePred9d0Tmp, options.threadNum, 2);
                    }
                }
                if (dbNoncodePred9d1 != null) {
                    /*
                    //varAnnoter.noncodingRandomForestGFC(chromosomes[chromID], needProgressionIndicator, filterNonDisMut, needThreadNumber);
                    currentLineList = varAnnoter.noncodingRandomForestGFC(chromosomes[chromID], options.needProgressionIndicator, options.filterNonDiseaseMut,
                            options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                            lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                            options.needVerboseNoncode, dbNoncodePred9d1.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1);
                     */

                    currentLineList = varAnnoter.noncodingRandomForestGFRegions(chromosomes[chromID], options.needProgressionIndicator, options.filterNonDiseaseMut,
                            options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                            lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                            options.needVerboseNoncode, dbNoncodePred9d1.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1);
                    if (tmpChrom != null) {
                        currentLineList = varAnnoter.noncodingRandomForestGFRegions(tmpChrom, options.needProgressionIndicator, options.filterNonDiseaseMut,
                                options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                                lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                                options.needVerboseNoncode, dbNoncodePred9d1Tmp.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1Tmp);
                    }
                    scoreIndex = dbNoncodePred9d1.getAvailableFeatureIndex();
                }

                if (dbNoncodePred9d2 != null) {
                    // noncode 4 represents 4 calcualting parameters (BF,Composite_P,Cell_P,Combine_P)
                    /*
                    varAnnoter.noncodingCellTypeSpecificPrediction(chromosomes[chromID], options.needProgressionIndicator, lineReaderList9d2,
                            bayesPredictor, chromID, dbNoncodePred9d2.getAvailableFeatureIndex(),
                            dbNoncodePred9d2.getAvailableFeatureIndex() + options.dbncfpFeatureColumn.length + 4);
                     */

                    varAnnoter.noncodingCompositPredictionMultiThread(chromosomes[chromID], options.usedDBncfpFeatureIndex,
                            bayesPredictor, dbNoncodePred9d2.getAvailableFeatureIndex(), options.threadNum, baye1NonCodingPredic,
                            baye2NonCodingPredic, options.cellLineName != null);
                    if (tmpChrom != null) {
                        varAnnoter.noncodingCompositPredictionMultiThread(tmpChrom, options.usedDBncfpFeatureIndex,
                                bayesPredictor, dbNoncodePred9d2Tmp.getAvailableFeatureIndex(), options.threadNum, baye1NonCodingPredic,
                                baye2NonCodingPredic, options.cellLineName != null);
                    }
                    if (options.cellLineName != null) {
                        scoreIndex = dbNoncodePred9d2.getAvailableFeatureIndex() + 2;
                    } else {
                        scoreIndex = dbNoncodePred9d2.getAvailableFeatureIndex() + 1;
                    }
                }

                //this should not be filttered by gene-feature; this will be used for gene-based analysis
                if (somatNumIndex >= 0) {
                    if (useMinIDForGeneMapping) {
                        // varAnnoter.summarizeMinIDSomaticVarPerGene(chromosomes[chromID], somatNumIndex, readInfoIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, funcScoreBinLen);
                        // varAnnoter.summarizeSomaticVarPerGene(chromosomes[chromID], somatNumIndex, readInfoIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, funcScoreBinLen);

                    } else {
                        varAnnoter.summarizeSomaticVarPerGene(chromosomes[chromID], somatNumIndex, readInfoIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, funcScoreBinLen);
                    }

                } else {
                    if (tmpChrom != null) {
                        if (useMinIDForGeneMapping) {
                            geneAnnotor.generateGeneVarMinIDFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                        } else {
                            geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                        }

// geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, scorePercentiles, scoreCutoffs, chromID == 0, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                        //geneAnnotor.generateGeneVarFreq(tmpChrom, options.minAlleleFreqExc * mafFolder, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                    }
                    if (useMinIDForGeneMapping) {
                        //options.minAlleleFreqExc*2
                        if (useLocalGeneScore) {
                            varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen, localGeneFreqScores, hittedGeneSet, mafBins);
                        } else {
                            varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen);
                        }
                        //           
                    } else {
                        varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc, funcScoreBinLen);
                    }

                    //varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc, scoreCutoffs);
                }

                if (options.ldPruning) {
                    varAnnoter.LDPruneWithinDistance(chromosomes[chromID], subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, options.ldPrunWindowSize, options.ldPrunR2, ldPruningASS);
                }

                System.gc();
                if (options.geneMaxVarPerPerson > 0) {
                    //    varFilter.filterByGeneVarNum(chromosomes[chromID], assGVF10, options.geneMaxVarPerPerson, uniqueGenome.getVariantFeatureLabels(), uniqueGenome.isIsPhasedGty());
                }

                if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {

                    if (uniqueGenome.getGeneNum() > 0) {
                        varAnnoter.canidateGeneExploreGene(chromosomes[chromID], assG11, options.candidateGeneSet);
                    } else if (uniqueGenome.getVarNum() > 0) {
                        varAnnoter.canidateGeneExploreVar(chromosomes[chromID], assV12, options.candidateGeneSet);
                    }

                    if (options.ppiDB != null) {
                        if (uniqueGenome.getGeneNum() > 0) {
                            varAnnoter.canidateGenePPIExploreGene(chromosomes[chromID], assPPIG13, options.candidateGeneSet, ppiTree, options.ppiDepth);
                        } else if (uniqueGenome.getVarNum() > 0) {
                            varAnnoter.canidateGenePPIExploreVar(chromosomes[chromID], assPPIV14, options.candidateGeneSet, ppiTree, options.ppiDepth);
                        }
                    }

                    if (mappedPathes != null) {
                        if (uniqueGenome.getGeneNum() > 0) {
                            varAnnoter.canidateGenePathwayExploreGene(chromosomes[chromID], assPWG15, options.candidateGeneSet, mappedPathes);
                        } else if (uniqueGenome.getVarNum() > 0) {
                            varAnnoter.canidateGenePathwayExploreVar(chromosomes[chromID], assPWV16, options.candidateGeneSet, mappedPathes);
                        }
                    }
                }

                if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                    varAnnoter.exploreLongIBSRegion(chromosomes[chromID], assIBS17d1, chromosomeVarAll, options.ibsCheckCase * 1000, uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caeSetID);
                }

                if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                    varAnnoter.exploreLongHomozygosityRegion(chromosomes[chromID], assHRC17d2, chromosomeVarAll, options.homozygousRegionCase * 1000, uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caeSetID, controlSetID);
                }
                //to save memory
                chromosomeVarAll.clear();

                if (options.ibdFileName != null) {
                    varAnnoter.ibdRegionExplore(chromosomes[chromID], assIBD17d5, regionItems);
                }

                if (dbScSNV18 != null) {
                    varAnnoter.dbscSNV(chromosomes[chromID], dbScSNV18, options.needProgressionIndicator);
                }

                int predictionIDCol = -1;
                if (dbNSFPPred9 != null) {
                    predictionIDCol = dbNSFPPred9.getAvailableFeatureIndex();
                }

                // System.out.println(chromID);
                if (doubleHitGeneModelFilter19 != null) {
                    if (options.doubleHitGeneTriosCasePsudo) {
                        chromDoubleHitGeneScoresMap = varFilter.doubleHitGeneExploreVarTriosSudoControl(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                                options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, options.countAllPsudoControl,
                                doubleHitGeneModelFilter19, options.pubmedMiningGene, predictionIDCol);

                    } else if (options.doubleHitGeneTriosFilter) {
                        varFilter.doubleHitGeneExploreVarTriosFilter(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                                options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, doubleHitGeneModelFilter19, options.pubmedMiningGene);

                    } else if (options.doubleHitGeneTriosCaseControl) {
                        varFilter.doubleHitGeneExploreVarTriosCaseControl(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                                options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, doubleHitGeneModelFilter19, options.pubmedMiningGene);
                    }
                }
                if (doubleHitGeneModelFilter19d1 != null) {
                    varFilter.doubleHitGeneExploreVarPhasedGty(chromosomes[chromID], pedEncodeGytIDMap, caeSetID, controlSetID, options.searchList, geneNamesMap, genePubMedID,
                            options.noHomo, pathogenicPredicIndex, doubleHitGenePhasedGenes, doubleHitGenePhasedReads, caseDoubleHitPhasedGenes, controlDoubleHitPhasedGenes, doubleHitGeneModelFilter19d1, options.pubmedMiningGene);
                }

                if (options.needAnnotateGene) {
                    String fileNameHg = "HgncGene.txt";
                    File resourceFileHg = new File(GlobalManager.RESOURCE_PATH + "/" + fileNameHg);
                    if (uniqueGenome.getGeneNum() > 0) {
                        varAnnoter.pseudogeneAnnotationGene(chromosomes[chromID], assGene20, resourceFileHg.getCanonicalPath());
                    } else if (uniqueGenome.getVarNum() > 0) {
                        varAnnoter.pseudogeneAnnotationVar(chromosomes[chromID], assVariant20, resourceFileHg.getCanonicalPath());
                    }
                }

                if (options.omimAnnotateGene) {
                    File resourceFileOmim = new File(GlobalManager.RESOURCE_PATH + "/morbidmap.gz");
                    if (uniqueGenome.getGeneNum() > 0) {
                        varAnnoter.omimGeneAnnotationGene(chromosomes[chromID], assOmimGene21, resourceFileOmim.getCanonicalPath());
                    } else if (uniqueGenome.getVarNum() > 0) {
                        varAnnoter.omimGeneAnnotationVar(chromosomes[chromID], assOmimVar21, resourceFileOmim.getCanonicalPath());
                    }
                }

                if (options.tissueSpecAnnot) {

                    if (uniqueGenome.getGeneNum() > 0) {
                        //  varAnnoter.omimGeneAnnotationGene(chromosomes[chromID], assOmimGene21, resourceFileOmim.getCanonicalPath());
                    } else if (uniqueGenome.getVarNum() > 0) {
                        varAnnoter.tissueSpecGeneAnnotationVar(chromosomes[chromID], assTissueSpecVar21, tissueSpecGeneMap);
                    }

                }

                if (options.superdupAnnotate) {
                    varAnnoter.superDupAnnotation(chromosomes[chromID], assSDA22, refGenomeSD);
                }

                if (options.dgvcnvAnnotate) {
                    varAnnoter.cnvAnnotation(chromosomes[chromID], assDGV23, refGenomeDGV);
                }

                if (options.overlappedGeneFilter) {
                    varAnnoter.overlappedGeneExploreVar(chromosomes[chromID], assOLGF, subjectList, pedEncodeGytIDMap, options.filterNonDiseaseMut, caseSubIDs, controlSubIDs, pathogenicPredicIndex, uniqueGenome);
                }

                if (options.simulGeneRegionsGtyNum > 0 && options.doubleHitGeneTriosCasePsudo) {
                    String dbFileName = options.PUBDB_FILE_MAP.get("dbnsfp");

                    //coresponding to different populatons, currently it only consideres the first  
                    //System.out.println(chromosomes[chromID].getName());
                    geneAnnotor.geneScoreSimulationMultiThread(chromDoubleHitGeneScoresMap, chromosomes[chromID].getName(), mergedGeneCodingRegions, GlobalManager.RESOURCE_PATH + "/" + dbFileName,
                            dbNSFP3ScoreIndexes, varaintDBFilterFiles, freqColIndexes, options.threadNum, combOrderList, options.mendelBestModelNum,
                            options.isAlleleFreqExcMode, options.minAlleleFreqExc, options.minAlleleFreqInc, options.maxAlleleFreqInc, options.threadNum, options.simulGeneRegionsGtyNum, effectiveIndivIDsTrios.size(), options.noHomo);
                    /*
                    geneAnnotor.geneScoreSimulationMultiThread1(chromDoubleHitGeneScoresMap, chromosomes[chromID].getName(), mergedGeneCodingRegions, GlobalManager.RESOURCE_PATH + "/" + dbFileName,
                            dbNSFP3ScoreIndexes, varaintDBFilterFiles, freqColIndexes, options.threadNum, combOrderList, options.mendelBestModelNum,
                            options.isAlleleFreqExcMode, options.minAlleleFreqExc, options.minAlleleFreqInc, options.maxAlleleFreqInc, options.threadNum, options.simulGeneRegionsGtyNum, effectiveIndivIDsTrios.size());
                     */

                    allDoubleHitGeneScoresMap.putAll(chromDoubleHitGeneScoresMap);

                }

                if (options.phenoMouse) {
                    varAnnoter.annotateGenesArray(chromosomes[chromID], assMousePheno, g2MP, 2);
                }
                if (options.zebraFish) {
                    varAnnoter.annotateGenes(chromosomes[chromID], assZebra, xebraP2Phe);
                }
                if (options.dddPhenotypes) {
                    varAnnoter.annotateGenes(chromosomes[chromID], assDDD, dddP2Phe);
                }

                if (options.searchList != null && !options.searchList.isEmpty()) {
                    if (uniqueGenome.getGeneNum() > 0) {
                        if (options.pubmedMiningIdeo) {
                            varAnnoter.pubMedIDIdeogramExploreGene(chromosomes[chromID], pubmedSearch24_Gene_Ideo, options.searchList, ideogramItemsGene);
                        }
                        if (options.pubmedMiningGene) {
                            varAnnoter.pubMedIDGeneExploreGene(chromosomes[chromID], pubmedSearch24_Gene, options.searchList, geneNamesMap, genePubMedID);
                        }
                    } else if (uniqueGenome.getVarNum() > 0) {
                        if (options.pubmedMiningIdeo) {
                            varAnnoter.pubMedIDIdeogramExploreVar(chromosomes[chromID], pubmedSearch24_Var_Ideo, options.searchList, ideogramItemsVar, options.refGenomeVersion, true, driverPredicIndex);
                        }
                        if (options.pubmedMiningGene) {
                            varAnnoter.pubMedIDGeneExploreVar(chromosomes[chromID], pubmedSearch24_Var, options.searchList, true, geneNamesMap, genePubMedID, driverPredicIndex);
                        }
                    }
                }
                if (chromosomes[chromID].variantList.isEmpty()) {
                    chromosomes[chromID].getPosIndexMap().clear();
                    chromosomeVarAll.clear();
                    System.gc();
                    continue;
                }
                if (options.rsid) {
                    varAnnoter.addRSID(chromosomes[chromID], assRSID25, altMapID[chromID]);
                }

                if (options.flankingSequence > 0) {
                    seqRe.addFlankingSequences(chromosomes[chromID], assFS, options.flankingSequence, options.refGenomeVersion);
                }
                if (options.phenolyzer) {
                    phenolyzer.addScore(chromosomes[chromID], assPhenolyzer26, hmpPhenolyzer);
                }

                geneVars.clear();
                if (options.skatGeneset || options.rvtestGeneset || options.isGeneVarGroupFileOut || options.rvtestGene || options.skatGene || (dbPathwaySet != null && !dbPathwaySet.isEmpty())) {
                    varAnnoter.assignSelectedVar2Genes(chromosomes[chromID].variantList, STAND_CHROM_NAMES[chromID], geneVars, options.independentGeneFeature);
                }

                if (options.skatGene) {
                    if (skat.boolSnowFail) {
                        skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), 1, genePVList, -1);
                    } else {
                        skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, genePVList, -1);
                    }
                }

                if (options.mendelGenePatho) {
                    varAnnoter.addPatho(chromosomes[chromID], assPatho27, hmpPatho, intPatho);
                }
                if (options.cosmicAnnotate) {
                    varAnnoter.cosmicGeneAnnotationVar(chromosomes[chromID], cosmicDBAnnot28, cosmicGeneMut);
                }

                if (!subjectList.isEmpty()) {
                    if (options.isPlinkBedOut) {
                        uniqueGenome.exportPlinkBinaryGty(chromosomes[chromID], subjectList, pedEncodeGytIDMap, fileBedStream, bwMapBed, savedBinnaryBedVar);
                    }
                    if (options.isBinaryGtyOut) {
                        uniqueGenome.exportKGGSeqBinaryGty(chromosomes[chromID], filelKedStream, bwMapKed, savedBinnaryKedVar);
                    }
                    if (options.isPlinkPedOut) {
                        uniqueGenome.export2FlatTextPlink(chromosomes[chromID], subjectList, pedEncodeGytIDMap, bwMapPed, options.outputFileName, savedPedVar, options.outGZ);
                    }
                }

                if (needWriteTmp) {
                    //uniqueGenome.export2ATmpFormat(tmpWriter, chromID);
                    uniqueGenome.export2ANNOVARAnnot(tmpWriter, chromID);

                }
                if (options.isANNOVAROut) {
                    uniqueGenome.export2ANNOVARInput(annovarFilteredInFileWriter, chromID);
                }

                if (options.isGeneVarGroupFileOut) {
                    uniqueGenome.export2GeneVarGroupFile(bwGeneVarGroupFile, chromID, geneVars);
                }
                //to release memory, release all lefte variants on this chromosome  and unused feature of variants
                uniqueGenome.outputVariant2FlatTextAndReleaseRAM(finalExportWriter, chromID, needHead, options.needRecordAltFreq, options.refGenomeVersion);//To write the result into a temp file. 
                System.gc();

                if (options.isVCFOut) {
                    //Othervise this will repeat twice
                    if (origionallySorted[0]) {
                        writenVCFVarNum += uniqueGenome.export2VCFFormatNoSorting(vcfFilteredInFileWriter, chromosomes[chromID], maxEffectiveColVCF, maxThreadID[0]);
                    } else {
                        writenVCFVarNum += uniqueGenome.export2VCFFormatSorting(vcfFilteredInFileWriter, chromosomes[chromID], maxEffectiveColVCF, options.threadNum, maxThreadID[0]);
                    }
                }
                if (options.isSimpleVCFOut) {
                    uniqueGenome.export2VCFFormatSimple(simpleVcfFilteredInFileWriter, chromosomes[chromID], subjectList.size(), pedEncodeGytIDMap, hasChrLabel);
                }

                if (options.rvtestGene) {
                    BufferedWriter bwGeneRVTestGroupFile = null;
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".chr" + STAND_CHROM_NAMES[chromID] + ".gene.rvtest.grp.gz"));
                    bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
                    uniqueGenome.export2GeneVarGroupFileRVTest(bwGeneRVTestGroupFile, chromID, geneVars, options.rvtestMinVar, hasChrLabel, null);

                    bwGeneRVTestGroupFile.close();
                }

                if (options.rvtestVar) {
                    BufferedWriter bwGeneRVTestGroupFile = null;
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".chr" + STAND_CHROM_NAMES[chromID] + ".var.rvtest.grp.gz"));
                    bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
                    uniqueGenome.export2GeneVarGroupFileRVTest(bwGeneRVTestGroupFile, chromID, geneVars, options.rvtestMinVar, hasChrLabel, null);
                    bwGeneRVTestGroupFile.close();
                }
                if (options.calcLD) {
                    varAnnoter.calculateLDVar(chromosomes[chromID], subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, options.ldPrunWindowSize, options.ldPrunR2, bwLD);
                }

                if (options.mergeGtyDb != null && (options.isPlinkPedOut || options.isPlinkBedOut)) {
                    //a special function to merge public resoruces
                    String vcfFilePath = GlobalManager.RESOURCE_PATH + "/" + options.mergeGtyDb + ".chr" + chromosomes[chromID].getName() + ".vcf.gz";
                    File f = new File(vcfFilePath);
                    if (f.exists()) {
                        refhapGenome = vsParser.readVariantGtyFilterOnly("1kgmerge", options.threadNum, null, vcfFilePath, options.seqQual, options.minMappingQuality, options.maxStandBias,
                                options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                                options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel,
                                options.ignoreCNV, options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, true, false, false, false, false, options.forced2Unphased, null, null, null, null, null, null, options.groupTags, hasGty);
                        int[] refPedEncodeGytIDMap = vsParser.getPedEncodeGytIDMap();

                        refhapGenome.loadVariantFromDisk(chromID, true, origionallySorted, maxThreadID);

                        if (!subjectList.isEmpty() && !refIndivList.isEmpty()) {
                            if (options.isPlinkBedOut) {
                                uniqueGenome.exportPlinkBinaryGty(chromosomes[chromID], subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], refhapGenome.isIsPhasedGty(), refIndivList, refPedEncodeGytIDMap, mergedFileStream, mergedBwMap, coutVar);//Write .bim and .bed file
                            }
                            //This is too slow. Only support the binary format
                            if (options.isPlinkPedOut) {
                                //  uniqueGenome.export2FlatTextPlink(chromosomes[chromID], wahBit, subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], wahBit1, true, refIndivList, refPedEncodeGytIDMap, mergedBwMap, options.outputFileName+".merged", intsSPV, options.outGZ);//Write .map and .ped file
                            }
                        }
                        refhapGenome.getChromosomes()[chromID].variantList.clear();

                    } else {
                        LOG.warn("The file," + f.getCanonicalPath() + ", does not exist and cannot be merged!");
                    }
                }

                finalVarNum += chromosomes[chromID].variantList.size();
                chromosomes[chromID].getPosIndexMap().clear();
                needHead = false;
                chromosomeVarAll.clear();
                chromosomes[chromID].variantList.clear();

                //set back genotypes 
                if (!geneVars.isEmpty() && (dbPathwaySet != null && !dbPathwaySet.isEmpty())) {
                    varAnnoter.assignSelectedVar2Genesets(dbPathwaySet, geneVars, genesetVars, (byte) chromID, chromosomeVarAll);
                    /*
                    for (Variant var : chromosomeVarAll) {
                        if (var.compressedGtyLabel >= 0) {
                            continue;
                        }
                        for (long t = var.encodedGtyIndex[0]; t < var.encodedGtyIndex[1]; t++) {
                            if (wahBit.containsKey(t)) {
                                wahBitGeneset.put(wahBitGenesetSize + t - var.encodedGtyIndex[0], 0);
                            }
                        }
                        len = var.encodedGtyIndex[1] - var.encodedGtyIndex[0];
                        wahBitGenesetSize += len;
                        var.encodedGtyIndex[0] = wahBitGenesetSize - len;
                        var.encodedGtyIndex[1] = wahBitGenesetSize;
                    }
                     */
                }
                geneVars.clear();

                System.gc();
            }

//--------------------------------------------------The big circle has completed!------------------------------------------   
            if (needWriteTmp) {
                tmpWriter.close();
            }

            if (options.isVCFOut) {
                vcfFilteredInFileWriter.close();
            }
            if (options.isSimpleVCFOut) {
                simpleVcfFilteredInFileWriter.close();
                //Note: this VCF tabix function is subject to be fixed
                //LocalFileFunc.tabixVCFFile(simpleVcfFilteredInFile.getCanonicalPath());
                //LOG.info("The index file " + simpleVcfFilteredInFile.getCanonicalPath() + ".tbi is created.");
            }

            File rvTestGroupTestFile = null;
            File simpleIndiviGenesetSumFile = null;

            if ((options.skatGeneset || options.rvtestGeneset) && !genesetVars.isEmpty()) {
                RVTest rvtest = null;
                if (options.needNewVCFForRVTest) {
                    rvtest = new RVTest(null, options.outputFileName);
                } else {
                    rvtest = new RVTest(options.inputFileName, options.outputFileName);
                }
                rvtest.setCommand(options.rvtestCommand);

                featureLabels = uniqueGenome.getVariantFeatureLabels();
                int probIndex = -1;
                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("DiseaseCausalProb_ExoVarTrainedModel")) {
                        probIndex = i;
                        break;
                    }
                }
                if (!subjectList.isEmpty()) {
                    simpleIndiviGenesetSumFile = new File(options.outputFileName + ".geneset.indiv.sum");
                    rvtest.summarizeVarCountsBySubject(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.phenotypeColID, simpleIndiviGenesetSumFile.getCanonicalPath(), probIndex, false);
                }
                if (options.skatGeneset) {
                    if (skat.boolSnowFail) {
                        skat.runGenesetAssoc(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), 1, genePVList);
                    } else {
                        skat.runGenesetAssoc(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, genePVList);
                    }
                }

                if (options.rvtestGeneset) {
                    rvTestGroupTestFile = new File(options.outputFileName + ".geneset.rvtest.grp.gz");
                    BufferedWriter bwGeneRVTestGroupFile = null;
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(rvTestGroupTestFile));
                    bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
                    rvtest.generateGenesetAssocGroup(genesetVars, bwGeneRVTestGroupFile, hasChrLabel);
                    bwGeneRVTestGroupFile.close();
                }
                genesetVars.clear();
            }

//************************************************************************************************************************************************************************//
            finalExportWriter.close();
            if (annovarFilteredInFileWriter != null) {
                annovarFilteredInFileWriter.close();
            }

            if (minMissingQCFilter1 != null) {
                String info = minMissingQCFilter1.toString();
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
                minMissingQCFilter1 = null;
            }

            if (referenceGenomes != null) {
                for (int i = 0; i < referenceGenomes.length; i++) {
                    referenceGenomes[i] = null;
                }
            }

            if (variantsCounters != null) {
                double totolVarNum = 0;
                for (int num : variantsCounters) {
                    totolVarNum += num;
                }

                StringBuilder info = new StringBuilder();
                info.append("Gene feature summary of variants:\n");
                for (int i = 0; i < VAR_FEATURE_NAMES.length; i++) {
                    info.append(" ").append(i).append(".").append(VAR_FEATURE_NAMES[i]).append(": ").append(variantsCounters[i]).append(" (")
                            .append(Util.doubleToString(variantsCounters[i] / totolVarNum * 100, 3)).append("%)\n");
                }
                LOG.info(info);
                LOG.info(geneDBFilter7.toString());
            }

            if (inheritanceModelFilter2 != null) {
                String info = inheritanceModelFilter2.toString();
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
                inheritanceModelFilter2 = null;
            }

            if (denovoModelFilter3 != null) {
                String info = denovoModelFilter3.toString();
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
                denovoModelFilter3 = null;
            }

            if (somaticModelFilter4 != null) {
                String info = somaticModelFilter4.toString();
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
            }

            if (options.sampleVarHardFilterCode != null) {
                if (uniqueFilters[0] || uniqueFilters[1]) {
                    uniqueGenome.setVarNum(assCCUMFV.getAnnotNum());
                    if (uniqueGenome.getVarNum() == 0) {
                        LOG.info("0 sequence variant(s) are left finally!");

                    }
                    String info = assCCUMFV.getAnnotNum() + " variant(s) are left after filtration according to " + options.sampleVarHardFilterCode;
                    LOG.info(info);
                }
            }

            if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
                if (options.hwdPCase > 0) {
                    if (assHWD.getAnnotNum() > 0) {
                        String info = assHWD.getAnnotNum() + " sequence variants failed case-HWE test ( p <=" + options.hwdPCase + " ) and have been excluded!";
                        LOG.info(info);
                    }
                }
                if (options.hwdPControl > 0) {
                    if (assHWD.getLeftNum() > 0) {
                        String info = assHWD.getLeftNum() + " sequence variants failed control-HWE test ( p <=" + options.hwdPControl + " ) and have been excluded!";
                        LOG.info(info);
                    }
                }
                if (options.hwdPAll > 0) {
                    if (assHWD.getTotalNum() > 0) {
                        String info = assHWD.getTotalNum() + " sequence variants failed HWE test ( p <=" + options.hwdPAll + " ) and have been excluded!";
                        LOG.info(info);
                    }
                }
            }

            if (options.varAssoc) {
                if (options.pValueThreshold != -9) {
                    LOG.info(assSVHF.getLeftNum() + " variant(s) are left after filtering the p-value cutoff " + options.pValueThreshold + ".");
                }
            }

            String multiCorrMethodName = null;
            if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                multiCorrMethodName = "";
            } else if (options.multipleTestingMethod.equals("benfdr")) {
                multiCorrMethodName = " by Benjamini-Hochberg FDR";
            } else if (options.multipleTestingMethod.equals("bonhol")) {
                multiCorrMethodName = " by Bonferroni-Holm procedure";
            } else if (options.multipleTestingMethod.equals("bonf")) {
                multiCorrMethodName = " by Standard Bonferroni";
            }
            // if (options.sampleVarHardFilterCode != null && options.sampleVarHardFilterCode.equals("association") && options.inputFormat.endsWith("--vcf-file")) 
            if (options.toQQPlot && options.varAssoc) {
                List<String> nameList = new ArrayList<String>();
                nameList.add("Allelic");
                nameList.add("Dominant");
                nameList.add("Recessive");
                nameList.add("Genotypic");
                PValuePainter pvPainter = new PValuePainter(450, 450);
                File plotFile2 = new File(options.outputFileName + ".var.qq.png");
                StringBuilder message = new StringBuilder();

                if (options.pValueThreshold >= 0) {
                    if (multiCorrMethodName.length() > 0) {
                        message.append("Significance level of p value cutoffs for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ":\n");
                    } else {
                        message.append("Significance level of a fixed p value cutoff ").append(options.pValueThreshold).append(":\n");
                    }

                    double[] thrholds = new double[4];

                    for (int i = 0; i < 4; i++) {
                        message.append(" ");
                        if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                            thrholds[i] = options.pValueThreshold;
                        } else if (options.multipleTestingMethod.equals("benfdr")) {
                            thrholds[i] = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, varPArray[i]);
                        } else if (options.multipleTestingMethod.equals("bonhol")) {
                            thrholds[i] = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, varPArray[i]);
                        } else if (options.multipleTestingMethod.equals("bonf")) {
                            thrholds[i] = options.pValueThreshold / varPArray[i].size();
                        }
                        message.append(nameList.get(i));
                        message.append(": ");
                        message.append(thrholds[i]).append("\n");
                    }
                    LOG.info(message.substring(0, message.length() - 1));
                }

                pvPainter.drawMultipleQQPlot(Arrays.asList(varPArray), nameList, null, plotFile2.getCanonicalPath(), 1E-10);
                String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
                LOG.info(info);
                showPlots(new File[]{plotFile2});
            }

            if (options.toQQPlot && allDoubleHitGeneScoresMap != null && !allDoubleHitGeneScoresMap.isEmpty()) {
                List<String> nameList = new ArrayList<String>();
                nameList.add("Empirical p");

                PValuePainter pvPainter = new PValuePainter(450, 450);
                File plotFile2 = new File(options.outputFileName + ".doublehit.qq.png");
                StringBuilder message = new StringBuilder();
                DoubleArrayList pvalues = new DoubleArrayList();

                for (Map.Entry<String, double[]> item : allDoubleHitGeneScoresMap.entrySet()) {
                    pvalues.add(item.getValue()[1]);
                }
                if (options.pValueThreshold < 0) {
                    options.pValueThreshold = 0.05;
                }
                if (multiCorrMethodName.length() > 0) {
                    message.append("Significance level of p value cutoffs for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ": ");
                } else {
                    message.append("Significance level of a fixed p value cutoff ").append(options.pValueThreshold).append(": ");
                }

                double thrholds = 1;

                message.append(" ");
                if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                    thrholds = options.pValueThreshold;
                } else if (options.multipleTestingMethod.equals("benfdr")) {
                    thrholds = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, pvalues);
                } else if (options.multipleTestingMethod.equals("bonhol")) {
                    thrholds = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, pvalues);
                } else if (options.multipleTestingMethod.equals("bonf")) {
                    thrholds = options.pValueThreshold / pvalues.size();
                }
                message.append(nameList.get(0));
                message.append(": ");
                message.append(thrholds).append("\n");

                LOG.info(message.substring(0, message.length() - 1));
                List<DoubleArrayList> pList = new ArrayList<DoubleArrayList>();
                pList.add(pvalues);
                pvPainter.drawMultipleQQPlot(pList, nameList, null, plotFile2.getCanonicalPath(), 1E-10);
                String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
                LOG.info(info);
                showPlots(new File[]{plotFile2});
            }

            if (options.toQQPlot && options.skatGene) {
                List<String> nameList = new ArrayList<String>();
//                if (options.skatBinary) {
                nameList.add("SKAT");
                nameList.add("SKATO");
                nameList.add("Burden");
//                } else {
//                    nameList.add("SKAT");
//                    nameList.add("SKATO");
//                }

                PValuePainter pvPainter = new PValuePainter(450, 450);
                File plotFile2 = new File(options.outputFileName + ".skat.gene.qq.png");
                StringBuilder message = new StringBuilder();
                if (options.pValueThreshold < 0) {
                    options.pValueThreshold = 0.05;
                }
                if (multiCorrMethodName.length() > 0) {
                    message.append("Significance level of p value cutoffs for SKAT p-values for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ":\n");
                } else {
                    message.append("Significance level of a fixed p value cutoff for SKAT p-values ").append(options.pValueThreshold).append(" : ");
                }

                double[] thrholds = new double[4];
                for (int i = 0; i < genePVList.length; i++) {
                    message.append(" ");
                    if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                        thrholds[i] = options.pValueThreshold;
                    } else if (options.multipleTestingMethod.equals("benfdr")) {
                        thrholds[i] = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, genePVList[i]);
                    } else if (options.multipleTestingMethod.equals("bonhol")) {
                        thrholds[i] = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, genePVList[i]);
                    } else if (options.multipleTestingMethod.equals("bonf")) {
                        thrholds[i] = options.pValueThreshold / genePVList[i].size();
                    }
                    message.append(nameList.get(i));
                    message.append(": ");
                    message.append(thrholds[i]).append("; ");
                }
                LOG.info(message.substring(0, message.length() - 1));

                pvPainter.drawMultipleQQPlot(Arrays.asList(genePVList), nameList, null, plotFile2.getCanonicalPath(), 1E-10);
                String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
                LOG.info(info);
                showPlots(new File[]{plotFile2});

            }
            double[][] thresholds = {{0, 0.01}, {0.01, 0.02}, {0.02, 0.03}, {0.03, 0.04}, {0.04, 0.05}, {0.05, 0.06}, {0.06, 0.07}, {0.07, 0.08},
            {0.08, 0.09}, {0.09, 0.1}, {0.1, 0.11}, {0.11, 0.12}, {0.12, 0.13}, {0.13, 0.14}, {0.14, 0.15}, {0.15, 0.16}, {0.16, 0.17},
            {0.17, 0.18}, {0.18, 0.19}, {0.19, 0.2}, {0.2, 0.21}, {0.21, 0.22}, {0.22, 0.23}, {0.23, 0.24}, {0.24, 0.25}, {0.25, 0.26},
            {0.26, 0.27}, {0.27, 0.28}, {0.28, 0.29}, {0.29, 0.3}, {0.3, 0.31}, {0.31, 0.32}, {0.32, 0.33}, {0.33, 0.34}, {0.34, 0.35},
            {0.35, 0.36}, {0.36, 0.37}, {0.37, 0.38}, {0.38, 0.39}, {0.39, 0.4}, {0.4, 0.41}, {0.41, 0.42}, {0.42, 0.43}, {0.43, 0.44},
            {0.44, 0.45}, {0.45, 0.46}, {0.46, 0.47}, {0.47, 0.48}, {0.48, 0.49}, {0.49, 0.50001}};
            HistogramPainter pvPainter = new HistogramPainter(800, 600);
            if (options.toMAFPlotSample) {
                final File plotFile = new File(options.outputFileName + ".maf.sample.png");
                pvPainter.drawColorfulHistogramPlot(mafSampleList, thresholds, null, "MAF in reference DB", plotFile.getCanonicalPath());
                String info = "The Histogram plot of MAF is saved in " + plotFile.getCanonicalPath();
                LOG.info(info);
                showPlots(new File[]{plotFile});
            }

            if (varaintDBHardFilterFiles5 != null) {
                for (int i = 0; i < varaintDBHardFilterFiles5.length; i++) {
                    varaintDBHardFilterFiles5[i].getBr().close();
                    String info = varaintDBHardFilterFiles5[i].getLeftNum() + " variant(s) are left after hard filtering in database " + varaintDBHardFilterFiles5[i].getName() + ".";//+ ", which contains " + varaintDBHardFilterFiles5[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    varaintDBHardFilterFiles5[i] = null;
                }
            }

            if (varaintDBFilterFiles6 != null) {
                for (int i = 0; i < varaintDBFilterFiles6.length; i++) {
                    if (varaintDBFilterFiles6[i].getBr() != null) {
                        varaintDBFilterFiles6[i].getBr().close();
                    }
                    String info = varaintDBFilterFiles6[i].getLeftNum() + " variant(s) exist in " + varaintDBFilterFiles6[i].getName() + ".";// ", which contains " + varaintDBFilterFiles6[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    varaintDBFilterFiles6[i] = null;
                }
            }

            if (assLocalHardFilterFile5 != null) {
                for (int i = 0; i < assLocalHardFilterFile5.length; i++) {
                    assLocalHardFilterFile5[i].getBr().close();
                    String info = assLocalHardFilterFile5[i].getLeftNum() + " variant(s) are left after hard filtering in database " + assLocalHardFilterFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterFile5[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalHardFilterFile5[i] = null;
                }
            }

            if (assLocalFilterFile6 != null) {
                for (int i = 0; i < assLocalFilterFile6.length; i++) {
                    assLocalFilterFile6[i].getBr().close();
                    String info = assLocalFilterFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterFile6[i].getName() + ".";//+ ", which contains " + assLocalFilterFile6[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalFilterFile6[i] = null;
                }
            }

            if (assLocalHardFilterVCFFile5 != null) {
                for (int i = 0; i < assLocalHardFilterVCFFile5.length; i++) {
                    assLocalHardFilterVCFFile5[i].getBr().close();
                    String info = assLocalHardFilterVCFFile5[i].getLeftNum() + " variant(s) are left after hard filtering in database " + assLocalHardFilterVCFFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterVCFFile5[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalHardFilterVCFFile5[i] = null;
                }
            }

            if (assLocalFilterVCFFile6 != null) {
                for (int i = 0; i < assLocalFilterVCFFile6.length; i++) {
                    assLocalFilterVCFFile6[i].getBr().close();
                    String info = assLocalFilterVCFFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterVCFFile6[i].getName() + ".";// + ", which contains " + assLocalFilterVCFFile6[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalFilterVCFFile6[i] = null;
                }
            }

            if (assLocalHardFilterNoGtyVCFFile5 != null) {
                for (int i = 0; i < assLocalHardFilterNoGtyVCFFile5.length; i++) {
                    assLocalHardFilterNoGtyVCFFile5[i].getBr().close();
                    String info = assLocalHardFilterNoGtyVCFFile5[i].getLeftNum() + " variant(s) are left after hard filtering in database " + assLocalHardFilterNoGtyVCFFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterNoGtyVCFFile5[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalHardFilterNoGtyVCFFile5[i] = null;
                }
            }

            if (assLocalFilterNoGtyVCFFile6 != null) {
                for (int i = 0; i < assLocalFilterNoGtyVCFFile6.length; i++) {
                    assLocalFilterNoGtyVCFFile6[i].getBr().close();
                    String info = assLocalFilterNoGtyVCFFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterNoGtyVCFFile6[i].getName() + ".";//+ ", which contains " + assLocalFilterNoGtyVCFFile6[i].getTotalNum() + " effective variants.";
                    LOG.info(info);
                    assLocalFilterNoGtyVCFFile6[i] = null;
                }
            }

            if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
                if (options.isAlleleFreqExcMode) {
                    uniqueGenome.setVarNum(assFBAFEM.getAnnotNum());
                    String info = assFBAFEM.getAnnotNum() + " variant(s) with minor allele frequency [" + 0 + ", " + options.minAlleleFreqExc + ") in the reference datasets above are left!";
                    LOG.info(info);
                } else {
                    uniqueGenome.setVarNum(assFBAFIM.getAnnotNum());
                    String info = assFBAFIM.getAnnotNum() + " variant(s) with minor allele frequency [" + options.minAlleleFreqInc + ", " + options.maxAlleleFreqInc + "] in the reference datasets above are left!";
                    LOG.info(info);
                }
                if (options.toMAFPlotRef) {
                    final File plotFile = new File(options.outputFileName + ".maf.ref.png");
                    pvPainter.drawColorfulHistogramPlot(mafRefList, thresholds, null, "MAF in reference DB", plotFile.getCanonicalPath());
                    String info = "The Histogram plot of MAF is saved in " + plotFile.getCanonicalPath();
                    LOG.info(info);
                    showPlots(new File[]{plotFile});
                }
            }

            // only keep genes in inGeneSet
            if (options.geneDBLabels != null) {
                if (!options.inGeneSet.isEmpty()) {
                    StringBuilder info = new StringBuilder();
                    info.append(assGIS17d3.getAnnotNum()).append(" variant(s) are left after filtering those outside specified genes!");
                    LOG.info(info);
                    uniqueGenome.setVarNum(assGIS17d3.getAnnotNum());
                }

                // only keep genes in outGeneSet
                if (!options.outGeneSet.isEmpty()) {
                    StringBuilder info = new StringBuilder();
                    info.append(assGOS17d4.getAnnotNum()).append(" variant(s) are left after filtering those inside specified genes!");
                    LOG.info(info);
                    uniqueGenome.setVarNum(assGOS17d4.getAnnotNum());
                }
            }

            if (dbNSFPAnnot8 != null) {
                String info = dbNSFPAnnot8.toString();
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
            }

            if (dbNSFPPred9 != null) {
                LOG.info(dbNSFPPred9.toString(0, 3, " "));
                String info = dbNSFPPred9.toString(3, 4, "");
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
            }

            if (dbNoncodePred9d1 != null) {
                LOG.info(dbNoncodePred9d1.toString(0, 2, " "));
                String info = dbNoncodePred9d1.toString(2, 3, "");
                if (!info.isEmpty()) {
                    LOG.info(info);
                }
            }

            if (options.ldPruning) {
                String info = ldPruningASS.getLeftNum() + " variant(s) are left after LD pruning with window size " + options.ldPrunWindowSize + " bp and r-square " + options.ldPrunR2 + ".";
                LOG.info(info);
            }

            if (options.geneMaxVarPerPerson > 0) {
                StringBuilder info = new StringBuilder();
                info.append(assGVF10.getLeftNum()).append(" variant(s) are left after filtered by genes with ").append(options.geneMaxVarPerPerson).append(" or over variants!");
                LOG.info(info);
                uniqueGenome.setVarNum(assGVF10.getLeftNum());
            }

            if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {
                if (uniqueGenome.getGeneNum() > 0) {
                    String strInfo = assG11.getName() + ": " + assG11.getAnnotNum() + " mRNAs belong to the candidate gene set.";
                    LOG.info(strInfo);
                } else if (uniqueGenome.getVarNum() > 0) {
                    String strInfo = assV12.getName() + ": " + assV12.getAnnotNum() + " variants are within candidate gene set.";
                    LOG.info(strInfo);
                }
                if (options.ppiDB != null) {
                    if (uniqueGenome.getGeneNum() > 0) {
                        String strInfo = assPPIG13.getName() + ": " + assPPIG13.getAnnotNum() + " mRNAs belong to the candidate gene set.";
                        LOG.info(strInfo);
                    } else if (uniqueGenome.getVarNum() > 0) {
                        LOG.info(assPPIV14.getAnnotNum() + " sequence variant(s) are highlighted by PPI information!");
                    }
                }

                if (options.genesetdb != null) {
                    if (mappedPathes != null) {
                        if (uniqueGenome.getGeneNum() > 0) {
                            LOG.info(assPWG15.getName() + ": " + assPWG15.getAnnotNum() + " mRNAs are involved into the related GeneSets.");
                        } else if (uniqueGenome.getVarNum() > 0) {
                            LOG.info(assPWV16.getAnnotNum() + " sequence variant(s) are highlighted by GeneSet information!");
                        }
                    }
                }
            }

            if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                uniqueGenome.setVarNum(assIBS17d1.getAnnotNum());
                LOG.info(assIBS17d1.getAnnotNum() + " variant(s) are left after filtered by IBS filtering!");
                if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                    LOG.info("0 sequence variant(s) are left finally!");
                    return;
                }
            }

            if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
                uniqueGenome.setVarNum(assHRC17d2.getAnnotNum());
                LOG.info(assHRC17d2.getAnnotNum() + " variant(s) are left after filtered by Homozygosity filtering!");
                if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                    LOG.info("0 sequence variant(s) are left finally!");
                    return;
                }
            }

            if (options.ibdFileName != null) {
                LOG.info(assIBD17d5.getLeftNum() + " variant(s) are left after filtered by IBD Region filtering!");
            }

            if (dbScSNV18 != null) {
                dbScSNV18.getBr().close();
                String info = dbScSNV18.getLeftNum() + " variant(s) exist in " + dbScSNV18.getName() + ".";//", which contains " + dbScSNV18.getTotalNum() + " effective variants.";
                LOG.info(info);
                dbScSNV18 = null;
            }

            if (doubleHitGeneModelFilter19 != null) {
                int hitGenenNum = hitDisCountsTriosGenes.size();
                for (int i = 2; i < hitGenenNum; i++) {
                    String[] row = hitDisCountsTriosGenes.get(i);
                    Double lens = geneLengths.get(row[0]);
                    if (lens == null) {
                        row[2] = "0";
                        hitDisCountsTriosGenes.get(i)[2] = row[2];
                        hitDisCounTriosReads.get(i)[2] = row[2];
                    } else {
                        row[2] = String.valueOf(lens);
                        hitDisCountsTriosGenes.get(i)[2] = row[2];
                        hitDisCounTriosReads.get(i)[2] = row[2];
                    }
                    double[] scores = allDoubleHitGeneScoresMap.get(row[0]);

                    if (scores == null) {
                        row[1] = ".";
                        hitDisCountsTriosGenes.get(i)[1] = row[1];
                        hitDisCounTriosReads.get(i)[1] = row[1];
                    } else {
                        row[1] = String.valueOf(scores[1]);
                        hitDisCountsTriosGenes.get(i)[1] = row[1];
                        hitDisCounTriosReads.get(i)[1] = row[1];
                    }
                }

                StringBuilder info = new StringBuilder();
                String info1 = doubleHitGeneModelFilter19.toString();
                if (info1.isEmpty()) {
                    info.append(info1).append('\n');
                }

                String outFileName = options.outputFileName + ".doublehit.gene.trios.flt";

                List<List<String[]>> arrys = new ArrayList<List<String[]>>();

                arrys.add(hitDisCountsTriosGenes);
                arrys.add(hitDisCounTriosReads);

                if (options.excelOut) {
                    List<String> sheetLabels = new ArrayList<String>();
                    sheetLabels.add("counts");
                    sheetLabels.add("genotypes");

                    File savedFile = new File(outFileName + ".xlsx");
                    LocalExcelFile.writeMultArray2XLSXFile(savedFile.getCanonicalPath(), arrys, sheetLabels, true, 0);
                    info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile.getCanonicalPath()).append(".");
                } else {
                    File savedFile1 = new File(outFileName + ".count.txt");
                    LocalFile.writeData(savedFile1.getCanonicalPath(), arrys.get(0), "\t", false);
                    File savedFile2 = new File(outFileName + ".gty.txt");
                    LocalFile.writeData(savedFile2.getCanonicalPath(), arrys.get(1), "\t", false);
                    info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile1.getCanonicalPath()).append(" and ").append(savedFile2.getCanonicalPath()).append(".");
                }

                info.append("\nThe double-hit genes:\n");
                if (!caseDoubleHitTriosGenes.isEmpty()) {
                    info.append("in cases: ").append(caseDoubleHitTriosGenes.size()).append("\n").append(caseDoubleHitTriosGenes.toString()).append("\n");
                }
                LOG.info(info);
            }

            if (doubleHitGeneModelFilter19d1 != null) {
                /*
                 //assign gene length
                 int hitGenenNum = doubleHitGenePhasedGenes.size();
                 for (int i = 2; i < hitGenenNum; i++) {
                 String[] row = doubleHitGenePhasedGenes.get(i);
                 Double lens = geneLengths.get(row[0]);
                 if (lens == null) {
                 row[2] = "0";
                 doubleHitGenePhasedGenes.get(i)[2] = row[2];
                 doubleHitGenePhasedReads.get(i)[2] = row[2];
                 } else {
                 row[2] = String.valueOf(lens);
                 doubleHitGenePhasedGenes.get(i)[2] = row[2];
                 doubleHitGenePhasedReads.get(i)[2] = row[2];
                 }
                 }
                 */
                StringBuilder info = new StringBuilder();
                String info1 = doubleHitGeneModelFilter19d1.toString();
                if (info1.isEmpty()) {
                    info.append(info1).append('\n');
                }

                String outFileName = options.outputFileName + ".doublehit.gene.phased.flt";

                List<List<String[]>> arrys = new ArrayList<List<String[]>>();

                arrys.add(doubleHitGenePhasedGenes);
                arrys.add(doubleHitGenePhasedReads);

                if (options.excelOut) {
                    List<String> sheetLabels = new ArrayList<String>();
                    sheetLabels.add("counts");
                    sheetLabels.add("genotypes");

                    File savedFile = new File(outFileName + ".xlsx");
                    LocalExcelFile.writeMultArray2XLSXFile(savedFile.getCanonicalPath(), arrys, sheetLabels, true, 0);
                    info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile.getCanonicalPath()).append(".");
                } else {
                    File savedFile1 = new File(outFileName + ".count.txt");
                    LocalFile.writeData(savedFile1.getCanonicalPath(), arrys.get(0), "\t", false);
                    File savedFile2 = new File(outFileName + ".gty.txt");
                    LocalFile.writeData(savedFile2.getCanonicalPath(), arrys.get(1), "\t", false);
                    info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile1.getCanonicalPath()).append(" and ").append(savedFile2.getCanonicalPath()).append(".");
                }
                //controlDoubleHitPhasedGenes
                info.append("\nThe double-hit genes:\n");
                if (!caseDoubleHitPhasedGenes.isEmpty()) {
                    info.append("in cases: ").append(caseDoubleHitPhasedGenes.size()).append("\n").append(caseDoubleHitPhasedGenes.toString()).append("\n");
                }
                LOG.info(info);
            }

            if (options.needAnnotateGene) {
                if (uniqueGenome.getGeneNum() > 0) {
                    String strInfo = assGene20.getName() + ": " + assGene20.getAnnotNum() + " variants are annotated out of " + assGene20.getTotalNum() + " variants.";
                    //  LOG.info(strInfo);
                } else if (uniqueGenome.getVarNum() > 0) {
                    String strInfo = assVariant20.getName() + ": " + assVariant20.getAnnotNum() + " variants are annotated out of " + assVariant20.getTotalNum() + " variants.";
                    // LOG.info(strInfo);
                }
            }

            if (options.omimAnnotateGene) {
                if (uniqueGenome.getGeneNum() > 0) {
                    String strInfo = assOmimGene21.getName() + ": " + assOmimGene21.getAnnotNum() + " variants are annotated out of " + assOmimGene21.getTotalNum() + " variants.";
                    LOG.info(strInfo);
                } else if (uniqueGenome.getVarNum() > 0) {
                    LOG.info(assOmimVar21.getAnnotNum() + " sequence variant(s) are highlighted by OMIM information!");
                }
            }

            if (options.tissueSpecAnnot) {
                if (uniqueGenome.getGeneNum() > 0) {
                    String strInfo = assTissueSpecGene21.getName() + ": " + assTissueSpecGene21.getAnnotNum() + " variants are annotated out of " + assTissueSpecGene21.getTotalNum() + " variants.";
                    LOG.info(strInfo);
                } else if (uniqueGenome.getVarNum() > 0) {
                    LOG.info(assTissueSpecVar21.getAnnotNum() + " sequence variant(s) are highlighted by tissue specific expression data!");
                }
            }

            if (options.superdupAnnotate) {
                String info = assSDA22.getLeftNum() + " variant(s) are in super-duplicated regions registered in a data set genomicSuperDups table of UCSC";
                LOG.info(info);
            } else if (options.superdupFilter) {
                uniqueGenome.setVarNum(assSDF22.getLeftNum());
                LOG.info(assSDF22.getLeftNum() + " variant(s) are left after filtering those in super-duplicated regions registered in a data set genomicSuperDups table of UCSC!");
            }

            if (options.dgvcnvAnnotate) {
                StringBuilder info = new StringBuilder();
                info.append('\n');
                LOG.info(info);
                LOG.info(assDGV23.getLeftNum() + " variant(s) are in large copy-number variation (CNV) regions registered in Database of Genomic Variants http://projects.tcag.ca/variation/.");
            }

            if (options.overlappedGeneFilter) {
                uniqueGenome.setVarNum(assOLGF.getLeftNum());
                String info = assOLGF.getLeftNum() + " variant(s) are left after filtered by the unique variants on gene level.\n";
                LOG.info(info);
            }

            if (options.phenoMouse) {
                String info = assMousePheno.getAnnotNum() + " variants are annotated with mouse phenotypes.";
                LOG.info(info);
            }

            if (options.zebraFish) {
                String info = assZebra.getAnnotNum() + " variants are annotated with zebrafish phenotypes.";
                LOG.info(info);
            }
            if (options.dddPhenotypes) {
                String info = assDDD.getAnnotNum() + " variants are annotated with diseases documented in  Deciphering Developmental Disorders (DDD) study.";
                LOG.info(info);
            }
            if (options.searchList != null && !options.searchList.isEmpty()) {
                if (uniqueGenome.getGeneNum() > 0) {
                    if (options.pubmedMiningIdeo) {

                    }
                    if (options.pubmedMiningGene) {
                        LOG.info(pubmedSearch24_Gene.getAnnotNum() + " genes are highlighted by Pubmed information!");
                    }
                } else if (uniqueGenome.getVarNum() > 0) {
                    if (options.pubmedMiningIdeo) {

                    }
                    if (options.pubmedMiningGene) {
                        LOG.info(pubmedSearch24_Var.getAnnotNum() + " sequence variants' genes are highlighted by Pubmed information!");
                    }
                }
            }

            if (options.rsid) {
                String info = assRSID25.getAnnotNum() + " variants are annotated with rsid.";
                LOG.info(info);
            }

            if (options.flankingSequence > 0) {
                String info = assFS.getAnnotNum() + " variants are annotated with flanking sequence.";
                LOG.info(info);
            }

            if (options.phenolyzer) {
                String info = assPhenolyzer26.getAnnotNum() + " variants are annotated by phenolyzer.";
                LOG.info(info);
            }
            LOG.info("------------------------------------------------------------");
            if (options.skatGene) {
                skat.closeRCluster();
                String geneSumOutFile = options.outputFileName + ".skat.gene.xlsx";
                skat.saveGeneResult2Xlsx(geneSumOutFile);
            }
            if (options.skatGeneset) {
                skat.closeRCluster();
                String geneSumOutFile = options.outputFileName + ".skat.geneset.xlsx";
                skat.saveGenesetResult2Xlsx(geneSumOutFile);
            }
            if (options.rvtestGene || options.rvtestGeneset || options.rvtestVar) {
                RVTest rvtest = null;
                if (options.needNewVCFForRVTest) {
                    rvtest = new RVTest(null, options.outputFileName);
                } else {
                    rvtest = new RVTest(options.inputFileName, options.outputFileName);
                }

                rvtest.setPheno(options.pheItem);
                rvtest.setCov(options.covItems);
                rvtest.setCommand(options.rvtestCommand);
                rvtest.runTabix();
                // rvtest.runBGzip();              
                //LocalFileFunc.tabixFile(options.outputFileName + ".flt.vcf.gz");
                boolean keepRVTRstTmp = false;
                if (options.rvtestVar) {
                    rvtest.runGeneAssoc(options.pedFile, options.threadNum, "variant");
//                    rvtest.collectResultGene(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut);
                    ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut, options.genePCut,
                            options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, null);
                    titleList.remove(0);
                    if (options.toQQPlot) {
                        File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRSingle(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.var.qq.png");
                        showPlots(new File[]{plotFile});
                    }
                    rvtest.releaseHmpRSingle();
                }

                if (options.rvtestGene) {
                    rvtest.runGeneAssoc(options.pedFile, options.threadNum, "gene");
                    //System.out.println("RVTest Done");
                    ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut, options.genePCut,
                            options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, null);
                    //  ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, true, options.excelOut);
                    // System.out.println("RVTest Collected");
                    titleList.remove(0);

                    if (options.toQQPlot) {
                        File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRGroup(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.gene.qq.png");
                        showPlots(new File[]{plotFile});
                    }
                    rvtest.releaseHmpRGroup();
                }

                if (options.rvtestGeneset) {
                    rvtest.runGenesetAssoc(options.pedFile, rvTestGroupTestFile);
//                    rvtest.collectResultGeneset(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut);
                    ArrayList<String> titleList = rvtest.collectResultGeneset(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut);
                    titleList.remove(0);
                    if (options.toQQPlot) {
                        File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRGroup(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.geneset.qq.png");
                        showPlots(new File[]{plotFile});
                    }
                    rvtest.releaseHmpRGroup();
                }
            }

            if (simpleIndiviGenesetSumFile != null) {
                String infor = "The summary statistics of variants in specified genesets for each individual are listed in " + simpleIndiviGenesetSumFile.getCanonicalPath();
                LOG.info(infor);
            }
            if (options.mendelGenePatho) {
                String info = assPatho27.getAnnotNum() + " variants are annotated by pathology gene prediction.";
                LOG.info(info);
            }
            if (options.cosmicAnnotate) {
                String info = cosmicDBAnnot28.getAnnotNum() + " variant(s) are annotated by genes in the COSMIC database!";
                LOG.info(info);
            }

            if (options.isPlinkBedOut) {
                String info = null;
                if (bwMapBed != null) {
                    bwMapBed.close();
                }
                if (fileBedStream != null) {

                    fileBedStream.close();
                    //rafBed.close();
                }

                if (options.mergeGtyDb != null) {
                    if (refhapGenome != null) {
                        refhapGenome.removeTempFileFromDisk();
                    }
                    mergedBwMap.close();
                    mergedFileStream.close();
                }

                //force to convert the gz to txt file
                if (options.outGZ) {
                    File f1 = new File(options.outputFileName + ".fam.gz");
                    File f2 = new File(options.outputFileName + ".fam");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();
                    f1 = new File(options.outputFileName + ".bed.gz");
                    f2 = new File(options.outputFileName + ".bed");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();
                    f1 = new File(options.outputFileName + ".bim.gz");
                    f2 = new File(options.outputFileName + ".bim");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();

                    if (options.mergeGtyDb != null) {
                        f1 = new File(options.outputFileName + ".merged.fam.gz");
                        f2 = new File(options.outputFileName + ".merged.fam");
                        LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                        f1.delete();
                        f1 = new File(options.outputFileName + ".merged.bed.gz");
                        f2 = new File(options.outputFileName + ".merged.bed");
                        LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                        f1.delete();
                        f1 = new File(options.outputFileName + ".merged.bim.gz");
                        f2 = new File(options.outputFileName + ".merged.bim");
                        LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                        f1.delete();
                    }

                }
                info = "Genotype of " + savedBinnaryBedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved in "
                        + options.outputFileName + ".fam " + options.outputFileName + ".bim " + options.outputFileName + ".bed " + " with Plink binary genotype format.";
                LOG.info(info);

                if (options.mergeGtyDb != null) {
                    info = "Genotype of " + coutVar[0] + " sequence variant(s) and " + intsIndiv[0] + " individuals are saved in "
                            + options.outputFileName + ".merged.fam" + " " + options.outputFileName + ".merged.bim" + " " + options.outputFileName + ".merged.bed" + " " + " with Plink binary genotype format.";
                    LOG.info(info);
                }

            }

            if (options.isGeneVarGroupFileOut) {
                if (bwGeneVarGroupFile != null) {
                    bwGeneVarGroupFile.close();
                }
                String info;
                if (options.outGZ) {
                    info = "A group file for gene-based association analysis is produced, " + options.outputFileName + ".gene.epacts.grp.gz.";
                } else {
                    info = "A group file for gene-based association analysis is produced, " + options.outputFileName + ".gene.epacts.grp.";
                }
                LOG.info(info);
            }
            if (options.calcLD) {
                bwLD.close();
                String info = "The pair-wise Pearson genotypic correlation of biallelic variants are save in ";
                if (uniqueGenome.isIsPhasedGty()) {
                    info = "The pair-wise linkage disequilibrium coefficients, r, of biallelic variants are save in ";
                }
                File f = null;
                if (options.outGZ) {
                    f = new File(options.outputFileName + ".ld.gz");
                } else {
                    f = new File(options.outputFileName + ".ld");
                }
                info += f.getCanonicalPath() + ".";
                LOG.info(info);
            }

            if (options.isPlinkPedOut) {
                bwMapPed.close();
                //merge   files
                BufferedReader brPed = null;
                if (options.outGZ) {
                    brPed = LocalFileFunc.getBufferedReader(options.outputFileName + ".ped.p.gz");
                } else {
                    brPed = LocalFileFunc.getBufferedReader(options.outputFileName + ".ped.p");
                }

                File[] files = new File[STAND_CHROM_NAMES.length];
                BufferedReader[] brPedGty = new BufferedReader[STAND_CHROM_NAMES.length];
                for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                    if (options.outGZ) {
                        files[i] = new File(options.outputFileName + ".ped." + i + ".gz");
                    } else {
                        files[i] = new File(options.outputFileName + ".ped." + i);
                    }
                    if (!files[i].exists()) {
                        continue;
                    }
                    brPedGty[i] = LocalFileFunc.getBufferedReader(files[i].getCanonicalPath());
                }

//                BufferedWriter bwPed = LocalFileFunc.getBufferedWriter(options.outputFileName + ".ped", false);
                BufferedWriter bwPed = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ped" + ".gz"));
                    bwPed = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    bwPed = LocalFileFunc.getBufferedWriter(options.outputFileName + ".ped", false);
                }

                String line;
                //assume the brPed and brPedGty have the same number of rows
                while ((line = brPed.readLine()) != null) {
                    bwPed.write(line);
                    for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                        if (brPedGty[i] == null) {
                            continue;
                        }
                        bwPed.write(brPedGty[i].readLine());
                    }
                    bwPed.write('\n');
                }
                brPed.close();
                bwPed.close();

                //file.delete();
                for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                    if (!files[i].exists()) {
                        continue;
                    }
                    brPedGty[i].close();
                    files[i].deleteOnExit();
                    //files[i].delete();
                }

                File filePedP;
                if (options.outGZ) {
                    filePedP = new File(options.outputFileName + ".ped.p.gz");
                } else {
                    filePedP = new File(options.outputFileName + ".ped.p");
                }
                filePedP.deleteOnExit();
                String info = null;
                if (options.outGZ) {
                    info = "Genotype of " + savedPedVar[0] + " sequence variant(s) and " + subjectList.size()
                            + " individuals are saved in " + options.outputFileName + ".map.gz " + options.outputFileName + ".ped.gz  with Plink pedigree format.";
                } else {
                    info = "Genotype of " + savedPedVar[0] + " sequence variant(s) and " + subjectList.size()
                            + " individuals are saved in " + options.outputFileName + ".map " + options.outputFileName + ".ped  with Plink pedigree format.";
                }
                LOG.info(info);
            }

            if (options.isBinaryGtyOut) {
                if (bwMapKed != null) {
                    bwMapKed.close();
                }

                if (filelKedStream != null) {
                    filelKedStream.close();
                    rafKed.close();
                }
                String info = null;
                if (options.outGZ) {
                    info = "Genotype of " + savedBinnaryKedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved in "
                            + options.outputFileName + ".kam.gz " + options.outputFileName + ".kim.gz " + options.outputFileName + ".ked.gz " + " with KGGSseq binary genotype format.";
                } else {
                    info = "Genotype of " + savedBinnaryKedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved in "
                            + options.outputFileName + ".kam " + options.outputFileName + ".kim " + options.outputFileName + ".ked " + " with KGGSseq binary genotype format.";
                }

                LOG.info(info);
            }

            if (options.isVCFOut) {
                /*
                if (!options.rvtestGene && !options.rvtestGeneset) {
                    RVTest rvtest = new RVTest(options.outputFileName);
                    rvtest.runBGzip(vcfFilteredInFile.getCanonicalPath());
                }
                 */
                if (!options.outGZ) {
                    String newName = LocalFileFunc.gunzipFile(vcfFilteredInFile.getCanonicalPath());
                    vcfFilteredInFile = new File(newName);
                }
                LOG.info(writenVCFVarNum + " variants are saved in " + vcfFilteredInFile.getCanonicalPath() + " with VCF format.");
                //LocalFileFunc.bgzipFile(vcfFilteredInFile.getCanonicalPath());
                //Note: this VCF tabix function is subject to be fixed
                // LocalFileFunc.tabixVCFFile(vcfFilteredInFile.getCanonicalPath());
                //LOG.info("The index file " + vcfFilteredInFile.getCanonicalPath() + ".tbi is created.");
            }

            if (options.isSimpleVCFOut) {
                /*
                if (!options.rvtestGene && !options.rvtestGeneset) {
                    RVTest rvtest = new RVTest(options.outputFileName);
                    rvtest.runBGzip(vcfFilteredInFile.getCanonicalPath());
                }
                 */
                if (!options.outGZ) {
                    String newName = LocalFileFunc.gunzipFile(simpleVcfFilteredInFile.getCanonicalPath());
                    simpleVcfFilteredInFile = new File(newName);
                }
                //LocalFileFunc.bgzipFile(vcfFilteredInFile.getCanonicalPath());
                //Note: this VCF tabix function is subject to be fixed
                //LocalFileFunc.tabixVCFFile(simpleVcfFilteredInFile.getCanonicalPath());
                LOG.info("Finally, " + finalVarNum + " variants are saved in " + simpleVcfFilteredInFile.getCanonicalPath() + " with a simplified VCF format.");
            }

            if (options.isANNOVAROut) {
                LOG.info("Finally, " + finalVarNum + " variants are saved in " + annovarFilteredInFile.getCanonicalPath() + " with ANNOVAR format.");
                annovarFilteredInFileWriter.close();
            }

            if (options.excelOut) {
                File finalFilteredInFile1 = new File(options.outputFileName + ".flt.xlsx");
                //As the function of appending data into an existing file is very slow; So I just have convert a text file into an excel file 
                LocalExcelFile.convertTextFile2XLSXFile(finalFilteredInFile.getCanonicalPath(), finalFilteredInFile1.getCanonicalPath(), true, 4);
                //Remove the text file to save storage space
                finalFilteredInFile.delete();
                LOG.info("Finally, " + finalVarNum + " variants are saved in " + finalFilteredInFile1.getCanonicalPath() + " with Excel format.\n");
            } else {
                LOG.info("Finally, " + finalVarNum + " variants are saved in " + finalFilteredInFile.getCanonicalPath() + " with flat text format.\n");
            }

            //-----------------------Annotate genes and gene sets on whole genome-------------------------------
            String[] cells = null;
            String[] fixedColNames = null;
            List<String> scoreNames = new ArrayList<String>();

            String[] indexLabels = null;
            boolean[] availScores = new boolean[4];
            Arrays.fill(availScores, false);
            if (options.iterGeneCoding || options.witerGeneCoding) {
                String geneCoVarFilePath = options.PUBDB_FILE_MAP.get("cancer.mutsig");
                //Map<String, double[]> geneChromStatSocre = geneAnnotor.readGeneExp(GlobalManager.RESOURCE_PATH, "TCGA_ATAC_peak_Log2Counts_dedup_sample.gz", "Breast invasive carcinoma");

                //geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.hm.txt";
                geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
                fixedColNames = new String[]{"Gene", "AvgCodingLen", "expr", "hic", "reptime", "constraint_score"};
//"reptime", "hic",   ,  "constraint_score" , "reptime" , "constraint_score" "expr", , "constraint_score", "constraint_score"  "expr", "hic", "reptime",
                //"expr", 

                geneMutationScores = geneAnnotor.readGeneScore(geneCoVarFilePath, fixedColNames, scoreNames, 0);
                for (int i = 0; i < scoreNames.size(); i++) {
                    if (scoreNames.get(i).equals("AvgCodingLen")) {
                        scoreNames.set(i, "RegionLength");
                    } else if (scoreNames.get(i).equals("expr")) {
                        scoreNames.set(i, "CellLineExpression");
                    } else if (scoreNames.get(i).equals("hic")) {
                        scoreNames.set(i, "HiC");
                    } else if (scoreNames.get(i).equals("reptime")) {
                        scoreNames.set(i, "ReplicationTiming");
                    } else if (scoreNames.get(i).equals("constraint_score")) {
                        scoreNames.set(i, "ConstraintScore");
                    }
                }

                int extraCol = 0;
                int accuCol = 0;
                if (options.cancerLabel != null) {
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneExp.txt.gz";
                    Map<String, double[]> geneExpSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
                    if (geneExpSocre != null) {
                        extraCol++;
                        availScores[0] = true;
                    }
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneCNV.txt.gz";
                    Map<String, double[]> cnvSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
                    if (cnvSocre != null) {
                        extraCol++;
                        availScores[1] = true;
                    }
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAATACGene.txt.gz";
                    Map<String, double[]> tactSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
                    if (tactSocre != null) {
                        extraCol++;
                        availScores[2] = true;
                    }
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAMeth450Gene.txt.gz";
                    Map<String, double[]> methSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
                    if (methSocre != null) {
                        extraCol++;
                        availScores[3] = true;
                    }

                    if (geneExpSocre != null) {
                        scoreNames.add("TissueExpression");
                    }
                    if (cnvSocre != null) {
                        scoreNames.add("CNV");
                    }
                    if (tactSocre != null) {
                        scoreNames.add("ATACSeq");
                    }
                    if (methSocre != null) {
                        scoreNames.add("Methylation");
                    }

                    double[] vals;
                    double[] vals0;
                    Map< String, double[]> geneMutationScoresTmp = new HashMap< String, double[]>();
                    for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                        vals = new double[fixedColNames.length - 1 + extraCol];
                        Arrays.fill(vals, Double.NaN);
                        vals0 = item.getValue();
                        System.arraycopy(vals0, 0, vals, 0, vals0.length);
                        geneMutationScoresTmp.put(item.getKey(), vals);
                    }
                    geneMutationScores.clear();
                    geneMutationScores.putAll(geneMutationScoresTmp);
                    geneMutationScoresTmp.clear();

                    for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                        accuCol = 0;
                        vals0 = item.getValue();
                        if (availScores[0]) {
                            vals = geneExpSocre.get(item.getKey());
                            if (vals != null) {
                                vals0[fixedColNames.length - 1] = vals[0];
                                accuCol++;
                            }
                        }
                        if (availScores[1]) {
                            vals = cnvSocre.get(item.getKey());
                            if (vals != null) {
                                vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                                accuCol++;
                            }
                        }
                        if (availScores[2]) {
                            vals = tactSocre.get(item.getKey());
                            if (vals != null) {
                                vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                                accuCol++;
                            }
                        }
                        if (availScores[3]) {
                            vals = methSocre.get(item.getKey());
                            if (vals != null) {
                                vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                                accuCol++;
                            }
                        }
                    }

                    //assign min value for missing value genes          
                    for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                        accuCol = 0;
                        vals0 = item.getValue();
                        if (availScores[0]) {
                            accuCol++;
                            if (Double.isNaN(vals0[fixedColNames.length - 1])) {
                                vals0[fixedColNames.length - 1] = 0;
                            }
                        }

                        if (availScores[1]) {
                            accuCol++;
                            if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                                vals0[fixedColNames.length - 1 + accuCol] = 0;
                            }
                        }
                        if (availScores[2]) {
                            if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                                vals0[fixedColNames.length - 1 + accuCol] = -2.0773416789013055;
                            }
                            accuCol++;
                        }
                        if (availScores[3]) {
                            if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                                vals0[fixedColNames.length - 1 + accuCol] = 0;
                            }
                            accuCol++;
                        }
                    }

                }

                indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
                Map<String, double[]> geneMutRegPValueAllVar = new HashMap<String, double[]>();

                List<String[]> geneMutRateSheet = geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
                        options.witerGeneCoding, geneMutRegPValueAllVar, options.independentGeneFeature.isEmpty(), options.refMutGeneFile);
                geneMutRegPValueAllVar.clear();

                geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
                        options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.outputFileName + ".gene.mutationrate");

            }

            if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                /*
                String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
                fixedColNames = new String[]{"Gene", "AvgRegionLen", "constraint_score"};
                scoreNames.add("AvgRegionLen");
                scoreNames.add("constraint_score");
                 */

                scoreNames.clear();
                if (needRegionLen) {
                    scoreNames.add("RegionLength");
                }
                geneFreqScoreIndex = scoreNames.size();

                scoreNames.add(popuNames[0]);

                boolean multiCut = true;
                Map<String, double[]> geneMutRegPValueAllVarControl = new HashMap<String, double[]>();
                Map<String, double[]> geneMutRegPValueAllVar = new HashMap<String, double[]>();

                if (multiCut) {
                    if (needRegionLen) {
                        Map<String, double[]> geneMutationScoresTmp = new HashMap<String, double[]>(geneMutationScores);
                        geneMutationScores.clear();
                        List<String> excludedGenes = new ArrayList<String>();
                        double[] tmpDoubles;

                        for (Map.Entry<String, double[]> item : geneMutationScoresTmp.entrySet()) {
                            if (!hittedGeneSet.contains(item.getKey())) {
                                excludedGenes.add(item.getKey());
                            } else {
                                if (useLocalGeneScore) {
                                    tmpDoubles = localGeneFreqScores.get(item.getKey());
                                } else {
                                    tmpDoubles = geneFreqScores.get(item.getKey());
                                }

                                if (item.getKey() == null || tmpDoubles == null) {
                                    continue;
                                }

                                for (int t = 0; t < popuNames.length; t++) {
                                    item.getValue()[geneFreqScoreIndex] += (tmpDoubles[0]);
                                }

                                geneMutationScores.put(item.getKey(), item.getValue());
                            }
                        }

                        geneMutationScoresTmp.clear();
                        if (excludedGenes.size() > 0) {
                            //  LOG.info(excludedGenes.size() + " genes are excluded due to missing reference allele frequencies in the gnomad database.");
                            // System.out.println(excludedGenes.toString());
                        }

                        excludedGenes.clear();
                        hittedGeneSet.clear();
                    } else {
                        geneMutationScores = new HashMap<String, double[]>(geneMutationScores);
                        if (useLocalGeneScore) {
                            for (Map.Entry<String, double[]> item : localGeneFreqScores.entrySet()) {
                                geneMutationScores.put(item.getKey(), new double[]{0});
                            }
                        } else {
                            for (Map.Entry<String, double[]> item : geneFreqScores.entrySet()) {
                                geneMutationScores.put(item.getKey(), new double[]{0});
                            }
                        }
                    }

                    /*
          if (!useLocalGeneScore && hasControls) {
            indexLabels = new String[]{"ResponseVarControl", "ExplanatoryVarControl", "ResponseVarFuncScoreControl"};

            List<String[]> geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(RHOST, RPORT,uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, geneFreqScores, mafBins, geneFreqScoreIndex, scoreNames,
                options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.refMutGeneFile,
                options.independentGeneFeature.isEmpty(), options.threadNum);
            geneAnnotor.annotateGeneAndOutput(geneMutRateSheet, options.excelOut, options.genePCut,
                options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.outputFileName + ".gene.mutationrate.contol");

            //  geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
            //      options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.witerRefMutGeneFile, options.outputFileName + ".gene.mutationrate.contol",
            //    options.independentGeneFeature.isEmpty(), options.excelOut);
          }

          indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
          if (useLocalGeneScore) {
            List<String[]> geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(RHOST, RPORT,uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, localGeneFreqScores, mafBins, geneFreqScoreIndex, scoreNames,
                options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.refMutGeneFile,
                options.independentGeneFeature.isEmpty(), options.threadNum);
            geneAnnotor.annotateGeneAndOutput(geneMutRateSheet, options.excelOut, options.genePCut,
                options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.outputFileName + ".gene.mutationrate");
          } else {
            List<String[]> geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(RHOST, RPORT,uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, geneFreqScores, mafBins, geneFreqScoreIndex, scoreNames,
                options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.refMutGeneFile,
                options.independentGeneFeature.isEmpty(), options.threadNum);

            geneAnnotor.annotateGeneAndOutput(geneMutRateSheet, options.excelOut, options.genePCut,
                options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.outputFileName + ".gene.mutationrate");

          }
                     */
 /*
          geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
              options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.witerRefMutGeneFile, options.outputFileName + ".gene.mutationrate",
              options.independentGeneFeature.isEmpty(), options.excelOut);
                     */
                }
                /*else {
          geneMutationScores = geneAnnotor.readGeneScore(geneCoVarFilePath, fixedColNames, 0);
          geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/hg19/hg19_1kg.gene.var.freq.gz";

          geneAnnotor.appendGeneVarFreq(geneCoVarFilePath, popuNames, options.minAlleleFreqExc * mafFolder, funcScoreBinLen, options.dependentGeneFeature, options.runnerGeneCoding, geneMutationScores, hittedGeneSet);
 
          Map<String, double[]> driverGeneScoresTmp = new HashMap<String, double[]>(geneMutationScores);
          geneMutationScores.clear();
          List<String> excludedGenes = new ArrayList<String>();
          double[] tmpDoubles;
          for (Map.Entry<String, double[]> item : driverGeneScoresTmp.entrySet()) {
            if (!hittedGeneSet.contains(item.getKey())) {
              excludedGenes.add(item.getKey());
            } else {
              geneMutationScores.put(item.getKey(), item.getValue());
            }
          }
          driverGeneScoresTmp.clear();
          if (excludedGenes.size() > 0) {
            LOG.info(excludedGenes.size() + " genes are excluded due to missing reference allele frequencies in the gnomad database.");
          }

          excludedGenes.clear();
          hittedGeneSet.clear();

          if (hasControls) {
            indexLabels = new String[]{"ResponseVarControl", "ExplanatoryVarControl", "ResponseVarFuncScoreControl"};
            geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
                options.runnerGeneCoding, geneMutRegPValueAllVarControl, options.witerRefMutGeneFile, options.independentGeneFeature.isEmpty());
          }

          indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};

          geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
              options.runnerGeneCoding, geneMutRegPValueAllVar, options.witerRefMutGeneFile, options.independentGeneFeature.isEmpty());
        }
                 */
                geneMutRegPValueAllVar.clear();

                if (options.genesetEnrichmentTest && dbPathwaySet != null && !geneMutRegPValueAllVar.isEmpty()) {
                    geneAnnotor.enrichmentTestGeneSet(dbPathwaySet, null, options.genesetSizeMin, options.genesetHyperGenePCut, options.outputFileName + "mutationrate.enrichment.geneset.xlsx");
                }
            }

        } finally {
            if (uniqueGenome != null) {
                uniqueGenome.removeTempFileFromDisk();
            }
        }
    }
}
