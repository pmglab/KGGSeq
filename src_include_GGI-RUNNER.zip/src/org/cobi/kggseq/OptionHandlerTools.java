/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.FloatArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import cern.jet.stat.Descriptive;
import cern.jet.stat.Probability;
import edu.sysu.pmglab.ccf.CCFReader;
import edu.sysu.pmglab.container.array.BaseArray;
import edu.sysu.pmglab.container.array.StringArray;
import edu.sysu.pmglab.gbc.GTBIndexer;
import edu.sysu.pmglab.gbc.GTBReader;
import htsjdk.samtools.util.BlockCompressedOutputStream;
import java.awt.GraphicsEnvironment;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.GZIPOutputStream;
import javax.swing.JFrame;

import org.apache.log4j.Logger;
import static org.cobi.kggseq.Constants.VAR_FEATURE_NAMES;
import static org.cobi.kggseq.Constants.STAND_CHROM_NAMES;

import org.cobi.bayes.Bayes;
import org.cobi.kggseq.controller.BinaryGtyProcessor;
import org.cobi.kggseq.controller.CandidateGeneExtender;
import org.cobi.kggseq.controller.GeneAnnotator;
import org.cobi.kggseq.controller.GeneRegionParser;
import org.cobi.kggseq.controller.GeneSetExplorer;
import org.cobi.kggseq.controller.LinkageFileParser;
import org.cobi.kggseq.controller.PileupFormatParser;
import org.cobi.kggseq.controller.SimpleFormatParser;
import org.cobi.kggseq.controller.VariantAnnotator;
import org.cobi.kggseq.controller.VariantFilter;
import org.cobi.kggseq.dialog.PlotShowFrame;
import org.cobi.kggseq.entity.AnnotationSummarySet;
import org.cobi.kggseq.entity.CNVRegionParser;
import org.cobi.kggseq.entity.Chromosome;
import org.cobi.kggseq.entity.CombOrderComparator;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.FiltrationSummarySet;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.Individual;
import org.cobi.kggseq.entity.PPIGraph;
import org.cobi.kggseq.entity.GeneSet;
import org.cobi.kggseq.entity.RegressionParams;
import org.cobi.kggseq.entity.Variant;
import org.cobi.kggseq.controller.Phenolyzer;
import org.cobi.kggseq.controller.RVTest;
import org.cobi.kggseq.controller.SKAT;
import org.cobi.kggseq.controller.SequenceRetriever;
import org.cobi.kggseq.controller.VCFParserFast;
import org.cobi.kggseq.entity.RefGene;
import org.cobi.randomforests.MyRandomForest;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.plot.HistogramPainter;
import org.cobi.util.plot.PValuePainter;
import org.cobi.util.stat.MultipleTestingMethod;
import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.text.LocalExcelFile;
import org.cobi.util.text.LocalFile;
import org.cobi.util.text.Util;
import org.cobi.kggseq.Tuple.*;
import org.cobi.kggseq.entity.Gene;
import org.cobi.kggseq.entity.ReferenceGenome;
import org.cobi.kggseq.entity.SampleVarGtyUnit;
import org.cobi.kggseq.phenotyping.DownScore;
import org.cobi.kggseq.phenotyping.TermRelatedHPO;
import org.cobi.util.graph.GeneGraphShort;
import org.cobi.util.net.NetUtils;
import org.cobi.util.stat.ContingencyTable;
import org.cobi.util.stat.LogisticRegression;
import org.cobi.util.stat.RankTest;
import org.cobi.util.text.StringArrayIntegerComparator;

/**
 *
 * @author user
 */
public class OptionHandlerTools {

    private static Options options;
    private static Logger LOG;

    private OptionHandlerTools(Options options, Logger LOG) {
        this.options = options;
        this.LOG = LOG;
    }

    public static void optionHandlerToolsGenerator(Options options, Logger LOG) {
        new OptionHandlerTools(options, LOG);
    }

    private static void showPlots(final File[] plotFiles) {
        if (!GraphicsEnvironment.isHeadless()) {
            java.awt.EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    PlotShowFrame psf = new PlotShowFrame();
                    psf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    for (final File file : plotFiles) {
                        if (file == null) {
                            continue;
                        }
                        psf.insertImage2PlottingPane(file);
                    }
                    psf.setVisible(true);
                }
            });
        } else {
            String info = "But no avaible graphics environment to present the figure(s) here!";
            LOG.info(info);
        }
    }

    public static ThreeTuple<String[], int[], String[]> geneVarFreqFilePopuName(boolean[] toUseLocal, boolean hasControls) throws Exception {
        String[] geneVarFreqFiles = null;
        //assume 1 resource file by default
        int internalNum = 1;
        if (options.geneVarFreqLabels == null && options.inputGeneVarFreqFiles == null) {
            return TupleUtil.tuple(null, null, geneVarFreqFiles);
        }
        if (options.geneVarFreqLabels == null) {
            internalNum = 0;
        }
        if (options.inputGeneVarFreqFiles != null) {
            if (options.geneVarFreqLabels != null) {
                geneVarFreqFiles = new String[options.inputGeneVarFreqFiles.length + 1];
                geneVarFreqFiles[0] = "gadexome.gene.freq";
                for (int i = 0; i < options.inputGeneVarFreqFiles.length; i++) {
                    geneVarFreqFiles[i + 1] = "&" + options.inputGeneVarFreqFiles[i];
                }
            } else {
                geneVarFreqFiles = new String[options.inputGeneVarFreqFiles.length];
                for (int i = 0; i < options.inputGeneVarFreqFiles.length; i++) {
                    geneVarFreqFiles[i] = "&" + options.inputGeneVarFreqFiles[i];
                }
            }
        } else {
            if (options.geneVarFreqLabels != null) {
                geneVarFreqFiles = new String[]{"gadexome.gene.freq"};
            }
        }

        if (options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
            geneVarFreqFiles = new String[]{"gadgenome.gene.freq"};
        }

        String[] popuNames = null;
        int[] effecIndexVarFreq = new int[geneVarFreqFiles.length];
        Arrays.fill(effecIndexVarFreq, -1);

        if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.uwrunnerDiGeneInteractCoding || options.runnerDiGeneInteractCoding || options.renerGeneNonCoding
                || options.uwrunnerMoGeneInteractCoding || options.runnerMoGeneInteractCoding || options.wrenerGeneNonCoding) {
            if (options.inputGeneVarFreqFiles == null && options.geneVarFreqLabels == null) {
                String info = "The '--gene-freq-score or --gene-freq-file ' is not specificid! for RUNNER analysis";
                throw new Exception(info);
            }
            if (options.geneVarFreqLabels != null) {
                popuNames = new String[internalNum];
                if (options.geneVarFreqLabels.toUpperCase().equals("CONTROL")) {
                    popuNames = new String[1];
                    popuNames[0] = "CONTROL";
                    if (!hasControls) {
                        String info = "The '--gene-freq-score control' cannot be specified because no control samples are input!";
                        throw new Exception(info);
                    }

                    toUseLocal[0] = true;
                    return TupleUtil.tuple(popuNames, effecIndexVarFreq, geneVarFreqFiles);
                } else {
                    for (int i = 0; i < internalNum; i++) {
                        popuNames[i] = options.geneVarFreqLabels.toUpperCase();
                        if (geneVarFreqFiles[i].endsWith("gadexome.gene.freq")) {
                            if (popuNames[i].equals("EUR")) {
                                popuNames[i] = "NFE";
                            }
                        }
                    }
                }
            }

            int availablePopuNum = 0;
            if (popuNames != null) {
                for (int i = 0; i < popuNames.length; i++) {
                    String geneCoVarFilePath = options.PUBDB_FILE_MAP.get(geneVarFreqFiles[i]);
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + geneCoVarFilePath;
                    BufferedReader br = LocalFileFunc.getBufferedReader(geneCoVarFilePath);
                    String[] cells = br.readLine().split("\t");
                    br.close();
                    for (int j = 0; j < cells.length; j++) {
                        if (cells[j].toUpperCase().endsWith(popuNames[i])) {
                            effecIndexVarFreq[i] = j;
                            availablePopuNum++;
                            break;
                        }
                    }
                    if (effecIndexVarFreq[i] < 0) {
                        String infor = "No reference population avaialbe for " + popuNames[i] + " in the gene frequency score file!";
                        throw new Exception(infor);
                    }
                }
            }

            if (internalNum < geneVarFreqFiles.length) {
                for (int i = internalNum; i < geneVarFreqFiles.length; i++) {
                    //the forth column is the freqency
                    effecIndexVarFreq[i] = 3;
                }
            }

        }
        return TupleUtil.tuple(popuNames, effecIndexVarFreq, geneVarFreqFiles);

    }

    public static double setVarFuncScoreBin() {
        double funcScoreBinLen = 0.3;
        if (options.runnerGeneCoding) {
            funcScoreBinLen = 0.2;
        } else if (options.wrenerGeneNonCoding) {
            if (options.cellLineName == null) {
                funcScoreBinLen = 0.03;
            } else {
                funcScoreBinLen = 0.3;
            }
        }
        return funcScoreBinLen;
    }

    public static Map<String, GeneSet> readGeneSets() throws Exception {
        String geneSetDBAnaFile = null;
        Map<String, GeneSet> dbPathwaySet = null;
        if (options.geneSetDB != null) {
            geneSetDBAnaFile = options.PUBDB_FILE_MAP.get(options.geneSetDB);
            geneSetDBAnaFile = GlobalManager.RESOURCE_PATH + "/" + geneSetDBAnaFile;
            GeneSetExplorer genesetExplor = new GeneSetExplorer(geneSetDBAnaFile);
            genesetExplor.loadGSEAGeneSets(options.genesetSizeMin, options.genesetSizeMax);
            dbPathwaySet = genesetExplor.getGeneSetSet();
        } else if (options.geneSetTestFile != null) {
            geneSetDBAnaFile = options.geneSetTestFile;
            GeneSetExplorer genesetExplor = new GeneSetExplorer(geneSetDBAnaFile);
            genesetExplor.loadGSEAGeneSets(options.genesetSizeMin, options.genesetSizeMax);
            dbPathwaySet = genesetExplor.getGeneSetSet();
        }
        return dbPathwaySet;
    }

    public static void indexdbNCFPHandler() throws Exception {
        if (!options.scoreDBLableList.isEmpty()) {
            for (String dbLabelName : options.scoreDBLableList) {
                if (dbLabelName.equals("dbncfp_all")) {
                    String annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_all_SNV_dbNCFP.gz";
                    File annFile = new File(annNCFPPath);
                    if (!annFile.exists()) {
                        String infor = "The resource file " + annFile.getCanonicalPath() + " does not exist! Please manually download the file from http://147.8.193.36/ftp/MX/score/ANN/" + annFile.getName() + " by efficient tools (e.g. FileZilla).";
                        throw new Exception(infor);

                    }
                    //Very RAM comsumming part, we do it at the very begining
                    BGZFInputStream bfIndexes = new BGZFInputStream(annFile.getCanonicalPath(), options.threadNum, true);
                    if (!bfIndexes.checkIndex()) {
                        LOG.info("Building index file for " + annFile.getName() + ". It may take a while ...");
                        bfIndexes.adjustPos();
                        bfIndexes.buildIndex(annFile.getCanonicalPath(), 0, 1, false);
                    }
                } else if (dbLabelName.equals("dbncfp_known")) {
                    String annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_known_SNV_dbNCFP.gz";
                    File annFile = new File(annNCFPPath);
                    if (!annFile.exists()) {
                        String annNCFPPath1 = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_known_SNV_dbNCFP.a.ai.gz";
                        File annFile1 = new File(annNCFPPath1);
                        if (!annFile1.exists()) {
                            String infor = "The resource file " + annFile.getCanonicalPath() + " does not exist! Please manually download the file from http://147.8.193.36/ftp/MX/score/ANN/" + annFile.getName() + " by efficient tools (e.g. FileZilla).";
                            throw new Exception(infor);
                        } else {
                            String[] dbncfpAnnotationScore = new String[]{"known_SNV_dbNCFP.a.aa.gz", "known_SNV_dbNCFP.a.ab.gz", "known_SNV_dbNCFP.a.ac.gz",
                                "known_SNV_dbNCFP.a.ad.gz", "known_SNV_dbNCFP.a.ae.gz", "known_SNV_dbNCFP.a.af.gz", "known_SNV_dbNCFP.a.ag.gz",
                                "known_SNV_dbNCFP.a.ah.gz", "known_SNV_dbNCFP.a.ai.gz"};
                            NetUtils.concatenateFiles(GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_", dbncfpAnnotationScore, "known_SNV_dbNCFP.gz");
                            BGZFInputStream bfIndexes = new BGZFInputStream(annFile.getCanonicalPath(), options.threadNum, true);
                            LOG.info("Building index file for " + annFile.getName() + ". It may take a while ...");
                            bfIndexes.adjustPos();
                            bfIndexes.buildIndex(annFile.getCanonicalPath(), 0, 1, false);
                        }

                    }
                }

            }
        }
    }

    private static void GenomeHanlder(Genome uniqueGenome, boolean[] origionallySorted, int[] maxThreadID, BufferedWriter annovarFilteredInFileWriter) throws Exception {
        Chromosome[] chromosomes = uniqueGenome.getChromosomes();
        for (int chromID = 0; chromID < chromosomes.length; chromID++) {
            uniqueGenome.loadVariantFromDisk(chromID, false, origionallySorted, maxThreadID);
            List<Variant> chromosomeVar = chromosomes[chromID].variantList;
            if (chromosomeVar == null || chromosomeVar.isEmpty()) {
                continue;
            }
            uniqueGenome.export2ANNOVARAnnot(annovarFilteredInFileWriter, chromID);
            chromosomes[chromID].variantList.clear();
        }
    }

    public static TwoTuple<Boolean, Genome> makeVariantMAFFilterSet(Genome uniqueGenome, VCFParserFast vsParser, boolean[] origionallySorted, int[] maxThreadID) throws Exception {
        boolean flag = false;
        boolean[] hasGty = new boolean[1];
        if (options.command != null && options.command.endsWith("--make-filter")) {
            // a special function to more efficiently generate reference
            // variants as filters in the future
            // --make-filter --no-gty-vcf-file
            // ESP5400.snps.vcf/ESP5400.chr_CHROM_.snps.vcf --buildver-in hg19
            // --out hg19_ESP5400.snps.txt --buildver-out hg19
            if (options.inputFormat.equals("--no-gty-vcf-file") || options.inputFormat.equals("--vcf-file")) {
                uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, -9, -9, -9, -9, -9, -9, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel,
                        options.ignoreCNV, options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, false, false, false, false, false, false, null, null, null, null, null, null, null, hasGty);

                File localFileFiler = new File(options.outputFileName + ".kggseq.filter.txt");
                LOG.info("Prepare annotation resources from local VCF file(s)...");
                // altLocalFilterFiles.add(localFileFiler);
                // gtyCorrdiates used to keep the sequential order
                BufferedWriter annovarFilteredInFileWriter = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                    annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                }
                GenomeHanlder(uniqueGenome, origionallySorted, maxThreadID, annovarFilteredInFileWriter);
                annovarFilteredInFileWriter.close();
                uniqueGenome.removeTempFileFromDisk();
                String infor = "The VCF filtration data have been converted into a standard filtration dataset of kggseq, "
                        + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                        + " \', which is faster!\n\n";
                LOG.info(infor);

            } else {
                String infor = "Sorry, --make-filter currently only supports VCF format! Please specify it by \'--vcf-file path/to/file\'";
                throw new Exception(infor);
            }
            flag = true;
        }
        return TupleUtil.tuple(flag, uniqueGenome);
    }

    public static Genome autoGenerateVariantMAFFilterSet(Genome uniqueGenome, VCFParserFast vsParser,
            boolean[] origionallySorted, int[] maxThreadID, List<Individual> subjectList, IntArrayList allEffectIndivIDs) throws Exception {
        boolean needGty = false;
        boolean[] hasGty = new boolean[1];
        if (options.localFilterVCFFileNames != null || options.localHardFilterVCFFileNames != null) {
            List<String> allFiles = new ArrayList<String>();
            if (options.localFilterVCFFileNames != null) {
                allFiles.addAll(Arrays.asList(options.localFilterVCFFileNames));
            }
            if (options.localHardFilterVCFFileNames != null) {
                allFiles.addAll(Arrays.asList(options.localHardFilterVCFFileNames));
            }
            for (String localFilterFileName : allFiles) {
                File localFileFiler = new File(localFilterFileName + ".kggseq.filter.txt");
                LOG.info("Prepare annotation resources from local VCF file(s)...");
                // altLocalFilterFiles.add(localFileFiler);
                // gtyCorrdiates used to keep the sequential order
                uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName + File.separator + localFileFiler.getName(), options.threadNum, null, localFilterFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, -9, -9, -9, -9, -9, -9, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                        options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, false, false, false, false, false, false, null, null, null, null, null, null, null, hasGty);

                BufferedWriter annovarFilteredInFileWriter = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                    annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                }
                GenomeHanlder(uniqueGenome, origionallySorted, maxThreadID, annovarFilteredInFileWriter);
                annovarFilteredInFileWriter.close();
                uniqueGenome.removeTempFileFromDisk();
                String infor = "The VCF filtration data " + localFilterFileName + " have been converted into a standard filtration dataset of kggseq, "
                        + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                        + " \', which is faster!\n\n";
                LOG.info(infor);
                //  varFilter.markByANNOVARefFormat(uniqueGenome, localFileFiler.getCanonicalPath(), localFileFiler.getName(), options.needProgressionIndicator);
            }
        }

        if (options.localHardFilterNoGtyVCFFileNames != null || options.localFilterNoGtyVCFFileNames != null) {//To be discussed.
            List<String> allFiles = new ArrayList<String>();
            if (options.localFilterNoGtyVCFFileNames != null) {
                allFiles.addAll(Arrays.asList(options.localFilterNoGtyVCFFileNames));
            }
            if (options.localHardFilterNoGtyVCFFileNames != null) {
                allFiles.addAll(Arrays.asList(options.localHardFilterNoGtyVCFFileNames));
            }
            for (String localFilterFileName : allFiles) {
                File localFileFiler = new File(localFilterFileName + ".kggseq.filter.txt");
                LOG.info("Prepare annotation resources from local VCF file(s) with no genotype ...");
                //  altLocalFilterFiles.add(localFileFiler);
                // gtyCorrdiates used to keep the sequential order
                uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName + File.separator + localFileFiler.getName(), options.threadNum, null, localFilterFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                        options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, false, options.isVCFOut || options.isVCFOutFilterd, options.isSimpleVCFOut || options.isVCFOut || options.isVCFOutFilterd, true, options.forced2Unphased, subjectList, allEffectIndivIDs, null, null, options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);

                BufferedWriter annovarFilteredInFileWriter = null;
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(localFileFiler.getCanonicalPath() + ".gz"));
                    annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                } else {
                    annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(localFileFiler));
                }
                GenomeHanlder(uniqueGenome, origionallySorted, maxThreadID, annovarFilteredInFileWriter);
                annovarFilteredInFileWriter.close();
                uniqueGenome.removeTempFileFromDisk();
                String infor = "The VCF filtration data " + localFilterFileName + " have been converted into a standard filtration dataset of kggseq, "
                        + localFileFiler.getCanonicalPath() + ".\nYou can directly use the standard one next time by \'--local-filter " + localFileFiler.getCanonicalPath()
                        + " \', which is faster!\n\n";
                LOG.info(infor);
                //  varFilter.markByANNOVARefFormat(uniqueGenome, localFileFiler.getCanonicalPath(), localFileFiler.getName(), options.needProgressionIndicator);
            }
        }
        return uniqueGenome;
    }

    private static void pedFileHandler(List<Individual> subjectList) throws Exception {
        Set<String> caseSet = null;
        Set<String> controlSet = null;
        Set<String> unkownSet = null;

        // if pedigree file is specified options.indivPhenos will be
        // ignored
        if (options.pedFile != null) {
            LinkageFileParser linkPedParser = new LinkageFileParser();
            linkPedParser.readPedigreeOnly(options.pedFile, subjectList, options.useCompositeSubjectID, options.phenotypeColID, options.pheItem);
            caseSet = new HashSet<String>();
            controlSet = new HashSet<String>();
            unkownSet = new HashSet<String>();

            for (Individual indiv : subjectList) {
                switch (indiv.getAffectedStatus()) {
                    case 1:
                        controlSet.add(indiv.getLabelInChip());
                        break;
                    case 2:
                        caseSet.add(indiv.getLabelInChip());
                        break;
                    default:
                        unkownSet.add(indiv.getLabelInChip());
                        break;
                }
            }
        } /*
         * else if
         * (options.genetModel.equals("--compound-heterozygosity")
         * && options.pedFile == null) { throw new Exception(
         * "Please sepcify the relationship of subjects  by \'--ped-file path/to/pedigree/file\' for compound heterozygosity model checking!"
         * ); }
         */ else if (options.indivPhenos != null) {
            caseSet = new HashSet<String>();
            controlSet = new HashSet<String>();
            unkownSet = new HashSet<String>();
            for (String indivID : options.indivPhenos) {
                String label = indivID.substring(0, indivID.indexOf(':'));
                String d = indivID.substring(indivID.indexOf(":") + 1);
                Individual indiv = new Individual();
                switch (d.charAt(0)) {
                    case '1':
                        controlSet.add(label);
                        break;
                    case '2':
                        caseSet.add(label);
                        break;
                    default:
                        unkownSet.add(label);
                        break;
                }
                indiv.setLabelInChip(label);
                indiv.setFamilyID(label);
                indiv.setIndividualID(label);
                indiv.setDadID("0");
                indiv.setMomID("0");
                indiv.setAffectedStatus(d.charAt(0) - '0');
                subjectList.add(indiv);
                double[] traits = new double[1];
                traits[0] = indiv.getAffectedStatus();
                indiv.setTraits(traits);
            }
        }
        if (options.varAssoc) {
            if (caseSet.isEmpty() || controlSet.isEmpty()) {
                String infor = ("Sorry, the option of '--var-assoc' only works for case/control sample!");
                throw new Exception(infor);
            }
        }
        if (options.pedFile != null || options.indivPhenos != null) {
            if (caseSet.isEmpty() && controlSet.isEmpty()) {
                String infor = ("All subjects in phenotype or pedigree file have unknown disease status.\n"
                        + "    Please specify the clear disease status for AT LEAST one subject!!");
                // throw new Exception(infor);
            }
        }
        if (options.covAdjDisease) {
            LogisticRegression lr = new LogisticRegression();

            int intPhe = -1;
            if (options.phenotypeColID != null && options.phenotypeColID.containsKey(options.pheItem)) {
                intPhe = options.phenotypeColID.get(options.pheItem);
            }

            SKAT skat = new SKAT();
            double[] y = skat.getPhenotype(subjectList, true, intPhe);
            double[][] xMat = null;
            if (options.cov) {
                xMat = skat.getCovarite(subjectList, options.phenotypeColID, options.covItems, true);
            }
            lr.setX(xMat);
            lr.setY(y);
            lr.fitLM();
            //options.diseasePrevalence = 0.5;
            //lr.setPriorCorrectionFactor(options.diseasePrevalence);
            // LOG.info(lr.toString());

            double[] deviRes = lr.calcDevianceResiduals();
            int subSize = subjectList.size();

            double cut = Probability.normalInverse(1 - options.probCutDevianceResidue);
            int changedCase = 0, changedControl = 0;
            for (int i = 0; i < subSize; i++) {
                // xMat[i][2] + " " + 
                //System.out.println(xMat[i][1] + "\t" + subjectList.get(i).getAffectedStatus() + "\t" + (lr.getGivenProbability(xMat[i])));
                if (subjectList.get(i).getAffectedStatus() == 2) {
                    if (deviRes[i] < -cut) {
                        subjectList.get(i).setAffectedStatus(0);
                        changedCase++;
                    }
                } else if (subjectList.get(i).getAffectedStatus() == 1) {
                    if (deviRes[i] > cut) {
                        subjectList.get(i).setAffectedStatus(0);
                        changedControl++;
                    }
                }

            }
            LOG.info("After adjustment by the covariables according to the cutoff " + (options.probCutDevianceResidue) + ", " + changedCase + " patients and " + changedControl + " controls are ignored");
        }
    }

    private static boolean needGtyHandler() {
        boolean needGty = false;
        if (options.isPlinkPedOut || options.isPlinkBedOut || options.isBinaryGtyOut || options.isSimpleVCFOut || options.calcLD || options.ldPruning) {
            needGty = true;
        } else if (options.sampleGtyHardFilterCode != null) {
            for (int i = 0; i < 9; i++) {
                if (options.sampleGtyHardFilterCode.contains(String.valueOf(i))) {
                    needGty = true;
                    break;
                }
            }
        } else if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
            needGty = true;
        } else if (options.doubleHitGenePhasedFilter || options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
            needGty = true;
        } else if (options.skatGene || options.skatGeneset || options.rvtestGene || options.rvtestGeneset || options.digeneAssoc || options.uwrunnerDiGeneInteractCoding
                || options.runnerDiGeneInteractCoding || options.runnerMoGeneInteractCoding || options.uwrunnerMoGeneInteractCoding || options.geneCodingLogistAssoc || options.uwrunnerGeneCoding || options.runnerGeneCoding || options.makeDiGeneRef) {
            needGty = true;

        } else if (options.overlappedGeneFilter) {
            needGty = true;
        } else if (options.contextAnnotGFDis > 0) {
            needGty = true;
        }
        return needGty;
    }

    private static SevenTuple<Genome, int[], Boolean, Boolean, int[], int[], String[]> formatVCFFileHandler(Genome uniqueGenome, boolean needGty, int[] pedEncodeGytIDMap, VCFParserFast vsParser, List<Individual> subjectList,
            int[] caseSetID, int[] controlSetID, IntArrayList allEffectIndivIDs) throws Exception {
        pedFileHandler(subjectList);

        boolean[] hasGty = new boolean[1];
        boolean needReadsInfor = false;
        // options.sampleVarHardFilterCode
        if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("7") || options.sampleGtyHardFilterCode.contains("8"))) {
            needReadsInfor = true;
        }
        pedEncodeGytIDMap = new int[subjectList.size()];
        int sizeIndiv = subjectList.size();
        IntArrayList caseSetID1 = new IntArrayList();
        IntArrayList controlSetID1 = new IntArrayList();
        //The order is the same as that of caseSetID and controlSetID

        for (int i = 0; i < sizeIndiv; i++) {
            if (subjectList.get(i).getAffectedStatus() == 2) {
                caseSetID1.add(i);
            } else if (subjectList.get(i).getAffectedStatus() == 1) {
                controlSetID1.add(i);
            }
        }
        String[] subIDs = new String[caseSetID1.size() + controlSetID1.size()];
        if (!caseSetID1.isEmpty()) {
            caseSetID = new int[caseSetID1.size()];
            for (int i = 0; i < caseSetID.length; i++) {
                caseSetID[i] = caseSetID1.getQuick(i);
                subIDs[i] = subjectList.get(caseSetID[i]).getLabelInChip();
            }
        }

        if (!controlSetID1.isEmpty()) {
            controlSetID = new int[controlSetID1.size()];
            for (int i = 0; i < controlSetID.length; i++) {
                controlSetID[i] = controlSetID1.getQuick(i);
                subIDs[i + caseSetID.length] = subjectList.get(controlSetID[i]).getLabelInChip();
            }
        }

        // gtyCorrdiates used to keep the sequential order
        uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, needReadsInfor, options.isVCFOut || options.isVCFOutFilterd, options.isSimpleVCFOut || options.isVCFOut || options.isVCFOutFilterd, false, options.forced2Unphased, subjectList, allEffectIndivIDs,
                caseSetID, controlSetID, options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);

        pedEncodeGytIDMap = vsParser.getPedEncodeGytIDMap();
        /*
         * if (!subjectMap.isEmpty()) { FileOutputStream objFOut =
         * new FileOutputStream(outName + ".gty.obj");
         * BufferedOutputStream objOBfs = new
         * BufferedOutputStream(objFOut); ObjectOutputStream
         * localObjOut = new ObjectOutputStream(objOBfs);
         *
         * localObjOut.writeObject(subjectMap); localObjOut.flush();
         * localObjOut.close(); objOBfs.flush(); objOBfs.close();
         * objFOut.close(); }
         */

        return TupleUtil.tuple(uniqueGenome, pedEncodeGytIDMap, needGty, hasGty[0], caseSetID, controlSetID, subIDs);
    }

    private static ThreeTuple<Genome, int[], Boolean> formatKEDFileHandler(Genome uniqueGenome, int[] pedEncodeGytIDMap, boolean needGty, List<Individual> subjectList) throws Exception {
        Set<String> caseSet = null;
        Set<String> controlSet = null;
        Set<String> unkownSet = null;

        BinaryGtyProcessor bgp = new BinaryGtyProcessor(options.inputFileName);
        bgp.readPedigreeFile(subjectList);
        int[] counts = new int[3];
        Arrays.fill(counts, 0);
        uniqueGenome = bgp.readVariantsMapFile(counts);

        caseSet = new HashSet<String>();
        controlSet = new HashSet<String>();
        unkownSet = new HashSet<String>();
        //In the out put of ked, the genotypes are filled according to the order of subjects in the pedigree file
        pedEncodeGytIDMap = new int[subjectList.size()];
        for (int i = 0; i < pedEncodeGytIDMap.length; i++) {
            pedEncodeGytIDMap[i] = i;
        }
        for (Individual indiv : subjectList) {
            indiv.setHasGenotypes(true);
            if (indiv.getAffectedStatus() == 1) {
                controlSet.add(indiv.getLabelInChip());
            } else if (indiv.getAffectedStatus() == 2) {
                caseSet.add(indiv.getLabelInChip());
            }
        }
        if (options.isPlinkPedOut || options.isPlinkBedOut || options.isBinaryGtyOut || options.isSimpleVCFOut) {
            needGty = true;
        } else if (options.sampleGtyHardFilterCode != null) {
            for (int i = 0; i < 9; i++) {
                if (options.sampleGtyHardFilterCode.contains(String.valueOf(i))) {
                    needGty = true;
                    break;
                }
            }
        } else if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
            needGty = true;
        } else if (options.doubleHitGenePhasedFilter || options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
            needGty = true;
        } else if (options.contextAnnotGFDis > 0) {
            needGty = true;
        }

        StringBuilder message = null;
        if (needGty) {
            message = bgp.readBinaryGenotype(subjectList, uniqueGenome, options.minOBS, options.maxGtyAlleleNum, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel);
        }

        // subject to do something more
        String info = counts[0] + " variant-lines (" + counts[2] + " indels) are scanned in " + options.inputFileName + "; and " + counts[1] + " variants of " + subjectList.size() + " individual(s) are retained for further analysis.";
        LOG.info(message.append(info).append("\n------------------------------------------------------------\n"));
        LOG.info(info);
        uniqueGenome.writeChromsomeToDiskClean();
        return TupleUtil.tuple(uniqueGenome, pedEncodeGytIDMap, needGty);

    }

    private static SixTuple<Genome, int[], Boolean, int[], int[], String[]> formatGTBFileHandler(String gbtBinaryFileName, int[] pedEncodeGytIDMap,
            boolean needGty, List<Individual> subjectList) throws Exception {

        pedFileHandler(subjectList);

        if (subjectList == null) {
            subjectList = new ArrayList<Individual>();
        }
        Genome uniqueGenome = new Genome("InputVariantGenome", options.outputFileName);
        uniqueGenome.removeTempFileFromDisk();

        int[] counts = new int[3];
        Arrays.fill(counts, 0);

        IntArrayList caseSetID1 = new IntArrayList();
        IntArrayList controlSetID1 = new IntArrayList();
        //In the out put of ked, the genotypes are filled according to the order of subjects in the pedigree file

        if (options.isPlinkPedOut || options.isPlinkBedOut || options.isBinaryGtyOut || options.isSimpleVCFOut) {
            needGty = true;
        } else if (options.sampleGtyHardFilterCode != null) {
            for (int i = 0; i < 9; i++) {
                if (options.sampleGtyHardFilterCode.contains(String.valueOf(i))) {
                    needGty = true;
                    break;
                }
            }
        } else if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
            needGty = true;
        } else if (options.doubleHitGenePhasedFilter || options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
            needGty = true;
        } else if (options.contextAnnotGFDis > 0) {
            needGty = true;
        }

        StringBuilder message = null;
        BinaryGtyProcessor bgtp = new BinaryGtyProcessor();
//        bgtp.readVariantsGTBFile(gbtBinaryFileName, subjectList, uniqueGenome, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.maxGtyAlleleNum,
//                options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, counts, needGty);
        bgtp.readVariantsGTBFileThread(gbtBinaryFileName, subjectList, uniqueGenome, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.maxGtyAlleleNum,
                options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, counts, needGty, options.threadNum, options.regionsInPos, options.regionsOutPos);
        // subject to do something more
        String info = counts[0] + " variants (" + counts[2] + " indels) are scanned in " + options.inputFileName + "; and " + counts[1] + " variants of " + subjectList.size() + " individual(s) are retained for further analysis.";
        // LOG.info(message.append(info).append("\n------------------------------------------------------------\n"));
        LOG.info(info);
        uniqueGenome.setVarNum(counts[1]);
        uniqueGenome.writeChromsomeToDiskClean();

        pedEncodeGytIDMap = new int[subjectList.size()];
        for (int i = 0; i < pedEncodeGytIDMap.length; i++) {
            //acturally, it is no need because the genotypes of subjects are in the order of pedigree
            pedEncodeGytIDMap[i] = i;
            if (subjectList.get(i).getAffectedStatus() == 2) {
                caseSetID1.add(i);
            } else if (subjectList.get(i).getAffectedStatus() == 1) {
                controlSetID1.add(i);
            }
        }
        String[] subIDs = new String[caseSetID1.size() + controlSetID1.size()];

        int[] caseSetID, controlSetID;
        if (!caseSetID1.isEmpty()) {
            caseSetID = new int[caseSetID1.size()];
            for (int i = 0; i < caseSetID.length; i++) {
                caseSetID[i] = caseSetID1.getQuick(i);
                subIDs[i] = subjectList.get(caseSetID[i]).getLabelInChip();
            }
        } else {
            caseSetID = new int[0];
        }

        if (!controlSetID1.isEmpty()) {
            controlSetID = new int[controlSetID1.size()];
            for (int i = 0; i < controlSetID.length; i++) {
                controlSetID[i] = controlSetID1.getQuick(i);
                subIDs[i + caseSetID.length] = subjectList.get(controlSetID[i]).getLabelInChip();
            }
        } else {
            controlSetID = new int[0];
        }

        int sizeIndiv = subjectList.size();
        boolean needAccoundAffect = false;
        boolean needAccoundUnaffect = false;

        for (int i = 0; i < sizeIndiv; i++) {
            if (subjectList.get(i).getAffectedStatus() == 2) {
                needAccoundAffect = true;
            } else if (subjectList.get(i).getAffectedStatus() == 1) {
                needAccoundUnaffect = true;
            }
            if (needAccoundAffect && needAccoundUnaffect) {
                break;
            }
        }

        uniqueGenome.setNeedAccoundAffect(needAccoundAffect);
        uniqueGenome.setNeedAccoundUnaffect(needAccoundUnaffect);
        if (!needAccoundUnaffect && !needAccoundAffect) {
            uniqueGenome.setNeedAccoundAll(true);
        }

        return TupleUtil.tuple(uniqueGenome, pedEncodeGytIDMap, needGty, caseSetID, controlSetID, subIDs);
    }

    public static SevenTuple<Genome, int[], Boolean, Boolean, int[], int[], String[]> loadInputVariants(Genome uniqueGenome, VCFParserFast vsParser, List<Individual> subjectList, int[] caseSetID,
            int[] controlSetID, IntArrayList allEffectIndivIDs) throws Exception {
        int[] pedEncodeGytIDMap = null;
        boolean needGty = needGtyHandler();
        boolean[] hasGty = new boolean[1];
        String[] subIDByCaseControlSetID=null;
        if (options.inputFormat.endsWith("--vcf-file")) {
            hasGty[0] = true;

            return formatVCFFileHandler(uniqueGenome, needGty, pedEncodeGytIDMap, vsParser, subjectList, caseSetID, controlSetID, allEffectIndivIDs);
        } else if (options.inputFormat.endsWith("--maf-file")) {
            SimpleFormatParser pileParser = new SimpleFormatParser();
            uniqueGenome = pileParser.readCancerGenomeVariantFormat(options.outputFileName, options.inputFileName, options.needProgressionIndicator);
        } else if (options.inputFormat.endsWith("--no-gty-vcf-file")) {
            // gtyCorrdiates used to keep the sequential order
            uniqueGenome = vsParser.readVariantGtyFilterOnly(options.outputFileName, options.threadNum, null, options.inputFileName, options.seqQual, options.minMappingQuality, options.maxStandBias,
                    options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                    options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel, options.ignoreCNV,
                    options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, needGty, false, false, false, true, options.forced2Unphased, subjectList, allEffectIndivIDs, null, null, options.regionsInPos, options.regionsOutPos, options.groupTags, hasGty);
        } else if (options.inputFormat.endsWith("--ked-file")) {
            ThreeTuple<Genome, int[], Boolean> tuple_tmp = formatKEDFileHandler(uniqueGenome, pedEncodeGytIDMap, needGty, subjectList);
            uniqueGenome = tuple_tmp.getFirst();
            pedEncodeGytIDMap = tuple_tmp.getSecond();

        } else if (options.inputFormat.endsWith("--gtb-file")) {
            hasGty[0] = true;

            SixTuple<Genome, int[], Boolean, int[], int[],String[]> tuple_tmp = formatGTBFileHandler(options.inputFileName, pedEncodeGytIDMap, needGty, subjectList);
            uniqueGenome = tuple_tmp.getFirst();
            pedEncodeGytIDMap = tuple_tmp.getSecond();
            hasGty[0] = tuple_tmp.getThird();
            caseSetID = tuple_tmp.getFourth();
            controlSetID = tuple_tmp.getFifth();
            subIDByCaseControlSetID= tuple_tmp.getSixth();
        } else if (options.inputFormat.endsWith("--annovar-file")) {
            PileupFormatParser pileParser = new PileupFormatParser();
            uniqueGenome = pileParser.readVariantAnnovarFormat(options.inputFileName, options.outputFileName, options.needProgressionIndicator);
            uniqueGenome.writeChromsomeToDiskClean();
        } else if (options.inputFormat.endsWith("--simple-file")) {
            PileupFormatParser pileParser = new PileupFormatParser();
            uniqueGenome = pileParser.readVariantAnnovarFormatSimple(options.inputFileName, options.outputFileName, options.needProgressionIndicator);
            uniqueGenome.writeChromsomeToDiskClean();
        }

        return TupleUtil.tuple(uniqueGenome, pedEncodeGytIDMap, needGty, hasGty[0], caseSetID, controlSetID,subIDByCaseControlSetID);
    }

    public static FourTuple<List<int[]>, FiltrationSummarySet, FiltrationSummarySet, FiltrationSummarySet>
            setSampleGtyHardFilterModels(Genome uniqueGenome, int filterNum, boolean[] genotypeFilters, List<String> setSampleLabelList, VariantFilter varFilter, List<Individual> subjectList) throws Exception {
        boolean filterByModel = false;
        String hardFilterModel = options.sampleGtyHardFilterCode;

        List<int[]> setSampleIDList = null;
        FiltrationSummarySet inheritanceModelFilter2 = null;
        FiltrationSummarySet denovoModelFilter3 = null;
        FiltrationSummarySet somaticModelFilter4 = null;

        if (options.sampleGtyHardFilterCode != null && options.sampleGtyHardFilterCode.length() > 0) {
            for (int i = 0; i < filterNum; i++) {
                String[] cells = options.sampleGtyHardFilterCode.split(",");
                for (int t = 0; t < cells.length; t++) {
                    int s = Integer.parseInt(cells[t]) - 1;
                    if (s < filterNum) {
                        genotypeFilters[s] = true;
                        filterByModel = true;
                    }
                }
            }
            //the de novel mutation filltering will be processed seperately
            if (hardFilterModel.indexOf('7') >= 0) {
                String[] cells = options.sampleGtyHardFilterCode.split(",");
                hardFilterModel = "";
                for (String s : cells) {
                    if (s.equals("7")) {
                        continue;
                    }
                    hardFilterModel += s;
                    hardFilterModel += ",";
                }
                if (hardFilterModel.length() > 0) {
                    hardFilterModel = hardFilterModel.substring(0, hardFilterModel.length() - 1);
                }
            }
        }

        if (filterByModel) {
            inheritanceModelFilter2 = new FiltrationSummarySet("InheritanceModel", uniqueGenome.getVariantFeatureNum());
            inheritanceModelFilter2.initiateAMessage(0, "variants are ignored by genotype-based hard-filtering.");
            inheritanceModelFilter2.initiateAMessage(0, "variant(s) are retained after filtration according to inheritance mode at genotypes, " + hardFilterModel + ".");
        }

        if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("7"))) {
            denovoModelFilter3 = new FiltrationSummarySet("DenovoModel", uniqueGenome.getVariantFeatureNum());
            setSampleIDList = new ArrayList<int[]>();
            varFilter.matchTrioSet(subjectList, setSampleIDList);
            if (setSampleIDList.isEmpty()) {
                String infor = "No recognizable trios! To detect de novo mutation, you have to set the parents-child relationsby the tag --ped-file path/to/file!";
                throw new Exception(infor);
            }
            uniqueGenome.addVariantFeatureLabel("DenovoMutationEvent");
            denovoModelFilter3.initiateAMessage(0, "variant(s) are retained after filtration by denovo mutation!");
        }

        if (options.causingNSPredType == 2 || (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8")))) {
            somaticModelFilter4 = new FiltrationSummarySet("SomaticModel", uniqueGenome.getVariantFeatureNum());
        }

        if (options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8"))) {
            // search somatic mutation between cancer tissue and non-cancer tissues
            if (options.indivPairs == null) {
                String infor = "To detect somatic mutation, you have to set the tumor sample and non-tumor samples pairs by the tag --indiv-pair tumorIndivID1:normalIndivID1,tumorIndivID2:normalIndivID2";
                throw new Exception(infor);
            }

            // search somatic mutation between cancer tissue and non-cancer tissues
            // match pairs
            setSampleIDList = new ArrayList<int[]>();
            varFilter.matchTumorNontumorPair(options.indivPairs, subjectList, setSampleIDList, setSampleLabelList);
            if (setSampleIDList.isEmpty()) {
                List<String> vcfInds = new ArrayList<String>();
                List<String> pedIndivs = new ArrayList<String>();
                for (String pair : options.indivPairs) {
                    String[] invdivs = pair.split(":");
                    vcfInds.add(invdivs[0]);
                    vcfInds.add(invdivs[1]);
                }

                for (int t = 0; t < subjectList.size(); t++) {
                    pedIndivs.add(subjectList.get(t).getLabelInChip());
                }

                String infor = "No recognizable matched Tumor<->Nontumor pairs!\n"
                        + ("The subject IDs in the specified VCF file(s), " + vcfInds.toString() + " are not indentical to those in the phenotype or pedigree file " + pedIndivs.toString() + "!!");
                throw new Exception(infor);
            }
            somaticModelFilter4.initiateAMessage(0, "variant(s) are retained after filtration by somatic mutations!");
            uniqueGenome.addVariantFeatureLabel("SomaticAltAllele");
            uniqueGenome.addVariantFeatureLabel("TNTRefAltRead,P,OR");
        }
        return TupleUtil.tuple(setSampleIDList, inheritanceModelFilter2, denovoModelFilter3, somaticModelFilter4);
    }

    public static SixTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, DoubleArrayList[]> setCaseControlFilters(Genome uniqueGenome, boolean[] uniqueFilters) {
        AnnotationSummarySet assCCUMFV = null;
        if (options.sampleVarHardFilterCode != null) {
            if (options.sampleVarHardFilterCode.equals("case-unique")) {
                uniqueFilters[0] = true;
            } else if (options.sampleVarHardFilterCode.equals("control-unique")) {
                uniqueFilters[1] = true;
            }

            if (uniqueFilters[0] || uniqueFilters[1]) {
                assCCUMFV = new AnnotationSummarySet("casecontrolUniqueModelFilterVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        AnnotationSummarySet assHWD = null;
        if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
            assHWD = new AnnotationSummarySet("hwdTestVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
        }
        AnnotationSummarySet caseControlMAF = null;
        if (options.caseMafLess < 1 || options.caseMafOver > 0 || options.controlMafLess < 1 || options.controlMafOver > 0) {
            caseControlMAF = new AnnotationSummarySet("caseContrlMAF", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
        }
        AnnotationSummarySet ctTypeFilter = null;
        if (options.ctType > 0) {
            ctTypeFilter = new AnnotationSummarySet("ctType", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
        }
        AnnotationSummarySet assSVHF = null;
        DoubleArrayList[] varPArray = null;

        if (options.varAssoc) {
            //List<DoubleArrayList> varPArray = varAnnoter.assocTestVar(uniqueGenome);
            assSVHF = new AnnotationSummarySet("test filter", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("PValueAllelic");
            uniqueGenome.addVariantFeatureLabel("OddAllelic");
            uniqueGenome.addVariantFeatureLabel("PValueDom");
            uniqueGenome.addVariantFeatureLabel("OddDom");
            uniqueGenome.addVariantFeatureLabel("PValueRec");
            uniqueGenome.addVariantFeatureLabel("OddRec");
            uniqueGenome.addVariantFeatureLabel("PValueGeno");

            varPArray = new DoubleArrayList[4];
            for (int i = 0; i < varPArray.length; i++) {
                varPArray[i] = new DoubleArrayList();
            }

        }

        return TupleUtil.tuple(assCCUMFV, assHWD, caseControlMAF, ctTypeFilter, assSVHF, varPArray);
    }

    public static SixTuple<AnnotationSummarySet[], AnnotationSummarySet[], String[], int[][], AnnotationSummarySet, AnnotationSummarySet> setVariantDBAlleleFreqFilters(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet[] varaintDBHardFilterFiles5 = null;
        AnnotationSummarySet[] varaintDBFilterFiles6 = null;
        String[] varaintDBFilterFiles = null;

        int dbFileSize = options.varaintDBLableHardList != null ? options.varaintDBLableHardList.size() : 0;
        if (dbFileSize > 0) {
            varaintDBHardFilterFiles5 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String dbLabelName = options.varaintDBLableHardList.get(i);
                varaintDBHardFilterFiles5[i] = new AnnotationSummarySet(dbLabelName, LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName)), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        dbFileSize = options.varaintDBLableList != null ? options.varaintDBLableList.size() : 0;
        int[][] freqColIndexes = null;
        if (dbFileSize > 0) {
            varaintDBFilterFiles6 = new AnnotationSummarySet[dbFileSize];
            varaintDBFilterFiles = new String[dbFileSize];
            freqColIndexes = new int[dbFileSize][];
            for (int i = 0; i < dbFileSize; i++) {
                String dbLabelName = options.varaintDBLableList.get(i);
                if (dbLabelName.startsWith("exac")) {
                    BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("exac"));
                    String rowS = br.readLine();
                    br.close();
                    varaintDBFilterFiles6[i] = new AnnotationSummarySet("exac", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    freqColIndexes[i] = new int[options.exacPopLables.size()];
                    Arrays.fill(freqColIndexes[i], -1);
                    String[] rowSS = rowS.split("\t");
                    for (int k = 0; k < freqColIndexes[i].length; k++) {
                        rowS = options.exacPopLables.get(k);
                        //the populaiton label start at the forth column
                        for (int t = 4; t < rowSS.length; t++) {
                            if (rowS.equals(rowSS[t])) {
                                freqColIndexes[i][k] = t;
                                uniqueGenome.addVariantFeatureLabel("altFreq@exac" + rowS);
                                break;
                            }
                        }
                        if (freqColIndexes[i][k] < 0) {
                            throw new Exception("The population label " + rowS + " is NOT available in resource file " + options.PUBDB_FILE_MAP.get("exac") + "!");
                        }
                    }
                    varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("exac");

                } else if (dbLabelName.startsWith("gadexome")) {
                    BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadexome"));
                    String rowS = br.readLine();
                    br.close();
                    varaintDBFilterFiles6[i] = new AnnotationSummarySet("gnomad.exome", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    freqColIndexes[i] = new int[options.gnomadExomesPopLables.size()];
                    Arrays.fill(freqColIndexes[i], -1);
                    String[] rowSS = rowS.split("\t");
                    for (int k = 0; k < freqColIndexes[i].length; k++) {
                        rowS = options.gnomadExomesPopLables.get(k);
                        if (rowS.toUpperCase().equals("EUR")) {
                            rowS = "NFE";
                        }
                        //the populaiton label start at the forth column
                        for (int t = 4; t < rowSS.length; t++) {
                            if (rowSS[t].toUpperCase().endsWith(rowS)) {
                                freqColIndexes[i][k] = t;
                                uniqueGenome.addVariantFeatureLabel("altFreq@gnomad.exome" + rowS);
                                break;
                            }
                        }
                        if (freqColIndexes[i][k] < 0) {
                            throw new Exception("The population label " + rowS + " is NOT available in resource file " + options.PUBDB_FILE_MAP.get("gadexome") + "!");
                        }
                    }
                    varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadexome");

                } else if (dbLabelName.startsWith("gadgenome")) {
                    BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadgenome"));
                    String rowS = br.readLine();
                    br.close();
                    varaintDBFilterFiles6[i] = new AnnotationSummarySet("gnomad.genome", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    freqColIndexes[i] = new int[options.gnomadGenomesPopLables.size()];
                    Arrays.fill(freqColIndexes[i], -1);
                    String[] rowSS = rowS.split("\t");

                    for (int k = 0; k < freqColIndexes[i].length; k++) {
                        rowS = options.gnomadGenomesPopLables.get(k);
                        if (rowS.toUpperCase().equals("EUR")) {
                            rowS = "NFE";
                        }
                        //the populaiton label start at the forth column
                        for (int t = 4; t < rowSS.length; t++) {
                            if (rowSS[t].toUpperCase().endsWith(rowS)) {
                                freqColIndexes[i][k] = t;
                                uniqueGenome.addVariantFeatureLabel("altFreq@gnomad.genome" + rowS);
                                break;
                            }
                        }
                        if (freqColIndexes[i][k] < 0) {
                            throw new Exception("The population label " + rowS + " is NOT available in resource file " + options.PUBDB_FILE_MAP.get("gadgenome") + "!");
                        }
                    }
                    varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("gadgenome");

                } else if (dbLabelName.startsWith("ehr")) {
                    varaintDBFilterFiles6[i] = new AnnotationSummarySet("ehr", null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    freqColIndexes[i] = new int[1];
                    freqColIndexes[i][0] = 4;
                    uniqueGenome.addVariantFeatureLabel("altFreq@ehr");
                    varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);

                } else {
                    varaintDBFilterFiles6[i] = new AnnotationSummarySet(dbLabelName, null, new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("altFreq@" + dbLabelName);
                    varaintDBFilterFiles[i] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);
                    freqColIndexes[i] = new int[1];
                    freqColIndexes[i][0] = 4;
                }

            }
        }

        AnnotationSummarySet assFBAFEM = null;
        AnnotationSummarySet assFBAFIM = null;
        if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
            if (options.isAlleleFreqExcMode) {
                assFBAFEM = new AnnotationSummarySet("filterByAlleleFreqExcModel", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            } else {
                assFBAFIM = new AnnotationSummarySet("filterByAlleleFreqIncModel", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        return TupleUtil.tuple(varaintDBHardFilterFiles5, varaintDBFilterFiles6, varaintDBFilterFiles, freqColIndexes, assFBAFEM, assFBAFIM);

    }

    public static FourTuple<AnnotationSummarySet, String, int[], AnnotationSummarySet> setExpressionVariantFilters(Genome uniqueGenome) throws Exception {
        String[] tissueNames = options.varExpressionTissues;
        if (tissueNames != null) {
            String localFilePath = options.PUBDB_FILE_MAP.get("pext");
            localFilePath = GlobalManager.RESOURCE_PATH + "/" + localFilePath;
            AnnotationSummarySet expressVarSum = new AnnotationSummarySet("pext", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            AnnotationSummarySet expressVarSumTmp = new AnnotationSummarySet("pext", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            for (int i = 0; i < tissueNames.length; i++) {
                uniqueGenome.addVariantFeatureLabel(tissueNames[i] + "@pext");
            }

            BufferedReader br = LocalFileFunc.getBufferedReader(localFilePath);
            String rowS = br.readLine();
            br.close();
            String[] cells = rowS.split("\t");
            int[] varExpressionTissuesIndex = new int[tissueNames.length];
            Arrays.fill(varExpressionTissuesIndex, -1);

            for (int i = 0; i < varExpressionTissuesIndex.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (tissueNames[i].equals(cells[j])) {
                        varExpressionTissuesIndex[i] = j;
                        break;
                    }
                }

                if (varExpressionTissuesIndex[i] == -1) {
                    String infor = "The " + tissueNames[i] + " is not a valid tissue or cell type name! Please refere to " + "..." + "  set it correctly.";
                    throw new Exception(infor);
                }
            }
            return TupleUtil.tuple(expressVarSum, localFilePath, varExpressionTissuesIndex, expressVarSumTmp);
        }
        return TupleUtil.tuple(null, null, null, null);
    }

    public static ThreeTuple<AnnotationSummarySet, AnnotationSummarySet, int[]> setcustomizedVariantScoreFilters(Genome uniqueGenome) throws Exception {
        if (options.customizedScoreFilePath != null) {
            String localFilePath = options.customizedScoreFilePath;
            AnnotationSummarySet expressVarSum = new AnnotationSummarySet("CustomizedScore", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            AnnotationSummarySet expressVarSumTmp = new AnnotationSummarySet("CustomizedScore", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());

            BufferedReader br = LocalFileFunc.getBufferedReader(localFilePath);
            String rowS = br.readLine();
            br.close();
            String[] cells = rowS.split("\t");
            int[] varExpressionTissuesIndex = new int[1];
            varExpressionTissuesIndex[0] = 4;
            if (cells.length < 5) {
                String infor = "The file " + localFilePath + " has no customized score at the fifth column!";
                throw new Exception(infor);
            }
            uniqueGenome.addVariantFeatureLabel(cells[4]);

            return TupleUtil.tuple(expressVarSum, expressVarSumTmp, varExpressionTissuesIndex);
        }
        return TupleUtil.tuple(null, null, null);
    }

    public static SixTuple<AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[]>
            setVariantLocalAlleleFreqFilters(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet[] assLocalHardFilterFile5 = null;
        AnnotationSummarySet[] assLocalFilterFile6 = null;

        int dbFileSize = options.localHardFilterFileNames != null ? options.localHardFilterFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalHardFilterFile5 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localHardFilterFileNames[i];
                assLocalHardFilterFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        dbFileSize = options.localFilterFileNames != null ? options.localFilterFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalFilterFile6 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localFilterFileNames[i];
                assLocalFilterFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(strFileName).getName());
            }
        }

        AnnotationSummarySet[] assLocalHardFilterVCFFile5 = null;
        AnnotationSummarySet[] assLocalFilterVCFFile6 = null;

        dbFileSize = options.localHardFilterVCFFileNames != null ? options.localHardFilterVCFFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalHardFilterVCFFile5 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localHardFilterVCFFileNames[i];
                if (options.outGZ) {
                    strFileName += ".kggseq.filter.txt.gz";
                } else {
                    strFileName += ".kggseq.filter.txt";
                }
                assLocalHardFilterVCFFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        dbFileSize = options.localFilterVCFFileNames != null ? options.localFilterVCFFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalFilterVCFFile6 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localFilterVCFFileNames[i];
                if (options.outGZ) {
                    strFileName += ".kggseq.filter.txt.gz";
                } else {
                    strFileName += ".kggseq.filter.txt";
                }
                assLocalFilterVCFFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(options.localFilterVCFFileNames[i]).getName());
            }
        }

        AnnotationSummarySet[] assLocalHardFilterNoGtyVCFFile5 = null;
        AnnotationSummarySet[] assLocalFilterNoGtyVCFFile6 = null;

        dbFileSize = options.localHardFilterNoGtyVCFFileNames != null ? options.localHardFilterNoGtyVCFFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalHardFilterNoGtyVCFFile5 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localHardFilterNoGtyVCFFileNames[i];
                if (options.outGZ) {
                    strFileName += ".kggseq.filter.txt.gz";
                } else {
                    strFileName += ".kggseq.filter.txt";
                }
                assLocalHardFilterNoGtyVCFFile5[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
        }

        dbFileSize = options.localFilterNoGtyVCFFileNames != null ? options.localFilterNoGtyVCFFileNames.length : 0;
        if (dbFileSize > 0) {
            assLocalFilterNoGtyVCFFile6 = new AnnotationSummarySet[dbFileSize];
            for (int i = 0; i < dbFileSize; i++) {
                String strFileName = options.localFilterNoGtyVCFFileNames[i];
                if (options.outGZ) {
                    strFileName += ".kggseq.filter.txt.gz";
                } else {
                    strFileName += ".kggseq.filter.txt";
                }
                assLocalFilterNoGtyVCFFile6[i] = new AnnotationSummarySet(strFileName, LocalFileFunc.getBufferedReader(strFileName), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("altFreq@" + new File(options.localFilterNoGtyVCFFileNames[i]).getName());
            }
        }

        return TupleUtil.tuple(assLocalHardFilterFile5, assLocalFilterFile6, assLocalHardFilterVCFFile5, assLocalFilterVCFFile6, assLocalHardFilterNoGtyVCFFile5, assLocalFilterNoGtyVCFFile6);
    }

    public static FourTuple<FiltrationSummarySet, int[], ReferenceGenome[], int[]> setGeneModelDBs(Genome uniqueGenome) throws Exception {
        FiltrationSummarySet geneDBFilter7 = null;
        int[] variantsCounters = null;
        int dbFileSize = options.geneDBLabels != null ? options.geneDBLabels.length : 0;
        ReferenceGenome[] referenceGenomes = null;
        int[] availableFeatureSizeForGeneDB = new int[dbFileSize];
        if (dbFileSize > 0) {
            geneDBFilter7 = new FiltrationSummarySet("Gene DB", uniqueGenome.getVariantFeatureNum());

            geneDBFilter7.initiateAMessage(0, " variant(s) are retained after filtering by gene features.");
            variantsCounters = new int[VAR_FEATURE_NAMES.length];
            Arrays.fill(variantsCounters, 0);
            referenceGenomes = new ReferenceGenome[dbFileSize];
            File domainFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotDomain.txt.gz");
            GeneRegionParser grp = new GeneRegionParser();
            for (int i = 0; i < dbFileSize; i++) {
                String geneDBLabel = options.geneDBLabels[i];
                String dbFileName = options.PUBDB_FILE_MAP.get(geneDBLabel);
                File idMapFile = null;

                if (geneDBLabel.equals("gencode")) {
                    idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotEnsemblMap.tab.gz");
                    referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                    uniqueGenome.setGencodeAnnot(true);
                    availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                    uniqueGenome.addVariantFeatureLabel("UniProtFeatureForGEncode");
                } else if (geneDBLabel.equals("refgene")) {
                    uniqueGenome.setRefSeqAnnot(true);
                    availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                    uniqueGenome.addVariantFeatureLabel("UniProtFeatureForRefGene");
                    idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotRefSeqMap.tab.gz");
                    // unforturately the ucsc file rna fasta file
                    // are not always consistant with the ucsc
                    // chromsome fasta
                    // refGenome =
                    // grp.readRefGeneSeqUcsc(GlobalManager.RESOURCE_PATH
                    // + "/" + dbFileName,
                    // GlobalManager.RESOURCE_PATH + "/" +
                    // "refMrna.fa.gz", geneDBLabel,
                    // options.splicingDis, options.neargeneDis,
                    // domainFile, idMapFile);
                    referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                } else if (geneDBLabel.equals("ensembl")) {
                    idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotEnsemblMap.tab.gz");
                    referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                    uniqueGenome.setEnsemblAnnot(true);
                    availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                    uniqueGenome.addVariantFeatureLabel("UniProtFeatureForEnsembl");
                } else if (geneDBLabel.equals("knowngene")) {
                    idMapFile = new File(GlobalManager.RESOURCE_PATH + "/UniprotUCSCKnownGeneMap.tab.gz");
                    referenceGenomes[i] = grp.readRefGeneSeq(GlobalManager.RESOURCE_PATH + "/" + dbFileName, geneDBLabel, options.splicingDis, options.neargeneDis, domainFile, idMapFile);
                    uniqueGenome.setKnownAnnot(true);
                    availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                    uniqueGenome.addVariantFeatureLabel("UniProtFeatureForKnownGene");
                } else {
                    File dbFile = new File(geneDBLabel);
                    uniqueGenome.setCustomizeAnnot(true);
                    availableFeatureSizeForGeneDB[i] = uniqueGenome.getVariantFeatureNum();
                    referenceGenomes[i] = grp.readRefGeneSeq(dbFile.getCanonicalPath(), dbFile.getName(), options.splicingDis, options.neargeneDis, null, null);
                    referenceGenomes[i].setName(dbFile.getName());
                }
                referenceGenomes[i].setName(geneDBLabel);
            }
        }
        return TupleUtil.tuple(geneDBFilter7, variantsCounters, referenceGenomes, availableFeatureSizeForGeneDB);
    }

    public static TwoTuple<Integer, Integer> setFeaturesForGeneMutationRateTest(Genome uniqueGenome, boolean hasControls, List<String> featureLabels) {
        //to summarize
        int somatNumIndex = -1;
        int readInfoIndex = -1;
        for (int i = 0; i < featureLabels.size(); i++) {
            if (featureLabels.get(i).equals("EAS")) //  if (featureLabels.get(i).equals("SomaticAltAllele"))
            {
                somatNumIndex = i;
            } else if (featureLabels.get(i).equals("TNTRefAltRead,P,OR")) {
                readInfoIndex = i;
            }
            if (somatNumIndex >= 0 && readInfoIndex >= 0) {
                break;
            }
        }
        // special consideration for pileup files
        if (somatNumIndex < 0) {
            for (int i = 0; i < featureLabels.size(); i++) {
                if (featureLabels.get(i).equals("SomaticAltAllele")) {
                    somatNumIndex = i;
                    break;
                }
            }
        }

        if (somatNumIndex >= 0) {
            uniqueGenome.addGeneFeatureLabel("ResponseVar");
            uniqueGenome.addGeneFeatureLabel("ExplanatoryVar");
            uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScore");
            uniqueGenome.addGeneFeatureLabel("NonsynonymousReadsRatio");
            uniqueGenome.addGeneFeatureLabel("SynonymousReadsRatio");
            if (readInfoIndex > 0) {
                uniqueGenome.addGeneFeatureLabel("SomatReadsInfor");
            }
        } else {
            uniqueGenome.addGeneFeatureLabel("ResponseVar");
            uniqueGenome.addGeneFeatureLabel("ExplanatoryVar");
            uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScore");
            if (hasControls) {
                uniqueGenome.addGeneFeatureLabel("ResponseVarControl");
                uniqueGenome.addGeneFeatureLabel("ExplanatoryVarControl");
                uniqueGenome.addGeneFeatureLabel("ResponseVarFuncScoreControl");
            }

        }
        return TupleUtil.tuple(somatNumIndex, readInfoIndex);
    }

    private static Map<String, Object> dbncfpHandler(Genome uniqueGenome, String dbLabelName, String[] nonCodingPredicLabels, Map genicMap, Bayes bayesPredictor) throws Exception {
        String annNCFPPath = null;
        AnnotationSummarySet dbNoncodePred9d0 = null;
        FiltrationSummarySet dbNoncodePred9d1 = null;
        AnnotationSummarySet dbNoncodePred9d0Tmp = null;
        FiltrationSummarySet dbNoncodePred9d1Tmp = null;
        String resourcePathList[];
        boolean[] resourceTypeIsRegion;
        MyRandomForest[][] myRandomForestList = null;
        String[] currentLineList = null;
        BufferedReader[] lineReaderList = null;
        Boolean[] isReigonList = null;
        double iniScore[] = null;
        int[] fixedPosition = null;
        int scoreIndexNum = 0;
        FiltrationSummarySet dbNoncodePred9d2 = null;
        FiltrationSummarySet dbNoncodePred9d2Tmp = null;
        BufferedReader[] lineReaderList9d2 = null;
        boolean flag = false;
        AnnotationSummarySet dbNoncodeRegBase9d3 = null;

        Map<String, Object> result = new HashMap<>();
        if (dbLabelName.equals("dbncfp_known") || dbLabelName.equals("dbncfp_all")) {
            if (dbLabelName.equals("dbncfp_known")) {
                annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_known_SNV_dbNCFP.gz";
            } else {
                annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_all_SNV_dbNCFP.gz";

            }
            String comPath = options.refGenomeVersion + "/" + options.refGenomeVersion + "_funcnote";

            dbNoncodePred9d0 = new AnnotationSummarySet("noncodeScore", uniqueGenome.getVariantFeatureNum());
            dbNoncodePred9d0Tmp = new AnnotationSummarySet("noncodeScore", uniqueGenome.getVariantFeatureNum());

            for (String str : nonCodingPredicLabels) {
                uniqueGenome.addVariantScore2Label(str);
            }
            if (options.ncFuncPred) {
                dbNoncodePred9d1 = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                dbNoncodePred9d1Tmp = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                resourcePathList = new String[]{
                    GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.DNase-seq.cmp.gz",
                    GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.FAIRE-seq.cmp.gz",
                    GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Histone.cmp.gz",
                    GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Tfbs.cmp.gz",
                    GlobalManager.RESOURCE_PATH + comPath + "_all.footprints.bed.gz.cmp.gz"
                };
                resourceTypeIsRegion = new boolean[]{true, true, true, true, true};

                uniqueGenome.addVariantFeatureLabel("IsComplexDiseasePathogenic");
                uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                String genicRegion[] = new String[]{"5UTR", "3UTR", "intronic", "upstream", "downstream", "ncRNA", "intergenic"};
                for (int i = 0; i < genicRegion.length; i++) {
                    genicMap.put(genicRegion[i], i);
                }

                List<String> tmpStringCurrentList = new ArrayList<String>();
                List<BufferedReader> tmpLineReadersList = new ArrayList<BufferedReader>();
                List<Boolean> isRegionResource = new ArrayList<Boolean>();

                for (int i = 0; i < resourcePathList.length; i++) {
                    File rsFile = new File(resourcePathList[i]);
                    if (!rsFile.exists()) {
                        LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                        flag = true;
                        result.put("return", flag);
                        return result;
                    } else {
                        try {
                            BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                            tmpLineReadersList.add(lineReader);
                            isRegionResource.add(resourceTypeIsRegion[i]);
                            if (resourceTypeIsRegion[i]) {
                                //The ANN format has no head
                                tmpStringCurrentList.add(lineReader.readLine());
                            }
                        } catch (Exception e) {
                            // TODO: handle exception
                            e.printStackTrace();
                        }
                    }
                }

                currentLineList = tmpStringCurrentList.toArray(new String[tmpStringCurrentList.size()]);
                lineReaderList = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                isReigonList = isRegionResource.toArray(new Boolean[isRegionResource.size()]);
                String cells[] = null;
                String[] currentChrom = new String[isReigonList.length];
                int[] currentStartPos = new int[isReigonList.length];
                int[] currentEndPos = new int[isReigonList.length];

                fixedPosition = new int[isReigonList.length + 1];
                fixedPosition[0] = 0;
                List<String> scoreLabels = new ArrayList<String>();
                int startPosition = 3;
                for (int i = 0; i < currentLineList.length; i++) {
                    //only consider regions
                    if (isReigonList[i]) {
                        cells = Util.tokenize(currentLineList[i], '\t');
                        startPosition = 3;
                        currentEndPos[i] = Util.parseInt(cells[2]);
                        for (int j = startPosition; j < cells.length; j++) {
                            scoreLabels.add(cells[j]);
                            scoreIndexNum++;
                        }
                        fixedPosition[i + 1] = cells.length - startPosition + fixedPosition[i];
                    }
                    currentLineList[i] = lineReaderList[i].readLine();
                }

                if (options.needVerboseNoncode) {
                    uniqueGenome.getVariantScore2Labels().addAll(scoreLabels);
                }
                scoreLabels.clear();
                iniScore = new double[scoreIndexNum];

                Arrays.fill(iniScore, Double.NaN);
                for (int k = 0; k < fixedPosition.length - 1; k++) {
                    if (isReigonList[k]) {
                        for (int k2 = fixedPosition[k]; k2 < fixedPosition[k + 1]; k2++) {
                            iniScore[k2] = 0.0;
                        }
                    }
                }
                myRandomForestList = new MyRandomForest[options.threadNum][];
                for (int k = 0; k < options.threadNum; k++) {
                    String fileName = GlobalManager.RESOURCE_PATH + "hgmd_model.obj";
                    FileInputStream objFIn = new FileInputStream(fileName);
                    BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                    ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                    myRandomForestList[k] = (MyRandomForest[]) localObjIn.readObject();
                    localObjIn.close();
                    objIBfs.close();
                    objFIn.close();
                }

                dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be complex-disease-pathogenic;");
                dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be non-pathogenic according to the Random forest prediction model.");
                dbNoncodePred9d1.initiateAMessage(0, "variant(s) are retained after filtered by the complex disease prediction.");
            }
            /*else if (options.ncFuncPred == 1) {
                            dbNoncodePred9d1 = new FiltrationSummarySet("noncode Random Forest", uniqueGenome.getVariantFeatureNum());
                            resourcePathList = new String[]{
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.DNase-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.FAIRE-seq.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Histone.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_encode_megamix.bed.gz.Tfbs.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_all.footprints.bed.gz.cmp.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_GWAVA.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_CADD.CScore.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_DANN.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_fathmm-MKL.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_FunSeq.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_FunSeq2.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_GWAS3D.gz",
                                GlobalManager.RESOURCE_PATH + comPath + "_SuRFR.gz"
                            };
                            resourceTypeIsRegion = new boolean[]{true, true, true, true, true, false, false, false, false, false, false, false, false};

                            uniqueGenome.addVariantFeatureLabel("IsComplexDiseasePathogenic");
                            uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                            String genicRegion[] = new String[]{"5UTR", "3UTR", "intronic", "upstream", "downstream", "ncRNA", "intergenic"};
                            for (int i = 0; i < genicRegion.length; i++) {
                                genicMap.put(genicRegion[i], i);
                            }

                            List<String> tmpStringCurrentList = new ArrayList<String>();
                            List<BufferedReader> tmpLineReadersList = new ArrayList<BufferedReader>();
                            List<Boolean> isRegionResource = new ArrayList<Boolean>();

                            for (int i = 0; i < resourcePathList.length; i++) {
                                File rsFile = new File(resourcePathList[i]);
                                if (!rsFile.exists()) {
                                    LOG.warn(rsFile.getCanonicalPath() + " does not exist! Scores on this chromosome are ignored!");
                                    return;
                                } else {
                                    try {
                                        BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());
                                        tmpLineReadersList.add(lineReader);
                                        isRegionResource.add(resourceTypeIsRegion[i]);
                                        tmpStringCurrentList.add(lineReader.readLine());
                                    } catch (Exception e) {
                                        // TODO: handle exception
                                        e.printStackTrace();
                                    }
                                }
                            }

                            currentLineList = tmpStringCurrentList.toArray(new String[tmpStringCurrentList.size()]);
                            lineReaderList = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                            isReigonList = isRegionResource.toArray(new Boolean[isRegionResource.size()]);
                            String cells[] = null;
                            String[] currentChrom = new String[isReigonList.length];
                            int[] currentStartPos = new int[isReigonList.length];
                            int[] currentEndPos = new int[isReigonList.length];

                            fixedPosition = new int[isReigonList.length + 1];
                            fixedPosition[0] = 0;
                            List<String> scoreLabels = new ArrayList<String>();
                            for (int i = 0; i < currentLineList.length; i++) {
                                cells = Util.tokenize(currentLineList[i], '\t');
                                int startPosition = 2;
                                currentChrom[i] = cells[0];
                                currentStartPos[i] = Util.parseInt(cells[1]);
                                if (isReigonList[i]) {
                                    startPosition = 3;
                                    currentEndPos[i] = Util.parseInt(cells[2]);
                                }
                                for (int j = startPosition; j < cells.length; j++) {
                                    scoreLabels.add(cells[j]);
                                    scoreIndexNum++;
                                }
                                fixedPosition[i + 1] = cells.length - startPosition + fixedPosition[i];
                                currentLineList[i] = lineReaderList[i].readLine();
                            }
                            if (options.needVerboseNoncode) {
                                uniqueGenome.getVariantScore1Labels().addAll(scoreLabels);
                            } else {
                                int scoreNum = scoreLabels.size();
                                for (int i = scoreNum - 10; i < scoreNum; i++) {
                                    uniqueGenome.addVariantScore2Label(scoreLabels.get(i));
                                }
                            }
                            scoreLabels.clear();
                            iniScore = new double[scoreIndexNum];

                            Arrays.fill(iniScore, Double.NaN);
                            for (int k = 0; k < fixedPosition.length - 1; k++) {
                                if (isReigonList[k]) {
                                    for (int k2 = fixedPosition[k]; k2 < fixedPosition[k + 1]; k2++) {
                                        iniScore[k2] = 0.0;
                                    }
                                }
                            }
                            myRandomForestList = new MyRandomForest[options.threadNum][];
                            for (int k = 0; k < options.threadNum; k++) {
                                String fileName = GlobalManager.RESOURCE_PATH + "hgmd_model.obj";
                                FileInputStream objFIn = new FileInputStream(fileName);
                                BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                                ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                                myRandomForestList[k] = (MyRandomForest[]) localObjIn.readObject();
                                localObjIn.close();
                                objIBfs.close();
                                objFIn.close();
                            }

                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be complex-disease-pathogenic;");
                            dbNoncodePred9d1.initiateAMessage(0, "variants are predicted to be non-pathogenic according to the Random forest prediction model.");
                            dbNoncodePred9d1.initiateAMessage(0, "variant(s) are retained after filtered by the complex disease prediction.");
                        } else */

            boolean cellTypeSpec = options.cellLineName != null;
            if (options.ncRegPred) {
                dbNoncodePred9d2 = new FiltrationSummarySet("noncode Bayes model", uniqueGenome.getVariantFeatureNum());
                dbNoncodePred9d2Tmp = new FiltrationSummarySet("noncode Bayes model", uniqueGenome.getVariantFeatureNum());
                // bayesPredictor.changeFeatureNum(options.dbncfpFeatureName);
                if (cellTypeSpec) {
                    bayesPredictor.changeCellLineName(options.cellLineName);
                }
                bayesPredictor.readResource(cellTypeSpec);
                /*
                            LinkedList<BufferedReader> tmpLineReadersList = new LinkedList<BufferedReader>();
                            comPath = options.refGenomeVersion + "/" + options.refGenomeVersion + "_funcnote_";
                            for (int i = 0; i < options.dbncfpFeatureName.length; i++) {
                                File rsFile = new File(GlobalManager.RESOURCE_PATH + comPath + options.dbncfpFeatureName[i] + ".gz");
                                if (!rsFile.exists()) {
                                    LOG.error(options.dbncfpFeatureName[i] + " does not exist! Scores on this chromosome are ignored!");
                                } else {
                                    try {
                                        BufferedReader lineReader = LocalFileFunc.getBufferedReader(rsFile.getCanonicalPath());;
                                        tmpLineReadersList.add(lineReader);
                                    } catch (Exception e) {
                                        // TODO: handle exception
                                        e.printStackTrace();
                                    }
                                }
                            }
                            for (int i = 0; i < options.dbncfpFeatureName.length; i++) {
                                uniqueGenome.addVariantFeatureLabel(options.dbncfpFeatureName[i]);
                            }
                            lineReaderList9d2 = tmpLineReadersList.toArray(new BufferedReader[tmpLineReadersList.size()]);
                 */
                uniqueGenome.addVariantFeatureLabel("BF");
                uniqueGenome.addVariantFeatureLabel("Composite_Prob");
                if (cellTypeSpec) {
                    uniqueGenome.addVariantFeatureLabel("Cell_Prob");
                    uniqueGenome.addVariantFeatureLabel("Combine_Prob");
                }
            }
            result.put("annNCFPPath", annNCFPPath);
            result.put("dbNoncodePred9d0", dbNoncodePred9d0);
            result.put("dbNoncodePred9d1", dbNoncodePred9d1);
            result.put("dbNoncodePred9d0Tmp", dbNoncodePred9d0Tmp);
            result.put("dbNoncodePred9d1Tmp", dbNoncodePred9d1Tmp);
            result.put("myRandomForestList", myRandomForestList);
            result.put("currentLineList", currentLineList);
            result.put("lineReaderList", lineReaderList);
            result.put("isReigonList", isReigonList);
            result.put("iniScore", iniScore);
            result.put("fixedPosition", fixedPosition);
            result.put("scoreIndexNum", scoreIndexNum);
            result.put("dbNoncodePred9d2", dbNoncodePred9d2);
            result.put("dbNoncodePred9d2Tmp", dbNoncodePred9d2Tmp);
            result.put("lineReaderList9d2", lineReaderList9d2);
            result.put("return", flag);
        } else if (dbLabelName.startsWith("regbase_known") || dbLabelName.startsWith("regbase_all")) {
            if (dbLabelName.startsWith("dbncfp_known")) {
                annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_known__SNV_regBaseV1.0_prediction.ccf";
            } else {
                annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/" + options.refGenomeVersion + "_all_SNV_regBaseV1.0_prediction.ccf";

            }

            dbNoncodeRegBase9d3 = new AnnotationSummarySet("noncode RegBase", uniqueGenome.getVariantFeatureNum());
            //dbNoncodePred9d3.initiateAMessage(0, "variants are assgined scores;");
            int index = dbLabelName.indexOf(":");
            if (index < 0) {
                throw new Exception("The format of '" + dbLabelName + "' is incorrect. The correct should be like '--db-score regbase_all:CAN_PHRED'");
            }
            String colLable = dbLabelName.substring(index + 1);
            String[] colLables = colLable.split(",");
            for (int i = 0; i < colLables.length; i++) {
                uniqueGenome.addVariantFeatureLabel("regbase_" + colLables[i]);
            }
            dbNoncodeRegBase9d3.setDbColNames(colLables);
            /*
            BufferedReader br = LocalFileFunc.getBufferedReader(annNCFPPath);
            int[] labelIndexes = new int[colLables.length];
            Arrays.fill(labelIndexes, -1);
            String[] cells = br.readLine().split("\t");
            br.close();
            for (int i = 0; i < labelIndexes.length; i++) {
                for (int j = 0; j < cells.length; j++) {
                    if (colLables[i].equals(cells[j])) {
                        labelIndexes[i] = j;
                        break;
                    }
                }
                if (labelIndexes[i] < 0) {
                    String info = "The column name " + colLables[i] + " is not avaiable in " + annNCFPPath + "!";
                    throw new Exception(info);
                } else {
                    uniqueGenome.addVariantFeatureLabel("regbase_" + colLables[i]);
                }
            }
            dbNoncodeRegBase9d3.setColDBIndexes(labelIndexes);
             */
            result.put("annNCFPPath", annNCFPPath);
            result.put("dbNoncodeRegBase9d3", dbNoncodeRegBase9d3);
            result.put("return", flag);
        }

        return result;
    }

    private static Map<String, Object> dbEpimakerHandler(Genome uniqueGenome, String dbLabelName, String[] nonCodingPredicLabels, Map genicMap, Bayes bayesPredictor) throws Exception {
        String annNCFPPath = null;
        AnnotationSummarySet dbNoncodeRegBase9d4 = null;

        boolean flag = false;

        Map<String, Object> result = new HashMap<>();
        if (dbLabelName.equals("BSS01551_SMC3")) {

            annNCFPPath = options.PUBDB_FILE_MAP.get(dbLabelName);
            annNCFPPath = GlobalManager.RESOURCE_PATH + "/" + annNCFPPath;
            dbNoncodeRegBase9d4 = new AnnotationSummarySet("noncode RegBase", uniqueGenome.getVariantFeatureNum());
            String[] dbColNames = new String[]{dbLabelName};

            dbNoncodeRegBase9d4.setDbColNames(dbColNames);
            for (int i = 0; i < dbColNames.length; i++) {
                uniqueGenome.addVariantFeatureLabel(dbColNames[i]);
            }

            result.put("annNCFPPath", annNCFPPath);
            result.put("dbNoncodeRegBase9d4", dbNoncodeRegBase9d4);
            result.put("return", flag);
        }
        return result;
    }

    private static Map<String, Object> dbnsfpHandler(Genome uniqueGenome, String dbLabelName, int[] dbNSFP3ScoreIndexes,
            int[] dbNSFP3PredicIndex, List<CombOrders> combOrderList, MyRandomForest[][] myRandomForestsCancer) throws Exception {
        String currentLine;
        FiltrationSummarySet dbNSFPAnnot8 = null;
        FiltrationSummarySet dbNSFPPred9 = null;
        FiltrationSummarySet dbNSFPAnnot8Tmp = null;
        FiltrationSummarySet dbNSFPPred9Tmp = null;
        CombOrders fixedComb = null;
        Map<String, Object> result = new HashMap<>();

        if (dbLabelName.equals("dbnsfp")) {
            String dbFileName = options.PUBDB_FILE_MAP.get(dbLabelName);
            String path = null;
            boolean existFile = false;
            for (int s = STAND_CHROM_NAMES.length - 1; s >= 0; s--) {
                path = GlobalManager.RESOURCE_PATH + "/" + dbFileName + STAND_CHROM_NAMES[s] + ".gz";
                File f = new File(path);
                if (f.exists()) {
                    existFile = true;
                    break;
                }
            }
            if (!existFile) {
                throw new Exception("No dbNSFP resource data available!");
            }
            BufferedReader br = LocalFileFunc.getBufferedReader(path);
            currentLine = br.readLine();
            String[] cells = currentLine.split("\t");
            br.close();

            dbNSFPAnnot8 = new FiltrationSummarySet("dbNSFP", uniqueGenome.getVariantFeatureNum());
            dbNSFPAnnot8.initiateAMessage(0, "coding nonsynonymous variants are assigned functional prediction scores.");

            dbNSFPAnnot8Tmp = new FiltrationSummarySet("dbNSFP", uniqueGenome.getVariantFeatureNum());
            dbNSFPAnnot8Tmp.initiateAMessage(0, "coding nonsynonymous variants are assigned functional prediction scores.");

            for (int t = 0; t < dbNSFP3ScoreIndexes.length; t++) {
                uniqueGenome.getScore1Labels().add(cells[dbNSFP3ScoreIndexes[t]]);
            }
            for (int t = 0; t < dbNSFP3PredicIndex.length; t++) {
                uniqueGenome.addVariantFeatureLabel(cells[dbNSFP3PredicIndex[t]]);
            }
            if (options.causingNSPredType == 0) {
                // MendelFilter
                String logitParamFile = GlobalManager.RESOURCE_PATH + "/mendelcausalrare" + options.dbnsfpVersion + ".param.gz";
                br = LocalFileFunc.getBufferedReader(logitParamFile);
                String line = null;

                CombOrderComparator coc = new CombOrderComparator();
                // String[] names = {"SLR_test_statistic", "SIFT_score",
                // "Polyphen2_HDIV_score", "Polyphen2_HVAR_score", "LRT_score",
                // "MutationTaster_score", "MutationAssessor_score", "FATHMM_score",
                // "GERP++_NR", "GERP++_RS", "phyloP", "29way_logOdds"};
                boolean isFixed = false;
                if (!options.predictExplanatoryVar.startsWith("all") && !options.predictExplanatoryVar.startsWith("best")) {
                    isFixed = true;
                }
                float aucCutoff = 0.9f;
                while ((line = br.readLine()) != null) {
                    if (line.trim().length() == 0) {
                        continue;
                    }
                    if (line.trim().startsWith("#")) {
                        continue;
                    }
                    cells = line.split("\t");
                    RegressionParams rp = new RegressionParams();

                    String[] values = cells[1].split(";");
                    rp.coef = new double[values.length];
                    for (int i = 0; i < rp.coef.length; i++) {
                        rp.coef[i] = Double.parseDouble(values[i]);
                    }
                    rp.sampleCase2CtrRatio = Double.parseDouble(cells[2]);
                    rp.optimalCutoff = Double.parseDouble(cells[3].split(";")[0]);
                    rp.truePositiveRate = Double.parseDouble(cells[3].split(";")[1]);
                    rp.trueNegativeRate = Double.parseDouble(cells[3].split(";")[2]);

                    CombOrders co = new CombOrders(cells[0], Double.parseDouble(cells[4]), rp);
                    if (isFixed) {
                        if (cells[0].equals(options.predictExplanatoryVar)) {
                            fixedComb = co;
                            break;
                        }
                    } else {
                        if (co.auc < aucCutoff) {
                            continue;
                        }
                        combOrderList.add(co);
                    }
                }

                br.close();
                Collections.sort(combOrderList, coc);
                dbNSFPPred9 = new FiltrationSummarySet("dbNSFPMendelPred", uniqueGenome.getVariantFeatureNum());

                uniqueGenome.addVariantFeatureLabel("DiseaseCausalProb_ExoVarTrainedModel");
                uniqueGenome.addVariantFeatureLabel("IsRareDiseaseCausal_ExoVarTrainedModel");
                uniqueGenome.addVariantFeatureLabel("BestCombinedTools:OptimalCutoff:TP:TN");

                dbNSFPPred9.initiateAMessage(0, "variants (in");
                dbNSFPPred9.initiateAMessage(0, "genes) are predicted to be disease-causal;");
                dbNSFPPred9.initiateAMessage(0, "variants are predicted to be non-disease-causal according to the Logistic regression prediction model trained by ExoVar dataset (http://pmglab.top/kggseq/download/ExoVar.xls)");
                dbNSFPPred9.initiateAMessage(0, "variant(s) are retained after filtered by the disease mutation prediction.");

                dbNSFPPred9Tmp = new FiltrationSummarySet("dbNSFPMendelPred", uniqueGenome.getVariantFeatureNum());
                dbNSFPPred9Tmp.initiateAMessage(0, "variants (in");
                dbNSFPPred9Tmp.initiateAMessage(0, "genes) are predicted to be disease-causal;");
                dbNSFPPred9Tmp.initiateAMessage(0, "variants are predicted to be non-disease-causal according to the Logistic regression prediction model trained by ExoVar dataset (http://pmglab.top/kggseq/download/ExoVar.xls)");
                dbNSFPPred9Tmp.initiateAMessage(0, "variant(s) are retained after filtered by the disease mutation prediction.");

            } else if (options.causingNSPredType == 2) {
                for (int s = 0; s < options.threadNum; s++) {
                    try {
                        File fileName = new File(GlobalManager.RESOURCE_PATH + "/CancerRandomForests" + options.dbnsfpVersion + ".obj");
                        if (!fileName.exists()) {
                            throw new Exception("Cannot find data in hard disk!");
                        }

                        FileInputStream objFIn = new FileInputStream(fileName);
                        BufferedInputStream objIBfs = new BufferedInputStream(objFIn);
                        ObjectInputStream localObjIn = new ObjectInputStream(objIBfs);
                        myRandomForestsCancer[s] = (MyRandomForest[]) localObjIn.readObject();
                        localObjIn.close();
                        objIBfs.close();
                        objFIn.close();
                    } catch (Exception ex) {
                        LOG.error(ex);
                    }
                }
                // has some unsovled problem
                /*
                             Kryo kryo = new Kryo();

                             kryo.setReferences(false);
                             kryo.setRegistrationRequired(false);
                             kryo.setInstantiatorStrategy(new StdInstantiatorStrategy());
                             //note: it seems the order of registered classes is very very important
                             kryo.register(MyRandomTree.class);
                             kryo.register(MyRandomTree[].class);
                             kryo.register(MyRandomForest.class);

                             Input input = new Input(new FileInputStream(fileName), 1024 * 1024);
                             myRandomForestsCancer = (MyRandomForest) kryo.readObject(input, MyRandomForest.class);
                             input.close();
                 */
                dbNSFPPred9 = new FiltrationSummarySet("dbNSFPCancerPred", uniqueGenome.getVariantFeatureNum());
                dbNSFPPred9.initiateAMessage(0, "variants (in");
                dbNSFPPred9.initiateAMessage(0, "genes) are predicted to be cancer-driver;");
                dbNSFPPred9.initiateAMessage(0, "variants are predicted to be non-cancer-driver according to a Random Forests prediction model trained by COSMIC dataset (http://cancer.sanger.ac.uk/cancergenome/projects/cosmic/).");
                dbNSFPPred9.initiateAMessage(0, "variant(s) are retained after filtered by the cancer-driver mutation prediction.");

                uniqueGenome.addVariantFeatureLabel("IsHighMut_COSMICTrainedModel");
                uniqueGenome.addVariantFeatureLabel("RandomForestScore");

                dbNSFPPred9Tmp = new FiltrationSummarySet("dbNSFPCancerPred", uniqueGenome.getVariantFeatureNum());
                dbNSFPPred9Tmp.initiateAMessage(0, "variants (in");
                dbNSFPPred9Tmp.initiateAMessage(0, "genes) are predicted to be cancer-driver;");
                dbNSFPPred9Tmp.initiateAMessage(0, "variants are predicted to be non-cancer-driver according to a Random Forests prediction model trained by COSMIC dataset (http://cancer.sanger.ac.uk/cancergenome/projects/cosmic/).");
                dbNSFPPred9Tmp.initiateAMessage(0, "variant(s) are retained after filtered by the cancer-driver mutation prediction.");

            }
        }
        result.put("dbNSFPAnnot8", dbNSFPAnnot8);
        result.put("dbNSFPPred9", dbNSFPPred9);
        result.put("dbNSFPAnnot8Tmp", dbNSFPAnnot8Tmp);
        result.put("dbNSFPPred9Tmp", dbNSFPPred9Tmp);
        result.put("fixedComb", fixedComb);
        return result;
    }

    public static Map<String, Object> addVarFuncScoreLabels(Genome uniqueGenome, String[] nonCodingPredicLabels,
            Map genicMap, Bayes bayesPredictor, int[] dbNSFP3ScoreIndexes, int[] dbNSFP3PredicIndex, List<CombOrders> combOrderList,
            MyRandomForest[][] myRandomForestsCancer) throws Exception {
        boolean flag = false;

        String annNCFPPath = null;
        AnnotationSummarySet dbNoncodePred9d0 = null;
        FiltrationSummarySet dbNoncodePred9d1 = null;
        AnnotationSummarySet dbNoncodePred9d0Tmp = null;
        FiltrationSummarySet dbNoncodePred9d1Tmp = null;
        String resourcePathList[];
        boolean[] resourceTypeIsRegion;
        MyRandomForest[][] myRandomForestList = null;
        String[] currentLineList = null;
        BufferedReader[] lineReaderList = null;
        Boolean[] isReigonList = null;
        double iniScore[] = null;
        int[] fixedPosition = null;
        int scoreIndexNum = 0;
        FiltrationSummarySet dbNoncodePred9d2 = null;
        FiltrationSummarySet dbNoncodePred9d2Tmp = null;
        BufferedReader[] lineReaderList9d2 = null;

        FiltrationSummarySet dbNSFPAnnot8 = null;
        FiltrationSummarySet dbNSFPPred9 = null;
        FiltrationSummarySet dbNSFPAnnot8Tmp = null;
        FiltrationSummarySet dbNSFPPred9Tmp = null;
        AnnotationSummarySet dbNoncodeRegBase9d3 = null;
        AnnotationSummarySet dbNoncodeRegBase9d4 = null;
        GTBReader regbaseCCFTable;
        GTBReader regbaseCCFOriginReader = null;
        GTBIndexer regbaseCCFChromosomeInterval = null;

        GTBReader epiDBCCFTable;
        GTBReader epiDBCCFOriginReader = null;
        GTBIndexer epiDBCCFChromosomeInterval = null;
        CombOrders fixedComb = null;

        Map<String, Object> result = new HashMap<>();

        if (!options.scoreDBLableList.isEmpty()) {
            for (String dbLabelName : options.scoreDBLableList) {
                if (dbLabelName.startsWith("dbncfp")) {
                    Map<String, Object> dbncfpMap = dbncfpHandler(uniqueGenome, dbLabelName, nonCodingPredicLabels, genicMap, bayesPredictor);
                    if ((boolean) dbncfpMap.get("return") == true) {
                        flag = true;
                        result.put("return", flag);
                        return result;
                    }
                    annNCFPPath = (String) dbncfpMap.get("annNCFPPath");
                    dbNoncodePred9d0 = (AnnotationSummarySet) dbncfpMap.get("dbNoncodePred9d0");
                    dbNoncodePred9d1 = (FiltrationSummarySet) dbncfpMap.get("dbNoncodePred9d1");
                    dbNoncodePred9d0Tmp = (AnnotationSummarySet) dbncfpMap.get("dbNoncodePred9d0Tmp");
                    dbNoncodePred9d1Tmp = (FiltrationSummarySet) dbncfpMap.get("dbNoncodePred9d1Tmp");
                    myRandomForestList = (MyRandomForest[][]) dbncfpMap.get("myRandomForestList");
                    currentLineList = (String[]) dbncfpMap.get("currentLineList");
                    lineReaderList = (BufferedReader[]) dbncfpMap.get("lineReaderList");
                    isReigonList = (Boolean[]) dbncfpMap.get("isReigonList");
                    iniScore = (double[]) dbncfpMap.get("iniScore");
                    fixedPosition = (int[]) dbncfpMap.get("fixedPosition");
                    scoreIndexNum = (int) dbncfpMap.get("scoreIndexNum");
                    dbNoncodePred9d2 = (FiltrationSummarySet) dbncfpMap.get("dbNoncodePred9d2");
                    dbNoncodePred9d2Tmp = (FiltrationSummarySet) dbncfpMap.get("dbNoncodePred9d2Tmp");
                    lineReaderList9d2 = (BufferedReader[]) dbncfpMap.get("lineReaderList9d2");
                } else if (dbLabelName.startsWith("dbnsfp")) {
                    Map<String, Object> dbnsfpMap = dbnsfpHandler(uniqueGenome, dbLabelName, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, combOrderList, myRandomForestsCancer);
                    dbNSFPAnnot8 = (FiltrationSummarySet) dbnsfpMap.get("dbNSFPAnnot8");
                    dbNSFPPred9 = (FiltrationSummarySet) dbnsfpMap.get("dbNSFPPred9");
                    dbNSFPAnnot8Tmp = (FiltrationSummarySet) dbnsfpMap.get("dbNSFPAnnot8Tmp");
                    dbNSFPPred9Tmp = (FiltrationSummarySet) dbnsfpMap.get("dbNSFPPred9Tmp");
                    fixedComb = (CombOrders) dbnsfpMap.get("fixedComb");
                } else if (dbLabelName.startsWith("regbase")) {
                    Map<String, Object> dbncfpMap = dbncfpHandler(uniqueGenome, dbLabelName, null, null, null);
                    dbNoncodeRegBase9d3 = (AnnotationSummarySet) dbncfpMap.get("dbNoncodeRegBase9d3");

                    annNCFPPath = (String) dbncfpMap.get("annNCFPPath");
                    StringArray feildNames = new StringArray();
                    feildNames.add("Chrom");
                    feildNames.add("Pos_end");
                    feildNames.add("Ref");
                    feildNames.add("Alts");
                    String[] otherNames = dbNoncodeRegBase9d3.getDbColNames();
                    for (int i = 0; i < otherNames.length; i++) {
                        feildNames.add(otherNames[i]);
                    }
                    regbaseCCFTable = new GTBReader(annNCFPPath);

                    regbaseCCFChromosomeInterval = regbaseCCFTable.getManager().getIndexer();

                    // 实例化读取器
                    regbaseCCFOriginReader = regbaseCCFTable.getManager().instanceReader(false, feildNames);

                    if ((boolean) dbncfpMap.get("return") == true) {
                        flag = true;
                        result.put("return", flag);
                        return result;
                    }
                }
            }
        }
        for (String dbLabelName : options.epimarkDBLableList) {
            Map<String, Object> dbncfpMap = dbEpimakerHandler(uniqueGenome, dbLabelName, null, null, null);
            dbNoncodeRegBase9d4 = (AnnotationSummarySet) dbncfpMap.get("dbNoncodeRegBase9d4");

            annNCFPPath = (String) dbncfpMap.get("annNCFPPath");

            if ((boolean) dbncfpMap.get("return") == true) {
                flag = true;
                result.put("return", flag);
                return result;
            }

            epiDBCCFTable = new GTBReader(annNCFPPath);
            epiDBCCFChromosomeInterval = epiDBCCFTable.getManager().getIndexer();

            // 实例化读取器
            epiDBCCFOriginReader = epiDBCCFTable.newInstance();
        }

        result.put("annNCFPPath", annNCFPPath);
        result.put("dbNoncodePred9d0", dbNoncodePred9d0);
        result.put("dbNoncodePred9d1", dbNoncodePred9d1);
        result.put("dbNoncodePred9d0Tmp", dbNoncodePred9d0Tmp);
        result.put("dbNoncodePred9d1Tmp", dbNoncodePred9d1Tmp);
        result.put("myRandomForestList", myRandomForestList);
        result.put("currentLineList", currentLineList);
        result.put("lineReaderList", lineReaderList);
        result.put("isReigonList", isReigonList);
        result.put("iniScore", iniScore);
        result.put("fixedPosition", fixedPosition);
        result.put("scoreIndexNum", scoreIndexNum);
        result.put("dbNoncodePred9d2", dbNoncodePred9d2);
        result.put("dbNoncodePred9d2Tmp", dbNoncodePred9d2Tmp);
        result.put("lineReaderList9d2", lineReaderList9d2);
        result.put("dbNoncodeRegBase9d3", dbNoncodeRegBase9d3);
        result.put("regbaseCCFChromosomeInterval", regbaseCCFChromosomeInterval);
        result.put("regbaseCCFOriginReader", regbaseCCFOriginReader);

        result.put("dbNoncodeRegBase9d4", dbNoncodeRegBase9d4);
        result.put("epiDBCCFChromosomeInterval", epiDBCCFChromosomeInterval);
        result.put("epiDBCCFOriginReader", epiDBCCFOriginReader);

        result.put("dbNSFPAnnot8", dbNSFPAnnot8);
        result.put("dbNSFPPred9", dbNSFPPred9);
        result.put("dbNSFPAnnot8Tmp", dbNSFPAnnot8Tmp);
        result.put("dbNSFPPred9Tmp", dbNSFPPred9Tmp);
        result.put("fixedComb", fixedComb);
        result.put("return", flag);
        return result;
    }

    public static Map<String, Object> prepareCandidateGeneSetFeatures(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet assG11 = null;
        AnnotationSummarySet assV12 = null;
        AnnotationSummarySet assPPIG13 = null;
        AnnotationSummarySet assPPIV14 = null;
        AnnotationSummarySet assPWG15 = null;
        AnnotationSummarySet assPWV16 = null;
        PPIGraph ppiTree = null;
        Map<String, GeneSet> mappedPathes = null;
        String ppiDBFile = null;

        Map<String, Object> result = new HashMap<>();

        if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {
            assG11 = new AnnotationSummarySet("IsCandidateGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
            uniqueGenome.addmRNAFeatureLabel("IsCandidateGene");

            assV12 = new AnnotationSummarySet("IsWithinCandidateGene", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("IsWithinCandidateGene");

            String genesetDBFile = null;
            if (options.ppiDB != null) {
                ppiDBFile = options.PUBDB_FILE_MAP.get("string");

                ppiTree = new PPIGraph(GlobalManager.RESOURCE_PATH + "/" + ppiDBFile);
                ppiTree.readPPIItems();
                assPPIG13 = new AnnotationSummarySet(ppiDBFile, null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("PPI");

                assPPIV14 = new AnnotationSummarySet(ppiDBFile, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("PPI");
            }

            if (options.genesetdb != null) {
                genesetDBFile = options.PUBDB_FILE_MAP.get(options.genesetdb);
                genesetDBFile = GlobalManager.RESOURCE_PATH + "/" + genesetDBFile;

                if (genesetDBFile != null) {
                    CandidateGeneExtender candiGeneExtender = new CandidateGeneExtender();
                    candiGeneExtender.setSeedGeneSet(options.candidateGeneSet);
                    candiGeneExtender.loadGeneSetDB(genesetDBFile, 2, 400);
                    mappedPathes = candiGeneExtender.pickRelevantGeneSet();

                    assPWG15 = new AnnotationSummarySet("SharedGeneSet", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                    uniqueGenome.addmRNAFeatureLabel("SharedGeneSet");

                    assPWV16 = new AnnotationSummarySet("SharedGeneSet", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                    uniqueGenome.addVariantFeatureLabel("SharedGeneSet");
                } else {
                    String info = "The geneset data set name " + options.genesetdb + " does not exist! So the geneset-based prioritization will be ignored!";
                    LOG.warn(info);
                }
            }
        }
        result.put("assG11", assG11);
        result.put("assV12", assV12);
        result.put("assPPIG13", assPPIG13);
        result.put("assPPIV14", assPPIV14);
        result.put("assPWG15", assPWG15);
        result.put("assPWV16", assPWV16);
        result.put("ppiTree", ppiTree);
        result.put("mappedPathes", mappedPathes);
        result.put("ppiDBFile", ppiDBFile);
        return result;
    }

    public static TwoTuple<AnnotationSummarySet, AnnotationSummarySet> addHomoAndIBSFeatureNames(Genome uniqueGenome) {
        AnnotationSummarySet assIBS17d1 = null;
        if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            assIBS17d1 = new AnnotationSummarySet("ibs", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("LongestIBSRegion");
            uniqueGenome.addVariantFeatureLabel("LongestIBSRegionLength(bp)");
        }

        AnnotationSummarySet assHRC17d2 = null;
        if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            assHRC17d2 = new AnnotationSummarySet("homozygousRegionCase", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("LongestHomozygosityRegion");
            uniqueGenome.addVariantFeatureLabel("LongestHomozygosityRegionLength(bp)");
        }
        return TupleUtil.tuple(assIBS17d1, assHRC17d2);
    }

    public static TwoTuple<List<String[]>, AnnotationSummarySet> ibdFileNameHandler(Genome uniqueGenome) throws Exception {
        List<String[]> regionItems = null;
        AnnotationSummarySet assIBD17d5 = null;
        if (options.ibdFileName != null) {
            int[] indexes = new int[]{0, 1, 2};
            regionItems = new ArrayList<String[]>();
            File ibdFile = new File(options.ibdFileName);
            LocalFile.retrieveData(ibdFile.getCanonicalPath(), regionItems, indexes, "\t");

            assIBD17d5 = new AnnotationSummarySet(options.ibdFileName, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("IBDRegion");
            uniqueGenome.addVariantFeatureLabel("IBDRegionAnnot");
        }
        return TupleUtil.tuple(regionItems, assIBD17d5);
    }

    public static AnnotationSummarySet setDBscSNVAnnoter(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet dbScSNV18 = null;
        if (options.dbscSNVAnnote) {
            String dbLabelName = "dbscSNV";

            dbScSNV18 = new AnnotationSummarySet("dbscSNV", LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName)), new StringBuilder(), 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("ada_score@" + dbLabelName);
            //skip the head line
            dbScSNV18.getBr().readLine();
        }
        return dbScSNV18;
    }

    public static FourTuple<Map<String, Double>, AnnotationSummarySet, AnnotationSummarySet, Map<String, RefGene>>
            getGeneLength(Genome uniqueGenome, boolean needRegionLen, Map<String, double[]> geneMutationScores) throws Exception {
        Map<String, Double> geneLengths = null;
        AnnotationSummarySet assGIS17d3 = null;
        AnnotationSummarySet assGOS17d4 = null;
        Map<String, RefGene> mergedGeneCodingRegions = null;

        if (options.geneDBLabels != null) {
            GeneRegionParser grp = new GeneRegionParser();
            // geneLengths =
            // grp.readRefGeneLength(GlobalManager.RESOURCE_PATH + "/" +
            // options.PUBDB_FILE_MAP.get(options.geneDBLabels[0]),
            // options.splicingDis);
            String[] pathes = new String[options.geneDBLabels.length];
            int ii = 0;
            for (String lbs : options.geneDBLabels) {
                File f = new File(lbs);
                if (f.exists()) {
                    pathes[ii] = lbs;
                } else {
                    pathes[ii] = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(lbs);
                }
                ii++;
            }
            if (options.contextAnnotGFDis > 0 || (options.simulGeneRegionsGtyNum > 0 && options.doubleHitGeneTriosCasePsudo)) {
                mergedGeneCodingRegions = new HashMap<String, RefGene>();
            }
            if (options.dependentGeneFeature.contains(11)) {
                geneLengths = grp.readMergeRefGeneIntronLength(pathes, options.splicingDis, mergedGeneCodingRegions, options.dependentMaxIntronFeature);
            } else {
                geneLengths = grp.readMergeRefGeneCodingLength(pathes, options.splicingDis, true, mergedGeneCodingRegions);
            }

            // only keep genes in inGeneSet
            if (!options.inGeneSet.isEmpty()) {
                assGIS17d3 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            // only keep genes in outGeneSet
            if (!options.outGeneSet.isEmpty()) {
                assGOS17d4 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }
            double[] ss;
            if (needRegionLen) {
                for (Map.Entry<String, Double> item : geneLengths.entrySet()) {
                    // double[] ss = new double[1 + popuNames.length];  
                    if (Double.isNaN(item.getValue())) {
                        continue;
                    }
                    ss = new double[2];
                    ss[0] = item.getValue();
                    //for freqency scores
                    ss[1] = Double.NaN;

                    geneMutationScores.put(item.getKey(), ss);
                }
            }
        }
        return TupleUtil.tuple(geneLengths, assGIS17d3, assGOS17d4, mergedGeneCodingRegions);
    }

    public static EightTuple<List<String[]>, List<String[]>, List<int[]>, IntArrayList, Set<String>, Set<String>, FiltrationSummarySet, Boolean>
            setDoubleHitGeneTriosFeatures(Genome uniqueGenome, List<Individual> subjectList, VariantFilter varFilter, int[] caseSetID, int[] controlSetID) throws Exception {
        List<String[]> hitDisCountsTriosGenes = null;
        List<String[]> hitDisCounTriosReads = null;
        List<int[]> triosIDList = null;
        IntArrayList effectiveIndivIDsTrios = null;
        Set<String> caseDoubleHitTriosGenes = null;
        Set<String> controlDoubleHitTriosGenes = null;
        FiltrationSummarySet doubleHitGeneModelFilter19 = null;
        boolean flag = false;

        if (options.doubleHitGeneTriosFilter || options.doubleHitGeneTriosCasePsudo || options.doubleHitGeneTriosCaseControl) {
            hitDisCountsTriosGenes = new ArrayList<String[]>();
            hitDisCounTriosReads = new ArrayList<String[]>();
            doubleHitGeneModelFilter19 = new FiltrationSummarySet("DoubleHitModel", uniqueGenome.getVariantFeatureNum());
            doubleHitGeneModelFilter19.initiateAMessage(0, "variant(s) are retained after filtered by the double-hit genes using parents' genotypes.");
            caseDoubleHitTriosGenes = new HashSet<String>();
            controlDoubleHitTriosGenes = new HashSet<String>();
            // cluster counts according to phentoypes
            int indivSize = subjectList.size();

            triosIDList = new ArrayList<int[]>();
            varFilter.matchTrioSet(subjectList, triosIDList);
            if (triosIDList.isEmpty()) {
                String infor = "No recognizable trios for double-hit gene checking!";
                LOG.error(infor);
                flag = true;
                return TupleUtil.tuple(hitDisCountsTriosGenes, hitDisCounTriosReads, triosIDList, effectiveIndivIDsTrios, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, doubleHitGeneModelFilter19, flag);
            }
            List<int[]> tmpTriosIDList = new ArrayList<int[]>();
            int trioSize = triosIDList.size();
            for (int t = 0; t < 3; t++) {
                for (int j = 0; j < trioSize; j++) {
                    int[] trio = triosIDList.get(j);
                    Individual mIndiv = subjectList.get(trio[0]);
                    if (mIndiv.getAffectedStatus() == t) {
                        tmpTriosIDList.add(trio);
                    }
                }
            }
            triosIDList.clear();
            triosIDList.addAll(tmpTriosIDList);
            tmpTriosIDList.clear();

            //prepare the output format
            List<String> headActual = new ArrayList<String>();
            headActual.add("Gene");
            headActual.add("PubMed");
            headActual.add("ExonLen");
            List<String> headPhenotype = new ArrayList<String>();
            headPhenotype.add("Disease");
            headPhenotype.add(".");
            headPhenotype.add(".");

            int effectiveIndivSize = 0;
            if (options.doubleHitGeneTriosFilter) {
                headActual.add("CountHitCase");
                headPhenotype.add(".");
                headActual.add("CountHitControl");
                headPhenotype.add(".");

            } else if (options.doubleHitGeneTriosCasePsudo) {
                headActual.add("CountHitCase");
                headActual.add("CountHitPseudoControl");
                headActual.add("TotalNum");
                headActual.add("p-Value");
                headPhenotype.add(".");
                headPhenotype.add(".");
                headPhenotype.add(".");
                headPhenotype.add(".");
            } else if (options.doubleHitGeneTriosCaseControl) {
                headActual.add("CountHitCase");
                headActual.add("TotalNumCase");
                headActual.add("CountHitControl");
                headActual.add("TotalNumControl");
                headActual.add("p-Value");
                headPhenotype.add(".");
                headPhenotype.add(".");
                headPhenotype.add(".");
                headPhenotype.add(".");
                headPhenotype.add(".");
            }

            effectiveIndivIDsTrios = new IntArrayList();
            int setSize = triosIDList.size();
            for (int j = 0; j < setSize; j++) {
                Individual mIndiv = subjectList.get(triosIDList.get(j)[0]);
                if (triosIDList.get(j)[0] < 0 || triosIDList.get(j)[1] < 0 || triosIDList.get(j)[2] < 0) {
                    continue;
                }

                effectiveIndivIDsTrios.add(j);
                headActual.add(mIndiv.getLabelInChip());
                headPhenotype.add(String.valueOf(mIndiv.getAffectedStatus()));
                effectiveIndivSize++;
            }
            hitDisCountsTriosGenes.add(headActual.toArray(new String[0]));
            hitDisCountsTriosGenes.add(headPhenotype.toArray(new String[0]));
            hitDisCounTriosReads.add(headActual.toArray(new String[0]));
            hitDisCounTriosReads.add(headPhenotype.toArray(new String[0]));

            if (effectiveIndivSize == 0) {
                String infor = "No valid trios for double-hit gene checking!";
                LOG.warn(infor);
                flag = true;
                return TupleUtil.tuple(hitDisCountsTriosGenes, hitDisCounTriosReads, triosIDList, effectiveIndivIDsTrios, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, doubleHitGeneModelFilter19, flag);
            }

            if (options.doubleHitGeneTriosCaseControl && caseSetID == null) {
                throw new Exception("No cases for '--double-hit-gene-trio-case-control'!");
            }
            if (options.doubleHitGeneTriosCaseControl && controlSetID == null) {
                throw new Exception("No controls for '--double-hit-gene-trio-case-control'!");
            }
        }
        return TupleUtil.tuple(hitDisCountsTriosGenes, hitDisCounTriosReads, triosIDList, effectiveIndivIDsTrios, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, doubleHitGeneModelFilter19, flag);
    }

    public static SixTuple<FiltrationSummarySet, List<String[]>, List<String[]>, Set<String>, Set<String>, Integer> setDoubleHitGenePhasedGtyFeatures(Genome uniqueGenome, List<String> featureLabels, List<Individual> subjectList, int[] caseSetID, int[] controlSetID) throws Exception {
        FiltrationSummarySet doubleHitGeneModelFilter19d1 = null;
        List<String[]> doubleHitGenePhasedGenes = null;
        List<String[]> doubleHitGenePhasedReads = null;
        Set<String> caseDoubleHitPhasedGenes = null;
        Set<String> controlDoubleHitPhasedGenes = null;
        int pathogenicPredicIndex = -1;

        if (options.doubleHitGenePhasedFilter) {
            if (caseSetID == null && controlSetID == null) {
                throw new Exception("'--double-hit-gene-phased-filter' requires case/control phenotype inormation.");
            }
            if (!uniqueGenome.isIsPhasedGty()) {
                throw new Exception("'--double-hit-gene-phased-filter' does not work for unphased genotyps.");
            }
            doubleHitGeneModelFilter19d1 = new FiltrationSummarySet("DoubleHitModel", uniqueGenome.getVariantFeatureNum());
            doubleHitGeneModelFilter19d1.initiateAMessage(0, "variant(s) are retained after filtered by the double-hit genes using phased genotypes.");
            caseDoubleHitPhasedGenes = new HashSet<String>();
            controlDoubleHitPhasedGenes = new HashSet<String>();

            for (int i = 0; i < featureLabels.size(); i++) {
                if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                    pathogenicPredicIndex = i;
                }
                if (pathogenicPredicIndex >= 0) {
                    break;
                }
            }

            doubleHitGenePhasedGenes = new ArrayList<String[]>();
            doubleHitGenePhasedReads = new ArrayList<String[]>();
            List<String> heads1 = new ArrayList<String>();
            heads1.add("Gene");
            heads1.add("PubMed");
            heads1.add("P");
            heads1.add("CountCtl");
            heads1.add("CountCase");
            List<String> heads2 = new ArrayList<String>();
            heads2.add("Disease");
            heads2.add(".");
            heads2.add(".");
            heads2.add(".");
            heads2.add(".");
            int effectiveIndivSize = 0;

            int caseNum = caseSetID == null ? 0 : caseSetID.length;
            int controlNum = controlSetID == null ? 0 : controlSetID.length;

            for (int j = 0; j < controlNum; j++) {
                int index = controlSetID[j];
                Individual mIndiv = subjectList.get(index);
                heads1.add(mIndiv.getLabelInChip());
                heads2.add(String.valueOf(mIndiv.getAffectedStatus()));
                effectiveIndivSize++;
            }

            for (int j = 0; j < caseNum; j++) {
                int index = caseSetID[j];
                Individual mIndiv = subjectList.get(index);
                heads1.add(mIndiv.getLabelInChip());
                heads2.add(String.valueOf(mIndiv.getAffectedStatus()));
                effectiveIndivSize++;
            }
            if (effectiveIndivSize == 0) {
                String infor = "No valid genotype information for double-hit gene checking!";
                LOG.warn(infor);

            }

            doubleHitGenePhasedGenes.add(heads1.toArray(new String[0]));
            doubleHitGenePhasedGenes.add(heads2.toArray(new String[0]));
            doubleHitGenePhasedReads.add(heads1.toArray(new String[0]));
            doubleHitGenePhasedReads.add(heads2.toArray(new String[0]));
        }
        return TupleUtil.tuple(doubleHitGeneModelFilter19d1, doubleHitGenePhasedGenes, doubleHitGenePhasedReads, caseDoubleHitPhasedGenes, controlDoubleHitPhasedGenes, pathogenicPredicIndex);
    }

    public static FourTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet> setAnnotateGeneFeatures(Genome uniqueGenome) {
        AnnotationSummarySet assGene20 = null;
        AnnotationSummarySet assVariant20 = null;
        if (options.needAnnotateGene) {
            String fileNameHg = "HgncGene.txt";
            //File resourceFileHg = new File(GlobalManager.RESOURCE_PATH + "/" + fileNameHg);
            assGene20 = new AnnotationSummarySet(fileNameHg, null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
            uniqueGenome.addmRNAFeatureLabel("GeneDescription");
            uniqueGenome.addmRNAFeatureLabel("Pseudogenes");

            assVariant20 = new AnnotationSummarySet(fileNameHg, null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("GeneDescription");
            uniqueGenome.addVariantFeatureLabel("Pseudogenes");
        }

        AnnotationSummarySet assOmimGene21 = null;
        AnnotationSummarySet assOmimVar21 = null;
        if (options.omimAnnotateGene) {
            //File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/morbidmap.gz");
            assOmimGene21 = new AnnotationSummarySet("morbidmap.gz", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
            uniqueGenome.addmRNAFeatureLabel("DiseaseName(s)MIMid");
            uniqueGenome.addmRNAFeatureLabel("GeneMIMid");

            assOmimVar21 = new AnnotationSummarySet("morbidmap.gz", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("DiseaseName(s)MIMid");
            uniqueGenome.addVariantFeatureLabel("GeneMIMid");
        }
        return TupleUtil.tuple(assGene20, assVariant20, assOmimGene21, assOmimVar21);
    }

    public static ThreeTuple<AnnotationSummarySet, AnnotationSummarySet, Map<String, StringBuilder>> tissueSpecAnnotHandler(Genome uniqueGenome, GeneAnnotator geneAnnotor) throws Exception {
        AnnotationSummarySet assTissueSpecGene21 = null;
        AnnotationSummarySet assTissueSpecVar21 = null;
        Map<String, StringBuilder> tissueSpecGeneMap = new HashMap<String, StringBuilder>();
        if (options.tissueSpecAnnot) {
            assTissueSpecGene21 = new AnnotationSummarySet("gene.trans.spc.tissue.txt.gz", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
            uniqueGenome.addmRNAFeatureLabel("TissueSpecificExpression(p)");

            assTissueSpecVar21 = new AnnotationSummarySet("gene.trans.spc.tissue.txt.gz", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("TissueWithSpecificExpression");
            tissueSpecGeneMap = geneAnnotor.readTissueSpecficGenes(GlobalManager.RESOURCE_PATH + "/gene.trans.spc.tissue.txt.gz");
        }
        return TupleUtil.tuple(assTissueSpecGene21, assTissueSpecVar21, tissueSpecGeneMap);
    }

    public static FourTuple<AnnotationSummarySet, AnnotationSummarySet, CNVRegionParser, ReferenceGenome> setSuperdupFeatures(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet assSDA22 = null;
        AnnotationSummarySet assSDF22 = null;
        CNVRegionParser grpSD = null;
        ReferenceGenome refGenomeSD = null;
        if (options.superdupAnnotate) {
            grpSD = new CNVRegionParser();
            refGenomeSD = grpSD.readSuperDupRegions(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("superdup"));
            assSDA22 = new AnnotationSummarySet("superdup", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("SuperDupKValue");
        } else if (options.superdupFilter) {
            grpSD = new CNVRegionParser();
            refGenomeSD = grpSD.readSuperDupRegions(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("superdup"));
            assSDF22 = new AnnotationSummarySet("superdup", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
        }
        return TupleUtil.tuple(assSDA22, assSDF22, grpSD, refGenomeSD);
    }

    public static ThreeTuple<AnnotationSummarySet, CNVRegionParser, ReferenceGenome> setDgvCNVAnnotationFeatures(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet assDGV23 = null;
        CNVRegionParser grpDGV = null;
        ReferenceGenome refGenomeDGV = null;
        if (options.dgvcnvAnnotate) {
            grpDGV = new CNVRegionParser();
            refGenomeDGV = grpDGV.readRefCNVSeq(GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("dgvcnv"));
            assDGV23 = new AnnotationSummarySet("dgvcnv", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("DGVIDs");
            uniqueGenome.addVariantFeatureLabel("CNVSampleSize");
            uniqueGenome.addVariantFeatureLabel("LossCNV");
            uniqueGenome.addVariantFeatureLabel("GainCNV");
        }
        return TupleUtil.tuple(assDGV23, grpDGV, refGenomeDGV);
    }

    public static ThreeTuple<AnnotationSummarySet, List<String>, Integer> setPredictedGeneLabels(Genome uniqueGenome, List<String> featureLabels,
            int pathogenicPredicIndex, List<Individual> subjectList, IntArrayList caseSubIDs, IntArrayList controlSubIDs) {
        AnnotationSummarySet assOLGF = null;
        if (options.overlappedGeneFilter) {
            assOLGF = new AnnotationSummarySet("overlappedGeneFilter", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            featureLabels = uniqueGenome.getVariantFeatureLabels();
            for (int i = 0; i < featureLabels.size(); i++) {
                if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                    pathogenicPredicIndex = i;
                }
                if (pathogenicPredicIndex >= 0) {
                    break;
                }
            }

            int indivSize = subjectList.size();
            for (int j = 0; j < indivSize; j++) {
                Individual mIndiv = subjectList.get(j);
                if (mIndiv.getAffectedStatus() == 2) {
                    caseSubIDs.add(j);
                } else if (mIndiv.getAffectedStatus() == 1) {
                    controlSubIDs.add(j);
                }
            }
        }
        return TupleUtil.tuple(assOLGF, featureLabels, pathogenicPredicIndex);
    }

    public static TwoTuple<AnnotationSummarySet, Map> setMousePhenoLabels(Genome uniqueGenome, GeneAnnotator geneAnnotor) throws Exception {
        AnnotationSummarySet assMousePheno = null;
        Map g2MP = null;
        if (options.phenoMouse) {
            assMousePheno = new AnnotationSummarySet("phenotype_mouse", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("MousePhenotypeMGI");
            uniqueGenome.addVariantFeatureLabel("MousePhenotypeIMPC");
            g2MP = new HashMap<String, String[]>();
            geneAnnotor.readMousePhenotype(g2MP);
        }
        return TupleUtil.tuple(assMousePheno, g2MP);
    }

    public static TwoTuple<AnnotationSummarySet, HashMap<String, String>> setZebraFishLabels(Genome uniqueGenome, GeneAnnotator geneAnnotor) throws Exception {
        AnnotationSummarySet assZebra = null;
        HashMap<String, String> xebraP2Phe = null;
        if (options.zebraFish) {
            assZebra = new AnnotationSummarySet("phenotypeZebra", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("ZebrafishPhenotype");
            xebraP2Phe = new HashMap<String, String>();
            geneAnnotor.readZebrafishPhenotype(xebraP2Phe);
        }
        return TupleUtil.tuple(assZebra, xebraP2Phe);
    }

    public static TwoTuple<AnnotationSummarySet, HashMap<String, String>> setDddPhenotypeLabel(Genome uniqueGenome, File fisher) throws Exception {
        AnnotationSummarySet assDDD = null;
        HashMap<String, String> dddP2Phe = null;
        if (options.dddPhenotypes) {
            assDDD = new AnnotationSummarySet("phenotypeDDD", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("DDDPhenotype");

            BufferedReader br = LocalFileFunc.getBufferedReader(fisher.getCanonicalPath());
            //skip the headline
            br.readLine();
            br.readLine();

            dddP2Phe = new HashMap<String, String>();
            String strLine;
            while ((strLine = br.readLine()) != null) {
                String[] strItems = Util.splitCVS(strLine);
                String pheno = strItems[2] + ";" + strItems[4] + ";" + strItems[7];
                dddP2Phe.put(strItems[0], pheno);
            }
            br.close();
        }
        return TupleUtil.tuple(assDDD, dddP2Phe);
    }

    public static SixTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, Integer, Boolean>
            setPubMedSearchList(Genome uniqueGenome, List<String[]> ideogramItemsGene, List<String[]> ideogramItemsVar, int driverPredicIndex,
                    List<String> featureLabels, int pathogenicPredicIndex) throws Exception {
        AnnotationSummarySet pubmedSearch24_Gene_Ideo = null;
        AnnotationSummarySet pubmedSearch24_Gene = null;
        AnnotationSummarySet pubmedSearch24_Var_Ideo = null;
        AnnotationSummarySet pubmedSearch24_Var = null;
        boolean flag = false;

        if (options.searchList != null && !options.searchList.isEmpty()) {
            if (options.pubmedMiningIdeo) {
                pubmedSearch24_Gene_Ideo = new AnnotationSummarySet("pubmedMiningIdeoGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("PubMedIDIdeogram");

                String ideoFileName = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("ideogram");
                File ideoFile = new File(ideoFileName);
                if (!ideoFile.exists()) {
                    LOG.error(ideoFile.getCanonicalPath() + " does not exist!!");
                    flag = true;
                    return TupleUtil.tuple(pubmedSearch24_Gene_Ideo, pubmedSearch24_Gene, pubmedSearch24_Var_Ideo, pubmedSearch24_Var, pathogenicPredicIndex, flag);//Or ignore this ?
                }

                if (options.refGenomeVersion.equals("hg18")) {
                    int[] indexes = new int[]{0, 1, 2, 5, 6};
                    LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsGene, indexes, "\t");
                    List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                    ideogramItemsTmp.addAll(ideogramItemsGene);
                    ideogramItemsGene.clear();
                    for (String[] item : ideogramItemsTmp) {
                        String[] newItem = new String[4];
                        newItem[0] = item[0];
                        newItem[1] = item[1] + item[2];
                        newItem[2] = item[3];
                        newItem[3] = item[4];
                        ideogramItemsGene.add(newItem);
                    }
                } else if (options.refGenomeVersion.equals("hg19")) {
                    int[] indexes = new int[]{0, 3, 1, 2};
                    LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsGene, indexes, "\t");
                    List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                    ideogramItemsTmp.addAll(ideogramItemsGene);
                    ideogramItemsGene.clear();
                    for (String[] item : ideogramItemsTmp) {
                        String[] newItem = new String[4];
                        if (item[0].length() > 3) {
                            newItem[0] = item[0].substring(3);//This may be wrong if the chromosome doesn't have chr start.
                        } else {
                            newItem[0] = item[0];
                        }
                        newItem[1] = item[1];
                        newItem[2] = item[2];
                        newItem[3] = item[3];
                        ideogramItemsGene.add(newItem);
                    }
                }
            }
            if (options.pubmedMiningGene) {
                pubmedSearch24_Gene = new AnnotationSummarySet("pubmedMiningGene", null, null, 0, 0, 0, uniqueGenome.getmRNAFeatureNum());
                uniqueGenome.addmRNAFeatureLabel("PubMedIDGene");
            }

            if (options.pubmedMiningIdeo) {
                pubmedSearch24_Var_Ideo = new AnnotationSummarySet("pubmedMiningIdeoVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("PubMedIDIdeogram");

                String ideoFileName = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get("ideogram");
                File ideoFile = new File(ideoFileName);
                if (!ideoFile.exists()) {
                    LOG.error(ideoFile.getCanonicalPath() + " does not exist!!");
                    flag = true;
                    return TupleUtil.tuple(pubmedSearch24_Gene_Ideo, pubmedSearch24_Gene, pubmedSearch24_Var_Ideo, pubmedSearch24_Var, pathogenicPredicIndex, flag);//or ignore?
                }

                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                        pathogenicPredicIndex = i;
                    }

                    if (driverPredicIndex >= 0) {
                        break;
                    }
                }

                if (options.refGenomeVersion.equals("hg18") || options.refGenomeVersion.equals("hg19")) {
                    int[] indexes = new int[]{0, 1, 2, 5, 6};
                    LocalFile.retrieveData(ideoFile.getCanonicalPath(), ideogramItemsVar, indexes, "\t");
                    List<String[]> ideogramItemsTmp = new ArrayList<String[]>();
                    ideogramItemsTmp.addAll(ideogramItemsVar);
                    ideogramItemsVar.clear();
                    for (String[] item : ideogramItemsTmp) {
                        String[] newItem = new String[4];
                        newItem[0] = item[0];
                        newItem[1] = item[1] + item[2];
                        newItem[2] = item[3];
                        newItem[3] = item[4];
                        ideogramItemsVar.add(newItem);
                    }
                }
            }

            if (options.pubmedMiningGene) {
                pubmedSearch24_Var = new AnnotationSummarySet("pubmedMiningVar", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
                uniqueGenome.addVariantFeatureLabel("PubMedIDGene");

                for (int i = 0; i < featureLabels.size(); i++) {
                    if (featureLabels.get(i).equals("IsHighMut_COSMICTrainedModel") || featureLabels.get(i).equals("IsRareDiseaseCausal_ExoVarTrainedModel") || featureLabels.get(i).equals("IsComplexDiseasePathogenic")) {
                        pathogenicPredicIndex = i;
                    }
                    if (driverPredicIndex >= 0) {
                        break;
                    }
                }
            }
        }
        return TupleUtil.tuple(pubmedSearch24_Gene_Ideo, pubmedSearch24_Gene, pubmedSearch24_Var_Ideo, pubmedSearch24_Var, pathogenicPredicIndex, flag);
    }

    public static TwoTuple<AnnotationSummarySet, OpenIntIntHashMap[]> setRSIDLabels(Genome uniqueGenome, VariantAnnotator varAnnoter) throws Exception {
        AnnotationSummarySet assRSID25 = null;
        OpenIntIntHashMap[] altMapID = null;
        if (options.rsid) {
            String urlT = options.PUBDB_URL_MAP.get("rsid");
            urlT = urlT.substring(urlT.lastIndexOf("/") + 1);
            assRSID25 = new AnnotationSummarySet("RSID", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            File resourceFileRSID = new File(GlobalManager.RESOURCE_PATH + "/" + options.refGenomeVersion + "/" + urlT);
            altMapID = new OpenIntIntHashMap[STAND_CHROM_NAMES.length];
            for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                altMapID[i] = new OpenIntIntHashMap();
            }
            varAnnoter.readChrPosRs(altMapID, resourceFileRSID);
        }
        return TupleUtil.tuple(assRSID25, altMapID);
    }

    public static TwoTuple<AnnotationSummarySet, SequenceRetriever> setFlankingSeqLabels(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet assFS = null;
        SequenceRetriever seqRe = null;
        if (options.flankingSequence > 0) {
            assFS = new AnnotationSummarySet("FlankingSequence", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("FlankingSeq" + options.flankingSequence + "bp");
            seqRe = new SequenceRetriever();
        }
        return TupleUtil.tuple(assFS, seqRe);
    }

    public static ThreeTuple<AnnotationSummarySet, Phenolyzer, HashMap<String, String>> setPhenolyzerLabels(Genome uniqueGenome) {
        AnnotationSummarySet assPhenolyzer26 = null;
        Phenolyzer phenolyzer = null;
        HashMap<String, String> hmpPhenolyzer = null;
        if (options.phenolyzer) {
            assPhenolyzer26 = new AnnotationSummarySet("Phenolyzer", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("Phenolyzer_Score");
            phenolyzer = new Phenolyzer(options.searchList, options.outputFileName + "phenolyzer/out");

            phenolyzer.runPhenolyzer();
            phenolyzer.parseResult();
            hmpPhenolyzer = phenolyzer.getHashMap();
        }
        return TupleUtil.tuple(assPhenolyzer26, phenolyzer, hmpPhenolyzer);
    }

    public static TwoTuple<SKAT, DoubleArrayList[]> setSKATGeneLabel(List<Individual> subjectList) throws Exception {
        SKAT skat = null;
        DoubleArrayList[] genePVList = null;
        if (options.skatGene || options.skatGeneset) {
            if (subjectList == null | subjectList.isEmpty()) {
                String info = "No case and control information! Failed in SKAT.";
                LOG.info(info);
                options.skatGene = false;
            } else {
                skat = new SKAT(options.outputFileName, options.skatCutoff, options.skatWeight);
                //int intParallel = options.threadNum >= 10 ? 10 : options.threadNum;
                skat.startRCluster(options.threadNum);//Visit R.

                int intPhe = -1;
                if (options.phenotypeColID != null && options.phenotypeColID.containsKey(options.pheItem)) {
                    intPhe = options.phenotypeColID.get(options.pheItem);
                }

                double dblPhe[] = skat.getPhenotype(subjectList, options.skatBinary, intPhe);
                double dblCov[][] = null;
                if (options.cov) {
                    dblCov = skat.getCovarite(subjectList, options.phenotypeColID, options.covItems);
                }

                skat.setPhenotype(dblPhe, dblCov, options.permutePheno);//Visit R.

                //if (skatGene.isBoolBinary()) {
                genePVList = new DoubleArrayList[3];
                //} else {
                //genePVList = new DoubleArrayList[2];
                //}
                for (int i = 0; i < genePVList.length; i++) {
                    genePVList[i] = new DoubleArrayList();
                }
            }
        }
        return TupleUtil.tuple(skat, genePVList);
    }

    public static IntArrayList[] readBEDRegions() throws Exception {
        IntArrayList[] chromRegions = new IntArrayList[25];
        for (int i = 0; i < chromRegions.length; i++) {
            chromRegions[i] = new IntArrayList();
        }
        int chromID;

        if (options.calcLDRegionFile != null) {
            String strLine;
            BufferedReader br = LocalFileFunc.getBufferedReader(options.calcLDRegionFile);
            //skip head
            br.readLine();
            while ((strLine = br.readLine()) != null) {
                strLine = strLine.trim();
                if (strLine.length() == 0) {
                    continue;
                }
                String[] items = strLine.split("[,| |\t]");
                if (items[0].charAt(0) == 'c' || items[0].charAt(0) == 'C') {
                    items[0] = items[0].substring(3);
                }
                if (items[0].toUpperCase().equals("X")) {
                    chromID = 22;
                } else if (items[0].toUpperCase().equals("Y")) {
                    chromID = 23;
                } else if (items[0].toUpperCase().equals("M")) {
                    chromID = 24;
                } else {
                    chromID = Integer.parseInt(items[0]) - 1;
                }

                chromRegions[chromID].add(Integer.parseInt(items[1]));
                chromRegions[chromID].add(Integer.parseInt(items[2]));
            }
            br.close();
        }
        return chromRegions;
    }

    public static ThreeTuple<AnnotationSummarySet, HashMap<String, String[]>, Integer> mendelGenePathoHandler(Genome uniqueGenome) throws Exception {
        AnnotationSummarySet assPatho27 = null;
        HashMap<String, String[]> hmpPatho = null;
        int intPatho = 0;
        if (options.mendelGenePatho) {
            hmpPatho = new HashMap<String, String[]>();
            assPatho27 = new AnnotationSummarySet("Pathology Gene Pediction:", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            String geneMendelPredFilePath = options.PUBDB_FILE_MAP.get("mendelgene");

            BufferedReader br = LocalFileFunc.getBufferedReader(GlobalManager.RESOURCE_PATH + "/" + geneMendelPredFilePath);
            String strLine = br.readLine();
            String[] title = strLine.split(",");
            intPatho = 11;

            for (int i = 1; i < intPatho; i++) {
                uniqueGenome.addVariantFeatureLabel(title[i]);
            }

            while ((strLine = br.readLine()) != null) {
                String[] items = strLine.split(",");
                String[] values = new String[intPatho - 1];
                System.arraycopy(items, 1, values, 0, values.length);
                hmpPatho.put(items[0], values);
            }
            br.close();
        }
        return TupleUtil.tuple(assPatho27, hmpPatho, intPatho);
    }

    public static ThreeTuple<Map<String, Map<String, Integer>>, AnnotationSummarySet, String> setCosmicLabels(Genome uniqueGenome, String fileName, GeneAnnotator geneAnnotor) throws Exception {
        Map<String, Map<String, Integer>> cosmicGeneMut = null;
        AnnotationSummarySet cosmicDBAnnot28 = null;
        if (options.cosmicAnnotate) {
            fileName = options.PUBDB_FILE_MAP.get("cosmicdb");
            cosmicGeneMut = geneAnnotor.readCosmicGeneAnnotation(GlobalManager.RESOURCE_PATH + "/" + fileName);
            cosmicDBAnnot28 = new AnnotationSummarySet("COSMIC data", uniqueGenome.getVariantFeatureNum());
            uniqueGenome.addVariantFeatureLabel("COSMICCancerInfo");
        }
        return TupleUtil.tuple(cosmicGeneMut, cosmicDBAnnot28, fileName);
    }

    public static FourTuple<File, BufferedWriter, BufferedWriter, BlockCompressedOutputStream> seGeneVarGroupFileOut() throws Exception {
        File file = null;
        BufferedWriter annovarFilteredInFileWriter = null;
        BufferedWriter bwGeneVarGroupFile = null;
        if (options.isANNOVAROut) {
            file = new File(options.outputFileName + ".flt.annovar");
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(file.getCanonicalPath() + ".gz"));
                annovarFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
            } else {
                annovarFilteredInFileWriter = new BufferedWriter(new FileWriter(file));
            }
        }

        if (options.isGeneVarGroupFileOut) {
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".gene.epacts.grp.gz"));
                bwGeneVarGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
            } else {
                bwGeneVarGroupFile = new BufferedWriter(new FileWriter(options.outputFileName + ".gene.epacts.grp"));
            }
        }
        BlockCompressedOutputStream bwVarGeneFile = null;
        if (options.isVarGeneFreqOut) {
            file = new File(options.outputFileName + ".gene.var.freq.gz");
            bwVarGeneFile = new BlockCompressedOutputStream(file);
        }

        return TupleUtil.tuple(file, annovarFilteredInFileWriter, bwGeneVarGroupFile, bwVarGeneFile);
    }

    public static FourTuple<BufferedWriter, BufferedOutputStream, WritableByteChannel, BufferedWriter> setPlinkOut(List<Individual> subjectList, int[] savedBinnaryBedVar, int[] savedPedVar) throws Exception {
        BufferedWriter bwMapBed = null;
        //RandomAccessFile rafBed = null;
        //FileChannel fileBedStream = null;
        BufferedOutputStream fileBedStream = null;
        WritableByteChannel wbcFileBed = null;

        if (options.isPlinkBedOut) {
            BufferedWriter bwPed = null;
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".bim" + ".gz"));
                bwMapBed = new BufferedWriter(new OutputStreamWriter(gzOut));
                GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".fam" + ".gz"));
                bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
            } else {
                bwMapBed = new BufferedWriter(new FileWriter(options.outputFileName + ".bim"));
                bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".fam"));
            }
            //bwMapBed = new BufferedWriter(new FileWriter(options.outputFileName + ".bim"));

            //BufferedWriter bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".fam"));
            for (Individual indiv : subjectList) {
                if (indiv == null) {
                    continue;
                }
                savedBinnaryBedVar[1]++;
                bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                        + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                bwPed.write("\n");
            }
            bwPed.close();

            File bedFile = new File(options.outputFileName + ".bed");
            if (bedFile.exists()) {
                bedFile.delete();
            }
            if (options.outGZ) {
                wbcFileBed = Channels.newChannel(new FileOutputStream(bedFile.getCanonicalPath() + ".gz"));
                fileBedStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed)));
                //bwFileChannelBed=new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed))));
            } else {
                wbcFileBed = Channels.newChannel(new FileOutputStream(bedFile));
                fileBedStream = new BufferedOutputStream(Channels.newOutputStream(wbcFileBed));
            }

            byte[] byteInfo = new byte[3];
            //|-magic number-
            //01101100 00011011
            byteInfo[0] = (byte) 0x6C;

            byteInfo[1] = (byte) 0x1B;

            //|-mode-| 00000001 (SNP-major)
            //00000001
            byteInfo[2] = 1;
            fileBedStream.write(byteInfo);

        }

        BufferedWriter bwMapPed = null;
        if (options.isPlinkPedOut) {
            BufferedWriter bwPed = null;
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".map" + ".gz"));
                bwMapPed = new BufferedWriter(new OutputStreamWriter(gzOut));
                GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ped.p" + ".gz"));
                bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
            } else {
                bwMapPed = new BufferedWriter(new FileWriter(options.outputFileName + ".map"));
                bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".ped.p"));
            }
            //bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".ped.p"));
            for (Individual indiv : subjectList) {
                if (indiv == null) {
                    continue;
                }
                savedPedVar[1]++;
                bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                        + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                bwPed.write("\n");
            }
            bwPed.close();
        }
        return TupleUtil.tuple(bwMapBed, fileBedStream, wbcFileBed, bwMapPed);
    }

    public static ThreeTuple<BufferedOutputStream, WritableByteChannel, BufferedWriter> setKEDGtyOut(Genome uniqueGenome, List<Individual> subjectList, int[] savedBinnaryKedVar) throws Exception {
        BufferedOutputStream filelKedStream = null;
        WritableByteChannel rafKed = null;
        BufferedWriter bwMapKed = null;

        if (options.isBinaryGtyOut) {
            File kedFile = null;
            if (options.outGZ) {
                kedFile = new File(options.outputFileName + ".ked.gz");
                rafKed = Channels.newChannel(new FileOutputStream(kedFile));
                filelKedStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(rafKed)));
                //fileChannelKed = new BufferedOutputStream((Channels.newOutputStream(rafKed)));
                //   filelKedStream = new BufferedOutputStream(new FileOutputStream(bedMergedFile), 10000);

            } else {
                kedFile = new File(options.outputFileName + ".ked");
                rafKed = Channels.newChannel(new FileOutputStream(kedFile));
                filelKedStream = new BufferedOutputStream((Channels.newOutputStream(rafKed)));
            }

            byte[] head = new byte[3];
            head[0] = (byte) 0x9E;
            head[1] = (byte) 0x82;
            if (uniqueGenome.isIsPhasedGty()) {
                head[2] = (byte) 0x1;
            } else {
                head[2] = (byte) 0x0;
            }
            filelKedStream.write(head);

            //pedigree
            BufferedWriter bwPed = null;
            if (options.outGZ) {
                GZIPOutputStream gzOut2 = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".kam" + ".gz"));
                bwPed = new BufferedWriter(new OutputStreamWriter(gzOut2));
            } else {
                bwPed = new BufferedWriter(new FileWriter(options.outputFileName + ".kam"));
            }
            for (Individual indiv : subjectList) {
                if (indiv == null) {
                    continue;
                }
                savedBinnaryKedVar[1]++;
                bwPed.write(indiv.getFamilyID() + " " + indiv.getIndividualID() + " " + indiv.getDadID()
                        + " " + indiv.getMomID() + " " + indiv.getGender() + " " + indiv.getAffectedStatus());
                bwPed.write("\n");
            }
            bwPed.close();

            //bwMapKed = new BufferedWriter(new FileWriter(options.outputFileName + ".kim"));//For isBinaryGtyOut.
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".kim" + ".gz"));
                bwMapKed = new BufferedWriter(new OutputStreamWriter(gzOut));
            } else {
                bwMapKed = new BufferedWriter(new FileWriter(options.outputFileName + ".kim"));
            }
        }
        return TupleUtil.tuple(filelKedStream, rafKed, bwMapKed);
    }

    public static FourTuple<File, BlockCompressedOutputStream, File, BlockCompressedOutputStream> setVCFOut(VCFParserFast vsParser, List<Individual> subjectList) throws Exception {
        File vcfFilteredInFile = null;
        BlockCompressedOutputStream vcfFilteredInFileWriter = null;
        // BufferedWriter vcfFilteredInFileWriter = null;
        //output VCF data for rvtestGene
        if (options.isVCFOut) {
            vcfFilteredInFile = new File(options.outputFileName + ".flt.vcf.gz");
            vcfFilteredInFileWriter = new BlockCompressedOutputStream(vcfFilteredInFile);
            /*
                if (options.outGZ) {
                    GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(vcfFilteredInFile.getCanonicalPath()));
                    vcfFilteredInFileWriter = new BufferedWriter(new OutputStreamWriter(gzOut));

                } else {
                    vcfFilteredInFile = new File(options.outputFileName + ".flt.vcf");
                    vcfFilteredInFileWriter = new BufferedWriter(new FileWriter(vcfFilteredInFile));
                }
             */
            //vcfFilteredInFileWriter = new BufferedWriter(new FileWriter(vcfFilteredInFile));
            vcfFilteredInFileWriter.write(vsParser.getVcfHead().toString().getBytes());
            vcfFilteredInFileWriter.write("#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT".getBytes());
            for (Individual indiv : subjectList) {
                if (!indiv.isHasGenotypes()) {
                    continue;
                }
                vcfFilteredInFileWriter.write("\t".getBytes());
                vcfFilteredInFileWriter.write(indiv.getLabelInChip().getBytes());
            }
            vcfFilteredInFileWriter.write("\n".getBytes());
        }

        File simpleVcfFilteredInFile = null;
        BlockCompressedOutputStream simpleVcfFilteredInFileWriter = null;

        if (options.isSimpleVCFOut) {
            simpleVcfFilteredInFile = new File(options.outputFileName + ".flt.simple.vcf.gz");
            simpleVcfFilteredInFileWriter = new BlockCompressedOutputStream(simpleVcfFilteredInFile);
            if (options.inputFormat.endsWith("--ked-file")) {
                simpleVcfFilteredInFileWriter.write("##fileformat=VCFv4.1\n".getBytes());
                simpleVcfFilteredInFileWriter.write("##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n".getBytes());
            } else {
                simpleVcfFilteredInFileWriter.write(vsParser.getVcfHead().toString().getBytes());
            }
            simpleVcfFilteredInFileWriter.write("#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT".getBytes());
            for (Individual indiv : subjectList) {
                if (!indiv.isHasGenotypes()) {
                    continue;
                }
                simpleVcfFilteredInFileWriter.write("\t".getBytes());
                simpleVcfFilteredInFileWriter.write(indiv.getLabelInChip().getBytes());
            }
            simpleVcfFilteredInFileWriter.write("\n".getBytes());
        }
        return TupleUtil.tuple(vcfFilteredInFile, vcfFilteredInFileWriter, simpleVcfFilteredInFile, simpleVcfFilteredInFileWriter);
    }

    public static TwoTuple<File, BufferedWriter> setMainOutFormat() throws Exception {
        File finalFilteredInFile = null;
        BufferedWriter finalExportWriter = null;
        if (options.excelOut) {
            if (options.outGZ) {
                finalFilteredInFile = new File(options.outputFileName + ".flt.xls.gz");
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(finalFilteredInFile.getCanonicalPath()));
                finalExportWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
                //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), true);
            } else {
                finalFilteredInFile = new File(options.outputFileName + ".flt.xls");
                finalExportWriter = new BufferedWriter(new FileWriter(finalFilteredInFile));
                //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), false);
            }
        } else if (options.outGZ) {
            finalFilteredInFile = new File(options.outputFileName + ".flt.txt.gz");
            GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(finalFilteredInFile.getCanonicalPath()));
            finalExportWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
            //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), true);
        } else {
            finalFilteredInFile = new File(options.outputFileName + ".flt.txt");
            finalExportWriter = new BufferedWriter(new FileWriter(finalFilteredInFile));
            //finalExportWriter = LocalFileFunc.getBufferedWriter(finalFilteredInFile.getCanonicalPath(), false);
        }
        return TupleUtil.tuple(finalFilteredInFile, finalExportWriter);
    }

    public static FiveTuple<List<Individual>, BufferedWriter, BufferedOutputStream, WritableByteChannel, BlockCompressedOutputStream>
            setMergeGtyDb(Genome uniqueGenome, VCFParserFast vsParser, List<Individual> subjectList, int[] coutVar, int[] intsSPV, int[] intsIndiv) throws Exception {
        List<Individual> refIndivList = null;
        BufferedWriter mergedBwMap = null;
        BufferedOutputStream mergedFileStream = null;
        WritableByteChannel mergedFileChannel = null;
        BlockCompressedOutputStream simpleVcfMergedInFileWrite = null;
        if (options.mergeGtyDb != null && (options.isPlinkPedOut || options.isPlinkBedOut || options.isSimpleVCFOut)) {
            refIndivList = new ArrayList<Individual>();
            String vcfFilePath = GlobalManager.RESOURCE_PATH + options.mergeGtyDb + ".chr1.vcf.gz";
            vsParser.extractSubjectIDsVCFInFile(vcfFilePath, refIndivList);

            if (!subjectList.isEmpty() && !refIndivList.isEmpty()) {
                if (options.isPlinkBedOut) {
                    coutVar[0] = 0;
                    intsIndiv[0] = 0;
                    if (options.outGZ) {
                        GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".merged.bim" + ".gz"));
                        mergedBwMap = new BufferedWriter(new OutputStreamWriter(gzOut));
                    } else {
                        mergedBwMap = new BufferedWriter(new FileWriter(options.outputFileName + ".merged.bim"));
                    }

                    File bedMergedFile = new File(options.outputFileName + ".merged.bed");
                    if (bedMergedFile.exists()) {
                        bedMergedFile.delete();
                    }

                    if (options.outGZ) {
                        mergedFileChannel = Channels.newChannel(new FileOutputStream(bedMergedFile.getCanonicalPath() + ".gz"));
                        mergedFileStream = new BufferedOutputStream(new GZIPOutputStream(Channels.newOutputStream(mergedFileChannel)));
                        //bwFileChannelBed=new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(Channels.newOutputStream(wbcFileBed))));
                    } else {
                        mergedFileChannel = Channels.newChannel(new FileOutputStream(bedMergedFile));
                        mergedFileStream = new BufferedOutputStream(Channels.newOutputStream(mergedFileChannel));
                    }

                    byte[] byteInfo = new byte[3];
                    //|-magic number-
                    //01101100 00011011
                    byteInfo[0] = (byte) 0x6C;

                    byteInfo[1] = (byte) 0x1B;

                    //|-mode-| 00000001 (SNP-major)
                    //00000001
                    byteInfo[2] = 1;
                    mergedFileStream.write(byteInfo);

                    uniqueGenome.exportPlinkBinaryGtyFam(subjectList, refIndivList, options.outputFileName, intsIndiv, options.outGZ);
                }

                if (options.isPlinkPedOut) {
                    intsSPV[0] = 0;
                    intsSPV[1] = 0;
                    if (options.outGZ) {
                        GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".merged.map.gz"));
                        mergedBwMap = new BufferedWriter(new OutputStreamWriter(gzOut));
                    } else {
                        mergedBwMap = new BufferedWriter(new FileWriter(options.outputFileName + ".merged.map"));
                    }
                }

                if (options.isSimpleVCFOut) {
                    //if not output family file
                    if (!options.isPlinkBedOut) {
                        uniqueGenome.exportPlinkBinaryGtyFam(subjectList, refIndivList, options.outputFileName, intsIndiv, options.outGZ);
                    }
                    File simpleVcfFilteredInFile = new File(options.outputFileName + ".merged.vcf.gz");
                    simpleVcfMergedInFileWrite = new BlockCompressedOutputStream(simpleVcfFilteredInFile);
                    if (options.inputFormat.endsWith("--ked-file")) {
                        simpleVcfMergedInFileWrite.write("##fileformat=VCFv4.1\n".getBytes());
                        simpleVcfMergedInFileWrite.write("##FORMAT=<ID=GT,Number=1,Type=String,Description=\"Genotype\">\n".getBytes());
                    } else {
                        simpleVcfMergedInFileWrite.write(vsParser.getVcfHead().toString().getBytes());
                    }
                    simpleVcfMergedInFileWrite.write("#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO	FORMAT".getBytes());
                    for (Individual indiv : subjectList) {
                        if (!indiv.isHasGenotypes()) {
                            continue;
                        }
                        simpleVcfMergedInFileWrite.write("\t".getBytes());
                        simpleVcfMergedInFileWrite.write(indiv.getLabelInChip().getBytes());
                    }

                    for (Individual indiv : refIndivList) {
                        simpleVcfMergedInFileWrite.write("\t".getBytes());
                        simpleVcfMergedInFileWrite.write(indiv.getLabelInChip().getBytes());
                    }

                    simpleVcfMergedInFileWrite.write("\n".getBytes());

                }
            }
        }
        return TupleUtil.tuple(refIndivList, mergedBwMap, mergedFileStream, mergedFileChannel, simpleVcfMergedInFileWrite);
    }

    public static BufferedWriter setCalcLD() throws Exception {
        BufferedWriter bwLD = null;
        if (options.calcLD || options.calcLDRegionFile != null) {
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ld" + ".gz"));
                bwLD = new BufferedWriter(new OutputStreamWriter(gzOut));
            } else {
                bwLD = new BufferedWriter(new FileWriter(options.outputFileName + ".ld"));
            }
        }
        return bwLD;
    }

    public static int[] geneCodingHandler(String[] popuNames, String[] geneCoVarFiles) throws Exception {
        int[] effecIndexVarFreq = null;

        if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
            if (popuNames != null) {
                effecIndexVarFreq = new int[popuNames.length];
                Arrays.fill(effecIndexVarFreq, -1);

                for (int i = 0; i < effecIndexVarFreq.length; i++) {
                    String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + options.refGenomeVersion + "/" + geneCoVarFiles[i];
                    BufferedReader br = LocalFileFunc.getBufferedReader(geneCoVarFilePath);
                    String[] cells = br.readLine().split("\t");
                    br.close();
                    for (int j = 0; j < cells.length; j++) {
                        if (popuNames[i].equals(cells[j])) {
                            effecIndexVarFreq[i] = j;
                            break;
                        }
                    }
                }

            }
        }
        return effecIndexVarFreq;
    }

    public static boolean variantQC(int chromID, Chromosome[] chromosomes, List<Variant> chromosomeVarAll, VariantFilter varFilter, FiltrationSummarySet minMissingQCFilter1,
            FloatArrayList mafSampleList, VariantAnnotator varAnnoter, AnnotationSummarySet assHWD) throws Exception {
        if (chromosomes[chromID].variantList == null || chromosomes[chromID].variantList.isEmpty()) {
            return true;
        }
        if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
            chromosomeVarAll.addAll(chromosomes[chromID].variantList);
        }

        //More variant QC
        varFilter.sumFilterCaseControlVar(chromosomes[chromID], options.minHetA, options.minHomA, options.minHetU, options.minHomU, options.minOBSA, options.minOBSU, minMissingQCFilter1, mafSampleList);
        if (chromosomes[chromID].variantList.isEmpty()) {
            //   LOG.info("0 sequence variant(s) are retained finally!");
        }

        if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
            varAnnoter.hweTestVar(chromosomes[chromID], options.hwdPCase, options.hwdPControl, options.hwdPAll, assHWD);
        }
        return false;
    }

//-----------------------------------xc part start------------------------------------------------------
    public static void qualityControl(int chromID, Chromosome[] chromosomes, List<Variant> chromosomeVarAll, VariantFilter varFilter, VariantAnnotator varAnnoter,
            FiltrationSummarySet minMissingQCFilter1, FloatArrayList mafSampleList, AnnotationSummarySet assHWD, AnnotationSummarySet assCaseMAF, AnnotationSummarySet ctTypeFilter) throws Exception {
        if (options.ibsCheckCase >= 0 || options.homozygousRegionCase >= 0) {
            chromosomeVarAll.addAll(chromosomes[chromID].variantList);
        }

        //More variant QC
        varFilter.sumFilterCaseControlVar(chromosomes[chromID], options.minHetA, options.minHomA, options.minHetU, options.minHomU, options.minOBSA, options.minOBSU, minMissingQCFilter1, mafSampleList);
        if (chromosomes[chromID].variantList.isEmpty()) {
            //   LOG.info("0 sequence variant(s) are retained finally!");
        }

        if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
            varAnnoter.hweTestVar(chromosomes[chromID], options.hwdPCase, options.hwdPControl, options.hwdPAll, assHWD);
        }
        if (options.caseMafLess < 1 || options.caseMafOver > 0 || options.controlMafLess < 1 || options.controlMafOver > 0) {
            varAnnoter.caseControlMAFFilterVar(chromosomes[chromID], options.caseMafLess, options.caseMafOver, options.controlMafLess, options.controlMafOver, assCaseMAF);
        }
        //ctTypeFilter
        if (options.ctType > 0) {
            varAnnoter.ctTypeFilterVar(chromosomes[chromID], options.ctType, ctTypeFilter);
        }

    }

    public static void geneMappingAndFiltration(ReferenceGenome[] referenceGenomes, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, int[] availableFeatureSizeForGeneDB,
            Genome uniqueGenome, Map<String, RefGene> mergedGeneCodingRegions, int[] pedEncodeGytIDMap, int[] caseSetID, int[] controlSetID,
            VariantFilter varFilter, int[] variantsCounters, FiltrationSummarySet geneDBFilter7, boolean useMinIDForGeneMapping,
            AnnotationSummarySet assGIS17d3, AnnotationSummarySet assGOS17d4) throws Exception {
        if (referenceGenomes != null) {
            for (int i = 0; i < referenceGenomes.length; i++) {
                varAnnoter.geneFeatureAnnot(chromosomes[chromID].variantList, chromID, referenceGenomes[i], options.geneFeatureIn, availableFeatureSizeForGeneDB[i], options.threadNum);
            }

            if (options.contextAnnotGFDis > 0) {
                List<Variant> newVariantList = varAnnoter.contextBasedAnnotion(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), mergedGeneCodingRegions, pedEncodeGytIDMap, caseSetID, controlSetID, options.contextAnnotGFDis);
                if (newVariantList != null && !newVariantList.isEmpty()) {
                    for (int i = 0; i < referenceGenomes.length; i++) {
                        varAnnoter.geneFeatureAnnot(newVariantList, chromID, referenceGenomes[i], options.geneFeatureIn, availableFeatureSizeForGeneDB[i], options.threadNum);
                    }
                    chromosomes[chromID].variantList.addAll(newVariantList);
                    chromosomes[chromID].setHasNotOrderVariantList(true);
                    chromosomes[chromID].buildVariantIndexMap();
                }
            }

            varFilter.geneFeatureFilter(chromosomes[chromID], variantsCounters, options.geneFeatureIn, geneDBFilter7, useMinIDForGeneMapping);

            if (options.geneDBLabels != null) {
                if (!options.inGeneSet.isEmpty()) {
                    varFilter.keepGenesInSet(chromosomes[chromID], assGIS17d3, options.inGeneSet);
                }
                // only keep genes in outGeneSet
                if (!options.outGeneSet.isEmpty()) {
                    varFilter.keepGenesOutSet(chromosomes[chromID], assGOS17d4, options.outGeneSet);
                }
            }
        }
    }

    public static void genetModelFiltration(FiltrationSummarySet inheritanceModelFilter2, VariantFilter varFilter, Chromosome[] chromosomes, int chromID, Genome uniqueGenome,
            List<Individual> subjectList, int[] pedEncodeGytIDMap, int[] caseSetID, int[] controlSetID, boolean[] genotypeFilters, FiltrationSummarySet denovoModelFilter3,
            List<int[]> setSampleIDList, boolean needGty, List<String> setSampleLabelList, FiltrationSummarySet somaticModelFilter4,
            boolean[] uniqueFilters, VariantAnnotator varAnnoter, AnnotationSummarySet assCCUMFV, AnnotationSummarySet caseControlMAFRatio) throws Exception {
        if (inheritanceModelFilter2 != null) {
            varFilter.inheritanceModelFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caseSetID, controlSetID, genotypeFilters, inheritanceModelFilter2);

        }
        if (denovoModelFilter3 != null) {
            varFilter.devnoMutationFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, controlSetID, setSampleIDList, options.noHomo, denovoModelFilter3);
        }

        if (needGty && options.sampleGtyHardFilterCode != null && (options.sampleGtyHardFilterCode.contains("8"))) {
            varFilter.somaticMutationFilterVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, controlSetID, setSampleIDList, setSampleLabelList, somaticModelFilter4, options.somatReadsP);

        }

        if (options.sampleVarHardFilterCode != null) {
            if (uniqueFilters[0] || uniqueFilters[1]) {
                varAnnoter.casecontrolUniqueModelFilterVar(chromosomes[chromID], assCCUMFV, uniqueFilters);
            }
        }

        if (options.minCCFreqRatio > 1) {
            varAnnoter.caseControlMAFRatioFilterVar(chromosomes[chromID], options.minCCFreqRatio, caseControlMAFRatio);

        }
    }

    public static int mafRefDBHardFilteration(AnnotationSummarySet[] varaintDBHardFilterFiles5, int leftVar, VariantAnnotator varAnnoter, Chromosome[] chromosomes,
            int chromID) {
        if (varaintDBHardFilterFiles5 != null) {
            for (int i = 0; i < varaintDBHardFilterFiles5.length; i++) {
                leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBHardFilterFiles5[i], options.needProgressionIndicator);
                if (leftVar == 0) {
                    break;
                }
                chromosomes[chromID].buildVariantIndexMap();
            }
        }
        return leftVar;
    }

    public static void mafRefDBAnnotation(AnnotationSummarySet[] varaintDBFilterFiles6, VariantAnnotator varAnnoter, Chromosome[] chromosomes,
            int chromID, int[][] freqColIndexes) {
        if (varaintDBFilterFiles6 != null) {
            for (int i = 0; i < varaintDBFilterFiles6.length; i++) {
                // varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBFilterFiles6[i], options.needProgressionIndicator);
                String dbLabelName = options.varaintDBLableList.get(i);
                String filePath = GlobalManager.RESOURCE_PATH + "/" + options.PUBDB_FILE_MAP.get(dbLabelName);
                if (filePath.endsWith("vcf.gz")) {
                    varAnnoter.markByVCFAlleleFormatThread(filePath, freqColIndexes[i], chromosomes[chromID], varaintDBFilterFiles6[i], options.threadNum);
                } else {
                    varAnnoter.markByANNOVARefFormatThread(filePath, chromosomes[chromID], varaintDBFilterFiles6[i], options.threadNum);
                }
            }
        }
    }

    public static void pextAnnotation(AnnotationSummarySet pextSumSet, String pextFileLocalPath, VariantAnnotator varAnnoter, Chromosome chromosome,
            int[] varExpressionTissuesIndex) {
        if (pextSumSet != null) {
            if (pextFileLocalPath.endsWith("vcf.gz")) {
                varAnnoter.readPextScoreSNVFilterMultiThread(chromosome, pextFileLocalPath, options.refGenomeVersion, varExpressionTissuesIndex, options.varExpressionTissues, pextSumSet, options.minVarExpression, options.threadNum);
            }
            //thake the average

        }
    }

    public static int mafANNOVARefDBHardFilteration(VariantAnnotator varAnnoter, Chromosome[] chromosomes, int leftVar, AnnotationSummarySet[] assLocalHardFilterFile5,
            int chromID) {
        if (assLocalHardFilterFile5 != null) {
            for (int i = 0; i < assLocalHardFilterFile5.length; i++) {
                leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterFile5[i], options.needProgressionIndicator);
                if (leftVar == 0) {
                    break;
                }
                chromosomes[chromID].buildVariantIndexMap();
            }
        }
        return leftVar;
    }

    public static void mafANNOVARefDBAnnotation(AnnotationSummarySet[] assLocalFilterFile6, Chromosome[] chromosomes, int chromID, VariantAnnotator varAnnoter) {
        if (assLocalFilterFile6 != null) {
            for (int i = 0; i < assLocalFilterFile6.length; i++) {
                varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterFile6[i], options.needProgressionIndicator);
            }
        }
    }

    public static int mafVCFRefDBHardFilteration(VariantAnnotator varAnnoter, Chromosome[] chromosomes, int leftVar, AnnotationSummarySet[] assLocalHardFilterVCFFile5,
            int chromID) {
        if (assLocalHardFilterVCFFile5 != null) {
            for (int i = 0; i < assLocalHardFilterVCFFile5.length; i++) {
                leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterVCFFile5[i],
                        options.needProgressionIndicator);
                if (leftVar == 0) {
                    break;
                }
                chromosomes[chromID].buildVariantIndexMap();
            }
        }
        return leftVar;
    }

    public static void mafVCFRefDBAnnotation(VariantAnnotator varAnnoter, AnnotationSummarySet[] assLocalFilterVCFFile6, Chromosome[] chromosomes, int chromID) {
        if (assLocalFilterVCFFile6 != null) {
            for (int i = 0; i < assLocalFilterVCFFile6.length; i++) {
                varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterVCFFile6[i], options.needProgressionIndicator);
            }
        }
    }

    public static int mafNoGtyVCFRefDBHardFilteration(VariantAnnotator varAnnoter, Chromosome[] chromosomes, int leftVar, AnnotationSummarySet[] assLocalHardFilterNoGtyVCFFile5,
            int chromID) {
        if (assLocalHardFilterNoGtyVCFFile5 != null) {
            for (int i = 0; i < assLocalHardFilterNoGtyVCFFile5.length; i++) {
                leftVar = varAnnoter.hardFilterByANNOVARefFormat(chromosomes[chromID], chromID, assLocalHardFilterNoGtyVCFFile5[i], options.needProgressionIndicator);
                if (leftVar == 0) {
                    break;
                }
                chromosomes[chromID].buildVariantIndexMap();
            }
        }
        return leftVar;
    }

    public static void mafVCFNoGtyRefDBAnnotation(VariantAnnotator varAnnoter, AnnotationSummarySet[] assLocalFilterNoGtyVCFFile6, Chromosome[] chromosomes, int chromID) {
        if (assLocalFilterNoGtyVCFFile6 != null) {
            for (int i = 0; i < assLocalFilterNoGtyVCFFile6.length; i++) {
                varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, assLocalFilterNoGtyVCFFile6[i], options.needProgressionIndicator);
            }
        }
    }

    public static void mafRefDBSoftFiltration(AnnotationSummarySet[] varaintDBFilterFiles6, Chromosome[] chromosomes, VariantFilter varFilter, int chromID, AnnotationSummarySet assFBAFEM, AnnotationSummarySet assFBAFIM,
            FloatArrayList mafRefList) {
        if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
            if (options.isAlleleFreqExcMode) {
                varFilter.filterByAlleleFreqExcModel(chromosomes[chromID], assFBAFEM, options.minAlleleFreqExc, mafRefList);
            } else {
                varFilter.filterByAlleleFreqIncModel(chromosomes[chromID], assFBAFIM, options.minAlleleFreqInc, options.maxAlleleFreqInc, mafRefList);
            }
        }
    }

    public static void pextFiltration(AnnotationSummarySet[] varaintDBFilterFiles6, Chromosome[] chromosomes, VariantFilter varFilter, int chromID, AnnotationSummarySet assFBAFEM, AnnotationSummarySet assFBAFIM,
            FloatArrayList mafRefList) {
        if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
            if (options.minVarExpression > 0) {
                varFilter.filterByAlleleFreqExcModel(chromosomes[chromID], assFBAFEM, options.minAlleleFreqExc, mafRefList);
            } else {
                varFilter.filterByAlleleFreqIncModel(chromosomes[chromID], assFBAFIM, options.minAlleleFreqInc, options.maxAlleleFreqInc, mafRefList);
            }
        }
    }

    public static void varAssocTest(VariantAnnotator varAnnoter, Chromosome[] chromosomes, VariantFilter varFilter, int chromID, AnnotationSummarySet assSVHF,
            DoubleArrayList[] varPArray, Genome uniqueGenome) throws Exception {
        if (options.varAssoc) {
            varAnnoter.assocTestVar(chromosomes[chromID], assSVHF, varPArray);
            if (options.pValueThreshold != -9) {
                varFilter.filterBy4ModelPValue(chromosomes[chromID], assSVHF, options.pValueThreshold, uniqueGenome);
            }
        }
    }

    public static Chromosome loadRefVariantRenerGene(int chromID, String[] geneVarFreqFiles, GeneAnnotator geneAnnotor,
            int[] effecIndexVarFreq, boolean useMinIDForGeneMapping) throws Exception {
        Chromosome tmpChrom = null;
        String geneCoVarFilePath;
        if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.uwrunnerDiGeneInteractCoding || options.runnerDiGeneInteractCoding
                || options.uwrunnerMoGeneInteractCoding || options.runnerMoGeneInteractCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
            if (!geneVarFreqFiles[0].startsWith("&")) {
                geneCoVarFilePath = options.PUBDB_FILE_MAP.get(geneVarFreqFiles[0]);
                geneCoVarFilePath = GlobalManager.RESOURCE_PATH + geneCoVarFilePath;
            } else {
                geneCoVarFilePath = geneVarFreqFiles[0].substring(1);
            }

            tmpChrom = geneAnnotor.readAnnotGeneVarFreq(geneCoVarFilePath, chromID, effecIndexVarFreq[0], 0, effecIndexVarFreq.length, options.dependentGeneFeature, options.dependentMaxIntronFeature, useMinIDForGeneMapping, options.ctType);
            for (int i = 1; i < geneVarFreqFiles.length; i++) {
                if (!geneVarFreqFiles[i].startsWith("&")) {
                    geneCoVarFilePath = options.PUBDB_FILE_MAP.get(geneVarFreqFiles[i]);
                    geneCoVarFilePath = GlobalManager.RESOURCE_PATH + geneCoVarFilePath;
                } else {
                    geneCoVarFilePath = geneVarFreqFiles[i].substring(1);
                }
                if (effecIndexVarFreq[i] < 0) {
                    continue;
                }
                geneAnnotor.appendAnnotGeneVarFreq(tmpChrom, geneCoVarFilePath, chromID, effecIndexVarFreq[i], i, effecIndexVarFreq.length, options.dependentGeneFeature);
            }
        }
        tmpChrom.buildVariantIndexMap();
        return tmpChrom;
    }

    public static int[] dbNSFPAnnotPrediction(int chromID, Chromosome tmpChrom, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int[] dbNSFP3ScoreIndexes, List<CombOrders> combOrderList,
            Genome uniqueGenome, FiltrationSummarySet dbNSFPPred9, CombOrders fixedComb, MyRandomForest[][] myRandomForestsCancer, FiltrationSummarySet dbNSFPPred9Tmp,
            int[] dbNSFP3PredicIndex, FiltrationSummarySet dbNSFPAnnot8, FiltrationSummarySet dbNSFPAnnot8Tmp, int pextStart, int len) throws Exception {
        //the first one is the main chrom and the second one is the tmp chrom
        int[] scoreIndexes = new int[]{-1, -1};
        if (dbNSFPAnnot8 != null) {
            String dbLabelName = "dbnsfp";
            if (options.scoreDBLableList.contains(dbLabelName)) {
                String dbFileName = options.PUBDB_FILE_MAP.get(dbLabelName);
                // varAnnoter.readExonicScoreNSFPNucleotideMerge(chromosomes[chromID], GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8, options.needProgressionIndicator);
                varAnnoter.readExonicScoreNSFPNucleotideMergeMultiThread(chromosomes[chromID], GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8, options.needProgressionIndicator, options.threadNum);

                if (options.causingNSPredType == 0) {
                    //riskPredictionRareDiseaseAll(Chromosome chromosome, List<CombOrders> combOrderList, boolean filterNonDisMut, List<String> names, FiltrationSummarySet dbNSFPPred9)
                    if (options.predictExplanatoryVar.startsWith("best")) {
                        varAnnoter.riskPredictionRareDiseaseAllBest(chromosomes[chromID], combOrderList, options.mendelBestModelNum, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), options.threadNum, dbNSFPPred9);
                    } /*else if (options.predictExplanatoryVar.startsWith("best")) {
                                varAnnoter.riskPredictionRareDiseaseBest(chromosomes[chromID], combOrderList, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                            }*/ else {
                        varAnnoter.riskPredictionRareDiseaseFixParam(chromosomes[chromID], fixedComb, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                    }

                    scoreIndexes[0] = dbNSFPPred9.getAvailableFeatureIndex();
//                    if (pextStart > 0) {
//                        varAnnoter.weightScoreByExpression(chromosomes[chromID], pextStart, len, dbNSFPPred9.getAvailableFeatureIndex());
//                    }
                } else if (options.causingNSPredType == 2) {
                    //Chromosome chromosome, MyRandomForest myRandomForestsCancer, boolean filterNonDisMut, FiltrationSummarySet dbNSFPPred9
                    varAnnoter.riskPredictionRandomForest(chromosomes[chromID], myRandomForestsCancer, options.threadNum, options.filterNonDiseaseMut, dbNSFPPred9);
                    scoreIndexes[0] = dbNSFPPred9.getAvailableFeatureIndex() + 1;
                }

                if (tmpChrom != null) {
                    varAnnoter.readExonicScoreNSFPNucleotideMergeMultiThread(tmpChrom, GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8Tmp, options.needProgressionIndicator, options.threadNum);

                    if (options.causingNSPredType == 0) {
                        //riskPredictionRareDiseaseAll(Chromosome chromosome, List<CombOrders> combOrderList, boolean filterNonDisMut, List<String> names, FiltrationSummarySet dbNSFPPred9)
                        if (options.predictExplanatoryVar.startsWith("best")) {
                            varAnnoter.riskPredictionRareDiseaseAllBest(tmpChrom, combOrderList, options.mendelBestModelNum, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), options.threadNum, dbNSFPPred9Tmp);
                        } /*else if (options.predictExplanatoryVar.startsWith("best")) {
                                varAnnoter.riskPredictionRareDiseaseBest(chromosomes[chromID], combOrderList, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9);
                            }*/ else {
                            varAnnoter.riskPredictionRareDiseaseFixParam(tmpChrom, fixedComb, options.filterNonDiseaseMut, uniqueGenome.getScore1Labels(), dbNSFPPred9Tmp);
                        }
                        scoreIndexes[1] = dbNSFPPred9Tmp.getAvailableFeatureIndex();
//                        if (pextStart > 0) {
//                            varAnnoter.weightScoreByExpression(tmpChrom, pextStart, len, dbNSFPPred9Tmp.getAvailableFeatureIndex());
//                        }
                    } else if (options.causingNSPredType == 2) {
                        varAnnoter.riskPredictionRandomForest(tmpChrom, myRandomForestsCancer, options.threadNum, options.filterNonDiseaseMut, dbNSFPPred9Tmp);
                        scoreIndexes[1] = dbNSFPPred9Tmp.getAvailableFeatureIndex() + 1;
                    }
                }

            }
        }
        return scoreIndexes;
    }

    public static int[] customizedVarScoreAnnote(int chromID, Chromosome tmpChrom, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int[] dbNSFP3ScoreIndexes,
            Genome uniqueGenome, AnnotationSummarySet dbNSFPAnnot8, AnnotationSummarySet dbNSFPAnnot8Tmp) throws Exception {
        //the first one is the main chrom and the second one is the tmp chrom
        int[] scoreIndexes = new int[]{-1, -1};
        if (options.customizedScoreFilePath != null) {
            // varAnnoter.readExonicScoreNSFPNucleotideMerge(chromosomes[chromID], GlobalManager.RESOURCE_PATH + "/" + dbFileName, options.refGenomeVersion, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, dbNSFPAnnot8, options.needProgressionIndicator);
            varAnnoter.readCustomizedScoreSNVFilterMultiThread(chromosomes[chromID], options.customizedScoreFilePath, dbNSFP3ScoreIndexes, dbNSFPAnnot8, -1, options.threadNum);
            scoreIndexes[0] = dbNSFPAnnot8.getAvailableFeatureIndex();

            if (tmpChrom != null) {
                varAnnoter.readCustomizedScoreSNVFilterMultiThread(tmpChrom, options.customizedScoreFilePath, dbNSFP3ScoreIndexes, dbNSFPAnnot8Tmp, -1, options.threadNum);
                scoreIndexes[0] = dbNSFPAnnot8Tmp.getAvailableFeatureIndex();
            }

        }

        return scoreIndexes;
    }

    public static TwoTuple<String[], Integer> noncodeVarDBAnnotPrediction(int chromID, String[] currentLineList, VariantAnnotator varAnnoter, Chromosome[] chromosomes, Boolean[] isReigonList,
            double iniScore[], int[] fixedPosition, BufferedReader[] lineReaderList, int scoreIndexNum, MyRandomForest[][] myRandomForestList, Map genicMap,
            FiltrationSummarySet dbNoncodePred9d1, Chromosome tmpChrom, FiltrationSummarySet dbNoncodePred9d1Tmp, AnnotationSummarySet dbNoncodePred9d0,
            String annNCFPPath, AnnotationSummarySet dbNoncodePred9d0Tmp, FiltrationSummarySet dbNoncodePred9d2, Bayes bayesPredictor, double[] baye1NonCodingPredic, double[] baye2NonCodingPredic,
            FiltrationSummarySet dbNoncodePred9d2Tmp) throws Exception {
        /*
                    //varAnnoter.noncodingRandomForestGFC(chromosomes[chromID], needProgressionIndicator, filterNonDisMut, needThreadNumber);
                    currentLineList = varAnnoter.noncodingRandomForestGFC(chromosomes[chromID], options.needProgressionIndicator, options.filterNonDiseaseMut,
                            options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                            lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                            options.needVerboseNoncode, dbNoncodePred9d1.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1);
         */
        int annotationType = 2;
        int scoreIndex = -1;
        if (dbNoncodePred9d0 != null) {
            varAnnoter.readNocodeScoreNucleotideMultiThread(annNCFPPath, chromosomes[chromID], dbNoncodePred9d0, options.threadNum, annotationType);
            if (tmpChrom != null) {
                varAnnoter.readNocodeScoreNucleotideMultiThread(annNCFPPath, tmpChrom, dbNoncodePred9d0Tmp, options.threadNum, annotationType);
            }
        }
        if (dbNoncodePred9d1 != null) {
            currentLineList = varAnnoter.noncodingRandomForestGFRegions(chromosomes[chromID], options.needProgressionIndicator, options.filterNonDiseaseMut,
                    options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                    lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                    options.needVerboseNoncode, dbNoncodePred9d1.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1);
            if (tmpChrom != null) {
                currentLineList = varAnnoter.noncodingRandomForestGFRegions(tmpChrom, options.needProgressionIndicator, options.filterNonDiseaseMut,
                        options.threadNum, isReigonList, iniScore, currentLineList, fixedPosition,
                        lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                        options.needVerboseNoncode, dbNoncodePred9d1Tmp.getAvailableFeatureIndex(), chromID, dbNoncodePred9d1Tmp);
            }
            scoreIndex = dbNoncodePred9d1.getAvailableFeatureIndex();
        }
        if (dbNoncodePred9d2 != null) {
            // noncode 4 represents 4 calcualting parameters (BF,Composite_P,Cell_P,Combine_P)
            /*
                    varAnnoter.noncodingCellTypeSpecificPrediction(chromosomes[chromID], options.needProgressionIndicator, lineReaderList9d2,
                            bayesPredictor, chromID, dbNoncodePred9d2.getAvailableFeatureIndex(),
                            dbNoncodePred9d2.getAvailableFeatureIndex() + options.dbncfpFeatureColumn.length + 4);
             */

            varAnnoter.noncodingCompositPredictionMultiThread(chromosomes[chromID], options.usedDBncfpFeatureIndex,
                    bayesPredictor, dbNoncodePred9d2.getAvailableFeatureIndex(), options.threadNum, baye1NonCodingPredic,
                    baye2NonCodingPredic, options.cellLineName != null);
            if (tmpChrom != null) {
                varAnnoter.noncodingCompositPredictionMultiThread(tmpChrom, options.usedDBncfpFeatureIndex,
                        bayesPredictor, dbNoncodePred9d2Tmp.getAvailableFeatureIndex(), options.threadNum, baye1NonCodingPredic,
                        baye2NonCodingPredic, options.cellLineName != null);
            }
            if (options.cellLineName != null) {
                scoreIndex = dbNoncodePred9d2.getAvailableFeatureIndex() + 2;
            } else {
                scoreIndex = dbNoncodePred9d2.getAvailableFeatureIndex() + 1;
            }
        }
        TwoTuple<String[], Integer> reTwoTuple = new TwoTuple(currentLineList, scoreIndex);

        return reTwoTuple;
    }

    public static void regBaseAnnotateRegulatroyVar(AnnotationSummarySet regPreMeta, String annFilePath, Chromosome[] chromosomes, int chromID) {
        if (regPreMeta == null || options.scoreDBLableList.isEmpty()) {
            return;
        }
        String lable = options.scoreDBLableList.get(0);
        if (!lable.startsWith("regbase")) {
            return;
        }
        VariantAnnotator varAnnoter = new VariantAnnotator();

        int annotationType = 5;

        varAnnoter.readNocodeScoreNucleotideMultiThread(annFilePath, chromosomes[chromID], regPreMeta, options.threadNum, annotationType);

    }

    public static void regBaseAnnotateRegulatroyVar(CCFReader ccfOriginReader, Map<Integer, BaseArray<edu.sysu.pmglab.container.Interval<Long>>> ccfChromosomeInterval,
            AnnotationSummarySet regPreMeta, Chromosome[] chromosomes, int chromID, int annotationType) {
        if (regPreMeta == null) {
            return;
        }
        String lable = null;
        if (annotationType == 6) {
            lable = options.scoreDBLableList.get(0);
            if (!lable.startsWith("regbase")) {
                return;
            }
        } else if (annotationType == 7) {
            lable = options.epimarkDBLableList.get(0);
        }

        VariantAnnotator varAnnoter = new VariantAnnotator();

        varAnnoter.readCCFScoreNucleotideMultiThread(ccfOriginReader, ccfChromosomeInterval, chromosomes[chromID], regPreMeta, options.threadNum, annotationType);

    }

    public static void countRegionMutation(int somatNumIndex, int chromID, VariantAnnotator varAnnoter, Chromosome[] chromosomes, Chromosome tmpChrom, int[] scoreIndex,
            boolean useMinIDForGeneMapping, GeneAnnotator geneAnnotor, int geneFeatureTypeInTmpChrom, Map<String, DoubleArrayList> refGeneVarFreqScoreMap,
            Set<String> hittedGeneSet, int readInfoIndex, boolean useLocalGeneScore, double minCCFreqRatio) throws Exception {

        //useless in the new alogrithm
        double funcScoreBinLen = 0.2;
        if (somatNumIndex >= 0) {
            if (useMinIDForGeneMapping) {
                varAnnoter.summarizeMinIDSomaticVarPerRegion(chromosomes[chromID], somatNumIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex[0]);

            } else {
                varAnnoter.summarizeSomaticVarPerGene(chromosomes[chromID], somatNumIndex, readInfoIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex[0], funcScoreBinLen);
            }
        } else {
            //to generate gene frequency score in reference populations
            if (tmpChrom != null) {
                if (useMinIDForGeneMapping) {
                    // geneAnnotor.generateGeneVarMinIDFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                    geneAnnotor.generateGeneAllVarMinIDFreq(tmpChrom, geneFeatureTypeInTmpChrom, scoreIndex[1], options.dependentGeneFeature, options.independentGeneFeature, options.dependentMaxIntronFeature, options.runnerMoGeneInteractCoding || options.runnerDiGeneInteractCoding || options.runnerGeneCoding || options.wrenerGeneNonCoding, refGeneVarFreqScoreMap, hittedGeneSet);
                } else {
                    //geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, null, hittedGeneSet);
                }

                // geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, scorePercentiles, scoreCutoffs, chromID == 0, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                //geneAnnotor.generateGeneVarFreq(tmpChrom, options.minAlleleFreqExc * mafFolder, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
            }

            if (useMinIDForGeneMapping) {
                // varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc * 2, funcScoreBinLen);
                if (useLocalGeneScore) {
                    //varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen, refGeneVarFreqScoreMap, hittedGeneSet, mafBins);
                    boolean filterSharedCaseControlVariant = true;
                    varAnnoter.summarizeMinIDAltAllVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, scoreIndex[0], hittedGeneSet, refGeneVarFreqScoreMap, minCCFreqRatio, options.protectiveBurden);
                } else {

                    //varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen);
                    varAnnoter.summarizeMinIDAltAllVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex[0], options.minAlleleFreqLocal, options.maxAlleleFreqLocal, minCCFreqRatio, options.protectiveBurden);
                }

            } else {
                varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex[0], options.minAlleleFreqExc, funcScoreBinLen);
            }
        }
        //varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc, scoreCutoffs);
    }

    public static void countGeneMutation(int somatNumIndex, int chromID, VariantAnnotator varAnnoter, Chromosome[] chromosomes, Chromosome tmpChrom, int[] scoreIndex,
            boolean useMinIDForGeneMapping, GeneAnnotator geneAnnotor, int geneFeatureTypeInTmpChrom, Map<String, DoubleArrayList> refGeneVarFreqScoreMap,
            Set<String> hittedGeneSet, int readInfoIndex, boolean useLocalGeneScore, double minCCFreqRatio) throws Exception {
        if (options.dependentGeneFeature == null || options.dependentGeneFeature.isEmpty()) {
            return;
        }
        //useless in the new alogrithm
        double funcScoreBinLen = 0.2;
        if (somatNumIndex >= 0) {
            if (useMinIDForGeneMapping) {
                varAnnoter.summarizeMinIDSomaticVarPerGene(chromosomes[chromID], somatNumIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex[0]);

            } else {
                varAnnoter.summarizeSomaticVarPerGene(chromosomes[chromID], somatNumIndex, readInfoIndex, options.dependentGeneFeature, options.independentGeneFeature, scoreIndex[0], funcScoreBinLen);
            }
        } else {
            //to generate gene frequency score in reference populations
            if (tmpChrom != null) {
                if (useMinIDForGeneMapping) {
                    // geneAnnotor.generateGeneVarMinIDFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                    geneAnnotor.generateGeneAllVarMinIDFreq(tmpChrom, geneFeatureTypeInTmpChrom, scoreIndex[1], options.dependentGeneFeature, options.independentGeneFeature, options.dependentMaxIntronFeature, options.runnerMoGeneInteractCoding || options.runnerDiGeneInteractCoding || options.runnerGeneCoding || options.wrenerGeneNonCoding, refGeneVarFreqScoreMap, hittedGeneSet);
                } else {
                    //geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.dependentMaxIntronFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, null, hittedGeneSet);
                }

                // geneAnnotor.generateGeneVarFreq(tmpChrom, mafBins, options.minAlleleFreqExc, scorePercentiles, scoreCutoffs, chromID == 0, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
                //geneAnnotor.generateGeneVarFreq(tmpChrom, options.minAlleleFreqExc * mafFolder, funcScoreBinLen, popuNames.length, scoreIndex, options.dependentGeneFeature, options.runnerGeneCoding || options.wrenerGeneNonCoding, geneFreqScores, hittedGeneSet);
            }

            if (useMinIDForGeneMapping) {
                // varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc * 2, funcScoreBinLen);
                if (useLocalGeneScore) {
                    //varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen, refGeneVarFreqScoreMap, hittedGeneSet, mafBins);
                    boolean filterSharedCaseControlVariant = true;
                    varAnnoter.summarizeMinIDAltAllVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, scoreIndex[0], hittedGeneSet, refGeneVarFreqScoreMap, minCCFreqRatio, options.protectiveBurden);
                } else {

                    //varAnnoter.summarizeMinIDAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqLocal, options.maxAlleleFreqLocal, funcScoreBinLen);
                    varAnnoter.summarizeMinIDAltAllVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex[0], options.minAlleleFreqLocal, options.maxAlleleFreqLocal, minCCFreqRatio, options.protectiveBurden);
                }

            } else {
                varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.dependentMaxIntronFeature, options.independentGeneFeature, scoreIndex[0], options.minAlleleFreqExc, funcScoreBinLen);
            }
        }
        //varAnnoter.summarizeAltVarPerGene(chromosomes[chromID], options.dependentGeneFeature, options.independentGeneFeature, scoreIndex, options.minAlleleFreqExc, scoreCutoffs);
    }

    public static void ldPurningFiltration(int chromID, VariantAnnotator varAnnoter, Chromosome[] chromosomes, List<Individual> subjectList, int[] pedEncodeGytIDMap,
            Genome uniqueGenome, AnnotationSummarySet ldPruningASS) throws Exception {
        if (options.ldPruning) {
            varAnnoter.LDPruneWithinDistance(chromosomes[chromID], subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, options.ldPrunWindowSize, options.ldPrunR2, ldPruningASS);
        }

        System.gc();

    }

    public static void geneVarNumFiltration(int chromID, Chromosome[] chromosomes, Set<Byte> featureInSet, VariantFilter varFilter, AnnotationSummarySet assGVF10) throws Exception {
        if (options.geneMinVarFilter >= 0) {
            // varFilter.filterVarGeneByNumMinIDFreq(chromosomes[chromID], featureInSet, options.geneMinVarFilter, options.geneMaxVarPerPerson, assGVF10);
            //do the filtering by persons which is a more advanced function 
            varFilter.filterVarGeneByNumMinIDFreq(chromosomes[chromID], featureInSet, options.geneMinVarFilter, -1, assGVF10);
        }
    }

    public static void ppiAndPathwayAnnot(int chromID, VariantAnnotator varAnnoter, Chromosome[] chromosomes, Genome uniqueGenome, AnnotationSummarySet assG11,
            AnnotationSummarySet assV12, AnnotationSummarySet assPPIG13, PPIGraph ppiTree, AnnotationSummarySet assPPIV14, AnnotationSummarySet assPWG15, Map<String, GeneSet> mappedPathes,
            AnnotationSummarySet assPWV16) throws Exception {
        if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {
            if (uniqueGenome.getGeneNum() > 0) {
                varAnnoter.canidateGeneExploreGene(chromosomes[chromID], assG11, options.candidateGeneSet);
            } else {
                varAnnoter.canidateGeneExploreVar(chromosomes[chromID], assV12, options.candidateGeneSet);
            }

            if (options.ppiDB != null) {
                if (uniqueGenome.getGeneNum() > 0) {
                    varAnnoter.canidateGenePPIExploreGene(chromosomes[chromID], assPPIG13, options.candidateGeneSet, ppiTree, options.ppiDepth);
                } else {
                    varAnnoter.canidateGenePPIExploreVar(chromosomes[chromID], assPPIV14, options.candidateGeneSet, ppiTree, options.ppiDepth);
                }
            }

            if (mappedPathes != null) {
                if (uniqueGenome.getGeneNum() > 0) {
                    varAnnoter.canidateGenePathwayExploreGene(chromosomes[chromID], assPWG15, options.candidateGeneSet, mappedPathes);
                } else {
                    varAnnoter.canidateGenePathwayExploreVar(chromosomes[chromID], assPWV16, options.candidateGeneSet, mappedPathes);
                }
            }
        }
    }

    public static void ibsHomoCheckInCase(int chromID, VariantAnnotator varAnnoter, Chromosome[] chromosomes, AnnotationSummarySet assIBS17d1, List<Variant> chromosomeVarAll, Genome uniqueGenome,
            List<Individual> subjectList, int[] pedEncodeGytIDMap, int[] caseSetID, int[] controlSetID, AnnotationSummarySet assHRC17d2, AnnotationSummarySet assIBD17d5,
            List<String[]> regionItems) {

        if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            varAnnoter.exploreLongIBSRegion(chromosomes[chromID], assIBS17d1, chromosomeVarAll, options.ibsCheckCase * 1000, uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caseSetID);
        }

        if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            varAnnoter.exploreLongHomozygosityRegion(chromosomes[chromID], assHRC17d2, chromosomeVarAll, options.homozygousRegionCase * 1000, uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caseSetID, controlSetID);
        }
        //to save memory
        chromosomeVarAll.clear();

        if (options.ibdFileName != null) {
            varAnnoter.ibdRegionExplore(chromosomes[chromID], assIBD17d5, regionItems);
        }

    }

    //-----------------------------------xc part end------------------------------------------------------
    public static Map<String, double[]> doubleHitGeneModelFilteration(FiltrationSummarySet doubleHitGeneModelFilter19, FiltrationSummarySet doubleHitGeneModelFilter19d1,
            Map<String, double[]> chromDoubleHitGeneScoresMap, VariantFilter varFilter, Chromosome[] chromosomes,
            int chromID, Genome uniqueGenome, List<Individual> subjectList, int[] pedEncodeGytIDMap,
            List<int[]> triosIDList, IntArrayList effectiveIndivIDsTrios, Map<String, String[]> geneNamesMap,
            Map<String, String> genePubMedID, List<String[]> hitDisCountsTriosGenes, List<String[]> hitDisCounTriosReads,
            Set<String> caseDoubleHitTriosGenes, Set<String> controlDoubleHitTriosGenes, int predictionIDCol,
            int pathogenicPredicIndex, List<String[]> doubleHitGenePhasedGenes, List<String[]> doubleHitGenePhasedReads,
            Set<String> caseDoubleHitPhasedGenes, Set<String> controlDoubleHitPhasedGenes, int[] caseSetID, int[] controlSetID) throws Exception {
        if (doubleHitGeneModelFilter19 != null) {
            if (options.doubleHitGeneTriosCasePsudo) {
                chromDoubleHitGeneScoresMap = varFilter.doubleHitGeneExploreVarTriosSudoControl(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                        options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, options.countAllPsudoControl,
                        doubleHitGeneModelFilter19, options.pubmedMiningGene, predictionIDCol);

            } else if (options.doubleHitGeneTriosFilter) {
                varFilter.doubleHitGeneExploreVarTriosFilter(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                        options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, doubleHitGeneModelFilter19, options.pubmedMiningGene);

            } else if (options.doubleHitGeneTriosCaseControl) {
                varFilter.doubleHitGeneExploreVarTriosCaseControl(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, options.searchList, geneNamesMap, genePubMedID,
                        options.noHomo, hitDisCountsTriosGenes, hitDisCounTriosReads, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, doubleHitGeneModelFilter19, options.pubmedMiningGene);
            }
        }
        if (doubleHitGeneModelFilter19d1 != null) {
            varFilter.doubleHitGeneExploreVarPhasedGty(chromosomes[chromID], pedEncodeGytIDMap, caseSetID, controlSetID, options.searchList, geneNamesMap, genePubMedID,
                    options.noHomo, pathogenicPredicIndex, doubleHitGenePhasedGenes, doubleHitGenePhasedReads, caseDoubleHitPhasedGenes, controlDoubleHitPhasedGenes, doubleHitGeneModelFilter19d1, options.pubmedMiningGene);
        }
        return chromDoubleHitGeneScoresMap;
    }

    public static void hgncGeneAnnot(Genome uniqueGenome, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, AnnotationSummarySet assGene20,
            AnnotationSummarySet assVariant20, AnnotationSummarySet assOmimGene21, AnnotationSummarySet assOmimVar21) throws Exception {
        if (options.needAnnotateGene) {
            String fileNameHg = "HgncGene.txt";
            File resourceFileHg = new File(GlobalManager.RESOURCE_PATH + "/" + fileNameHg);
            if (uniqueGenome.getGeneNum() > 0) {
                varAnnoter.pseudogeneAnnotationGene(chromosomes[chromID], assGene20, resourceFileHg.getCanonicalPath());
            } else {
                varAnnoter.pseudogeneAnnotationVar(chromosomes[chromID], assVariant20, resourceFileHg.getCanonicalPath());
            }
        }

        if (options.omimAnnotateGene) {
            File resourceFileOmim = new File(GlobalManager.RESOURCE_PATH + "/morbidmap.gz");
            if (uniqueGenome.getGeneNum() > 0) {
                varAnnoter.omimGeneAnnotationGene(chromosomes[chromID], assOmimGene21, resourceFileOmim.getCanonicalPath());
            } else {
                varAnnoter.omimGeneAnnotationVar(chromosomes[chromID], assOmimVar21, resourceFileOmim.getCanonicalPath());
            }
        }

    }

    public static boolean otherAnnotationHandler(Genome uniqueGenome, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, AnnotationSummarySet assTissueSpecVar21,
            Map<String, StringBuilder> tissueSpecGeneMap, AnnotationSummarySet assSDA22, ReferenceGenome refGenomeSD, VariantFilter varFilter,
            AnnotationSummarySet assSDF22, AnnotationSummarySet dbScSNV18) throws Exception {
        if (dbScSNV18 != null) {
            varAnnoter.dbscSNV(chromosomes[chromID], dbScSNV18, options.needProgressionIndicator);
        }
        if (options.tissueSpecAnnot) {

            if (uniqueGenome.getGeneNum() > 0) {
                //  varAnnoter.omimGeneAnnotationGene(chromosomes[chromID], assOmimGene21, resourceFileOmim.getCanonicalPath());
            } else {
                varAnnoter.tissueSpecGeneAnnotationVar(chromosomes[chromID], assTissueSpecVar21, tissueSpecGeneMap);
            }

        }

        if (options.superdupAnnotate) {
            varAnnoter.superDupAnnotation(chromosomes[chromID], assSDA22, refGenomeSD);
        }

        return false;
    }

    public static void annotGenePheno(VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, AnnotationSummarySet assMousePheno, Map g2MP, AnnotationSummarySet assZebra,
            HashMap<String, String> xebraP2Phe, AnnotationSummarySet assDDD, HashMap<String, String> dddP2Phe,
            Phenolyzer phenolyzer, AnnotationSummarySet assPhenolyzer26, HashMap<String, String> hmpPhenolyzer) {
        if (options.phenoMouse) {
            varAnnoter.annotateGenesArray(chromosomes[chromID], assMousePheno, g2MP, 2);
        }
        if (options.zebraFish) {
            varAnnoter.annotateGenes(chromosomes[chromID], assZebra, xebraP2Phe);
        }
        if (options.dddPhenotypes) {
            varAnnoter.annotateGenes(chromosomes[chromID], assDDD, dddP2Phe);
        }
        if (options.phenolyzer) {
            phenolyzer.addScore(chromosomes[chromID], assPhenolyzer26, hmpPhenolyzer);
        }
    }

    public static void pubmedMining(Genome uniqueGenome, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, AnnotationSummarySet pubmedSearch24_Gene_Ideo, List<String[]> ideogramItemsGene,
            AnnotationSummarySet pubmedSearch24_Gene, Map<String, String[]> geneNamesMap, Map<String, String> genePubMedID, AnnotationSummarySet pubmedSearch24_Var_Ideo, List<String[]> ideogramItemsVar,
            int driverPredicIndex, AnnotationSummarySet pubmedSearch24_Var) throws Exception {
        if (options.searchList != null && !options.searchList.isEmpty()) {
            if (uniqueGenome.getGeneNum() > 0) {
                if (options.pubmedMiningIdeo) {
                    varAnnoter.pubMedIDIdeogramExploreGene(chromosomes[chromID], pubmedSearch24_Gene_Ideo, options.searchList, ideogramItemsGene);
                }
                if (options.pubmedMiningGene) {
                    varAnnoter.pubMedIDGeneExploreGene(chromosomes[chromID], pubmedSearch24_Gene, options.searchList, geneNamesMap, genePubMedID);
                }
            } else {
                if (options.pubmedMiningIdeo) {
                    varAnnoter.pubMedIDIdeogramExploreVar(chromosomes[chromID], pubmedSearch24_Var_Ideo, options.searchList, ideogramItemsVar, options.refGenomeVersion, true, driverPredicIndex);
                }
                if (options.pubmedMiningGene) {
                    varAnnoter.pubMedIDGeneExploreVar(chromosomes[chromID], pubmedSearch24_Var, options.searchList, true, geneNamesMap, genePubMedID, driverPredicIndex);
                }
            }
        }
    }

    public static boolean variantListHandler(Chromosome[] chromosomes, int chromID, List<Variant> chromosomeVarAll) {
        if (chromosomes[chromID].variantList.isEmpty()) {
            chromosomes[chromID].getPosIndexMap().clear();
            chromosomeVarAll.clear();
            System.gc();
            return true;
            //continue;
        }
        return false;
    }

    public static void rsIDFlankSeqAnnot(VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, AnnotationSummarySet assRSID25, OpenIntIntHashMap[] altMapID, SequenceRetriever seqRe,
            AnnotationSummarySet assFS) throws Exception {
        if (options.rsid) {
            varAnnoter.addRSID(chromosomes[chromID], assRSID25, altMapID[chromID]);
        }
        if (options.flankingSequence > 0) {
            seqRe.addFlankingSequences(chromosomes[chromID], assFS, options.flankingSequence, options.refGenomeVersion);
        }

    }

    public static void assignVar2Gene(Map<String, GeneSet> dbPathwaySet, VariantAnnotator varAnnoter, Chromosome[] chromosomes,
            int chromID, Map<String, List<Variant>> geneVars) {
        if (options.skatGeneset || options.rvtestGeneset || options.isGeneVarGroupFileOut || options.rvtestGene
                || options.skatGene || options.digeneAssoc || options.runnerDiGeneInteractCoding || options.uwrunnerDiGeneInteractCoding
                || options.runnerMoGeneInteractCoding || options.uwrunnerMoGeneInteractCoding
                || options.geneCodingLogistAssoc || (dbPathwaySet != null && !dbPathwaySet.isEmpty())
                || options.uwrunnerGeneCoding || options.runnerGeneCoding || options.makeDiGeneRef) {
            Set<Byte> varFeatureSetRunner = new HashSet<Byte>();
            varFeatureSetRunner.addAll(options.dependentGeneFeature);
            varFeatureSetRunner.addAll(options.independentGeneFeature);
            //give priority to runner's feature
            if (varFeatureSetRunner.isEmpty()) {
                varFeatureSetRunner.addAll(options.geneFeatureIn);
            }
            varAnnoter.assignSelectedVar2Genes(chromosomes[chromID].variantList, STAND_CHROM_NAMES[chromID], geneVars, varFeatureSetRunner);
        }

    }

    public static void cleanGtyAtGeneWithTooManyVarInIndividual(VariantAnnotator varAnnoter, Map<String, List<Variant>> geneVars, boolean isPhasedGty, int[] pedEncodeGytIDMap, int[] caseSetID, int[] controlIDs) throws Exception {
        /*
        if (options.skatGeneset || options.rvtestGeneset || options.isGeneVarGroupFileOut || options.rvtestGene
                || options.skatGene || options.digeneAssoc || options.runnerDiGeneInteractCoding || options.uwrunnerDiGeneInteractCoding
                || options.geneCodingLogistAssoc || options.uwrunnerGeneCoding || options.runnerGeneCoding || options.makeDiGeneRef)
         */
        {
            //later on i found it may be necessary to do the qc analyis for all genes
            // varAnnoter.cleanGtyAtGeneWithTooManyVarInIndividual(geneVars, isPhasedGty, pedEncodeGytIDMap, caseSetID, controlIDs, options.geneMaxVarPerPerson);
            varAnnoter.cleanGtyAtGeneWithTooManyVarInIndividual(geneVars, isPhasedGty, pedEncodeGytIDMap, caseSetID, controlIDs, options.geneMaxVarPerPerson, options.threadNum);

        }

    }

    public static void runSKAT(Map<String, List<Variant>> geneVars, SKAT skat, List<Individual> subjectList, int[] pedEncodeGytIDMap,
            Genome uniqueGenome, DoubleArrayList[] genePVList, int scoreIndex) {
        if (options.skatGene) {
            if (skat.boolSnowFail) {
                skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), 1, genePVList, scoreIndex);
            } else {
                skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, genePVList, scoreIndex);
            }
        }

    }

    public static void assignVar2GeneAndSKAT(Map<String, GeneSet> dbPathwaySet, VariantAnnotator varAnnoter, Chromosome[] chromosomes, int chromID, Map<String, List<Variant>> geneVars, SKAT skat,
            List<Individual> subjectList, int[] pedEncodeGytIDMap, Genome uniqueGenome, DoubleArrayList[] genePVList, int scoreIndex) {
        if (options.skatGeneset || options.rvtestGeneset || options.isGeneVarGroupFileOut || options.rvtestGene
                || options.skatGene || options.digeneAssoc || options.runnerMoGeneInteractCoding || options.uwrunnerDiGeneInteractCoding
                || options.runnerMoGeneInteractCoding || options.uwrunnerDiGeneInteractCoding
                || options.geneCodingLogistAssoc || (dbPathwaySet != null && !dbPathwaySet.isEmpty())) {
            varAnnoter.assignSelectedVar2Genes(chromosomes[chromID].variantList, STAND_CHROM_NAMES[chromID], geneVars, options.independentGeneFeature);
        }

        if (options.skatGene) {
            if (skat.boolSnowFail) {
                skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), 1, genePVList, scoreIndex);
            } else {
                skat.runGeneAssoc(geneVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, genePVList, scoreIndex);
            }
        }

    }

    public static void exportHandler(List<Individual> subjectList, Genome uniqueGenome, Chromosome[] chromosomes, int chromID, int[] pedEncodeGytIDMap, BufferedOutputStream fileBedStream, BufferedWriter bwMapBed,
            int[] savedBinnaryBedVar, BufferedOutputStream filelKedStream, BufferedWriter bwMapKed, int[] savedBinnaryKedVar, BufferedWriter bwMapPed, int[] savedPedVar, boolean needWriteTmp,
            BufferedWriter tmpWriter, BufferedWriter annovarFilteredInFileWriter, BufferedWriter bwGeneVarGroupFile, Map<String, List<Variant>> geneVars) throws Exception {
        if (!subjectList.isEmpty()) {
            if (options.isPlinkBedOut) {
                uniqueGenome.exportPlinkBinaryGty(chromosomes[chromID], subjectList, pedEncodeGytIDMap, fileBedStream, bwMapBed, savedBinnaryBedVar);
            }
            if (options.isBinaryGtyOut) {
                uniqueGenome.exportKGGSeqBinaryGty(chromosomes[chromID], filelKedStream, bwMapKed, savedBinnaryKedVar);
            }
            if (options.isPlinkPedOut) {
                uniqueGenome.export2FlatTextPlink(chromosomes[chromID], subjectList, pedEncodeGytIDMap, bwMapPed, options.outputFileName, savedPedVar, options.outGZ);
            }
        }

        if (needWriteTmp) {
            //uniqueGenome.export2ATmpFormat(tmpWriter, chromID);
            uniqueGenome.export2ANNOVARAnnot(tmpWriter, chromID);

        }
        if (options.isANNOVAROut) {
            uniqueGenome.export2ANNOVARInput(annovarFilteredInFileWriter, chromID);
        }

        if (options.isGeneVarGroupFileOut) {
            uniqueGenome.export2GeneVarGroupFile(bwGeneVarGroupFile, chromID, geneVars);
        }
    }

    public static int vcfOutHandler(boolean[] origionallySorted, int writenVCFVarNum, Genome uniqueGenome, BlockCompressedOutputStream vcfFilteredInFileWriter, Chromosome[] chromosomes, int chromID,
            int maxEffectiveColVCF, int[] maxThreadID, BlockCompressedOutputStream simpleVcfFilteredInFileWriter, List<Individual> subjectList, int[] pedEncodeGytIDMap, boolean hasChrLabel) {
        if (options.isVCFOut) {
            //Othervise this will repeat twice
            if (origionallySorted[0]) {
                writenVCFVarNum += uniqueGenome.export2VCFFormatNoSorting(vcfFilteredInFileWriter, chromosomes[chromID], maxEffectiveColVCF, maxThreadID[0]);
            } else {
                writenVCFVarNum += uniqueGenome.export2VCFFormatSorting(vcfFilteredInFileWriter, chromosomes[chromID], maxEffectiveColVCF, options.threadNum, maxThreadID[0]);
            }
        }
        if (options.isSimpleVCFOut) {
            uniqueGenome.export2VCFFormatSimple(simpleVcfFilteredInFileWriter, chromosomes[chromID], subjectList.size(), pedEncodeGytIDMap, hasChrLabel);
        }
        return writenVCFVarNum;
    }

    public static void prepareFilesForRVTests(int chromID, Genome uniqueGenome, Map<String, List<Variant>> geneVars, int minVar, boolean hasChrLabel, Map<String, String[]> geneAlleleCCMap) throws Exception {
        if (options.rvtestGene) {
            BufferedWriter bwGeneRVTestGroupFile = null;
            GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".chr" + STAND_CHROM_NAMES[chromID] + ".gene.rvtest.grp.gz"));
            bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
            uniqueGenome.export2GeneVarGroupFileRVTest(bwGeneRVTestGroupFile, chromID, geneVars, minVar, hasChrLabel, geneAlleleCCMap);
            bwGeneRVTestGroupFile.close();
        }

        if (options.rvtestVar) {
            BufferedWriter bwGeneRVTestGroupFile = null;
            GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".chr" + STAND_CHROM_NAMES[chromID] + ".var.rvtest.grp.gz"));
            bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
            uniqueGenome.export2GeneVarGroupFileRVTest(bwGeneRVTestGroupFile, chromID, geneVars, hasChrLabel);
            bwGeneRVTestGroupFile.close();
        }
    }

    public static Genome mergeResourceHandler(Chromosome[] chromosomes, int chromID, Genome refhapGenome, VCFParserFast vsParser, boolean[] origionallySorted, int[] maxThreadID, List<Individual> subjectList,
            List<Individual> refIndivList, Genome uniqueGenome, int[] pedEncodeGytIDMap, BufferedOutputStream mergedFileStream, BufferedWriter mergedBwMap, BlockCompressedOutputStream vcfWriter, int[] coutVar) throws Exception {
        if (options.mergeGtyDb != null && (options.isPlinkPedOut || options.isPlinkBedOut || options.isSimpleVCFOut)) {
            //a special function to merge public resoruces
            String vcfFilePath = GlobalManager.RESOURCE_PATH + "/" + options.mergeGtyDb + ".chr" + chromosomes[chromID].getName() + ".vcf.gz";
            File f = new File(vcfFilePath);
            boolean[] hasGty = new boolean[1];
            if (f.exists()) {
                refhapGenome = vsParser.readVariantGtyFilterOnly("1kgmerge", options.threadNum, null, vcfFilePath, options.seqQual, options.minMappingQuality, options.maxStandBias,
                        options.maxFisherStandBias, options.maxGtyAlleleNum, options.gtyQual, options.minGtySeqDP, options.maxAltAlleleFracRefHom, options.minAltAlleleFractHet,
                        options.minAltAlleleFractAltHom, options.vcfFilterLabelsIn, options.minOBS, options.minOBSRate, options.minOBSA, options.minOBSARate, options.minOBSU, options.minOBSURate, options.sampleMafOver, options.sampleMafLess, options.considerSNV, options.considerIndel,
                        options.ignoreCNV, options.gtySecPL, options.gtyBestGP, options.needProgressionIndicator, true, false, false, false, false, options.forced2Unphased, null, null, null, null, null, null, null, hasGty);
                int[] refPedEncodeGytIDMap = vsParser.getPedEncodeGytIDMap();

                refhapGenome.loadVariantFromDisk(chromID, true, origionallySorted, maxThreadID);

                if (!subjectList.isEmpty() && !refIndivList.isEmpty()) {
                    if (options.isPlinkBedOut) {
                        uniqueGenome.exportPlinkBinaryGty(chromosomes[chromID], subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], refhapGenome.isIsPhasedGty(), refIndivList, refPedEncodeGytIDMap, mergedFileStream, mergedBwMap, coutVar);//Write .bim and .bed file
                    }
                    //This is too slow. Only support the binary format
                    if (options.isPlinkPedOut) {
                        //  uniqueGenome.export2FlatTextPlink(chromosomes[chromID], wahBit, subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], wahBit1, true, refIndivList, refPedEncodeGytIDMap, mergedBwMap, options.outputFileName+".merged", intsSPV, options.outGZ);//Write .map and .ped file
                    }
                    if (options.isSimpleVCFOut) {
                        if (options.isPlinkBedOut) {
                            uniqueGenome.exportSimpleVCFFormat(chromosomes[chromID], subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], refhapGenome.isIsPhasedGty(), refIndivList, refPedEncodeGytIDMap, vcfWriter);//Write .bim and .bed file
                        } else {
                            uniqueGenome.exportSimpleVCFFormat(chromosomes[chromID], subjectList, pedEncodeGytIDMap, refhapGenome.getChromosomes()[chromID], refhapGenome.isIsPhasedGty(), refIndivList, refPedEncodeGytIDMap, vcfWriter, coutVar);//Write .bim and .bed file
                        }
                    }
                }
                refhapGenome.getChromosomes()[chromID].variantList.clear();

            } else {
                LOG.warn("The file," + f.getCanonicalPath() + ", does not exist and cannot be merged!");
            }
        }
        return refhapGenome;
    }

    public static TwoTuple<File, File> geneSetAssocTest(Map<String, List<Variant>> genesetVars, List<String> featureLabels, Genome uniqueGenome, List<Individual> subjectList, int[] pedEncodeGytIDMap,
            SKAT skat, DoubleArrayList[] genePVList, boolean hasChrLabel) throws Exception {
        File rvTestGroupTestFile = null;
        File simpleIndiviGenesetSumFile = null;
        if ((options.skatGeneset || options.rvtestGeneset) && !genesetVars.isEmpty()) {
            RVTest rvtest = null;
            if (options.needNewVCFForRVTest) {
                rvtest = new RVTest(null, options.outputFileName);
            } else {
                rvtest = new RVTest(options.inputFileName, options.outputFileName);
            }
            rvtest.setCommand(options.rvtestCommand);

            featureLabels = uniqueGenome.getVariantFeatureLabels();
            int probIndex = -1;
            for (int i = 0; i < featureLabels.size(); i++) {
                if (featureLabels.get(i).equals("DiseaseCausalProb_ExoVarTrainedModel")) {
                    probIndex = i;
                    break;
                }
            }
            if (!subjectList.isEmpty()) {
                simpleIndiviGenesetSumFile = new File(options.outputFileName + ".geneset.indiv.sum");
                rvtest.summarizeVarCountsBySubject(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.phenotypeColID, simpleIndiviGenesetSumFile.getCanonicalPath(), probIndex, false);
            }
            if (options.skatGeneset) {
                if (skat.boolSnowFail) {
                    skat.runGenesetAssoc(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), 1, genePVList);
                } else {
                    skat.runGenesetAssoc(genesetVars, subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, genePVList);
                }
            }

            if (options.rvtestGeneset) {
                rvTestGroupTestFile = new File(options.outputFileName + ".geneset.rvtest.grp.gz");
                BufferedWriter bwGeneRVTestGroupFile = null;
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(rvTestGroupTestFile));
                bwGeneRVTestGroupFile = new BufferedWriter(new OutputStreamWriter(gzOut));
                rvtest.generateGenesetAssocGroup(genesetVars, bwGeneRVTestGroupFile, hasChrLabel);
                bwGeneRVTestGroupFile.close();
            }
            genesetVars.clear();
        }
        return TupleUtil.tuple(rvTestGroupTestFile, simpleIndiviGenesetSumFile);
    }

    //--------------------------------------
    public static void closeAnnovarWriter(BufferedWriter annovarFilteredInFileWriter) throws Exception {
        if (annovarFilteredInFileWriter != null) {
            annovarFilteredInFileWriter.close();
        }
    }

//------------------------------------
    public static void printMinMissingQC(FiltrationSummarySet minMissingQCFilter1) {
        if (minMissingQCFilter1 != null) {
            String info = minMissingQCFilter1.toString();
            if (!info.isEmpty()) {
                LOG.info(info);
            }
            minMissingQCFilter1 = null;
        }
    }

    //------------------------------------
    public static void closeReferenceGenomes(ReferenceGenome[] referenceGenomes) {
        if (referenceGenomes != null) {
            for (int i = 0; i < referenceGenomes.length; i++) {
                referenceGenomes[i] = null;
            }
        }
    }
//-----------------------------------

    public static void printGeneFeatureSummary(int[] variantsCounters, FiltrationSummarySet geneDBFilter7) {
        if (variantsCounters != null) {
            double totolVarNum = 0;
            for (int num : variantsCounters) {
                totolVarNum += num;
            }

            StringBuilder info = new StringBuilder();
            info.append("Gene feature summary of variants:\n");
            for (int i = 0; i < VAR_FEATURE_NAMES.length; i++) {
                info.append(" ").append(i).append(".").append(VAR_FEATURE_NAMES[i]).append(": ").append(variantsCounters[i]).append(" (")
                        .append(Util.doubleToString(variantsCounters[i] / totolVarNum * 100, 3)).append("%)\n");
            }
            LOG.info(info);
            LOG.info(geneDBFilter7.toString());
        }
    }

//-----------------------------------
    public static void printInheritanceModelFiltrationSummary(FiltrationSummarySet inheritanceModelFilter2) {
        if (inheritanceModelFilter2 != null) {
            String info = inheritanceModelFilter2.toString();
            if (!info.isEmpty()) {
                LOG.info(info);
            }
            inheritanceModelFilter2 = null;
        }
    }
//-----------------------------------

    public static void printDenovoModelFiltrationSummary(FiltrationSummarySet denovoModelFilter3) {
        if (denovoModelFilter3 != null) {
            String info = denovoModelFilter3.toString();
            if (!info.isEmpty()) {
                LOG.info(info);
            }
            denovoModelFilter3 = null;
        }
    }

//----------------------------------
    public static void printSomatMuatModelFiltrationSummary(FiltrationSummarySet somaticModelFilter4) {
        if (somaticModelFilter4 != null) {
            String info = somaticModelFilter4.toString();
            if (!info.isEmpty()) {
                LOG.info(info);
            }
        }
    }

//----------------------------------
    public static Genome printMAFSampleHardFiltrationSummary(boolean[] uniqueFilters, Genome uniqueGenome, AnnotationSummarySet assCCUMFV) {
        if (options.sampleVarHardFilterCode != null) {
            if (uniqueFilters[0] || uniqueFilters[1]) {
                uniqueGenome.setVarNum(assCCUMFV.getAnnotNum());
                if (uniqueGenome.getVarNum() == 0) {
                    LOG.info("0 sequence variant(s) are retained finally!");

                }
                String info = assCCUMFV.getAnnotNum() + " variant(s) are retained after filtration according to " + options.sampleVarHardFilterCode;
                LOG.info(info);
            }
        }
        return uniqueGenome;
    }

//---------------------------------
    public static void printSampleHWDFiltrationSummary(AnnotationSummarySet assHWD) {
        if (options.hwdPControl > 0 || options.hwdPCase > 0 || options.hwdPAll > 0) {
            if (options.hwdPCase > 0) {
                if (assHWD.getAnnotNum() > 0) {
                    String info = assHWD.getAnnotNum() + " sequence variants failed case-HWE test ( p <=" + options.hwdPCase + " ) and have been excluded!";
                    LOG.info(info);
                }
            }
            if (options.hwdPControl > 0) {
                if (assHWD.getLeftNum() > 0) {
                    String info = assHWD.getLeftNum() + " sequence variants failed control-HWE test ( p <=" + options.hwdPControl + " ) and have been excluded!";
                    LOG.info(info);
                }
            }
            if (options.hwdPAll > 0) {
                if (assHWD.getTotalNum() > 0) {
                    String info = assHWD.getTotalNum() + " sequence variants failed HWE test ( p <=" + options.hwdPAll + " ) and have been excluded!";
                    LOG.info(info);
                }
            }
        }
    }

    public static void printCTTypeFiltrationSummary(AnnotationSummarySet assMAF) {
        if (options.ctType == 1) {
            if (assMAF.getLeftNum() > 0) {
                String info = assMAF.getLeftNum() + " sequence variants with C/T or T/C alleles are retained!";
                LOG.info(info);
            }
        } else if (options.ctType == 2) {
            if (assMAF.getLeftNum() > 0) {
                String info = assMAF.getLeftNum() + " sequence variants are retained after excluding those with C/T or T/C alleles!";
                LOG.info(info);
            }
        }
    }

    public static void printtCaseContrlMAFRatioFiltrationSummary(AnnotationSummarySet assMAF) {
        if (options.minCCFreqRatio > 1) {
            if (assMAF.getTotalNum() > 0) {
                String info = assMAF.getTotalNum() + "  variants are retained after removing " + assMAF.getLeftNum() + " variants with case/control alternative allele frequency ratio < " + options.minCCFreqRatio + ".";
                LOG.info(info);
            }
        }
    }

    public static void printCaseContrlMAFFiltrationSummary(AnnotationSummarySet assMAF) {
        if (options.caseMafOver > 0 || options.caseMafLess < 1) {
            if (options.caseMafOver > 0) {
                if (assMAF.getAnnotNum() > 0) {
                    String info = assMAF.getLeftNum() + " sequence variants with MAF <=" + String.format("%.3f", options.caseMafOver) + " in cases are excluded!";

                    LOG.info(info);
                }
            }
            if (options.caseMafLess < 1) {
                if (assMAF.getLeftNum() > 0) {
                    String info = assMAF.getLeftNum() + " sequence variants with MAF >=" + String.format("%.3f", options.caseMafLess) + " in cases are excluded!";
                    LOG.info(info);
                }
            }
        }

        if (options.controlMafOver > 0 || options.controlMafLess < 1) {
            if (options.controlMafOver > 0) {
                if (assMAF.getAnnotNum() > 0) {
                    String info = assMAF.getTotalNum() + " sequence variants with MAF <=" + String.format("%.3f", options.controlMafOver) + " in controls are excluded!";

                    LOG.info(info);
                }
            }
            if (options.controlMafLess < 1) {
                if (assMAF.getLeftNum() > 0) {
                    String info = assMAF.getTotalNum() + " sequence variants with MAF >=" + String.format("%.3f", options.controlMafLess) + " in controls are excluded!";
                    LOG.info(info);
                }
            }
        }
    }

//-----------------------------------
    public static void printPValueCutFiltrationSummary(AnnotationSummarySet assSVHF) {
        if (options.varAssoc) {
            if (options.pValueThreshold != -9) {
                LOG.info(assSVHF.getLeftNum() + " variant(s) are retained after filtering the p-value cutoff " + options.pValueThreshold + ".");
            }
        }
    }

//------------------------------------
    public static String nameMultipleTestingMethod() {
        String multiCorrMethodName = null;
        if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
            multiCorrMethodName = "";
        } else if (options.multipleTestingMethod.equals("benfdr")) {
            multiCorrMethodName = " by Benjamini-Hochberg FDR";
        } else if (options.multipleTestingMethod.equals("bonhol")) {
            multiCorrMethodName = " by Bonferroni-Holm procedure";
        } else if (options.multipleTestingMethod.equals("bonf")) {
            multiCorrMethodName = " by Standard Bonferroni";
        }
        return multiCorrMethodName;
    }

// if (options.sampleVarHardFilterCode != null && options.sampleVarHardFilterCode.equals("association") && options.inputFormat.endsWith("--vcf-file"))
//-----------------------------------------------
    public static void printAsscPValueCutFiltrationSummary(String multiCorrMethodName, DoubleArrayList[] varPArray) throws Exception {
        if (options.toQQPlot && options.varAssoc) {
            List<String> nameList = new ArrayList<String>();
            nameList.add("Allelic");
            nameList.add("Dominant");
            nameList.add("Recessive");
            nameList.add("Genotypic");
            PValuePainter pvPainter = new PValuePainter(450, 450);
            File plotFile2 = new File(options.outputFileName + ".var.qq.png");
            StringBuilder message = new StringBuilder();

            if (options.pValueThreshold > 0) {
                if (multiCorrMethodName.length() > 0) {
                    message.append("Significance level of p value cutoffs for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ":\n");
                } else {
                    message.append("Significance level of a fixed p value cutoff ").append(options.pValueThreshold).append(":\n");
                }

                double[] thrholds = new double[4];

                for (int i = 0; i < 4; i++) {
                    message.append(" ");
                    if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                        thrholds[i] = options.pValueThreshold;
                    } else if (options.multipleTestingMethod.equals("benfdr")) {
                        thrholds[i] = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, varPArray[i]);
                    } else if (options.multipleTestingMethod.equals("bonhol")) {
                        thrholds[i] = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, varPArray[i]);
                    } else if (options.multipleTestingMethod.equals("bonf")) {
                        thrholds[i] = options.pValueThreshold / varPArray[i].size();
                    }
                    message.append(nameList.get(i));
                    message.append(": ");
                    message.append(thrholds[i]).append("\n");
                }
                LOG.info(message.substring(0, message.length() - 1));
            }

            pvPainter.drawMultipleQQPlot(Arrays.asList(varPArray), nameList, null, plotFile2.getCanonicalPath(), 1E-10);
            String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
            LOG.info(info);
            showPlots(new File[]{plotFile2});
        }
    }

//------------------------------------------
    public static void printDoubleHitPValueCutFiltrationSummary(Map<String, double[]> allDoubleHitGeneScoresMap, String multiCorrMethodName) throws Exception {
        if (options.toQQPlot && allDoubleHitGeneScoresMap != null && !allDoubleHitGeneScoresMap.isEmpty()) {
            List<String> nameList = new ArrayList<String>();
            nameList.add("Empirical p");

            PValuePainter pvPainter = new PValuePainter(450, 450);
            File plotFile2 = new File(options.outputFileName + ".doublehit.qq.png");
            StringBuilder message = new StringBuilder();
            DoubleArrayList pvalues = new DoubleArrayList();

            for (Map.Entry<String, double[]> item : allDoubleHitGeneScoresMap.entrySet()) {
                pvalues.add(item.getValue()[1]);
            }
            if (multiCorrMethodName.length() > 0) {
                message.append("Significance level of p value cutoffs for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ": ");
            } else {
                message.append("Significance level of a fixed p value cutoff ").append(options.pValueThreshold).append(": ");
            }

            double thrholds = 1;

            message.append(" ");
            if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                thrholds = options.pValueThreshold;
            } else if (options.multipleTestingMethod.equals("benfdr")) {
                thrholds = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, pvalues);
            } else if (options.multipleTestingMethod.equals("bonhol")) {
                thrholds = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, pvalues);
            } else if (options.multipleTestingMethod.equals("bonf")) {
                thrholds = options.pValueThreshold / pvalues.size();
            }
            message.append(nameList.get(0));
            message.append(": ");
            message.append(thrholds).append("\n");

            LOG.info(message.substring(0, message.length() - 1));
            List<DoubleArrayList> pList = new ArrayList<DoubleArrayList>();
            pList.add(pvalues);
            pvPainter.drawMultipleQQPlot(pList, nameList, null, plotFile2.getCanonicalPath(), 1E-10);
            String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
            LOG.info(info);
            showPlots(new File[]{plotFile2});
        }
    }

//------------------------------------
    public static void printSKATPValueCutFiltrationSummary(String multiCorrMethodName, DoubleArrayList[] genePVList) throws Exception {
        if (options.toQQPlot && options.skatGene) {
            List<String> nameList = new ArrayList<String>();
//                if (options.skatBinary) {
            nameList.add("SKAT");
            nameList.add("SKATO");
            nameList.add("Burden");
//                } else {
//                    nameList.add("SKAT");
//                    nameList.add("SKATO");
//                }

            PValuePainter pvPainter = new PValuePainter(450, 450);
            File plotFile2 = new File(options.outputFileName + ".skat.gene.qq.png");
            StringBuilder message = new StringBuilder();

            if (multiCorrMethodName.length() > 0) {
                message.append("Significance level of p value cutoffs for SKAT p-values for the overall error rate ").append(options.pValueThreshold).append(multiCorrMethodName + ":\n");
            } else {
                message.append("Significance level of a fixed p value cutoff for SKAT p-values ").append(options.pValueThreshold).append(" : ");
            }
            double[] thrholds = new double[4];
            for (int i = 0; i < genePVList.length; i++) {
                message.append(" ");
                if (options.multipleTestingMethod == null || options.multipleTestingMethod.equals("no")) {
                    thrholds[i] = options.pValueThreshold;
                } else if (options.multipleTestingMethod.equals("benfdr")) {
                    thrholds[i] = MultipleTestingMethod.benjaminiHochbergFDR(options.pValueThreshold, genePVList[i]);
                } else if (options.multipleTestingMethod.equals("bonhol")) {
                    thrholds[i] = MultipleTestingMethod.bonferroniHolmFWE(options.pValueThreshold, genePVList[i]);
                } else if (options.multipleTestingMethod.equals("bonf")) {
                    thrholds[i] = options.pValueThreshold / genePVList[i].size();
                }
                message.append(nameList.get(i));
                message.append(": ");
                message.append(thrholds[i]).append("; ");
            }
            LOG.info(message.substring(0, message.length() - 1));

            pvPainter.drawMultipleQQPlot(Arrays.asList(genePVList), nameList, null, plotFile2.getCanonicalPath(), 1E-10);
            String info = "The QQ plot saved in " + plotFile2.getCanonicalPath();
            LOG.info(info);
            showPlots(new File[]{plotFile2});

        }

    }

//--------------------------------
    public static TwoTuple<double[][], HistogramPainter> printMAFBinSummary(FloatArrayList mafSampleList) throws Exception {
        double[][] thresholds = {{0, 0.01}, {0.01, 0.02}, {0.02, 0.03}, {0.03, 0.04}, {0.04, 0.05}, {0.05, 0.06}, {0.06, 0.07}, {0.07, 0.08},
        {0.08, 0.09}, {0.09, 0.1}, {0.1, 0.11}, {0.11, 0.12}, {0.12, 0.13}, {0.13, 0.14}, {0.14, 0.15}, {0.15, 0.16}, {0.16, 0.17},
        {0.17, 0.18}, {0.18, 0.19}, {0.19, 0.2}, {0.2, 0.21}, {0.21, 0.22}, {0.22, 0.23}, {0.23, 0.24}, {0.24, 0.25}, {0.25, 0.26},
        {0.26, 0.27}, {0.27, 0.28}, {0.28, 0.29}, {0.29, 0.3}, {0.3, 0.31}, {0.31, 0.32}, {0.32, 0.33}, {0.33, 0.34}, {0.34, 0.35},
        {0.35, 0.36}, {0.36, 0.37}, {0.37, 0.38}, {0.38, 0.39}, {0.39, 0.4}, {0.4, 0.41}, {0.41, 0.42}, {0.42, 0.43}, {0.43, 0.44},
        {0.44, 0.45}, {0.45, 0.46}, {0.46, 0.47}, {0.47, 0.48}, {0.48, 0.49}, {0.49, 0.50001}};
        HistogramPainter pvPainter = new HistogramPainter(800, 600);
        if (options.toMAFPlotSample) {
            final File plotFile = new File(options.outputFileName + ".maf.sample.png");
            pvPainter.drawColorfulHistogramPlot(mafSampleList, thresholds, null, "MAF in local sample", plotFile.getCanonicalPath());

            String info = "The Histogram plot of MAF is saved in " + plotFile.getCanonicalPath();
            LOG.info(info);
            showPlots(new File[]{plotFile});
        }
        return TupleUtil.tuple(thresholds, pvPainter);
    }

//--------------------------------
    public static void printMAFDBHardFiltrationSummary(AnnotationSummarySet[] varaintDBHardFilterFiles5) throws Exception {
        if (varaintDBHardFilterFiles5 != null) {
            for (int i = 0; i < varaintDBHardFilterFiles5.length; i++) {
                varaintDBHardFilterFiles5[i].getBr().close();
                String info = varaintDBHardFilterFiles5[i].getLeftNum() + " variant(s) are retained after hard filtering in database " + varaintDBHardFilterFiles5[i].getName() + ".";//+ ", which contains " + varaintDBHardFilterFiles5[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                varaintDBHardFilterFiles5[i] = null;
            }
        }
    }

//-----------------------------
    public static AnnotationSummarySet[] printMAFDBSoftFiltrationSummary(AnnotationSummarySet[] varaintDBFilterFiles6) throws Exception {
        if (varaintDBFilterFiles6 != null) {
            for (int i = 0; i < varaintDBFilterFiles6.length; i++) {
                if (varaintDBFilterFiles6[i].getBr() != null) {
                    varaintDBFilterFiles6[i].getBr().close();
                }
                String info = varaintDBFilterFiles6[i].getLeftNum() + " variant(s) exist in " + varaintDBFilterFiles6[i].getName() + ".";// ", which contains " + varaintDBFilterFiles6[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                varaintDBFilterFiles6[i] = null;
            }
        }
        return varaintDBFilterFiles6;
    }

//-----------------------------
    public static void printMAFLocalHardFiltrationSummary(AnnotationSummarySet[] assLocalHardFilterFile5) throws Exception {
        if (assLocalHardFilterFile5 != null) {
            for (int i = 0; i < assLocalHardFilterFile5.length; i++) {
                assLocalHardFilterFile5[i].getBr().close();
                String info = assLocalHardFilterFile5[i].getLeftNum() + " variant(s) are retained after hard filtering in database " + assLocalHardFilterFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterFile5[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalHardFilterFile5[i] = null;
            }
        }
    }

//----------------------------
    public static void printMAFLocalSoftFiltrationSummary(AnnotationSummarySet[] assLocalFilterFile6) throws Exception {
        if (assLocalFilterFile6 != null) {
            for (int i = 0; i < assLocalFilterFile6.length; i++) {
                assLocalFilterFile6[i].getBr().close();
                String info = assLocalFilterFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterFile6[i].getName() + ".";//+ ", which contains " + assLocalFilterFile6[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalFilterFile6[i] = null;
            }
        }
    }

//-----------------------------
    public static void printMAFLocalVCFHardFiltrationSummary(AnnotationSummarySet[] assLocalHardFilterVCFFile5) throws Exception {
        if (assLocalHardFilterVCFFile5 != null) {
            for (int i = 0; i < assLocalHardFilterVCFFile5.length; i++) {
                assLocalHardFilterVCFFile5[i].getBr().close();
                String info = assLocalHardFilterVCFFile5[i].getLeftNum() + " variant(s) are retained after hard filtering in database " + assLocalHardFilterVCFFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterVCFFile5[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalHardFilterVCFFile5[i] = null;
            }
        }
    }

    //-----------------------------
    public static void printMAFLocalVCFSoftFiltrationSummary(AnnotationSummarySet[] assLocalFilterVCFFile6) throws Exception {
        if (assLocalFilterVCFFile6 != null) {
            for (int i = 0; i < assLocalFilterVCFFile6.length; i++) {
                assLocalFilterVCFFile6[i].getBr().close();
                String info = assLocalFilterVCFFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterVCFFile6[i].getName() + ".";// + ", which contains " + assLocalFilterVCFFile6[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalFilterVCFFile6[i] = null;
            }
        }
    }

//----------------------------
    public static void printMAFLocalNoGtyVCFHardFiltrationSummary(AnnotationSummarySet[] assLocalHardFilterNoGtyVCFFile5) throws Exception {
        if (assLocalHardFilterNoGtyVCFFile5 != null) {
            for (int i = 0; i < assLocalHardFilterNoGtyVCFFile5.length; i++) {
                assLocalHardFilterNoGtyVCFFile5[i].getBr().close();
                String info = assLocalHardFilterNoGtyVCFFile5[i].getLeftNum() + " variant(s) are retained after hard filtering in database " + assLocalHardFilterNoGtyVCFFile5[i].getName() + ".";//+ ", which contains " + assLocalHardFilterNoGtyVCFFile5[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalHardFilterNoGtyVCFFile5[i] = null;
            }
        }
    }

//-----------------------------
    public static void printMAFLocalNoGtyVCFSoftFiltrationSummary(AnnotationSummarySet[] assLocalFilterNoGtyVCFFile6) throws Exception {
        if (assLocalFilterNoGtyVCFFile6 != null) {
            for (int i = 0; i < assLocalFilterNoGtyVCFFile6.length; i++) {
                assLocalFilterNoGtyVCFFile6[i].getBr().close();
                String info = assLocalFilterNoGtyVCFFile6[i].getLeftNum() + " variant(s) exist in " + assLocalFilterNoGtyVCFFile6[i].getName() + ".";//+ ", which contains " + assLocalFilterNoGtyVCFFile6[i].getTotalNum() + " effective variants.";
                LOG.info(info);
                assLocalFilterNoGtyVCFFile6[i] = null;
            }
        }
    }

//------------------------------
    public static Genome printMAFRangeFiltrationSummary(AnnotationSummarySet[] varaintDBFilterFiles6, Genome uniqueGenome,
            double[][] thresholds, AnnotationSummarySet assFBAFEM, AnnotationSummarySet assFBAFIM, FloatArrayList mafRefList, HistogramPainter pvPainter) throws Exception {
        if (varaintDBFilterFiles6 != null || options.localFilterFileNames != null || options.localFilterVCFFileNames != null) {
            if (options.isAlleleFreqExcMode) {
                uniqueGenome.setVarNum(assFBAFEM.getAnnotNum());
                String info = assFBAFEM.getAnnotNum() + " variant(s) with minor allele frequency [" + 0 + ", " + (options.minAlleleFreqExc > 1 ? 1 : options.minAlleleFreqExc) + ") in the reference datasets above are retained!";
                LOG.info(info);
            } else {
                uniqueGenome.setVarNum(assFBAFIM.getAnnotNum());
                String info = assFBAFIM.getAnnotNum() + " variant(s) with minor allele frequency [" + options.minAlleleFreqInc + ", " + (options.maxAlleleFreqInc > 1 ? 1 : options.maxAlleleFreqInc) + "] in the reference datasets above are retained!";
                LOG.info(info);
            }
            if (options.toMAFPlotRef) {
                final File plotFile = new File(options.outputFileName + ".maf.ref.png");
                pvPainter.drawColorfulHistogramPlot(mafRefList, thresholds, null, "MAF in reference DB", plotFile.getCanonicalPath());
                String info = "The Histogram plot of MAF is saved in " + plotFile.getCanonicalPath();
                LOG.info(info);
                showPlots(new File[]{plotFile});
            }
        }
        return uniqueGenome;
    }

    //chen-------------------------------------
    public static void printGeneRangeFiltrationSummary(Genome uniqueGenome, AnnotationSummarySet assGIS17d3, AnnotationSummarySet assGOS17d4) {
        if (options.geneDBLabels != null) {
            if (!options.inGeneSet.isEmpty()) {
                StringBuilder info = new StringBuilder();
                info.append(assGIS17d3.getAnnotNum()).append(" variant(s) are retained after filtering those outside specified genes!");
                LOG.info(info);
                uniqueGenome.setVarNum(assGIS17d3.getAnnotNum());
            }

            // only keep genes in outGeneSet
            if (!options.outGeneSet.isEmpty()) {
                StringBuilder info = new StringBuilder();
                info.append(assGOS17d4.getAnnotNum()).append(" variant(s) are retained after filtering those inside specified genes!");
                LOG.info(info);
                uniqueGenome.setVarNum(assGOS17d4.getAnnotNum());
            }
        }
    }

    public static void printVarFuncPredicFiltrationSummary(FiltrationSummarySet dbNSFPAnnot8, FiltrationSummarySet dbNSFPPred9, FiltrationSummarySet dbNoncodePred9d1, AnnotationSummarySet dbNSFPAnnot9) {
        if (dbNSFPAnnot8 != null) {
            String info = dbNSFPAnnot8.toString();
            if (!info.isEmpty()) {
                LOG.info(info);
            }
        }

        if (dbNSFPPred9 != null) {
            LOG.info(dbNSFPPred9.toString(0, 3, " "));
            String info = dbNSFPPred9.toString(3, 4, "");
            if (!info.isEmpty()) {
                LOG.info(info);
            }
        }

        if (dbNoncodePred9d1 != null) {
            LOG.info(dbNoncodePred9d1.toString(0, 2, " "));
            String info = dbNoncodePred9d1.toString(2, 3, "");
            if (!info.isEmpty()) {
                LOG.info(info);
            }
        }
        if (dbNSFPAnnot9 != null) {
            String info = dbNSFPAnnot9.getAnnotNum() + " variants out of " + dbNSFPAnnot9.getTotalNum() + " are assigned RegBase scores.";

            if (!info.isEmpty()) {
                LOG.info(info);
            }
        }

    }

    public static void printVarLDPruningFiltrationSummary(AnnotationSummarySet ldPruningASS) {
        if (options.ldPruning) {
            String info = ldPruningASS.getLeftNum() + " variant(s) are retained after LD pruning with window size " + options.ldPrunWindowSize + " bp and r-square " + options.ldPrunR2 + ".";
            LOG.info(info);
        }
    }

    public static void printGeneVarCountFiltrationSummary(AnnotationSummarySet assGVF10, Genome uniqueGenome) {
        /* if (options.geneMaxVarPerPerson > 0 && options.geneMinVarFilter > 0) {
            StringBuilder info = new StringBuilder();
            info.append(assGVF10.getLeftNum()).append(" variant(s) are retained after filtered by genes with <= ").append(options.geneMinVarFilter).append(" and >=").append(options.geneMaxVarPerPerson).append(" variants in the cohort!");
            LOG.info(info);
            uniqueGenome.setVarNum(assGVF10.getLeftNum());
        } else 
            if (options.geneMaxVarPerPerson > 0) {
            //This function has been updated.
//            StringBuilder info = new StringBuilder();
//            info.append(assGVF10.getLeftNum()).append(" variant(s) are retained after filtered by genes with >= ").append(options.geneMaxVarPerPerson).append(" variants  in the cohort!");
//            LOG.info(info);
//            uniqueGenome.setVarNum(assGVF10.getLeftNum());
        } else 
         */
        if (options.geneMinVarFilter > 0) {
            StringBuilder info = new StringBuilder();
            info.append(assGVF10.getLeftNum()).append(" variant(s) are retained after filtered by genes with <= ").append(options.geneMinVarFilter).append(" variants in the cohort!");
            LOG.info(info);
            uniqueGenome.setVarNum(assGVF10.getLeftNum());
        }
    }

    public static void printVarPPIGeneSetSummary(Genome uniqueGenome, AnnotationSummarySet assG11, AnnotationSummarySet assV12, AnnotationSummarySet assPPIG13, AnnotationSummarySet assPPIV14, AnnotationSummarySet assPWG15,
            AnnotationSummarySet assPWV16, Map<String, GeneSet> mappedPathes) {
        if (options.candidateGeneSet != null && !options.candidateGeneSet.isEmpty()) {
            if (uniqueGenome.getGeneNum() > 0) {
                String strInfo = assG11.getName() + ": " + assG11.getAnnotNum() + " mRNAs belong to the candidate gene set.";
                LOG.info(strInfo);
            } else {
                String strInfo = assV12.getName() + ": " + assV12.getAnnotNum() + " variants are within candidate gene set.";
                LOG.info(strInfo);
            }
            if (options.ppiDB != null) {
                if (uniqueGenome.getGeneNum() > 0) {
                    String strInfo = assPPIG13.getName() + ": " + assPPIG13.getAnnotNum() + " mRNAs belong to the candidate gene set.";
                    LOG.info(strInfo);
                } else {
                    LOG.info(assPPIV14.getAnnotNum() + " sequence variant(s) are highlighted by PPI information!");
                }
            }

            if (options.genesetdb != null) {
                if (mappedPathes != null) {
                    if (uniqueGenome.getGeneNum() > 0) {
                        LOG.info(assPWG15.getName() + ": " + assPWG15.getAnnotNum() + " mRNAs are involved into the related GeneSets.");
                    } else {
                        LOG.info(assPWV16.getAnnotNum() + " sequence variant(s) are highlighted by GeneSet information!");
                    }
                }
            }
        }
    }

    public static void printIBSFiltrationSummary(Genome uniqueGenome, AnnotationSummarySet assIBS17d1, AnnotationSummarySet assHRC17d2) {
        if (options.ibsCheckCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            uniqueGenome.setVarNum(assIBS17d1.getAnnotNum());
            LOG.info(assIBS17d1.getAnnotNum() + " variant(s) are retained after filtered by IBS filtering!");
            if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                LOG.info("0 sequence variant(s) are retained finally!");
            }
        }

        if (options.homozygousRegionCase >= 0 && options.inputFormat.endsWith("--vcf-file")) {
            uniqueGenome.setVarNum(assHRC17d2.getAnnotNum());
            LOG.info(assHRC17d2.getAnnotNum() + " variant(s) are retained after filtered by Homozygosity filtering!");
            if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                LOG.info("0 sequence variant(s) are retained finally!");
            }
        }
    }

    public static void printIBDFiltrationSummary(AnnotationSummarySet assIBD17d5) {
        if (options.ibdFileName != null) {
            LOG.info(assIBD17d5.getLeftNum() + " variant(s) are retained after filtered by IBD Region filtering!");
        }
    }

    public static void printScSNVSummary(AnnotationSummarySet dbScSNV18) throws Exception {
        if (dbScSNV18 != null) {
            dbScSNV18.getBr().close();
            String info = dbScSNV18.getLeftNum() + " variant(s) exist in " + dbScSNV18.getName() + ".";//", which contains " + dbScSNV18.getTotalNum() + " effective variants.";
            LOG.info(info);
            dbScSNV18 = null;
        }
    }

    public static void printPextSNVSummary(AnnotationSummarySet dbScSNV, double cutOff) throws Exception {
        if (dbScSNV != null) {
            if (cutOff > 0) {
                String info = dbScSNV.getLeftNum() + " variant(s) are retained after removing variants with expression less than "
                        + cutOff + " in specified tissues or cell-types in pext dataset.";
                LOG.info(info);
            }

        }
    }

    public static void printCustomizedVarScoreSummary(AnnotationSummarySet dbScSNV) throws Exception {
        if (dbScSNV != null) {
            String info = dbScSNV.getLeftNum() + " variant(s) are assigned the customized score";
            LOG.info(info);

        }
    }

    public static void printGeneDoubleHitFiltrationTriosOutput(FiltrationSummarySet doubleHitGeneModelFilter19, List<String[]> hitDisCountsTriosGenes, Map<String, Double> geneLengths, List<String[]> hitDisCounTriosReads,
            Map<String, double[]> allDoubleHitGeneScoresMap, Set<String> caseDoubleHitTriosGenes) throws Exception {
        if (doubleHitGeneModelFilter19 != null) {
            int hitGenenNum = hitDisCountsTriosGenes.size();
            for (int i = 2; i < hitGenenNum; i++) {
                String[] row = hitDisCountsTriosGenes.get(i);
                Double lens = geneLengths.get(row[0]);
                if (lens == null) {
                    row[2] = "0";
                    hitDisCountsTriosGenes.get(i)[2] = row[2];
                    hitDisCounTriosReads.get(i)[2] = row[2];
                } else {
                    row[2] = String.valueOf(lens);
                    hitDisCountsTriosGenes.get(i)[2] = row[2];
                    hitDisCounTriosReads.get(i)[2] = row[2];
                }
                double[] scores = allDoubleHitGeneScoresMap.get(row[0]);

                if (scores == null) {
                    row[1] = ".";
                    hitDisCountsTriosGenes.get(i)[1] = row[1];
                    hitDisCounTriosReads.get(i)[1] = row[1];
                } else {
                    row[1] = String.valueOf(scores[1]);
                    hitDisCountsTriosGenes.get(i)[1] = row[1];
                    hitDisCounTriosReads.get(i)[1] = row[1];
                }
            }

            StringBuilder info = new StringBuilder();
            String info1 = doubleHitGeneModelFilter19.toString();
            if (info1.isEmpty()) {
                info.append(info1).append('\n');
            }

            String outFileName = options.outputFileName + ".doublehit.gene.trios.flt";

            List<List<String[]>> arrys = new ArrayList<List<String[]>>();

            arrys.add(hitDisCountsTriosGenes);
            arrys.add(hitDisCounTriosReads);

            printGeneDoubleHitFiltrationSummary(outFileName, info, arrys);
            printGeneDoubleHitCaseFiltrationSummary(caseDoubleHitTriosGenes, info);
        }
    }

    private static void printGeneDoubleHitFiltrationSummary(String outFileName, StringBuilder info, List<List<String[]>> arrys) throws Exception {
        if (options.excelOut) {
            List<String> sheetLabels = new ArrayList<String>();
            sheetLabels.add("counts");
            sheetLabels.add("genotypes");

            File savedFile = new File(outFileName + ".xlsx");
            LocalExcelFile.writeMultArray2XLSXFile(savedFile.getCanonicalPath(), arrys, sheetLabels, true, 0);
            info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile.getCanonicalPath()).append(".");
        } else {
            File savedFile1 = new File(outFileName + ".count.txt");
            LocalFile.writeData(savedFile1.getCanonicalPath(), arrys.get(0), "\t", false);
            File savedFile2 = new File(outFileName + ".gty.txt");
            LocalFile.writeData(savedFile2.getCanonicalPath(), arrys.get(1), "\t", false);
            info.append("All POSSIBLE double-hit genes are saved in ").append(savedFile1.getCanonicalPath()).append(" and ").append(savedFile2.getCanonicalPath()).append(".");
        }

        info.append("\nThe double-hit genes:\n");
    }

    private static void printGeneDoubleHitCaseFiltrationSummary(Set<String> caseDoubleHitTriosGenes, StringBuilder info) {
        if (!caseDoubleHitTriosGenes.isEmpty()) {
            info.append("in cases: ").append(caseDoubleHitTriosGenes.size()).append("\n").append(caseDoubleHitTriosGenes.toString()).append("\n");
        }
        LOG.info(info);
    }

    public static void printGeneDoubleHitPhasedGtyFiltrationOut(FiltrationSummarySet doubleHitGeneModelFilter19d1, List<String[]> doubleHitGenePhasedGenes, List<String[]> doubleHitGenePhasedReads, Set<String> caseDoubleHitPhasedGenes) throws Exception {

        if (doubleHitGeneModelFilter19d1 != null) {
            /*
                 //assign gene length
                 int hitGenenNum = doubleHitGenePhasedGenes.size();
                 for (int i = 2; i < hitGenenNum; i++) {
                 String[] row = doubleHitGenePhasedGenes.get(i);
                 Double lens = geneLengths.get(row[0]);
                 if (lens == null) {
                 row[2] = "0";
                 doubleHitGenePhasedGenes.get(i)[2] = row[2];
                 doubleHitGenePhasedReads.get(i)[2] = row[2];
                 } else {
                 row[2] = String.valueOf(lens);
                 doubleHitGenePhasedGenes.get(i)[2] = row[2];
                 doubleHitGenePhasedReads.get(i)[2] = row[2];
                 }
                 }
             */
            StringBuilder info = new StringBuilder();
            String info1 = doubleHitGeneModelFilter19d1.toString();
            if (info1.isEmpty()) {
                info.append(info1).append('\n');
            }
            String outFileName = options.outputFileName + ".doublehit.gene.phased.flt";

            List<List<String[]>> arrys = new ArrayList<List<String[]>>();

            arrys.add(doubleHitGenePhasedGenes);
            arrys.add(doubleHitGenePhasedReads);

            printGeneDoubleHitFiltrationSummary(outFileName, info, arrys);
            printGeneDoubleHitPhasedGtyFiltrationSummary(caseDoubleHitPhasedGenes, info);
        }

    }

    private static void printGeneDoubleHitPhasedGtyFiltrationSummary(Set<String> caseDoubleHitPhasedGenes, StringBuilder info) {
        info.append("\nThe double-hit genes:\n");
        if (!caseDoubleHitPhasedGenes.isEmpty()) {
            info.append("in cases: ").append(caseDoubleHitPhasedGenes.size()).append("\n").append(caseDoubleHitPhasedGenes.toString()).append("\n");
        }
        LOG.info(info);
    }

    public static void annoteGeneSummary(Genome uniqueGenome, AnnotationSummarySet assGene20, AnnotationSummarySet assVariant20, AnnotationSummarySet assOmimGene21, AnnotationSummarySet assOmimVar21, AnnotationSummarySet assTissueSpecGene21,
            AnnotationSummarySet assTissueSpecVar21, AnnotationSummarySet assSDA22, AnnotationSummarySet assSDF22) {
        if (options.needAnnotateGene) {
            if (uniqueGenome.getGeneNum() > 0) {
                String strInfo = assGene20.getName() + ": " + assGene20.getAnnotNum() + " variants are annotated out of " + assGene20.getTotalNum() + " variants.";
                //  LOG.info(strInfo);
            } else if (uniqueGenome.getVarNum() > 0) {
                String strInfo = assVariant20.getName() + ": " + assVariant20.getAnnotNum() + " variants are annotated out of " + assVariant20.getTotalNum() + " variants.";
                // LOG.info(strInfo);
            }
        }

        if (options.omimAnnotateGene) {
            if (uniqueGenome.getGeneNum() > 0) {
                String strInfo = assOmimGene21.getName() + ": " + assOmimGene21.getAnnotNum() + " variants are annotated out of " + assOmimGene21.getTotalNum() + " variants.";
                LOG.info(strInfo);
            } else if (uniqueGenome.getVarNum() > 0) {
                LOG.info(assOmimVar21.getAnnotNum() + " sequence variant(s) are highlighted by OMIM information!");
            }
        }

        if (options.tissueSpecAnnot) {
            if (uniqueGenome.getGeneNum() > 0) {
                String strInfo = assTissueSpecGene21.getName() + ": " + assTissueSpecGene21.getAnnotNum() + " variants are annotated out of " + assTissueSpecGene21.getTotalNum() + " variants.";
                LOG.info(strInfo);
            } else if (uniqueGenome.getVarNum() > 0) {
                LOG.info(assTissueSpecVar21.getAnnotNum() + " sequence variant(s) are highlighted by tissue specific expression data!");
            }
        }

        if (options.superdupAnnotate) {
            String info = assSDA22.getLeftNum() + " variant(s) are in super-duplicated regions registered in a data set genomicSuperDups table of UCSC";
            LOG.info(info);
        } else if (options.superdupFilter) {
            uniqueGenome.setVarNum(assSDF22.getLeftNum());
            LOG.info(assSDF22.getLeftNum() + " variant(s) are retained after filtering those in super-duplicated regions registered in a data set genomicSuperDups table of UCSC!");
        }
    }

    public static void annoteGenePhenoSummary(AnnotationSummarySet assDGV23, Genome uniqueGenome, AnnotationSummarySet assOLGF, AnnotationSummarySet assMousePheno, AnnotationSummarySet assZebra, AnnotationSummarySet assDDD) {
        if (options.dgvcnvAnnotate) {
            StringBuilder info = new StringBuilder();
            info.append('\n');
            LOG.info(info);
            LOG.info(assDGV23.getLeftNum() + " variant(s) are in large copy-number variation (CNV) regions registered in Database of Genomic Variants http://projects.tcag.ca/variation/.");
        }

        if (options.overlappedGeneFilter) {
            uniqueGenome.setVarNum(assOLGF.getLeftNum());
            String info = assOLGF.getLeftNum() + " variant(s) are retained after filtered by the unique variants on gene level.\n";
            LOG.info(info);
        }

        if (options.phenoMouse) {
            String info = assMousePheno.getAnnotNum() + " variants are annotated with mouse phenotypes.";
            LOG.info(info);
        }

        if (options.zebraFish) {
            String info = assZebra.getAnnotNum() + " variants are annotated with zebrafish phenotypes.";
            LOG.info(info);
        }
        if (options.dddPhenotypes) {
            String info = assDDD.getAnnotNum() + " variants are annotated with diseases documented in  Deciphering Developmental Disorders (DDD) study.";
            LOG.info(info);
        }
    }

    public static void printPubMedSearchSummary(Genome uniqueGenome, AnnotationSummarySet pubmedSearch24_Gene, AnnotationSummarySet pubmedSearch24_Var) {
        if (options.searchList != null && !options.searchList.isEmpty()) {
            if (uniqueGenome.getGeneNum() > 0) {
                if (options.pubmedMiningIdeo) {

                }
                if (options.pubmedMiningGene) {
                    LOG.info(pubmedSearch24_Gene.getAnnotNum() + " genes are highlighted by Pubmed information!");
                }
            } else if (uniqueGenome.getVarNum() > 0) {
                if (options.pubmedMiningIdeo) {

                }
                if (options.pubmedMiningGene) {
                    LOG.info(pubmedSearch24_Var.getAnnotNum() + " sequence variants' genes are highlighted by Pubmed information!");
                }
            }
        }
    }

    //Yuanyy part: 4075-4403
    public static void outputSKAT(SKAT skat) {
        if (options.skatGene) {
            skat.closeRCluster();
            if (options.excelOut) {
                String geneSumOutFile = options.outputFileName + ".skat.gene.xlsx";
                skat.saveGeneResult2Xlsx(geneSumOutFile);
            } else {
                String geneSumOutFile = options.outputFileName + ".skat.gene.txt";
                skat.saveGeneResult2Text(geneSumOutFile);
            }
            skat.closeRServe();
        }
        if (options.skatGeneset) {
            skat.closeRCluster();
            if (options.excelOut) {
                String geneSumOutFile = options.outputFileName + ".skat.geneset.xlsx";
                skat.saveGenesetResult2Xlsx(geneSumOutFile);
            } else {
                String geneSumOutFile = options.outputFileName + ".skat.geneset.txt";
                skat.saveGenesetResult2Text(geneSumOutFile);
            }
            skat.closeRServe();
        }

    }

    public static void runRVTests(File rvTestGroupTestFile, Map<String, String[]> geneNamesMap, Map<String, String[]> geneAlleleCCMap) throws Exception {
        if (options.rvtestGene || options.rvtestGeneset || options.rvtestVar) {
            RVTest rvtest = null;
            if (options.needNewVCFForRVTest) {
                rvtest = new RVTest(null, options.outputFileName);
            } else {
                rvtest = new RVTest(options.inputFileName, options.outputFileName);
            }

            rvtest.setPheno(options.pheItem);
            rvtest.setCov(options.covItems);
            rvtest.setCommand(options.rvtestCommand);
            rvtest.runTabix();
            // rvtest.runBGzip();
            //LocalFileFunc.tabixFile(options.outputFileName + ".flt.vcf.gz");
            boolean keepRVTRstTmp = false;
            if (options.rvtestVar) {
                rvtest.runGeneAssoc(options.pedFile, options.threadNum, "variant");

                ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut, options.genePCut,
                        options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, geneAlleleCCMap);

                titleList.remove(0);
                if (options.toQQPlot) {
                    File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRSingle(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.var.qq.png");
                    showPlots(new File[]{plotFile});
                }
                rvtest.releaseHmpRSingle();
            }

            if (options.rvtestGene) {
                rvtest.runGeneAssoc(options.pedFile, options.threadNum, "gene");
                //System.out.println("RVTest Done");
                ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut, options.genePCut,
                        options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, geneAlleleCCMap);

                //  ArrayList<String> titleList = rvtest.collectResultGene(!options.rvtestRemoveSet, true, options.excelOut);
                // System.out.println("RVTest Collected");
                titleList.remove(0);
                if (options.toQQPlot) {
                    File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRGroup(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.gene.qq.png");
                    showPlots(new File[]{plotFile});
                }
                rvtest.releaseHmpRGroup();
            }

            if (options.rvtestGeneset) {
                rvtest.runGenesetAssoc(options.pedFile, rvTestGroupTestFile);
                //rvtest.collectResultGeneset(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut);
                ArrayList<String> titleList = rvtest.collectResultGeneset(!options.rvtestRemoveSet, keepRVTRstTmp, options.excelOut);
                titleList.remove(0);
                if (options.toQQPlot) {
                    File plotFile = rvtest.drwaQQPlot(rvtest.getHmpRGroup(), titleList, options.multipleTestingMethod, options.pValueThreshold, options.outputFileName + ".rvtest.geneset.qq.png");
                    showPlots(new File[]{plotFile});
                }
                rvtest.releaseHmpRGroup();
            }
        }
    }

    public static void isSimpleVCFOutMergeHandler(Genome refhapGenome, BlockCompressedOutputStream mergedFileStream, int[] coutVar, int[] intsIndiv) throws Exception {
        String info;
        if (mergedFileStream != null) {
            mergedFileStream.close();
        }
        if (options.mergeGtyDb != null) {
            if (refhapGenome != null) {
                refhapGenome.removeTempFileFromDisk();
            }
            if (options.outGZ) {
                File f1 = new File(options.outputFileName + ".merged.fam.gz");
                File f2 = new File(options.outputFileName + ".merged.fam");
                LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                f1.delete();
            }
        }
        if (options.mergeGtyDb != null && options.isSimpleVCFOut) {
            info = "Genotype of " + coutVar[0] + " sequence variant(s) and " + intsIndiv[0] + " individuals are saved in "
                    + options.outputFileName + ".merged.vcf.gz" + " with simple VCF format and  " + options.outputFileName + ".merged.fam.";
            LOG.info(info);
        }

    }

    public static void isPlinkBedOutHandler(BufferedWriter bwMapBed, BufferedOutputStream fileBedStream, Genome refhapGenome, BufferedWriter mergedBwMap,
            BufferedOutputStream mergedFileStream, int[] savedBinnaryBedVar, List<Individual> subjectList, int[] coutVar, int[] intsIndiv) throws Exception {
        if (options.isPlinkBedOut) {
            String info = null;
            if (bwMapBed != null) {
                bwMapBed.close();
            }
            if (fileBedStream != null) {

                fileBedStream.close();
                //rafBed.close();
            }

            if (options.mergeGtyDb != null) {
                if (refhapGenome != null) {
                    refhapGenome.removeTempFileFromDisk();
                }
                mergedBwMap.close();
                mergedFileStream.close();
            }

            //force to convert the gz to txt file
            if (options.outGZ) {
                File f1 = new File(options.outputFileName + ".fam.gz");
                File f2 = new File(options.outputFileName + ".fam");
                LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                f1.delete();
                f1 = new File(options.outputFileName + ".bed.gz");
                f2 = new File(options.outputFileName + ".bed");
                LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                f1.delete();
                f1 = new File(options.outputFileName + ".bim.gz");
                f2 = new File(options.outputFileName + ".bim");
                LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                f1.delete();

                if (options.mergeGtyDb != null) {
                    f1 = new File(options.outputFileName + ".merged.fam.gz");
                    f2 = new File(options.outputFileName + ".merged.fam");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();
                    f1 = new File(options.outputFileName + ".merged.bed.gz");
                    f2 = new File(options.outputFileName + ".merged.bed");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();
                    f1 = new File(options.outputFileName + ".merged.bim.gz");
                    f2 = new File(options.outputFileName + ".merged.bim");
                    LocalFileFunc.gunzipFile(f1.getCanonicalPath(), f2.getCanonicalPath());
                    f1.delete();
                }

            }
            info = "Genotype of " + savedBinnaryBedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved in "
                    + options.outputFileName + ".fam " + options.outputFileName + ".bim " + options.outputFileName + ".bed " + " with Plink binary genotype format.";
            LOG.info(info);

            if (options.mergeGtyDb != null) {
                info = "Genotype of " + coutVar[0] + " sequence variant(s) and " + intsIndiv[0] + " individuals are saved in "
                        + options.outputFileName + ".merged.fam" + " " + options.outputFileName + ".merged.bim" + " " + options.outputFileName + ".merged.bed" + " " + " with Plink binary genotype format.";
                LOG.info(info);
            }

        }
    }

    public static void isGenVarGFOHandler(BufferedWriter bwGeneVarGroupFile) throws Exception {
        if (options.isGeneVarGroupFileOut) {
            if (bwGeneVarGroupFile != null) {
                bwGeneVarGroupFile.close();
            }
            String info;
            if (options.outGZ) {
                info = "A group file for gene-based association analysis is produced, " + options.outputFileName + ".gene.epacts.grp.gz.";
            } else {
                info = "A group file for gene-based association analysis is produced, " + options.outputFileName + ".gene.epacts.grp.";
            }
            LOG.info(info);
        }
    }

    public static void calcLDHandler(BufferedWriter bwLD, Genome uniqueGenome) throws Exception {
        if (options.calcLD) {
            bwLD.close();
            String info = "The pair-wise Pearson genotypic correlation of biallelic variants are save in ";
            if (uniqueGenome.isIsPhasedGty()) {
                info = "The pair-wise linkage disequilibrium coefficients, r, of biallelic variants are save in ";
            }
            File f = null;
            if (options.outGZ) {
                f = new File(options.outputFileName + ".ld.gz");
            } else {
                f = new File(options.outputFileName + ".ld");
            }
            info += f.getCanonicalPath() + ".";
            LOG.info(info);
        }
    }

    public static void isPlinkPedOutHandler(BufferedWriter bwMapPed, int[] savedPedVar, List<Individual> subjectList) throws Exception {
        if (options.isPlinkPedOut) {
            bwMapPed.close();
            //merge   files
            BufferedReader brPed = null;
            if (options.outGZ) {
                brPed = LocalFileFunc.getBufferedReader(options.outputFileName + ".ped.p.gz");
            } else {
                brPed = LocalFileFunc.getBufferedReader(options.outputFileName + ".ped.p");
            }

            File[] files = new File[STAND_CHROM_NAMES.length];
            BufferedReader[] brPedGty = new BufferedReader[STAND_CHROM_NAMES.length];
            for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                if (options.outGZ) {
                    files[i] = new File(options.outputFileName + ".ped." + i + ".gz");
                } else {
                    files[i] = new File(options.outputFileName + ".ped." + i);
                }
                if (!files[i].exists()) {
                    continue;
                }
                brPedGty[i] = LocalFileFunc.getBufferedReader(files[i].getCanonicalPath());
            }

            //BufferedWriter bwPed = LocalFileFunc.getBufferedWriter(options.outputFileName + ".ped", false);
            BufferedWriter bwPed = null;
            if (options.outGZ) {
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".ped" + ".gz"));
                bwPed = new BufferedWriter(new OutputStreamWriter(gzOut));
            } else {
                bwPed = LocalFileFunc.getBufferedWriter(options.outputFileName + ".ped", false);
            }

            String line;
            //assume the brPed and brPedGty have the same number of rows
            while ((line = brPed.readLine()) != null) {
                bwPed.write(line);
                for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                    if (brPedGty[i] == null) {
                        continue;
                    }
                    bwPed.write(brPedGty[i].readLine());
                }
                bwPed.write('\n');
            }
            brPed.close();
            bwPed.close();

            //file.delete();
            for (int i = 0; i < STAND_CHROM_NAMES.length; i++) {
                if (!files[i].exists()) {
                    continue;
                }
                brPedGty[i].close();
                files[i].deleteOnExit();
                //files[i].delete();
            }

            File filePedP;
            if (options.outGZ) {
                filePedP = new File(options.outputFileName + ".ped.p.gz");
            } else {
                filePedP = new File(options.outputFileName + ".ped.p");
            }
            filePedP.deleteOnExit();
            String info = null;
            if (options.outGZ) {
                info = "Genotype of " + savedPedVar[0] + " sequence variant(s) and " + subjectList.size()
                        + " individuals are saved \nin " + options.outputFileName + ".map.gz " + options.outputFileName + ".ped.gz  with Plink pedigree format.";
            } else {
                info = "Genotype of " + savedPedVar[0] + " sequence variant(s) and " + subjectList.size()
                        + " individuals are saved \nin " + options.outputFileName + ".map " + options.outputFileName + ".ped  with Plink pedigree format.";
            }
            LOG.info(info);
        }
    }

    public static void isBinaryGtyOutHandler(BufferedWriter bwMapKed, BufferedOutputStream filelKedStream, WritableByteChannel rafKed, int[] savedBinnaryKedVar, List<Individual> subjectList) throws Exception {
        if (options.isBinaryGtyOut) {
            if (bwMapKed != null) {
                bwMapKed.close();
            }

            if (filelKedStream != null) {
                filelKedStream.close();
                rafKed.close();
            }
            String info = null;
            if (options.outGZ) {
                info = "Genotype of " + savedBinnaryKedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved \nin "
                        + options.outputFileName + ".kam.gz " + options.outputFileName + ".kim.gz " + options.outputFileName + ".ked.gz " + " with KGGSseq binary genotype format.";
            } else {
                info = "Genotype of " + savedBinnaryKedVar[0] + " sequence variant(s) and " + subjectList.size() + " individuals are saved \nin "
                        + options.outputFileName + ".kam " + options.outputFileName + ".kim " + options.outputFileName + ".ked " + " with KGGSseq binary genotype format.";
            }

            LOG.info(info);
        }
    }

    public static File isVCFOutHandler(File vcfFilteredInFile, int writenVCFVarNum) throws Exception {
        if (options.isVCFOut) {
            /*
                if (!options.rvtestGene && !options.rvtestGeneset) {
                    RVTest rvtest = new RVTest(options.outputFileName);
                    rvtest.runBGzip(vcfFilteredInFile.getCanonicalPath());
                }
             */
            if (!options.outGZ) {
                String newName = LocalFileFunc.gunzipFile(vcfFilteredInFile.getCanonicalPath());
                vcfFilteredInFile = new File(newName);
            }
            LOG.info(writenVCFVarNum + " variants are saved in " + vcfFilteredInFile.getCanonicalPath() + " with VCF format.");
            //LocalFileFunc.bgzipFile(vcfFilteredInFile.getCanonicalPath());
            //Note: this VCF tabix function is subject to be fixed
            // LocalFileFunc.tabixVCFFile(vcfFilteredInFile.getCanonicalPath());
            //LOG.info("The index file " + vcfFilteredInFile.getCanonicalPath() + ".tbi is created.");
        }
        return vcfFilteredInFile;
    }

    public static File isSimpleVCFOutHandler(File simpleVcfFilteredInFile, int finalVarNum) throws Exception {
        if (options.isSimpleVCFOut) {
            /*
                if (!options.rvtestGene && !options.rvtestGeneset) {
                    RVTest rvtest = new RVTest(options.outputFileName);
                    rvtest.runBGzip(vcfFilteredInFile.getCanonicalPath());
                }
             */
            if (!options.outGZ) {
                String newName = LocalFileFunc.gunzipFile(simpleVcfFilteredInFile.getCanonicalPath());
                simpleVcfFilteredInFile = new File(newName);
            }
            //LocalFileFunc.bgzipFile(vcfFilteredInFile.getCanonicalPath());
            //Note: this VCF tabix function is subject to be fixed
            //LocalFileFunc.tabixVCFFile(simpleVcfFilteredInFile.getCanonicalPath());
            LOG.info("Finally, " + finalVarNum + " variants are saved in " + simpleVcfFilteredInFile.getCanonicalPath() + " with a simplified VCF format.");
        }
        return simpleVcfFilteredInFile;
    }

    public static void excelOutHandler(File finalFilteredInFile, int finalVarNum) throws Exception {
        if (options.excelOut) {
            File finalFilteredInFile1 = new File(options.outputFileName + ".flt.xlsx");
            //As the function of appending data into an existing file is very slow; So I just have convert a text file into an excel file
            LocalExcelFile.convertTextFile2XLSXFile(finalFilteredInFile.getCanonicalPath(), finalFilteredInFile1.getCanonicalPath(), true, 4);
            //Remove the text file to save storage space
            finalFilteredInFile.delete();
            LOG.info("Finally, " + finalVarNum + " variants are saved in " + finalFilteredInFile1.getCanonicalPath() + " with Excel format.\n");
        } else {
            LOG.info("Finally, " + finalVarNum + " variants are saved in " + finalFilteredInFile.getCanonicalPath() + " with flat text format.\n");
        }
    }

    public static ThreeTuple<String[], Map<String, double[]>, String[]> cancerDriverGeneMutationRateTestHandler(GeneAnnotator geneAnnotor, String[] fixedColNames, Map<String, double[]> geneMutationScores, List<String> scoreNames, Genome uniqueGenome, String[] indexLabels,
            Map<String, Map<String, Integer>> cosmicGeneMut, Map<String, String[]> geneNamesMap) throws Exception {
        String geneCoVarFilePath = options.PUBDB_FILE_MAP.get("cancer.mutsig");
        //geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.hm.txt";
        geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
        fixedColNames = new String[]{"Gene", "AvgCodingLen", "expr", "reptime", "hic", "constraint_score"};
        geneMutationScores = geneAnnotor.readGeneScore(geneCoVarFilePath, fixedColNames, scoreNames, 0);
        for (int i = 0; i < scoreNames.size(); i++) {
            if (scoreNames.get(i).equals("AvgCodingLen")) {
                scoreNames.set(i, "RegionLength");
            } else if (scoreNames.get(i).equals("expr")) {
                scoreNames.set(i, "CellLineExpression");
            } else if (scoreNames.get(i).equals("hic")) {
                scoreNames.set(i, "HiC");
            } else if (scoreNames.get(i).equals("reptime")) {
                scoreNames.set(i, "ReplicationTiming");
            } else if (scoreNames.get(i).equals("constraint_score")) {
                scoreNames.set(i, "ConstraintScore");
            }
        }

        boolean[] availScores = new boolean[4];
        Arrays.fill(availScores, false);

        int extraCol = 0;
        int accuCol = 0;
        if (options.cancerLabel != null) {
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneExp.txt.gz";
            Map<String, double[]> geneExpSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (geneExpSocre != null) {
                extraCol++;
                availScores[0] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneCNV.txt.gz";
            Map<String, double[]> cnvSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (cnvSocre != null) {
                extraCol++;
                availScores[1] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAATACGene.txt.gz";
            Map<String, double[]> tactSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (tactSocre != null) {
                extraCol++;
                availScores[2] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAMeth450Gene.txt.gz";
            Map<String, double[]> methSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (methSocre != null) {
                extraCol++;
                availScores[3] = true;
            }

            if (geneExpSocre != null) {
                scoreNames.add("TissueExpression");
            }
            if (cnvSocre != null) {
                scoreNames.add("CNV");
            }
            if (tactSocre != null) {
                scoreNames.add("ATACSeq");
            }
            if (methSocre != null) {
                scoreNames.add("Methylation");
            }

            double[] vals;
            double[] vals0;
            Map< String, double[]> geneMutationScoresTmp = new HashMap< String, double[]>();
            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                vals = new double[fixedColNames.length - 1 + extraCol];
                Arrays.fill(vals, Double.NaN);
                vals0 = item.getValue();
                System.arraycopy(vals0, 0, vals, 0, vals0.length);
                geneMutationScoresTmp.put(item.getKey(), vals);
            }
            geneMutationScores.clear();
            geneMutationScores.putAll(geneMutationScoresTmp);
            geneMutationScoresTmp.clear();

            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                accuCol = 0;
                vals0 = item.getValue();
                if (availScores[0]) {
                    vals = geneExpSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[1]) {
                    vals = cnvSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[2]) {
                    vals = tactSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[3]) {
                    vals = methSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
            }

            //assign min value for missing value genes          
            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                accuCol = 0;
                vals0 = item.getValue();
                if (availScores[0]) {
                    accuCol++;
                    if (Double.isNaN(vals0[fixedColNames.length - 1])) {
                        vals0[fixedColNames.length - 1] = 0;
                    }
                }

                if (availScores[1]) {
                    accuCol++;
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = 0;
                    }
                }
                if (availScores[2]) {
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = -2.0773416789013055;
                    }
                    accuCol++;
                }
                if (availScores[3]) {
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = 0;
                    }
                    accuCol++;
                }
            }

        }

        indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
        Map<String, double[]> geneMutRegPValueAllVar = new HashMap<String, double[]>();

        List<String[]> geneMutRateSheet = geneAnnotor.geneSomaticMutationRateTestFlexibleWeight(options.RHOST, options.RPORT, uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
                options.witerGeneCoding, geneMutRegPValueAllVar, options.independentGeneFeature.isEmpty(), options.refMutGeneFile, options.threadNum);

        geneMutRegPValueAllVar.clear();
        String outFileName = options.outputFileName + ".gene.mutationburden";
        geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
                options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
        if (geneMutRateSheet != null) {
            if (options.excelOut) {
                outFileName += ".xlsx";
                LocalExcelFile.writeArray2XLSXFile(outFileName, geneMutRateSheet, true, -1, 0);
            } else {
                outFileName += ".txt";
                org.cobi.util.text.LocalFile.writeData(outFileName, geneMutRateSheet, "\t", false);
            }
        }
        String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
        LOG.info(info);

        return TupleUtil.tuple(fixedColNames, geneMutationScores, indexLabels);
    }

    public static ThreeTuple<String[], Map<String, double[]>, String[]> cancerDriverRegionMutationRateTestHandler(GeneAnnotator geneAnnotor, String[] fixedColNames, Map<String, double[]> geneMutationScores, List<String> scoreNames, Genome uniqueGenome, String[] indexLabels,
            Map<String, Map<String, Integer>> cosmicGeneMut, Map<String, String[]> geneNamesMap) throws Exception {
        String geneCoVarFilePath = options.PUBDB_FILE_MAP.get("cancer.mutsig");
        //geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.hm.txt";
        geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
        fixedColNames = new String[]{"Gene", "AvgCodingLen", "expr", "reptime", "hic", "constraint_score"};
        geneMutationScores = geneAnnotor.readGeneScore(geneCoVarFilePath, fixedColNames, scoreNames, 0);
        for (int i = 0; i < scoreNames.size(); i++) {
            if (scoreNames.get(i).equals("AvgCodingLen")) {
                scoreNames.set(i, "RegionLength");
            } else if (scoreNames.get(i).equals("expr")) {
                scoreNames.set(i, "CellLineExpression");
            } else if (scoreNames.get(i).equals("hic")) {
                scoreNames.set(i, "HiC");
            } else if (scoreNames.get(i).equals("reptime")) {
                scoreNames.set(i, "ReplicationTiming");
            } else if (scoreNames.get(i).equals("constraint_score")) {
                scoreNames.set(i, "ConstraintScore");
            }

        }

        boolean[] availScores = new boolean[4];
        Arrays.fill(availScores, false);

        int extraCol = 0;
        int accuCol = 0;
        if (options.cancerLabel != null) {
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneExp.txt.gz";
            Map<String, double[]> geneExpSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (geneExpSocre != null) {
                extraCol++;
                availScores[0] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAGeneCNV.txt.gz";
            Map<String, double[]> cnvSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (cnvSocre != null) {
                extraCol++;
                availScores[1] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAATACGene.txt.gz";
            Map<String, double[]> tactSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (tactSocre != null) {
                extraCol++;
                availScores[2] = true;
            }
            geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "TCGAMeth450Gene.txt.gz";
            Map<String, double[]> methSocre = geneAnnotor.readGeneValues(geneCoVarFilePath, options.cancerLabel + "-01");
            if (methSocre != null) {
                extraCol++;
                availScores[3] = true;
            }

            if (geneExpSocre != null) {
                scoreNames.add("TissueExpression");
            }
            if (cnvSocre != null) {
                scoreNames.add("CNV");
            }
            if (tactSocre != null) {
                scoreNames.add("ATACSeq");
            }
            if (methSocre != null) {
                scoreNames.add("Methylation");
            }

            double[] vals;
            double[] vals0;
            Map< String, double[]> geneMutationScoresTmp = new HashMap< String, double[]>();
            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                vals = new double[fixedColNames.length - 1 + extraCol];
                Arrays.fill(vals, Double.NaN);
                vals0 = item.getValue();
                System.arraycopy(vals0, 0, vals, 0, vals0.length);
                geneMutationScoresTmp.put(item.getKey(), vals);
            }
            geneMutationScores.clear();
            geneMutationScores.putAll(geneMutationScoresTmp);
            geneMutationScoresTmp.clear();

            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                accuCol = 0;
                vals0 = item.getValue();
                if (availScores[0]) {
                    vals = geneExpSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[1]) {
                    vals = cnvSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[2]) {
                    vals = tactSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
                if (availScores[3]) {
                    vals = methSocre.get(item.getKey());
                    if (vals != null) {
                        vals0[fixedColNames.length - 1 + accuCol] = vals[0];
                        accuCol++;
                    }
                }
            }

            //assign min value for missing value genes          
            for (Map.Entry<String, double[]> item : geneMutationScores.entrySet()) {
                accuCol = 0;
                vals0 = item.getValue();
                if (availScores[0]) {
                    accuCol++;
                    if (Double.isNaN(vals0[fixedColNames.length - 1])) {
                        vals0[fixedColNames.length - 1] = 0;
                    }
                }

                if (availScores[1]) {
                    accuCol++;
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = 0;
                    }
                }
                if (availScores[2]) {
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = -2.0773416789013055;
                    }
                    accuCol++;
                }
                if (availScores[3]) {
                    if (Double.isNaN(vals0[fixedColNames.length - 1 + accuCol])) {
                        vals0[fixedColNames.length - 1 + accuCol] = 0;
                    }
                    accuCol++;
                }
            }

        }

        indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
        Map<String, double[]> geneMutRegPValueAllVar = new HashMap<String, double[]>();

        List<String[]> geneMutRateSheet = geneAnnotor.geneSomaticMutationRateTestFlexibleWeight(options.RHOST, options.RPORT, uniqueGenome, indexLabels, cosmicGeneMut, geneMutationScores, scoreNames, options.genePCut,
                options.witerGeneCoding, geneMutRegPValueAllVar, options.independentGeneFeature.isEmpty(), options.refMutGeneFile, options.threadNum);

        geneMutRegPValueAllVar.clear();
        String outFileName = options.outputFileName + ".gene.mutationburden";
        geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
                options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
        if (geneMutRateSheet != null) {
            if (options.excelOut) {
                outFileName += ".xlsx";
                LocalExcelFile.writeArray2XLSXFile(outFileName, geneMutRateSheet, true, -1, 0);
            } else {
                outFileName += ".txt";
                org.cobi.util.text.LocalFile.writeData(outFileName, geneMutRateSheet, "\t", false);
            }
        }
        String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
        LOG.info(info);

        return TupleUtil.tuple(fixedColNames, geneMutationScores, indexLabels);
    }

    public static void appendGeneCovar(String filePatvh, List<String> names, Map<String, double[]> geneCovMap) throws Exception {
//format gene cov1 cov2     
        BufferedReader br = LocalFileFunc.getBufferedReader(filePatvh);
        //ingore head ine
        String line = br.readLine();
        double[] row;
        String[] cells = line.split("\\s+");
        int size = cells.length - 1;
        for (int i = 1; i < cells.length; i++) {
            names.add(cells[i]);
        }
        double[] row1;
        double[] cellDouble = new double[size];
        String pStr;
        Map<String, double[]> geneCovMapTmp = new HashMap<String, double[]>(geneCovMap);
        geneCovMap.clear();
        while ((line = br.readLine()) != null) {
            //line = line.trim();
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t", -1);
            row1 = geneCovMapTmp.get(cells[0]);
            if (row1 == null) {
                continue;
            }
            row = new double[size + row1.length];
            System.arraycopy(row1, 0, row, 0, row1.length);
            Arrays.fill(cellDouble, Double.NaN);
            for (int i = 1; i < cells.length; i++) {
                row[row1.length + i - 1] = Double.valueOf(cells[i]);
            }
            geneCovMap.put(cells[0], row);
        }
        br.close();

    }

    public static void appendGeneCovarWithInterationTerm(String filePatvh, List<String> names, Map<String, String> synonymuseGeneSymbolMap,
            Map<String, double[]> geneCovMap, boolean needInteraction) throws Exception {
//format gene cov1 cov2     
        BufferedReader br = LocalFileFunc.getBufferedReader(filePatvh);
        //ingore head ine
        String line = br.readLine();
        double[] row;
        String[] cells = line.split("\\s+");
        int size = cells.length - 1;
        int orgScoreNum = names.size();
        int interactionNum = 0;
        if (needInteraction) {
            interactionNum = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        for (int i = 1; i < cells.length; i++) {
            names.add(cells[i]);
        }
        double[] row1;

        String pStr;
        boolean isEmptyCov = geneCovMap.isEmpty();
        String newSymbl;

        Map<String, double[]> geneCovMapTmp = new HashMap<String, double[]>(geneCovMap);
        geneCovMap.clear();
        while ((line = br.readLine()) != null) {
            //line = line.trim();
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t", -1);
            if (isEmptyCov) {
                row = new double[size + orgScoreNum + interactionNum];

            } else {
                row1 = geneCovMapTmp.get(cells[0]);
                if (row1 == null) {
                    newSymbl = synonymuseGeneSymbolMap.get(cells[0]);
                    if (newSymbl != null) {
                        row1 = geneCovMapTmp.get(cells[0]);
                        if (row1 == null) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                row = new double[size + orgScoreNum + interactionNum];
                System.arraycopy(row1, 0, row, 0, row1.length);
            }

            for (int i = 1; i < cells.length; i++) {
                if (cells[i].equals("NA")) {
                    continue;
                }
                row[row.length - cells.length + i] = Double.valueOf(cells[i]);
            }
            geneCovMap.put(cells[0], row);
        }
        br.close();

    }

    public static void appendGeneCovarWithInterationTerm(String filePatvh, List<String> names, Map<String, String> synonymuseGeneSymbolMap,
            Map<String, double[]> geneCovMap, String[] needCols, boolean needInteraction) throws Exception {
//format gene cov1 cov2     
        BufferedReader br = LocalFileFunc.getBufferedReader(filePatvh);
        //ingore head ine
        String line = br.readLine();
        double[] row;
        String[] cells = line.split("\\s+");
        int size = needCols.length;
        if (size == 0) {
            //  return;
        }
        int orgScoreNum = names.size();
        int interactionNum = 0;
        if (needInteraction) {
            interactionNum = orgScoreNum * (orgScoreNum - 1) / 2;
        }
        int[] colIndexes = new int[needCols.length];
        Arrays.fill(colIndexes, -1);
        for (int j = 0; j < needCols.length; j++) {
            for (int i = 1; i < cells.length; i++) {
                if (needCols[j].equals(cells[i])) {
                    colIndexes[j] = i;
                    names.add(cells[i]);
                    break;
                }
            }
        }
        double[] row1;

        boolean isEmptyCov = geneCovMap.isEmpty();

        Map<String, double[]> geneCovMapTmp = new HashMap<String, double[]>(geneCovMap);
        geneCovMap.clear();
        String newSymbl;
        boolean hasNA = false;
        while ((line = br.readLine()) != null) {
            //line = line.trim();
            if (line.trim().length() == 0) {
                continue;
            }
            cells = line.split("\t", -1);
            if (isEmptyCov) {
                row = new double[size + orgScoreNum + interactionNum];
            } else {
                row1 = geneCovMapTmp.get(cells[0]);
                if (row1 == null) {
                    newSymbl = synonymuseGeneSymbolMap.get(cells[0]);
                    if (newSymbl != null) {
                        row1 = geneCovMapTmp.get(newSymbl);
                        if (row1 == null) {
                            continue;
                        }
                    } else {
                        continue;
                    }
                }

                row = new double[size + orgScoreNum + interactionNum];
                Arrays.fill(row, Double.NaN);
                System.arraycopy(row1, 0, row, 0, row1.length);
            }

            hasNA = false;
            for (int i = 0; i < size; i++) {
                if (cells[colIndexes[i]].equals("NA") || cells[colIndexes[i]].equals("NaN")) {
                    hasNA = true;
                    break;
                }
                row[row.length - size + i] = Double.valueOf(cells[colIndexes[i]]);
            }

            if (!hasNA) {
                geneCovMap.put(cells[0], row);
            }

        }
        br.close();

    }

    public static Map<String, String> readSynonymouseGenes(String filePath) throws Exception {
        BufferedReader br = LocalFileFunc.getBufferedReader(filePath);
        String line = null;
        Map<String, String> geneSymsMap = new HashMap<String, String>();
        String[] previousNames;
        //skip head
        br.readLine();
        while ((line = br.readLine()) != null) {
            if (line.trim().length() == 0) {
                continue;
            }

            String[] cells = line.split("\t", -1);
            cells[5] = cells[5].trim();
            if (cells[5].length() == 0) {
                continue;
            }
            previousNames = cells[5].split(",");
            for (String str : previousNames) {
                str = str.trim();
                geneSymsMap.put(str, cells[1]);
            }

            cells[4] = cells[4].trim();
            if (cells[4].length() == 0) {
                continue;
            }
            previousNames = cells[4].split(",");
            for (String str : previousNames) {
                str = str.trim();
                //non redundant
                if (geneSymsMap.containsKey(str)) {
                    continue;
                }
                geneSymsMap.put(str, cells[1]);
            }

        }
        br.close();
        return geneSymsMap;
    }

    public static List<String[]> digeneAssocAnalysis(Map<String, SampleVarGtyUnit> geneSampleMuts, String filePath, int caseNum, int controlNum,
            double minScore, int theadNum, Map<String, String[]> genePositions) throws Exception {
        // GeneGraphShort ppiGraph = new GeneGraphShort();
        // ppiGraph.readInteractionsFast(filePath, null, minScore, theadNum, true, false);

        List<String[]> genePairCounts = new ArrayList<String[]>();
        long[][] countsInt = new long[2][2];

        /*
        ppicolNames[0] = "GeneA";
        ppicolNames[1] = "GeneB";
        ppicolNames[2] = "ACase";
        ppicolNames[3] = "BCase";
        ppicolNames[4] = "ABCase";
        ppicolNames[5] = "AControl";
        ppicolNames[6] = "BControl";
        ppicolNames[7] = "ABControl";
        ppicolNames[8] = "p";
        ppicolNames[9] = "BHFDR-q";
        if (newColNum > 0) {
            ppicolNames[10] = "Gene1PubMedID";
            ppicolNames[11] = "Gene2PubMedID";
        }
         */
        int scoreIndex = 2;
        BufferedReader br = LocalFileFunc.getBufferedReader(filePath);
        String line = br.readLine();
        String[] ppi;
        double score, oddsValues;
        boolean hasLess5;
        double pValue;
        int id, count1, count2;
        int varCount = 0;
        String[] cells;
        IntArrayList g1Pos = new IntArrayList();
        IntArrayList g2Pos = new IntArrayList();
        int g1VarSize, g2VarSize;

        double maxCombinedScore = -1, maxCombinedMut = -1;

        double allCombinedScoreG2 = -1, allCombinedMutG2 = -1, allCombinedScoreG1 = -1, allCombinedMutG1 = -1;
        StringBuilder details = new StringBuilder();
        boolean hasInc;
        double scoreG1 = 0, scoreG2 = 0, totalCaseScore, totalControlScore;
        int mutG1 = 0, mutG2 = 0, totalCaseCount, totalControlCount;
        boolean useMax = true;
        int countCase1, countCase2, countControl1, countControl2;

        while ((line = br.readLine()) != null) {
            ppi = line.split("\t");
            score = Double.parseDouble(ppi[scoreIndex]);
            if (score < minScore) {
                continue;
            }
            //g1 contains variants 
            SampleVarGtyUnit g1 = geneSampleMuts.get(ppi[0]);
            SampleVarGtyUnit g2 = geneSampleMuts.get(ppi[1]);
            if (g1 == null || g2 == null) {
                continue;
            }

            totalCaseScore = 0;
            totalCaseCount = 0;
            countCase1 = 0;
            countCase2 = 0;
            countControl1 = 0;
            countControl2 = 0;
            details.delete(0, details.length());
            for (int k = 0; k < caseNum; k++) {
                id = k;
                if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);
                g2.subjectMutCount[id].keys(g2Pos);
                g1VarSize = g1Pos.size();
                g2VarSize = g2Pos.size();
                maxCombinedScore = 0;
                maxCombinedMut = 0;
                allCombinedScoreG1 = 0;
                allCombinedMutG1 = 0;
                allCombinedScoreG2 = 0;
                allCombinedMutG2 = 0;
                hasInc = false;
                mutG1 = 0;
                mutG2 = 0;
                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = 0; j < g2VarSize; j++) {
                            mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                            scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                            if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) {
                                maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }
                    allCombinedScoreG1 += (scoreG1 * mutG1);
                    allCombinedMutG1 += mutG1;
                }
                for (int j = 0; j < g2VarSize; j++) {
                    mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                    scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                    allCombinedScoreG2 += (scoreG2 * mutG2);
                    allCombinedMutG2 += mutG2;
                }

                countCase1 += mutG1;
                countCase2 += mutG2;
                if (useMax) {
                    totalCaseScore += (maxCombinedScore);
                    totalCaseCount += (maxCombinedMut);
                    if (maxCombinedMut > 0) {
                        details.append((int) maxCombinedMut);
                        details.append(',');
                        hasInc = true;
                    }
                } else {
                    totalCaseScore += (allCombinedScoreG1 * allCombinedScoreG2);
                    totalCaseCount += (allCombinedMutG1 * allCombinedMutG2);
                    if (allCombinedMutG1 > 0 && allCombinedMutG2 > 0) {
                        details.append((int) allCombinedMutG1).append("-").append((int) allCombinedMutG2);
                        details.append(',');
                        hasInc = true;
                    }

                }
                if (hasInc) {
                    details.deleteCharAt(details.length() - 1);
                    details.append(';');
                }
            }

            if (totalCaseCount == 0) {
                continue;
            }

            totalControlScore = 0;
            totalControlCount = 0;

            for (int k = 0; k < controlNum; k++) {
                id = k + caseNum;
                if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);
                g2.subjectMutCount[id].keys(g2Pos);
                g1VarSize = g1Pos.size();
                g2VarSize = g2Pos.size();
                maxCombinedScore = 0;
                maxCombinedMut = 0;
                allCombinedScoreG1 = 0;
                allCombinedMutG1 = 0;
                allCombinedScoreG2 = 0;
                allCombinedMutG2 = 0;
                mutG1 = 0;
                mutG2 = 0;
                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = 0; j < g2VarSize; j++) {
                            mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                            scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                            if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) {
                                maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }
                    allCombinedScoreG1 += (scoreG1 * mutG1);
                    allCombinedMutG1 += mutG1;
                }
                for (int j = 0; j < g2VarSize; j++) {
                    mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                    scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                    allCombinedScoreG2 += (scoreG2 * mutG2);
                    allCombinedMutG2 += mutG2;
                }
                countControl1 += mutG1;
                countControl2 += mutG2;
                if (useMax) {
                    totalControlScore += (maxCombinedScore);
                    totalControlCount += (maxCombinedMut);
                } else {
                    totalControlScore += (allCombinedScoreG1 * allCombinedScoreG2);
                    totalControlCount += (allCombinedMutG1 * allCombinedMutG2);
                }
            }

            if (totalCaseCount + totalControlCount == 0) {
                continue;
            }

            String[] ppiItems = new String[15];

            ppiItems[0] = ppi[0];
            cells = genePositions.get(ppi[0]);
            ppiItems[1] = cells[0] + ":" + cells[1] + "-" + cells[2];
            ppiItems[2] = ppi[1];
            cells = genePositions.get(ppi[1]);
            ppiItems[3] = cells[0] + ":" + cells[1] + "-" + cells[2];
            ppiItems[4] = ppi[2];

            ppiItems[5] = String.valueOf(caseNum);
            ppiItems[6] = String.valueOf(countCase1);
            ppiItems[7] = String.valueOf(countCase2);
            ppiItems[8] = String.valueOf(totalCaseCount);

            /*
            ppiItems[3] = countCase1 + "/" + caseNum;
            ppiItems[4] = countCase2 + "/" + caseNum;
            ppiItems[5] = countCase + "/" + caseNum;
             */
            ppiItems[9] = String.valueOf(controlNum);
            ppiItems[10] = String.valueOf(countControl1);
            ppiItems[11] = String.valueOf(countControl2);
            ppiItems[12] = String.valueOf(totalControlCount);

            /*
            ppiItems[6] = countControl1 + "/" + controlNum;
            ppiItems[7] = countControl2 + "/" + controlNum;
            ppiItems[8] = countControl + "/" + controlNum;
             */
            countsInt[0][0] = totalCaseCount;
            countsInt[0][1] = caseNum - totalCaseCount;
            countsInt[1][0] = totalControlCount;
            countsInt[1][1] = controlNum - totalControlCount;
            hasLess5 = false;
            for (int r = 0; r < 2; r++) {
                for (int c = 0; c < 2; c++) {
                    if (countsInt[r][c] < 5) {
                        hasLess5 = true;
                        break;
                    }
                }
                if (hasLess5) {
                    break;
                }
            }
            oddsValues = (double) countsInt[0][0] * countsInt[1][1] / ((countsInt[0][1] == 0 ? 0.5f : countsInt[0][1])
                    * (countsInt[1][0] == 0 ? 0.5f : countsInt[1][0]));
            if (hasLess5) {
                pValue = ContingencyTable.fisherExact22(countsInt, 2, 2, 2);
            } else {
                pValue = ContingencyTable.pearsonChiSquared22(countsInt);
                pValue = Probability.chiSquareComplemented(1, pValue);
            }

            ppiItems[13] = String.format(oddsValues < 0.01 ? "%.2e" : "%.3f", oddsValues);
            ppiItems[14] = String.format(pValue < 0.01 ? "%.2e" : "%.3f", pValue);

            genePairCounts.add(ppiItems);
        }
        br.close();
        String info = genePairCounts.size() + " gene-pairs are collected.";
        LOG.info(info);
        return genePairCounts;
    }

    public static Map<String, double[]> phenotypeRelatednessEstimate(String[] phenotypeTerms, String[] hpos, String[] giantnets, List<String> genes, int threadNum) throws Exception {
        //codes modified from Hui Jiang, a PhD student
        String hpFile = GlobalManager.RESOURCE_PATH + "/hp.structure.txt.gz";
        String hpoaFile = GlobalManager.RESOURCE_PATH + "./phenotype_annotation_hpoteam.tab.gz";
        String icFile = GlobalManager.RESOURCE_PATH + "./gene.IC.txt.gz";
        String ericFile = GlobalManager.RESOURCE_PATH + "./ERIC_setmax.txt.gz";

        GeneGraphShort gg = new GeneGraphShort();
        Map<String, String> symbolIDMap = gg.readHGNCGeneSymbolID(GlobalManager.RESOURCE_PATH);
        Map<Integer, String> idSymbolMap = gg.readHGNCGeneIDSymbol(GlobalManager.RESOURCE_PATH);

        HashSet<String> termSet = new HashSet<String>();
        ArrayList<DownScore> selectHP = new ArrayList<DownScore>();

        selectHP = new TermRelatedHPO().getRelatedHP(hpFile, hpoaFile, icFile, phenotypeTerms, termSet);

        HashSet<String> hpset = new HashSet<String>();
        ArrayList<DownScore> scoredHP = new ArrayList<DownScore>();
        if (hpos != null) {
            scoredHP = new TermRelatedHPO().scoredHP(icFile, hpos, hpset);
        }
        //if input both disease name and HP_ID,combine two parts HP
        ArrayList<DownScore> combinedHP = new TermRelatedHPO().combineHP(selectHP, scoredHP);

        //calculate genes' disease relatedness scores
        Map<String, double[]> geneRelatedness = new HashMap<String, double[]>();
        List<String> giantPathList = new ArrayList<String>();
        int netNum = giantnets.length;
        for (int i = 0; i < netNum; i++) {
            giantPathList.add(giantnets[i]);
        }
        gg.extendERICscore(ericFile, genes, combinedHP, giantPathList, symbolIDMap, idSymbolMap, threadNum, geneRelatedness);

        return geneRelatedness;
    }

    public static ThreeTuple<String[], List<String[]>, String[]> geneMutationRateTestChangeFreqHandler(String rHost, int rPort, GeneAnnotator geneAnnotor, String[] fixedColNames, List<String> scoreNames, boolean needRegionLen,
            String[] popuNames, Map<String, double[]> geneMutationScores, Set<String> hittedGeneSet, Map<String, DoubleArrayList> refGeneVarFreqScoreMap,
            double mafCut, Map<String, Map<String, Integer>> cosmicGeneMut, String[] indexLabels, Genome uniqueGenome, boolean hasControls, boolean useLocalGeneScore,
            boolean needInteraction, Map<String, GeneSet> dbPathwaySet, Map<String, String[]> geneNamesMap, boolean isOneGene, boolean usingLog, int regionType, boolean outputFile) throws Exception {

        /*
                String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
                fixedColNames = new String[]{"Gene", "AvgRegionLen", "constraint_score"};
                scoreNames.add("AvgRegionLen");
                scoreNames.add("constraint_score");
         */
        if (needRegionLen) {
            scoreNames.add("RegionLength");
        }
        //assme the last column is gene frequencey score
        if (popuNames == null) {
            scoreNames.add("Freq");
        } else {
            scoreNames.add(popuNames[0]);
        }
        int orgScoreNum = scoreNames.size();
        int addedCovNum = 0;
        File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/" + "HgncGene.txt");

        File resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/gene.gnomAD.gc.txt.gz");
        //resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/gnomad.gene.score.txt");

        if (regionType == 1) {
            // resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/GeneUpDownGC");
            resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/CodingGeneUpDownGC");
        }
        //File resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/gene.score.mf.gc.txt");
        Map<String, String> synonymuseGeneSymbolMap = readSynonymouseGenes(resourceFile.getCanonicalPath());
        if (options.geneCovariableFile != null) {
            appendGeneCovarWithInterationTerm(options.geneCovariableFile, scoreNames, synonymuseGeneSymbolMap, geneMutationScores, options.needInteraction);
            addedCovNum = scoreNames.size() - orgScoreNum;
        } else if (resourceFileGeneScore.exists()) {
            //exon 
            if (regionType == 0) {
                appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, options.runnerGeneCodingCovs, options.needInteraction);

                //   appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"mu_mis", "mu_lof", "ExonGC"}, options.needInteraction);
// ExonGC	mu_mis	mis_z	mu_syn	syn_z "mis_z","lof_z", "oe_mis", "oe_lof", "oe_syn", 
            } else if (regionType == 1) {
                //appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"oe_mis", "oe_lof", "ExonGC"}, options.needInteraction);
                appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"GC"}, options.needInteraction);
            }

//constraint_score	ExonGC
            // appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"constraint_score", "ExonGC"}, options.needInteraction);
            addedCovNum = scoreNames.size() - orgScoreNum;
        } else {
            //add interction term
            Map<String, double[]> geneMutationScoresTmp = new HashMap<String, double[]>(geneMutationScores);
            geneMutationScores.clear();
            int interactionNum = 0;
            if (options.needInteraction) {
                interactionNum = orgScoreNum * (orgScoreNum - 1) / 2;
            }
            for (Map.Entry<String, double[]> item : geneMutationScoresTmp.entrySet()) {
                double[] row = new double[orgScoreNum + interactionNum];
                System.arraycopy(item.getValue(), 0, row, 0, item.getValue().length);
                geneMutationScores.put(item.getKey(), row);
            }
            geneMutationScoresTmp.clear();
        }
        boolean multiCut = true;
        List<String[]> contorlResults = new ArrayList<String[]>();
        List<String[]> caseResults = new ArrayList<String[]>();

        if (multiCut) {
            // checkMissingPredictors(needRegionLen, geneMutationScores, hittedGeneSet, geneFreqScores, localGeneFreqScores, useLocalGeneScore);
            indexLabels = geneMutationRateTestRENER(rHost, rPort, geneAnnotor, hasControls, useLocalGeneScore, uniqueGenome, indexLabels,
                    geneMutationScores, refGeneVarFreqScoreMap, mafCut, scoreNames, orgScoreNum, addedCovNum, geneNamesMap, isOneGene, usingLog,
                    contorlResults, caseResults, outputFile);

        } else {
            /*
      TwoTuple<Map<String, double[]>, String[]> tuple = multiCutElseHandler(geneAnnotor, geneMutationScores, geneCoVarFilePath, fixedColNames, mafFolder, popuNames, funcScoreBinLen, hittedGeneSet, hasControls, indexLabels, uniqueGenome,
          cosmicGeneMut, scoreNames, geneMutRegPValueAllVar, geneMutRegPValueAllVarControl);
      geneMutationScores = tuple.getFirst();
      indexLabels = tuple.getSecond();
             */
        }
        /*
        if (options.ppiDB != null) {
            String ppiDBFile = options.PUBDB_FILE_MAP.get(options.ppiDB);
            String ppiFile = GlobalManager.RESOURCE_PATH + "/" + ppiDBFile;
            PPIGraph ppiGraph = new PPIGraph();
            ppiGraph.readPPIItems(ppiFile, 600);
            List<String[]> ppiPairs = ppiGraph.getForwardInteractionItems();
            if (!contorlResults.isEmpty()) {
                geneAnnotor.annotatePPIGeneAndOutput(contorlResults, options.excelOut, options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.genePCut, ppiPairs, options.outputFileName + ".ppi.mutationburden.control");
            }
            if (!caseResults.isEmpty()) {
                geneAnnotor.annotatePPIGeneAndOutput(caseResults, options.excelOut, options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.genePCut, ppiPairs, options.outputFileName + ".ppi.mutationburden.case");
            }

        }
        

        if (options.genesetBurdenTest) {
            if (!contorlResults.isEmpty()) {
                geneAnnotor.enrichmentTestGeneSet(dbPathwaySet, contorlResults, options.genesetSizeMin, options.genesetHyperGenePCut, options.outputFileName + ".geneset.mutationburden.control");
            }
            if (!caseResults.isEmpty()) {
                geneAnnotor.enrichmentTestGeneSet(dbPathwaySet, caseResults, options.genesetSizeMin, options.genesetHyperGenePCut, options.outputFileName + ".geneset.mutationburden.case");
            }
        }
         */
        return TupleUtil.tuple(fixedColNames, caseResults, indexLabels);
    }

    //this function was made to response a question of a reviewer
    public static void simpleGeneBasedAssoc(Map<String, FloatArrayList[]> geneSampleMuts, DoubleArrayList rareMutScores,
            int caseNum, int controlNum) throws Exception {
        int pos, size, g1VarSize, id;
        double allScoreNum = rareMutScores.size(), totalScoreG1, freqCase;
        BufferedWriter bw = LocalFileFunc.getBufferedWriter(options.outputFileName + "simpleGeneBased.txt", false);
        bw.write("Gene\tP\n");
        for (Map.Entry<String, FloatArrayList[]> item : geneSampleMuts.entrySet()) {
            FloatArrayList[] mutScores = item.getValue();
            for (int i = 0; i < mutScores.length; i++) {
                size = mutScores[i].size();
                for (int j = 0; j < size; j += 2) {
                    pos = rareMutScores.binarySearch(mutScores[i].getQuick(j + 1));
                    if (pos < 0) {
                        pos = -pos - 1;
                    }
                    mutScores[i].setQuick(j + 1, (float) (pos / allScoreNum));
                }
            }
        }
        double[][] xMat = new double[caseNum + controlNum][2];
        double[] y = new double[caseNum + controlNum];
        LogisticRegression lr = new LogisticRegression();
        int counts = 0;
        for (Map.Entry<String, FloatArrayList[]> item : geneSampleMuts.entrySet()) {
            if (!item.getKey().equals("TCF4") && !item.getKey().equals("TIE1")) {
                // continue;
            }

            FloatArrayList[] g1 = item.getValue();
            if (g1 == null) {
                continue;
            }

            g1VarSize = g1[0].size();
            counts = 0;
            for (int k = 0; k < caseNum; k++) {
                xMat[k][0] = 1;
                xMat[k][1] = 0;
                y[k] = 1;
                for (int i = 0; i < g1VarSize; i += 2) {
                    xMat[k][1] += g1[k].getQuick(i) * g1[k].getQuick(i + 1);
                    if (xMat[k][1] != 0) {
                        counts++;
                    }
                }
            }

            for (int k = 0; k < controlNum; k++) {
                id = k + caseNum;
                xMat[id][0] = 1;
                xMat[id][1] = 0;
                y[id] = 0;
                for (int i = 0; i < g1VarSize; i += 2) {
                    xMat[id][1] += g1[id].getQuick(i) * g1[id].getQuick(i + 1);
                    if (xMat[id][1] != 0) {
                        counts++;
                    }
                }
            }
            if (counts < 50) {
                continue;
            }

            lr.setX(xMat);
            lr.setY(y);
            lr.fitLM();
            bw.write(item.getKey() + "\t" + lr.getCoefPValue(1) + "\n");
        }
        bw.close();

    }

    public static ThreeTuple<String[], List<String[]>, String[]> genetInteractionMutationRateTestChangeFreqHandler(String rHost, int rPort, String diGeneFilePath, double minScore, GeneAnnotator geneAnnotor, String[] fixedColNames, List<String> scoreNames, boolean needRegionLen,
            String[] popuNames, Map<String, double[]> geneMutationScores, Map<String, SampleVarGtyUnit> geneSampleMuts, DoubleArrayList rareMutScores, int caseNum, int controlNum, String[]subIDByCaseControlSetID, Set<String> hittedGeneSet, Map<String, DoubleArrayList> refGeneVarFreqScoreMap,
            double mafCut, String[] indexLabels, Genome uniqueGenome, boolean hasControls, boolean useLocalGeneScore,
            boolean needInteraction, Map<String, String[]> geneNamesMap, boolean isOneGene, boolean usingLog, int regionType, boolean outputFile) throws Exception {
        /*
                String geneCoVarFilePath = GlobalManager.RESOURCE_PATH + "/" + "gene.score.mf.txt";
                fixedColNames = new String[]{"Gene", "AvgRegionLen", "constraint_score"};
                scoreNames.add("AvgRegionLen");
                scoreNames.add("constraint_score");
         */
        int pos, size;
        rareMutScores.quickSort();
        float score1;
        double allScoreNum = rareMutScores.size();
        if (options.runnerDiGeneInteractCoding || options.runnerMoGeneInteractCoding) {
            for (Map.Entry<String, SampleVarGtyUnit> item : geneSampleMuts.entrySet()) {
                SampleVarGtyUnit mutScores = item.getValue();
                size = mutScores.varScores.size();
                for (int i = 0; i < size; i++) {
                    score1 = mutScores.varScores.getQuick(i);
                    if (!Float.isNaN(score1)) {
                        pos = rareMutScores.binarySearch(score1);
                        if (pos < 0) {
                            pos = -pos - 1;
                        }
                        mutScores.varScores.setQuick(i, (float) (pos / allScoreNum));
                    }

                }

            }
        }

        Map<String, Gene> mappedGenes = new HashMap<String, Gene>();
        Chromosome[] chroms = uniqueGenome.getChromosomes();
        boolean useFunctionWeight = options.runnerDiGeneInteractCoding || options.runnerMoGeneInteractCoding;
        DoubleArrayList scoresDistr = new DoubleArrayList();
        //stardaize the scores of varaints to be ranged 0 and 1
        if (useFunctionWeight) {
            for (int i = 0; i < chroms.length; i++) {
                if (chroms[i] == null) {
                    continue;
                }

                for (Gene gene : chroms[i].geneList) {
                    if (gene.geneSymb == null) {
                        continue;
                    }

                    DoubleArrayList tmpScore = gene.getDepMutScore(3);
                    if (tmpScore != null && !tmpScore.isEmpty()) {
                        scoresDistr.addAllOf(tmpScore);
                    }
                }
            }
            scoresDistr.quickSort();
            double medianScore = Descriptive.median(scoresDistr);
            for (int i = 0; i < chroms.length; i++) {
                if (chroms[i] == null) {
                    continue;
                }

                for (Gene gene : chroms[i].geneList) {
                    if (gene.geneSymb == null) {
                        continue;
                    }
                    gene.rescaleVarScores(scoresDistr, 3);
                    mappedGenes.put(gene.geneSymb, gene);
                }
            }
            scoresDistr.clear();
        }

        if (needRegionLen) {
            scoreNames.add("RegionLength");
        }
        //assme the last column is gene frequencey score

        scoreNames.add(popuNames[0]);
        int orgScoreNum = scoreNames.size();
        int addedCovNum = 0;
        File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/" + "HgncGene.txt");

        File resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/gene.gnomAD.gc.txt.gz");
        if (regionType == 1) {
            // resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/GeneUpDownGC");
            resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/CodingGeneUpDownGC");
        }
        //File resourceFileGeneScore = new File(GlobalManager.RESOURCE_PATH + "/gene.score.mf.gc.txt");
        Map<String, String> synonymuseGeneSymbolMap = readSynonymouseGenes(resourceFile.getCanonicalPath());
        if (options.geneCovariableFile != null) {
            appendGeneCovarWithInterationTerm(options.geneCovariableFile, scoreNames, synonymuseGeneSymbolMap, geneMutationScores, options.needInteraction);
            addedCovNum = scoreNames.size() - orgScoreNum;
        } else if (resourceFileGeneScore.exists()) {
            //, "expr", "reptime", "hic"//  
            if (regionType == 0) {
                //   appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"oe_mis", "oe_lof","mu_mis", "mu_lof", "ExonGC"}, options.needInteraction);
                //strange the mu_mis is highly correlated with coding region legnth
                appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"oe_mis", "oe_lof", "ExonGC"}, options.needInteraction);

            } else if (regionType == 1) {
                //appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"oe_mis", "oe_lof", "ExonGC"}, options.needInteraction);
                appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"GC"}, options.needInteraction);
            }

//constraint_score	ExonGC
            // appendGeneCovarWithInterationTerm(resourceFileGeneScore.getCanonicalPath(), scoreNames, synonymuseGeneSymbolMap, geneMutationScores, new String[]{"constraint_score", "ExonGC"}, options.needInteraction);
            addedCovNum = scoreNames.size() - orgScoreNum;
        } else {
            //add interction term
            Map<String, double[]> geneMutationScoresTmp = new HashMap<String, double[]>(geneMutationScores);
            geneMutationScores.clear();
            int interactionNum = 0;
            if (options.needInteraction) {
                interactionNum = orgScoreNum * (orgScoreNum - 1) / 2;
            }

            for (Map.Entry<String, double[]> item : geneMutationScoresTmp.entrySet()) {
                double[] row = new double[orgScoreNum + interactionNum];
                System.arraycopy(item.getValue(), 0, row, 0, item.getValue().length);
                geneMutationScores.put(item.getKey(), row);
            }
            geneMutationScoresTmp.clear();
        }

        List<String[]> contorlResults = new ArrayList<String[]>();
        List<String[]> caseResults = new ArrayList<String[]>();

//        if (multiCut) {
//            // checkMissingPredictors(needRegionLen, geneMutationScores, hittedGeneSet, geneFreqScores, localGeneFreqScores, useLocalGeneScore);
//            indexLabels = digeneMutationRateTestRENER(rHost, rPort, diGeneFilePath, minScore, geneAnnotor, hasControls, useLocalGeneScore, geneSampleMuts, caseNum, controlNum, indexLabels,
//                    geneMutationScores, refGeneVarFreqScoreMap, mafCut, scoreNames, orgScoreNum, addedCovNum, geneNamesMap, isOneGene, usingLog,
//                    contorlResults, caseResults, outputFile);
//
//        }
        indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
        String outFileName = options.outputFileName + ".digene.mutationburden.case";
        List<String[]> geneMutRateSheet = null;

        if (options.runnerDiGeneInteractCoding || options.uwrunnerDiGeneInteractCoding) {
            geneMutRateSheet = geneAnnotor.diGeneMutationBurdenTest(rHost, rPort, indexLabels, geneMutationScores, geneSampleMuts, caseNum, controlNum,subIDByCaseControlSetID, options.hasGenePairFreq, refGeneVarFreqScoreMap,
                    mafCut, scoreNames, useFunctionWeight, options.refMutGeneFile, options.independentGeneFeature.isEmpty(), options.needInteraction,
                    orgScoreNum, addedCovNum, options.threadNum, diGeneFilePath, minScore, usingLog, options.minCCFreqRatio, options.protectiveBurden, options.diGeneMax, options.runnerInteractMarginal, mappedGenes);
        } else if (options.runnerMoGeneInteractCoding || options.uwrunnerMoGeneInteractCoding) {
            geneMutRateSheet = geneAnnotor.singleGeneInteractionMutationBurdenTest(rHost, rPort, indexLabels, geneMutationScores, geneSampleMuts, caseNum, controlNum, options.hasGenePairFreq, refGeneVarFreqScoreMap,
                    mafCut, scoreNames, useFunctionWeight, options.refMutGeneFile, options.independentGeneFeature.isEmpty(), options.needInteraction,
                    orgScoreNum, addedCovNum, options.threadNum, diGeneFilePath, minScore, usingLog, options.minCCFreqRatio, options.protectiveBurden, options.diGeneMax, 500, options.runnerInteractMarginal, mappedGenes);

        }
        geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut, options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
        caseResults.addAll(geneMutRateSheet);
        if (outputFile && geneMutRateSheet != null && !geneMutRateSheet.isEmpty()) {
            if (options.excelOut) {
                outFileName += ".xlsx";
                LocalExcelFile.writeArray2XLSXFile(outFileName, caseResults, true, -1, 0);
            } else {
                outFileName += ".txt";
                org.cobi.util.text.LocalFile.writeData(outFileName, caseResults, "\t", false);
            }
            String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
            LOG.info(info);
        }

        /*
        if (options.ppiDB != null) {
            String ppiDBFile = options.PUBDB_FILE_MAP.get(options.ppiDB);
            String ppiFile = GlobalManager.RESOURCE_PATH + "/" + ppiDBFile;
            PPIGraph ppiGraph = new PPIGraph();
            ppiGraph.readPPIItems(ppiFile, 600);
            List<String[]> ppiPairs = ppiGraph.getForwardInteractionItems();
            if (!contorlResults.isEmpty()) {
                geneAnnotor.annotatePPIGeneAndOutput(contorlResults, options.excelOut, options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.genePCut, ppiPairs, options.outputFileName + ".ppi.mutationburden.control");
            }
            if (!caseResults.isEmpty()) {
                geneAnnotor.annotatePPIGeneAndOutput(caseResults, options.excelOut, options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.genePCut, ppiPairs, options.outputFileName + ".ppi.mutationburden.case");
            }

        }
         */
        return TupleUtil.tuple(fixedColNames, caseResults, indexLabels);
    }

    public static void makeDigeneRefMutationRateHandler0(String diGeneFilePath, double minScore, Map<String, float[]> geneSampleMuts,
            DoubleArrayList rareMutScores, int caseNum, int controlNum, String outputFile) throws Exception {

        int pos, size;
        rareMutScores.quickSort();
        double allScoreNum = rareMutScores.size();

        for (Map.Entry<String, float[]> item : geneSampleMuts.entrySet()) {
            float[] mutScores = item.getValue();
            for (int i = 0; i < mutScores.length; i++) {
                if (!Float.isNaN(mutScores[i])) {
                    pos = rareMutScores.binarySearch(mutScores[i]);
                    if (pos < 0) {
                        pos = -pos - 1;
                    }
                    mutScores[i] = (float) (pos / allScoreNum);
                }
            }
        }

        int totalMutG1 = 0, totalMutG2 = 0;
        int varSize, id;
        int scoreIndex = 2;
        BufferedReader br = LocalFileFunc.getBufferedReader(diGeneFilePath);
        String[] ppi;
        String line = br.readLine();
        boolean useMax = true;

        int g1VarSize, g2VarSize;
        double score, totalControlScore, totalControlCount;
        double maxCombinedScore = -1, maxCombinedMut = -1;
        float totalScoreG1, totalScoreG2;
        int count = 0;
        File outFile = new File(outputFile + "RefGenePairMut.gz");
        BufferedWriter bw = LocalFileFunc.getBufferedWriter(outFile.getCanonicalPath(), true);
        bw.write("Gene1\tGene2\tScore\tMutFreq\tMutFreqScore\n");
        while ((line = br.readLine()) != null) {
            ppi = line.split("\t");
            score = Double.parseDouble(ppi[scoreIndex]);
            if (score < minScore) {
                continue;
            }

            //g1 contains variants 
            float[] g1 = geneSampleMuts.get(ppi[0]);
            float[] g2 = geneSampleMuts.get(ppi[1]);
            if (g1 == null || g2 == null) {
                continue;
            }

            //filter out impossible variant pairs between two genes  
            totalControlScore = 0;
            totalControlCount = 0;
            for (int j = 0; j < controlNum; j++) {
                id = j + caseNum;

                maxCombinedScore = 0;
                maxCombinedMut = 0;

                totalScoreG1 = g1[id];
                totalScoreG2 = g2[id];
                if (Float.isNaN(totalScoreG1) || Float.isNaN(totalScoreG2)) {
                    continue;
                }
                maxCombinedScore = totalScoreG1 * totalScoreG2;
                maxCombinedMut = 1;

                totalControlScore += (maxCombinedScore);
                totalControlCount += (maxCombinedMut);
            }

            if (totalControlCount == 0) {
                continue;
            }
            totalControlCount /= controlNum;
            totalControlScore /= controlNum;
            bw.write(ppi[0] + "\t" + ppi[1] + "\t" + ppi[scoreIndex] + "\t" + totalControlCount + "\t" + totalControlScore + "\n");
            count++;
        }
        br.close();
        bw.close();

        LOG.info(count + " gene pairs with gene-pair frequencies are saved in " + outFile.getCanonicalPath());

    }

    public static void makeDigeneRefMutationRateHandler(String diGeneFilePath, double minScore, Map<String, SampleVarGtyUnit> geneSampleMuts,
            DoubleArrayList rareMutScores, int caseNum, int controlNum, String outputFile, boolean useMax) throws Exception {

        int pos, size;
        rareMutScores.quickSort();
        double allScoreNum = rareMutScores.size();
        float score1;
        rareMutScores.quickSort();

        if (options.runnerDiGeneInteractCoding) {
            for (Map.Entry<String, SampleVarGtyUnit> item : geneSampleMuts.entrySet()) {
                SampleVarGtyUnit mutScores = item.getValue();
                size = mutScores.varScores.size();
                for (int i = 0; i < size; i++) {
                    score1 = mutScores.varScores.getQuick(i);
                    if (!Float.isNaN(score1)) {
                        pos = rareMutScores.binarySearch(score1);
                        if (pos < 0) {
                            pos = -pos - 1;
                        }
                        mutScores.varScores.setQuick(i, (float) (pos / allScoreNum));
                    }

                }

            }
        }
        int id;
        int scoreIndex = 2;
        BufferedReader br = LocalFileFunc.getBufferedReader(diGeneFilePath);
        String[] ppi;
        String line = br.readLine();

        int g1VarSize, g2VarSize;
        double totalControlScore, totalControlCount;
        double maxCombinedScore = -1, maxCombinedMut = -1;

        int count = 0;

        double score, mutG1, scoreG1, mutG2, scoreG2;
        double allCombinedScoreG2 = -1, allCombinedMutG2 = -1, allCombinedScoreG1 = -1, allCombinedMutG1 = -1;

        File outFile = new File(outputFile + ".RefGenePairMut.gz");
        BufferedWriter bw = LocalFileFunc.getBufferedWriter(outFile.getCanonicalPath(), true);
        bw.write("Gene1\tGene2\tScore\tMutFreq\tMutFreqScore\n");
        IntArrayList g1Pos = new IntArrayList();
        IntArrayList g2Pos = new IntArrayList();

        while ((line = br.readLine()) != null) {
            ppi = line.split("\t");
            score = Double.parseDouble(ppi[scoreIndex]);
            if (score < minScore) {
                continue;
            }

            //g1 contains variants 
            SampleVarGtyUnit g1 = geneSampleMuts.get(ppi[0]);
            SampleVarGtyUnit g2 = geneSampleMuts.get(ppi[1]);
            if (g1 == null || g2 == null) {
                continue;
            }

            totalControlScore = 0;
            totalControlCount = 0;
            for (int k = 0; k < controlNum; k++) {
                id = k + caseNum;
                if (g1.subjectMutCount[id] == null || g2.subjectMutCount[id] == null) {
                    continue;
                }
                g1.subjectMutCount[id].keys(g1Pos);
                g2.subjectMutCount[id].keys(g2Pos);
                g1VarSize = g1Pos.size();
                g2VarSize = g2Pos.size();
                maxCombinedScore = 0;
                maxCombinedMut = 0;
                allCombinedScoreG1 = 0;
                allCombinedMutG1 = 0;
                allCombinedScoreG2 = 0;
                allCombinedMutG2 = 0;

                for (int i = 0; i < g1VarSize; i++) {
                    mutG1 = g1.subjectMutCount[id].get(g1Pos.getQuick(i));
                    scoreG1 = g1.varScores.getQuick(g1Pos.getQuick(i));
                    if (useMax) {
                        for (int j = 0; j < g2VarSize; j++) {
                            mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                            scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                            if (maxCombinedScore < (scoreG1 * scoreG2 * mutG1 * mutG2)) {
                                maxCombinedScore = scoreG1 * scoreG2 * mutG1 * mutG2;
                                maxCombinedMut = mutG1 * mutG2;
                            }
                        }
                    }
                    allCombinedScoreG1 += (scoreG1 * mutG1);
                    allCombinedMutG1 += mutG1;
                }
                for (int j = 0; j < g2VarSize; j++) {
                    mutG2 = g2.subjectMutCount[id].get(g2Pos.getQuick(j));
                    scoreG2 = g2.varScores.getQuick(g2Pos.getQuick(j));
                    allCombinedScoreG2 += (scoreG2 * mutG2);
                    allCombinedMutG2 += mutG2;
                }

                if (useMax) {
                    totalControlScore += (maxCombinedScore);
                    totalControlCount += (maxCombinedMut);
                } else {
                    totalControlScore += (allCombinedScoreG1 * allCombinedScoreG2);
                    totalControlCount += (allCombinedMutG1 * allCombinedMutG2);
                }
            }

            if (totalControlCount == 0) {
                continue;
            }
            totalControlCount /= controlNum;
            totalControlScore /= controlNum;
            bw.write(ppi[0] + "\t" + ppi[1] + "\t" + ppi[scoreIndex] + "\t" + totalControlCount + "\t" + totalControlScore + "\n");
            count++;
        }
        br.close();
        bw.close();

        LOG.info(count + " gene pairs with gene-pair frequencies are saved in " + outFile.getCanonicalPath());

    }

    public static void phenoRunnerAnalysis(List<String[]> caseResults, Map<String, String[]> geneNamesMap) throws Exception {
        int burdenResidueIndex = -1;
        String[] cells = caseResults.get(0);
        for (int i = 0; i < cells.length; i++) {
            if (cells[i].equals("Residual")) {
                burdenResidueIndex = i;
                break;
            }
        }

        if (options.genePhenoRelatedness) {
            boolean needPubMed = false;
            int addCol = 3;
            if (options.pubmedMiningSigGene || options.pubmedMiningTopGene > 0) {
                needPubMed = true;
                addCol++;
            }
            List<String[]> caseResultsNew = new ArrayList<String[]>();
            int geneNum = caseResults.size();
            String[] items = caseResults.get(0);
            String[] cellsT = new String[items.length + options.giantNetName.length * addCol];
            System.arraycopy(items, 0, cellsT, 0, items.length);
            caseResultsNew.add(cellsT);

            for (int i = 0; i < options.giantNetName.length; i++) {
                cellsT[items.length + addCol * i] = options.giantNetName[i] + ".Pheno.Relatedness";
                cellsT[items.length + addCol * i + 1] = options.giantNetName[i] + ".PhenoRUNNER.PR";
                cellsT[items.length + addCol * i + 2] = options.giantNetName[i] + ".PhenoRUNNER.q";
                if (needPubMed) {
                    cellsT[items.length + addCol * i + 3] = options.giantNetName[i] + ".GenePumMedID";
                }
            }
            List<String> genes = new ArrayList<String>();

            for (int j = 1; j < geneNum; j++) {
                items = caseResults.get(j);
                if (items[burdenResidueIndex] == null) {
                    continue;
                }
                genes.add(items[0]);
                cellsT = new String[items.length + options.giantNetName.length * addCol];
                System.arraycopy(items, 0, cellsT, 0, items.length);
                caseResultsNew.add(cellsT);
            }
            geneNum = caseResultsNew.size();
            int orgLen = caseResults.get(0).length;
            String[] diseaseNames = options.searchList.toArray(new String[0]);
            Map<String, double[]> geneRelatednessMap = OptionHandlerTools.phenotypeRelatednessEstimate(diseaseNames,
                    options.hpoTerm, options.giantNetFilePath, genes, options.threadNum);
            RankTest rt = new RankTest();
            List<String[]> geneScores = new ArrayList<String[]>();
            Map<String, String[]> geneScoresResults;
            double[] values;
            GeneAnnotator gat = new GeneAnnotator();

            for (int giantID = 0; giantID < options.giantNetName.length; giantID++) {
                LOG.info("Network-based phenotype-relatedness estimation at genes with " + options.giantNetName[giantID] + ".");
                geneScores.clear();
                cells = new String[3];
                cells[0] = "Gene";
                cells[1] = "S1";
                cells[2] = "S2";
                geneScores.add(cells);
                for (int j = 1; j < geneNum; j++) {
                    String[] item = caseResultsNew.get(j);
                    cells = new String[3];
                    cells[0] = item[0];
                    cells[1] = item[burdenResidueIndex];
                    if (cells[1] == null) {
                        continue;
                    }
                    values = geneRelatednessMap.get(cells[0]);
                    if (values == null) {
                        continue;
                    }

                    cells[2] = String.valueOf(values[giantID]);
                    geneScores.add(cells);
                }
                geneScoresResults = rt.permutationTest(geneScores, options.threadNum, 100000);
                for (int j = 1; j < geneNum; j++) {
                    items = caseResultsNew.get(j);
                    cellsT = geneScoresResults.get(items[0]);
                    if (cellsT == null) {
                        continue;
                    }
                    items[orgLen + addCol * giantID] = cellsT[cellsT.length - 3];
                    items[orgLen + 1 + addCol * giantID] = cellsT[cellsT.length - 2];
                    items[orgLen + 2 + addCol * giantID] = cellsT[cellsT.length - 1];
                }

                if (needPubMed) {
                    gat.annotateGenePubMed(caseResultsNew, orgLen + 1 + addCol * giantID, orgLen + 2 + addCol * giantID, orgLen + 3 + addCol * giantID, options.genePCut,
                            options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap);
                } else {
                    //only sort it
                    StringArrayIntegerComparator sic = new StringArrayIntegerComparator(orgLen + 1 + addCol * giantID);
                    Collections.sort(caseResultsNew, sic);
                }
            }

            String outFileName = options.outputFileName + ".gene.mutationburden.pheno";
            if (options.excelOut) {
                outFileName += ".xlsx";
                LocalExcelFile.writeArray2XLSXFile(outFileName, caseResultsNew, true, -1, 0);
            } else {
                outFileName += ".txt";
                org.cobi.util.text.LocalFile.writeData(outFileName, caseResultsNew, "\t", false);
            }
            String info = "The results of Pheno-RUNNER analyses are saved in " + (new File(outFileName)).getCanonicalPath() + "!";

            LOG.info(info);
        }
    }

    private static void checkMissingPredictors(boolean needRegionLen, Map<String, double[]> geneMutationScores, Set<String> hittedGeneSet,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap) {
        if (needRegionLen) {
            Map<String, double[]> geneMutationScoresTmp = new HashMap<String, double[]>(geneMutationScores); //////////////
            geneMutationScores.clear();
            List<String> excludedGenes = new ArrayList<String>(); ///////////////////
            DoubleArrayList tmpDoubles;

            for (Map.Entry<String, double[]> item : geneMutationScoresTmp.entrySet()) {
                if (!hittedGeneSet.contains(item.getKey())) {
                    excludedGenes.add(item.getKey());
                } else {
                    tmpDoubles = refGeneVarFreqScoreMap.get(item.getKey());
                    if (item.getKey() == null || tmpDoubles == null) {
                        continue;
                    }
                    geneMutationScores.put(item.getKey(), item.getValue());
                }
            }

            geneMutationScoresTmp.clear();
            if (excludedGenes.size() > 0) {
                //  LOG.info(excludedGenes.size() + " genes are excluded due to missing reference allele frequencies in the gnomad database.");
                // System.out.println(excludedGenes.toString());
            }

            excludedGenes.clear();
            hittedGeneSet.clear();
        } else {
            /*
      geneMutationScores = new HashMap<String, double[]>(geneMutationScores);
      if (toUseLocalGeneScore) {
        for (Map.Entry<String, double[]> item : localGeneFreqScores.entrySet()) {
          geneMutationScores.put(item.getKey(), new double[]{0});
        }
      } else {
        for (Map.Entry<String, double[]> item : geneFreqScores.entrySet()) {
          geneMutationScores.put(item.getKey(), new double[]{0});
        }
      }
             */
        }
    }
    // p correspondingP p 

    static void rescaleVarScores(DoubleArrayList values, DoubleArrayList distr) {
        if (values == null || values.isEmpty()) {
            return;
        }
        int size = values.size() / 2;
        double s;
        int pos, naNum = 0;
        double allScoreNum = distr.size();

        for (int i = 0; i < size; i++) {
            s = (values.getQuick(i + i + 1));
            if (!Double.isNaN(s)) {
                pos = distr.binarySearch(s);
                if (pos < 0) {
                    pos = -pos - 1;
                }
                values.setQuick(i + i + 1, pos / allScoreNum);
            }
        }
    }

    private static String[] geneMutationRateTestRENER(String rHost, int rPort, GeneAnnotator geneAnnotor, boolean hasControls, boolean useLocalGeneScore, Genome uniqueGenome, String[] indexLabels, Map<String, double[]> geneScoreMap,
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap, double mafCut, List<String> scoreNames, int orgCovNum, int addedCovNum,
            Map<String, String[]> geneNamesMap, boolean isOneGene, boolean usingLog, List<String[]> contorlResults, List<String[]> caseResults, boolean needOutputFile) throws Exception {
        int alleleNumIndex = 0;
        Chromosome[] chroms = uniqueGenome.getChromosomes();
        boolean useFunctionWeight = options.runnerGeneCoding || options.wrenerGeneNonCoding;
        DoubleArrayList scoresDistr = new DoubleArrayList();
        //stardaize the scores of varaints to be ranged 0 and 1
        if (useFunctionWeight) {
            for (int i = 0; i < chroms.length; i++) {
                if (chroms[i] == null) {
                    continue;
                }

                for (Gene gene : chroms[i].geneList) {
                    if (gene.geneSymb == null) {
                        continue;
                    }

                    DoubleArrayList tmpScore = gene.getDepMutScore(3);
                    if (tmpScore != null && !tmpScore.isEmpty()) {
                        scoresDistr.addAllOf(tmpScore);
                    }
                }
            }
            scoresDistr.quickSort();
           // double medianScore = Descriptive.median(scoresDistr);
            for (int i = 0; i < chroms.length; i++) {
                if (chroms[i] == null) {
                    continue;
                }

                for (Gene gene : chroms[i].geneList) {
                    if (gene.geneSymb == null) {
                        continue;
                    }

                    gene.rescaleVarScores(scoresDistr, 3);
                }
            }
            for (Map.Entry<String, DoubleArrayList> item : refGeneVarFreqScoreMap.entrySet()) {
                rescaleVarScores(item.getValue(), scoresDistr);
            }
            scoresDistr.clear();
        }

        // if (false) 
//        if (!useLocalGeneScore && hasControls) {
//            indexLabels = new String[]{"ResponseVarControl", "ExplanatoryVarControl", "ResponseVarFuncScoreControl"};
//            alleleNumIndex = 1;
//            List<String[]> geneMutRateSheet;
//            if (isOneGene) {
//                geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(rHost, rPort, uniqueGenome, indexLabels, geneScoreMap,
//                        refGeneVarFreqScoreMap, mafCut, scoreNames,
//                        options.runnerGeneCoding || options.wrenerGeneNonCoding, options.refMutGeneFile,
//                        options.independentGeneFeature.isEmpty(), options.needInteraction, orgCovNum, addedCovNum, options.threadNum, alleleNumIndex);
//            } else {
//                String ppiDBFile = options.PUBDB_FILE_MAP.get("string");
//                geneMutRateSheet = geneAnnotor.PPIMutationRateTestChangeFreq(rHost, rPort, uniqueGenome, indexLabels, geneScoreMap,
//                        refGeneVarFreqScoreMap, mafCut, scoreNames,
//                        options.runnerDiGeneInteractCoding, options.refMutGeneFile,
//                        options.independentGeneFeature.isEmpty(), options.needInteraction, orgCovNum, addedCovNum, options.threadNum, alleleNumIndex, GlobalManager.RESOURCE_PATH + "/" + ppiDBFile);
//
//            }
//            String outFileName = options.outputFileName + ".gene.mutationburden.control";
//            geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
//                    options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
//
//            /*
//            geneAnnotor.geneSomaticMutationRateTest(uniqueGenome, indexLabels, cosmicGeneMut, geneScoreMap, scoreNames, options.genesetHyperGenePCut,
//                options.runnerGeneCoding || options.wrenerGeneNonCoding, geneMutRegPValueAllVar, options.witerRefMutGeneFile, options.outputFileName + ".gene.mutationburden.contol",
//                options.independentGeneFeature.isEmpty(), options.excelOut);
//             */
//            contorlResults.addAll(geneMutRateSheet);
//            //if (needOutputFile) 
//            {
//                if (options.excelOut) {
//                    outFileName += ".xlsx";
//                    LocalExcelFile.writeArray2XLSXFile(outFileName, contorlResults, true, -1, 0);
//                } else {
//                    outFileName += ".txt";
//                    org.cobi.util.text.LocalFile.writeData(outFileName, contorlResults, "\t", false);
//                }
//                String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
//                LOG.info(info);
//            }
//
//        }
        indexLabels = new String[]{"ResponseVar", "ExplanatoryVar", "ResponseVarFuncScore"};
        alleleNumIndex = 0;
        String outFileName = options.outputFileName + ".gene.mutationburden.case";
        List<String[]> geneMutRateSheet;
        if (useLocalGeneScore) {
            geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(rHost, rPort, uniqueGenome, indexLabels, geneScoreMap,
                    refGeneVarFreqScoreMap, mafCut, scoreNames,
                    options.runnerGeneCoding || options.wrenerGeneNonCoding, options.refMutGeneFile,
                    options.independentGeneFeature.isEmpty(), options.needInteraction, orgCovNum, addedCovNum, options.threadNum, alleleNumIndex, usingLog, options.protectiveBurden);
            geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
                    options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
            caseResults.addAll(geneMutRateSheet);

        } else {
            if (isOneGene) {
                geneMutRateSheet = geneAnnotor.geneMutationRateTestChangeFreq(rHost, rPort, uniqueGenome, indexLabels, geneScoreMap, refGeneVarFreqScoreMap,
                        mafCut, scoreNames,
                        options.runnerGeneCoding || options.wrenerGeneNonCoding, options.refMutGeneFile,
                        options.independentGeneFeature.isEmpty(), options.needInteraction, orgCovNum, addedCovNum, options.threadNum, alleleNumIndex, usingLog, options.protectiveBurden);
            } else {
                String ppiDBFile = options.PUBDB_FILE_MAP.get("string");
                geneMutRateSheet = geneAnnotor.PPIMutationRateTestChangeFreq(rHost, rPort, uniqueGenome, indexLabels, geneScoreMap, refGeneVarFreqScoreMap,
                        mafCut, scoreNames,
                        options.runnerGeneCoding || options.wrenerGeneNonCoding, options.refMutGeneFile,
                        options.independentGeneFeature.isEmpty(), options.needInteraction, orgCovNum, addedCovNum, options.threadNum, alleleNumIndex,
                        GlobalManager.RESOURCE_PATH + "/" + ppiDBFile, options.protectiveBurden);
            }

            geneAnnotor.annotateGeneDrawQQPlot(geneMutRateSheet, options.genePCut,
                    options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, outFileName);
            caseResults.addAll(geneMutRateSheet);
        }
        boolean noWeightScore = false;
        if (noWeightScore) {
            //  dsdsd
            int geneNum = caseResults.size();
            List<String[]> tmpList = new ArrayList<String[]>();
            String[] cells1, cells2;
            int scoreIndex = 2;
            for (int i = 0; i < geneNum; i++) {
                cells1 = caseResults.get(i);
                cells2 = new String[cells1.length - 1];
                System.arraycopy(cells1, 0, cells2, 0, scoreIndex);
                System.arraycopy(cells1, scoreIndex + 1, cells2, scoreIndex, cells2.length - scoreIndex);
                tmpList.add(cells2);
            }
            caseResults.clear();
            caseResults.addAll(tmpList);
            tmpList.clear();
        }
        if (needOutputFile && geneMutRateSheet != null && !geneMutRateSheet.isEmpty()) {
            if (options.excelOut) {
                outFileName += ".xlsx";
                LocalExcelFile.writeArray2XLSXFile(outFileName, caseResults, true, -1, 0);
            } else {
                outFileName += ".txt";
                org.cobi.util.text.LocalFile.writeData(outFileName, caseResults, "\t", false);
            }
            String info = "The results of gene-based mutation rate test are saved in " + (new File(outFileName)).getCanonicalPath() + "!";
            LOG.info(info);
        }
        return indexLabels;
    }

}
