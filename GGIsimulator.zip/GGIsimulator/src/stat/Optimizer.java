package stat;//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.function.BiFunction;
import java.util.function.Function;

/**
 * @author suranyi
 */

public class Optimizer {
//    private static final Logger LOG = LoggerFactory.getLogger(stat.Optimizer.class);

    /**
     * 适应度函数
     */
    private final Function<double[], Double> fitness;

    /**
     * 子代解生成器, 默认: 随机解、交叉解、梯度解、混合解
     */
    private final BiFunction<Unit[], Random, double[]>[] generator;

    /**
     * 储存的中间解个数
     */
    private final int popSize;

    /**
     * 最大迭代次数
     */
    private final int maxIter;

    /**
     * 精英个体比例 (精英比例不能太高也不能太低. 太高会丧失解的多样性, 太低会导致模型难以产生有效的子代)
     */
    private final double eliteProb;

    /**
     * 显示日志
     */
    private final boolean display;

    /**
     * 期望的最优解
     */
    private final double bestObj;

    /**
     * 随机数发生器
     */
    private final Random random;

    /**
     * 取值范围, 默认为 0 ~ 1
     */
    private final double[][] bounds;

    /**
     * 精度
     */
    private final int precision;

    /**
     * 初始解, 可以用于将先验信息加入模型
     */
    private final ArrayList<double[]> initPops;

    private Optimizer(Builder builder) {
        fitness = builder.fitness;
        popSize = builder.popSize;
        maxIter = builder.maxIter;
        eliteProb = builder.eliteProb;
        display = builder.display;
        bestObj = builder.bestObj;
        bounds = builder.bounds;
        random = new Random(builder.seed);
        initPops = builder.initPops;
        generator = builder.generator;
        precision = builder.precision;
    }

    /**
     * 排序
     */
    private void eliteSelect(Unit[] pop) {
        Arrays.sort(pop);
    }

    /**
     * 运行最优化
     *
     * @return 最优解
     */
    public double[] run() {
        // 计算精英个体数量
        int eliteNum = (int) (eliteProb * popSize);

        // step 1: 创建初始种群
        int index = 0;
        ArrayList<Unit> pop = new ArrayList<>(popSize);

        if (this.initPops.size() > 0) {
            double[] vec = setPrecision(this.initPops.get(index));
            pop.add(new Unit(vec, fitness.apply(vec)));
        }

        for (int i = index; i < popSize; i++) {
            double[] vec = setPrecision(Unit.generate(random, bounds));
            pop.add(new Unit(vec, fitness.apply(vec)));
        }

        // step 2: 开始迭代
        for (int i = 0; i < maxIter; i++) {
            // step 3: 解排序
            pop.sort(Unit::compareTo);

            // 显示数据
            if (display) {
                System.out.printf("This is NO.%d iteration, the optimal solution is %s, f(x)=%g \n", i + 1, Arrays.toString(pop.get(0).vec), pop.get(0).lossValue);

//                LOG.info(String.format("This is NO.%d iteration, the optimal solution is %s, f(x)=%g", i + 1, Arrays.toString(pop.get(0).vec), pop.get(0).lossValue));
            }

            // 如果达到了指定的最优解或最大迭代次数,则结束搜索
            if (pop.get(0).lossValue <= bestObj || i == maxIter - 1) {
                break;
            }

            // step 4: 生成新的子代个体
            ArrayList<Unit> newPop = new ArrayList<>(popSize);

            // 保留精英个体
            Unit[] elitePop = new Unit[eliteNum];
            for (int j = 0; j < eliteNum; j++) {
                elitePop[j] = pop.get(j);
                newPop.add(elitePop[j]);
            }

            // 进行变异和交叉
            while (newPop.size() < popSize) {
                // 随机选择一个子代生成器
                double[] vec = setPrecision(generator[random.nextInt(this.generator.length)].apply(elitePop, random));
                newPop.add(new Unit(vec, fitness.apply(vec)));
            }
            pop = newPop;
        }

        // 输出最后结果
        if (display) {
            System.out.printf("Optimal Solution: %s, Fitness Value: %g \n", Arrays.toString(pop.get(0).vec), pop.get(0).lossValue);
//            LOG.info(String.format("Optimal Solution: %s, Fitness Value: %g", Arrays.toString(pop.get(0).vec), pop.get(0).lossValue));
        }
        return pop.get(0).vec;
    }

    double[] setPrecision(double[] vec) {
        for (int i = 0; i < vec.length; i++) {
            vec[i] = BigDecimal.valueOf(vec[i]).setScale(precision, RoundingMode.FLOOR).doubleValue();

            if (vec[i] < bounds[i][0]) {
                vec[i] = bounds[i][0];
            }
        }
        return vec;
    }

    public static class Builder {
        // 构建方法
        private final Function<double[], Double> fitness;
        private BiFunction<Unit[], Random, double[]>[] generator;
        private int popSize;
        private int maxIter;
        private double eliteProb;
        private double stepRatio;
        private double bestObj;
        private boolean display;
        private long seed;
        private double[][] bounds;
        private int precision;
        private final ArrayList<double[]> initPops = new ArrayList<>();

        public Builder(Function<double[], Double> fitness, int numOfVariables) {
            this.fitness = fitness;

            // 默认参数
            popSize = 50;
            maxIter = 200;
            eliteProb = 0.2d;
            stepRatio = 0.001d;
            bestObj = 0;
            precision = 20;
            display = false;
            seed = System.nanoTime();
            bounds = new double[numOfVariables][2];

            for (int i = 0; i < numOfVariables; i++) {
                bounds[i][0] = 0;
                bounds[i][1] = 1;
            }

            this.generator = new BiFunction[4];

            // 随机解生成器
            this.generator[0] = (units, random) -> Unit.generate(random, bounds);

            // 交叉解生成器
            this.generator[1] = (units, random) -> {
                if (units[0].vec.length == 1) {
                    double[] vec = new double[1];
                    Unit unit1 = units[random.nextInt(units.length)];
                    Unit unit2 = units[random.nextInt(units.length)];
                    vec[0] = (unit1.vec[0] + unit2.vec[0]) / 2;
                    return vec;
                } else if (units[0].vec.length == 2) {
                    double[] vec = new double[2];
                    Unit unit1 = units[random.nextInt(units.length)];
                    Unit unit2 = units[random.nextInt(units.length)];
                    vec[0] = unit1.vec[0];
                    vec[1] = unit2.vec[1];
                    return vec;
                } else {
                    double[] vec = new double[units[0].vec.length];

                    // 不含首尾
                    int index = random.nextInt(vec.length - 2) + 1;
                    Unit unit1 = units[random.nextInt(units.length)];
                    Unit unit2 = units[random.nextInt(units.length)];

                    System.arraycopy(unit1.vec, index, vec, 0, vec.length - index);
                    System.arraycopy(unit2.vec, 0, vec, vec.length - index, index);
                    return vec;
                }
            };

            // 梯度解生成器
            this.generator[2] = (units, random) -> {
                Unit unit1 = units[random.nextInt(units.length)];
                double[] vec = unit1.vec.clone();

                for (int i = 0; i < vec.length; i++) {
                    float status = random.nextFloat();
                    if (status < 0.333333) {
                        vec[i] = vec[i] + stepRatio * (bounds[i][1] - bounds[i][0]);
                        if (vec[i] > bounds[i][1]) {
                            vec[i] = bounds[i][1];
                        }

                    } else if (status < 0.666666) {
                        vec[i] = vec[i] - stepRatio * (bounds[i][1] - bounds[i][0]);
                        if (vec[i] < bounds[i][0]) {
                            vec[i] = bounds[i][0];
                        }
                    }
                }

                return vec;
            };

            // 混合解生成器
            this.generator[3] = (units, random) -> {
                Unit unit1 = units[random.nextInt(units.length)];
                Unit unit2 = units[random.nextInt(units.length)];
                double[] vec = new double[unit1.vec.length];
                for (int i = 0; i < vec.length; i++) {
                    vec[i] = (unit1.vec[i] + unit2.vec[i]) / 2;
                }
                return vec;
            };
        }

        public Builder setGenerator(BiFunction<Unit[], Random, double[]>[] generator) {
            this.generator = generator;
            return this;
        }

        @SafeVarargs
        public final Builder addGenerator(BiFunction<Unit[], Random, double[]>... generators) {
            BiFunction<Unit[], Random, double[]>[] newGenerators = new BiFunction[this.generator.length + generators.length];
            System.arraycopy(this.generator, 0, newGenerators, 0, this.generator.length);
            System.arraycopy(generators, 0, newGenerators, this.generator.length, generators.length);
            this.generator = newGenerators;
            return this;
        }

        public Builder setPrecision(int precision) {
            if (popSize < 0) {
                throw new UnsupportedOperationException("precision >= 0");
            }

            this.precision = precision;
            return this;
        }

        public Builder addInitPop(double[] vec) {
            this.initPops.add(vec);
            return this;
        }

        public Builder setPopSize(int popSize) {
            if (popSize < 10) {
                throw new UnsupportedOperationException("popSize >= 10");
            }

            this.popSize = popSize;
            return this;
        }

        public Builder setMaxIter(int maxIter) {
            if (maxIter < 1) {
                throw new UnsupportedOperationException("maxIter >= 1");
            }

            this.maxIter = maxIter;
            return this;
        }

        public Builder setEliteProb(double eliteProb) {
            if (eliteProb <= 0 || eliteProb >= 1) {
                throw new UnsupportedOperationException("0 < eliteProb < 1");
            }

            this.eliteProb = eliteProb;
            return this;
        }

        public Builder setStepRatio(double stepRatio) {
            if (stepRatio <= 0 || stepRatio >= 1) {
                throw new UnsupportedOperationException("0 < stepRatio < 1");
            }

            this.stepRatio = stepRatio;
            return this;
        }

        public Builder setDisplay(boolean display) {
            this.display = display;
            return this;
        }

        public Builder setBestObj(float bestObj) {
            this.bestObj = bestObj;
            return this;
        }

        public Builder setSeed(long seed) {
            this.seed = seed;
            return this;
        }

        public Builder setBounds(double[][] bounds) {
            this.bounds = bounds;
            return this;
        }

        public Optimizer build() {
            return new Optimizer(this);
        }
    }

    /**
     * @author suranyi
     */
    static class Unit implements Comparable<Unit> {
        public double[] vec;
        public double lossValue;

        public Unit(double[] vec, double lossValue) {
            this.vec = vec;
            this.lossValue = lossValue;
        }

        public static double[] generate(Random random, double[][] bounds) {
            /* 生成一个随机解 */
            double[] vec = new double[bounds.length];
            for (int i = 0, l = vec.length; i < l; i++) {
                vec[i] = random.nextDouble() * (bounds[i][1] - bounds[i][0]) + bounds[i][0];
            }
            return vec;
        }

        @Override
        public int compareTo(Unit o) {
            return Double.compare(lossValue, o.lossValue);
        }
    }

    public static void main(String[] args) {
        new Builder(doubles -> Math.abs(doubles[0] * doubles[0] - 2), 1)
                .setBounds(new double[][]{new double[]{1, 2}})
                .setPrecision(6)
                .setDisplay(true)
                .build()
                .run();
    }
}

