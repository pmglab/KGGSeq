/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package text;

import java.io.*;
import java.nio.channels.Channels;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipException;

/**
 *
 * @author limx54
 */
public class LocalFileFunc {

    static public BufferedReader getBufferedReader(String filePath) throws Exception {
        BufferedReader br = null;
        File dataFile = new File(filePath);
        if (dataFile.exists()) {
            CharsetDecoder decoder = Charset.forName("UTF-8").newDecoder();
            decoder.onMalformedInput(CodingErrorAction.IGNORE);
            try {
                //br = new BufferedReader(new InputStreamReader(new GZIPInputStream(new FileInputStream(dataFile))));
                //This will work slightly better under multiplthread senarios
                br = new BufferedReader(Channels.newReader(Channels.newChannel(new GZIPInputStream(Channels.newInputStream(new RandomAccessFile(dataFile, "r").getChannel()))), decoder, 1024 * 1024));
            } catch (ZipException ex) {
                // br = new BufferedReader(new InputStreamReader(new FileInputStream(dataFile)));
                br = new BufferedReader(Channels.newReader(Channels.newChannel(Channels.newInputStream(new RandomAccessFile(dataFile, "r").getChannel())), decoder, 1024 * 1024));

            }
        } else {
            throw new Exception("No input file: " + dataFile.getCanonicalPath());
        }
        return br;
    }

    static public BufferedWriter getBufferedWriter(String filePath, boolean isGzip) throws Exception {
        BufferedWriter bw = null;
        File dataFile = new File(filePath);
//        if (!dataFile.getParentFile().exists()) {
//            dataFile.getParentFile().mkdirs();
//        }
        CharsetEncoder decoder = Charset.forName("UTF-8").newEncoder();
        decoder.onMalformedInput(CodingErrorAction.IGNORE);
        if (isGzip) {
            //This will work slightly better under multiplthread senarios
            // bw = new BufferedWriter(Channels.newWriter(Channels.newChannel(new GZIPOutputStream(Channels.newOutputStream(new RandomAccessFile(dataFile, "rw").getChannel()))), decoder, 1024 * 1024));
            //I do not know why the above function leads to a written file with ill formate 
            bw = new BufferedWriter(new OutputStreamWriter(new GZIPOutputStream(new FileOutputStream(dataFile))));
        } else {
            // br = new BufferedWriter(new InputStreamWriter(new FileInputStream(dataFile)));
            //bw = new BufferedWriter(Channels.newWriter(Channels.newChannel(Channels.newOutputStream(new RandomAccessFile(dataFile, "rw").getChannel())), decoder, 1024 * 1024));
            bw = new BufferedWriter(new FileWriter(dataFile));
        }
        return bw;
    }

}
