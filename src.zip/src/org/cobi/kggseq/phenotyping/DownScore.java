/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.phenotyping;

/**
 *
 * @author dell
 */
public class DownScore implements Comparable<DownScore> {

    public String geneName;
    public Double geneScore;

    public String getName() {
        return geneName;
    }

    public Double getScore() {
        return geneScore;
    }

    public void setName(String name) {
        geneName = name;
    }

    public void setScore(Double score) {
        geneScore = score;
    }

    public int compareTo(DownScore o) {//按score值降序排列，若相等，则按基因名升序排列
        double scoreDiff = o.geneScore - this.geneScore;
        int d;
        if (scoreDiff > 0) {
            d = 1;
        } else if (scoreDiff < 0) {
            d = -1;
        } else {
            d = 0;
        }
        return d == 0 ? (this.geneName.compareTo(o.geneName)) : d;
    }
}
