/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.phenotyping;

import org.cobi.util.graph.GeneGraphShort;
import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import static org.cobi.util.file.LocalFileFunc.getBufferedReader;

/**
 *
 * @author Hui Jiang
 */
public class TermRelatedHPO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {

        String hpFile = "./resources/hp.structure.txt.gz";
        String hpoaFile = "./resources/phenotype_annotation_hpoteam.tab.gz";
        String icFile = "./resources/gene.IC.txt.gz";
        String codingGeneFile = "./resources/ProCodingGene.hgnc20200220.txt.gz";
//        String inputTerm="autism;autistic";
//        String inputTerm="Alzheimer;Aged dementia;senile dementia";
        String inputTerm = "Hirschsprung;megacolon";
        //String inputTerm = "autism;autistic";
        String outDir = "./selectHP";

        //1.1 input disease names, return scored disease-related HP_ID
        HashSet<String> termSet = new HashSet<String>();
        ArrayList<DownScore> selectHP = new ArrayList<DownScore>();
        selectHP = new TermRelatedHPO().getRelatedHP(hpFile, hpoaFile, icFile, inputTerm, outDir, termSet);

        //1.2 input manually selected HP_ID, return scored HP_ID
        String inputHP = "HP:0000717;HP:0000729;HP:0000750;HP:0001249";
        HashSet<String> hpset = new HashSet<String>();
        ArrayList<DownScore> scoredHP = new ArrayList<DownScore>();
        scoredHP = new TermRelatedHPO().scoredHP(icFile, inputHP, outDir, hpset);
        //if input both disease name and HP_ID,combine two parts HP
        ArrayList<DownScore> combinedHP = new TermRelatedHPO().combineHP(selectHP, scoredHP);

        //calculate genes' disease relatedness scores
        HashSet<String> giantPath = new HashSet<String>();
        giantPath.add("/home/mxli/data/work/data/giant/brain_top.b.gz");
        String ericFile = "./resources/ERIC_setmax.txt.gz";
        GeneGraphShort gg = new GeneGraphShort();
        Map<String, String> symbolIDMap = gg.readHGNCGeneSymbolID("./resources");
        Map<Integer, String> idSymbolMap = gg.readHGNCGeneIDSymbol("./resources");
        Map<String, double[]> geneScoreMap = new HashMap<String, double[]>();
        List<String> giantPathList = new ArrayList<String>(giantPath);
        List<String> genes = new ArrayList<String>();
        genes.add("ZSCAN18");
        genes.add("OSBPL6");
        gg.extendERICscore(ericFile, genes, combinedHP, giantPathList, symbolIDMap, idSymbolMap, 2, geneScoreMap);
        int sss = 0;
    }

    public ArrayList<DownScore> combineHP(ArrayList<DownScore> selectHP, ArrayList<DownScore> scoredHP) {

        HashMap<String, Double> allHP = new HashMap<String, Double>();
        if (selectHP != null && !selectHP.isEmpty()) {
            for (DownScore ds : selectHP) {
                String name = ds.getName();
                double score = ds.getScore();
                if (allHP.containsKey(name)) {
                    allHP.put(name, score > allHP.get(name) ? score : allHP.get(name));
                } else {
                    allHP.put(name, score);
                }
            }
        }
        if (scoredHP != null && !scoredHP.isEmpty()) {
            for (DownScore ds : scoredHP) {
                String name = ds.getName();
                double score = ds.getScore();
                if (allHP.containsKey(name)) {
                    allHP.put(name, score > allHP.get(name) ? score : allHP.get(name));
                } else {
                    allHP.put(name, score);
                }
            }
        }
        ArrayList<DownScore> combinedHP = new ArrayList<DownScore>();
        for (String hp : allHP.keySet()) {
            DownScore ds = new DownScore();
            ds.setName(hp);
            ds.setScore(allHP.get(hp));
            combinedHP.add(ds);
        }
        Collections.sort(combinedHP);
        return combinedHP;

    }

    public ArrayList<DownScore> scoredHP(String icFile, String inputHP, String outDir, HashSet<String> hpset) throws Exception {
        // multiple terms should be delimited by ";" or Enter
        if (inputHP.contains(";") || inputHP.contains("\t")) {
            String[] terms = inputHP.split(";|\t");
            for (String term : terms) {
                hpset.add(term.trim());
            }
        } else {
            hpset.add(inputHP);
        }

        HashMap<String, Double> hpIC = readICfile(icFile);
        ArrayList<DownScore> sortHP = new ArrayList<DownScore>();
        for (String hp : hpset) {
            double ic = hpIC.containsKey(hp) ? hpIC.get(hp) : 7.96;//mean of IC score:7.96
            DownScore ds = new DownScore();
            ds.setName(hp);
            ds.setScore(ic);
            sortHP.add(ds);
        }
        Collections.sort(sortHP);
        return sortHP;
    }

    public ArrayList<DownScore> scoredHP(String icFile, String[] inputHP, HashSet<String> hpset) throws Exception {
        // multiple terms should be delimited by ";" or Enter
        for (String term : inputHP) {
            hpset.add(term.trim());
        }

        HashMap<String, Double> hpIC = readICfile(icFile);
        ArrayList<DownScore> sortHP = new ArrayList<DownScore>();
        for (String hp : hpset) {
            double ic = hpIC.containsKey(hp) ? hpIC.get(hp) : 7.96;//mean of IC score:7.96
            DownScore ds = new DownScore();
            ds.setName(hp);
            ds.setScore(ic);
            sortHP.add(ds);
        }
        Collections.sort(sortHP);
        return sortHP;
    }

    public ArrayList<DownScore> getRelatedHP(String hpFile, String hpoaFile, String icFile, String inputTerm, String outDir, HashSet<String> termSet) throws Exception {

//        String ericFile="./resources/ERIC_setmax.txt";
//        String outFile=outDir+File.separator+"tmp"+File.separator+"inputTerm.relatedHP.txt";
        // multiple terms should be delimited by ";" or Enter
        if (inputTerm.contains(";") || inputTerm.contains("\t")) {
            String[] terms = inputTerm.split(";|\t");
            for (String term : terms) {
                termSet.add(term.trim());
            }
        } else {
            termSet.add(inputTerm);
        }

        //first read: construct map for hpID2name
        HashMap<String, String> hpID2name = new HashMap<String, String>();
        BufferedReader brhp = getBufferedReader(hpFile);
        brhp.readLine();
        String line = null;
        HashSet<String> newTermSet = new HashSet<String>();
        while ((line = brhp.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String offspring = cell[0] + ";" + cell[2];

            //construct map for hpID2name
            for (String o : offspring.split(";")) {
                hpID2name.put(o, cell[1]);
            }
            //enlarge termSet
            for (String term : termSet) {
                String hpName = cell[1] + ";" + cell[3];
                if (hpName.toLowerCase().contains(term.toLowerCase())) {
                    for (String n : hpName.split(";")) {
                        int upperCount = 0;
                        for (int i = 0; i < n.length(); i++) {
                            if (Character.isUpperCase(n.charAt(i))) {
                                upperCount++;
                            }
                        }
                        if (upperCount < n.length()) {//不考虑疾病或表型缩写名称，容易错配
                            newTermSet.add(n.trim().toLowerCase());
                        }

                    }
                }
            }
        }
        brhp.close();
        termSet.addAll(newTermSet);
        newTermSet.clear();
//        System.out.println(termSet.toString());

        //second read: select related HP and scored
        HashMap<String, Double> relatedHP = new HashMap<String, Double>();
        brhp = getBufferedReader(hpFile);
        brhp.readLine();
        while ((line = brhp.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String hpname = cell[1] + ";" + cell[3];
            String hp = cell[0] + ";" + cell[2];
            String def = cell[4];
            String isaHPname = cell[6];
            String isaHP = cell[5];
            for (String term : termSet) {
                if (hpname.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to HP_name or synonym---direct matched HP score=1.0
                    double hpScore = 1.0;
                    addRealtedHP(relatedHP, hp, hpScore);
                }
                if (isaHPname.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to is_a HP_name---direct matched HP score=1.0
                    double hpScore = 1.0;
                    String[] subCell = isaHPname.split(";");
                    for (int i = 0; i < subCell.length; i++) {
                        if (subCell[i].toLowerCase().contains(term.toLowerCase())) {
                            String matchHP = isaHP.split(";")[i];
                            addRealtedHP(relatedHP, matchHP, hpScore);
                        }
                    }

                }
                if (def.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to hp_def---direct matched HP score=0.8
                    double hpScore = 0.8;
                    addRealtedHP(relatedHP, hp, hpScore);
                }
            }
        }
        brhp.close();
//        System.out.println("after hp matching: "+relatedHP.size());

        HashMap<String, HashSet<String>> disHPset = readHpoaFile(hpoaFile);
        HashMap<String, Double> disRelatedHP = new HashMap<String, Double>();
        int macthedDis = 0;
        double maxMatchDisScore = 0;
        for (String d : disHPset.keySet()) {
            for (String term : termSet) {
                if (d.toLowerCase().contains(term.toLowerCase())) {//disease name contains term
                    macthedDis++;
                    List<String> hps = new ArrayList<String>();
                    for (String hp : disHPset.get(d)) {
                        if (!hp.equals("")) {
                            hps.add(hp);
                        }
                    }
                    double s = 1.0 / Double.valueOf(hps.size());
                    maxMatchDisScore += s;
                    for (String hp : hps) {
                        if (disRelatedHP.containsKey(hp)) {
                            double score = disRelatedHP.get(hp) + s;
                            disRelatedHP.put(hp, score);
                        } else {
                            double score = s;
                            disRelatedHP.put(hp, score);
                        }
                    }
                    break;//each diseae only count once
                }

            }
        }
        double cutoff = maxMatchDisScore / 2;
        for (String hp : disRelatedHP.keySet()) {
            if (disRelatedHP.get(hp) < cutoff) {
                continue;
            }
            double s = disRelatedHP.get(hp) > 1 ? 1 : disRelatedHP.get(hp);
            if (relatedHP.containsKey(hp)) {
                double score = relatedHP.get(hp) + s;
                relatedHP.put(hp, score);
            } else {
                double score = s;
                relatedHP.put(hp, score);
            }
        }
        disRelatedHP.clear();
//        System.out.println("after disease matching: "+relatedHP.size());

        //combine hp IC score
        HashMap<String, Double> hpIC = readICfile(icFile);
        ArrayList<DownScore> sortHP = new ArrayList<DownScore>();
        for (String hp : relatedHP.keySet()) {
            double ic = hpIC.containsKey(hp) ? hpIC.get(hp) : 7.96;//mean of IC score:7.96
            DownScore ds = new DownScore();
            ds.setName(hp);
            ds.setScore(relatedHP.get(hp) * ic);
            sortHP.add(ds);
        }
        Collections.sort(sortHP);

        /*//write to file
        BufferedWriter bw=getBufferedWriter(outFile,false);
        for(DownScore ds:sortHP){
            bw.write(ds.getName()+"\t"+hpID2name.get(ds.getName())+"\t"+ds.getScore()+"\n");
        }
        bw.close();*/
        return sortHP;
    }

    public ArrayList<DownScore> getRelatedHP(String hpFile, String hpoaFile, String icFile, String[] inputTerms, HashSet<String> termSet) throws Exception {
        for (String term : inputTerms) {
            termSet.add(term.trim());
        }

        //first read: construct map for hpID2name
        HashMap<String, String> hpID2name = new HashMap<String, String>();
        BufferedReader brhp = getBufferedReader(hpFile);
        brhp.readLine();
        String line = null;
        HashSet<String> newTermSet = new HashSet<String>();
        while ((line = brhp.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String offspring = cell[0] + ";" + cell[2];

            //construct map for hpID2name
            for (String o : offspring.split(";")) {
                hpID2name.put(o, cell[1]);
            }
            //enlarge termSet
            for (String term : termSet) {
                String hpName = cell[1] + ";" + cell[3];
                if (hpName.toLowerCase().contains(term.toLowerCase())) {
                    for (String n : hpName.split(";")) {
                        int upperCount = 0;
                        for (int i = 0; i < n.length(); i++) {
                            if (Character.isUpperCase(n.charAt(i))) {
                                upperCount++;
                            }
                        }
                        if (upperCount < n.length()) {//不考虑疾病或表型缩写名称，容易错配
                            newTermSet.add(n.trim().toLowerCase());
                        }

                    }
                }
            }
        }
        brhp.close();
        termSet.addAll(newTermSet);
        newTermSet.clear();
//        System.out.println(termSet.toString());

        //second read: select related HP and scored
        HashMap<String, Double> relatedHP = new HashMap<String, Double>();
        brhp = getBufferedReader(hpFile);
        brhp.readLine();
        while ((line = brhp.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String hpname = cell[1] + ";" + cell[3];
            String hp = cell[0] + ";" + cell[2];
            String def = cell[4];
            String isaHPname = cell[6];
            String isaHP = cell[5];
            for (String term : termSet) {
                if (hpname.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to HP_name or synonym---direct matched HP score=1.0
                    double hpScore = 1.0;
                    addRealtedHP(relatedHP, hp, hpScore);
                }
                if (isaHPname.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to is_a HP_name---direct matched HP score=1.0
                    double hpScore = 1.0;
                    String[] subCell = isaHPname.split(";");
                    for (int i = 0; i < subCell.length; i++) {
                        if (subCell[i].toLowerCase().contains(term.toLowerCase())) {
                            String matchHP = isaHP.split(";")[i];
                            addRealtedHP(relatedHP, matchHP, hpScore);
                        }
                    }

                }
                if (def.toLowerCase().contains(term.toLowerCase())) {
                    //term is matched to hp_def---direct matched HP score=0.8
                    double hpScore = 0.8;
                    addRealtedHP(relatedHP, hp, hpScore);
                }
            }
        }
        brhp.close();
//        System.out.println("after hp matching: "+relatedHP.size());

        HashMap<String, HashSet<String>> disHPset = readHpoaFile(hpoaFile);
        HashMap<String, Double> disRelatedHP = new HashMap<String, Double>();
        int macthedDis = 0;
        double maxMatchDisScore = 0;
        for (String d : disHPset.keySet()) {
            for (String term : termSet) {
                if (d.toLowerCase().contains(term.toLowerCase())) {//disease name contains term
                    macthedDis++;
                    List<String> hps = new ArrayList<String>();
                    for (String hp : disHPset.get(d)) {
                        if (!hp.equals("")) {
                            hps.add(hp);
                        }
                    }
                    double s = 1.0 / Double.valueOf(hps.size());
                    maxMatchDisScore += s;
                    for (String hp : hps) {
                        if (disRelatedHP.containsKey(hp)) {
                            double score = disRelatedHP.get(hp) + s;
                            disRelatedHP.put(hp, score);
                        } else {
                            double score = s;
                            disRelatedHP.put(hp, score);
                        }
                    }
                    break;//each diseae only count once
                }

            }
        }
        double cutoff = maxMatchDisScore / 2;
        for (String hp : disRelatedHP.keySet()) {
            if (disRelatedHP.get(hp) < cutoff) {
                continue;
            }
            double s = disRelatedHP.get(hp) > 1 ? 1 : disRelatedHP.get(hp);
            if (relatedHP.containsKey(hp)) {
                double score = relatedHP.get(hp) + s;
                relatedHP.put(hp, score);
            } else {
                double score = s;
                relatedHP.put(hp, score);
            }
        }
        disRelatedHP.clear();
//        System.out.println("after disease matching: "+relatedHP.size());

        //combine hp IC score
        HashMap<String, Double> hpIC = readICfile(icFile);
        ArrayList<DownScore> sortHP = new ArrayList<DownScore>();
        for (String hp : relatedHP.keySet()) {
            double ic = hpIC.containsKey(hp) ? hpIC.get(hp) : 7.96;//mean of IC score:7.96
            DownScore ds = new DownScore();
            ds.setName(hp);
            ds.setScore(relatedHP.get(hp) * ic);
            sortHP.add(ds);
        }
        Collections.sort(sortHP);

        /*//write to file
        BufferedWriter bw=getBufferedWriter(outFile,false);
        for(DownScore ds:sortHP){
            bw.write(ds.getName()+"\t"+hpID2name.get(ds.getName())+"\t"+ds.getScore()+"\n");
        }
        bw.close();*/
        return sortHP;
    }

    public HashMap<String, Double> addRealtedHP(HashMap<String, Double> relatedHP, String hps, double hpScore) {
        ArrayList<String> hpList = new ArrayList<String>();
        if (hps.contains(";")) {
            for (String hp : hps.split(";")) {
                hpList.add(hp);
            }
        } else {
            hpList.add(hps);
        }
        for (String hp : hpList) {
            //set matched HP as preSet score
            if (relatedHP.containsKey(hp)) {
                double maxScore = relatedHP.get(hp) > hpScore ? relatedHP.get(hp) : hpScore;
                relatedHP.put(hp, maxScore);
            } else {
                relatedHP.put(hp, hpScore);
            }
        }
        return relatedHP;
    }

    public HashMap<String, HashSet<String>> readHpoaFile(String hpoaFile) throws Exception {
        HashMap<String, HashSet<String>> disHPset = new HashMap<String, HashSet<String>>();
        BufferedReader br = getBufferedReader(hpoaFile);
        String line = null;
        int hpIndex = 4;
        int onsetHpIndex = 8;
        int aspectIndex = 10;
        HashSet<String> hpset = new HashSet<String>();
        String[] firstLine = br.readLine().split("\t", -1);
        String firstDis = firstLine[0] + ":" + firstLine[1];
        String firstDisname = firstLine[2];
        String hp = firstLine[hpIndex];
        String onsetHP = firstLine[onsetHpIndex];
        String aspect = firstLine[aspectIndex];
        if (aspect.equals("P")) {
            hpset.add(hp);
            hpset.add(onsetHP);
        }
        while ((line = br.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            String dis = cell[0] + ":" + cell[1];
            String disName = cell[2];
            hp = cell[hpIndex];
            onsetHP = cell[onsetHpIndex];
            aspect = cell[aspectIndex];
            if (!aspect.equals("P")) {
                continue;
            }
            if (dis.equals(firstDis)) {
                //continue add disease-related HP to hpset
                hpset.add(hp);
                hpset.add(onsetHP);
            } else {
                //add disease and its-related HP to map
                if (!hpset.isEmpty()) {
                    disHPset.put(firstDis + "\t" + firstDisname, hpset);
                }
                //reset
                firstDis = dis;
                firstDisname = disName;
                hpset = new HashSet<String>();
                hpset.add(hp);
                hpset.add(onsetHP);
            }
        }
        br.close();
        //add last disease and its-related HP to map
        if (!hpset.isEmpty()) {
            disHPset.put(firstDis + "\t" + firstDisname, hpset);
        }
        return disHPset;
    }

    public HashMap<String, Double> readICfile(String icFile) throws Exception {
        HashMap<String, Double> hpIC = new HashMap<String, Double>();
        BufferedReader br = getBufferedReader(icFile);
        String line = null;
        double mean = 0;
        while ((line = br.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            hpIC.put(cell[0], Double.parseDouble(cell[1]));
            mean += Double.parseDouble(cell[1]);
        }
//        System.out.println("mean of IC score: "+mean/Double.valueOf(hpIC.size()));
        br.close();
        return hpIC;
    }

    public HashSet<String> readHPGeneFile(String file) throws Exception {
        HashSet<String> aviHP = new HashSet<String>();
        BufferedReader br = getBufferedReader(file);
        br.readLine();
        String line = null;
        while ((line = br.readLine()) != null) {
            String[] cell = line.split("\t", -1);
            aviHP.add(cell[0]);
        }
        br.close();
        return aviHP;
    }
}
