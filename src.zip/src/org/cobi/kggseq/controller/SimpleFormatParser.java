/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import java.io.BufferedReader;
import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.Variant;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.text.Util;

/**
 *
 * @author mxli
 */
public class SimpleFormatParser {

  private static final Logger LOG = Logger.getLogger(SimpleFormatParser.class);

  public Genome readCancerGenomeVariantFormat(String tmpGenomePath, String vAFile, boolean needProgressionIndicator) throws Exception {

    String currentLine = null;
    String currChr = null;
    StringBuilder tmpBuffer = new StringBuilder();
    long lineCounter = 0;

    File dataFile = new File(vAFile);
    if (!dataFile.exists()) {
      throw new Exception("No input of variants: " + dataFile.getCanonicalPath());
    }

    BufferedReader br = LocalFileFunc.getBufferedReader(dataFile.getCanonicalPath());

    int makerPostionStart = 0;
    int makerPostionEnd = 0;

    String ref = null;
    String alt = null;
    boolean incomplete = true;
    int acceptVarNum = 0;

    int iCol = 0;
    //temp variables
    int indelNum = 0;
    boolean isIndel = false;

    StringBuilder sb = new StringBuilder();
    String comments = null;
    Integer count;
    String[] tumorAllele = new String[2];

    Map<String, Integer> varCountMap = new HashMap<String, Integer>();
    int avialbleFeatureIndex = 0;
    try {
      iCol = 0;
//skip head line
      currentLine = br.readLine();

      int indexCHROM = -1;
      int indexPosStart = -1;
      int indexPosEnd = -1;
      int indexREF = -1;
      int indexAllele2 = -1;
      int indexType = -1;
      int indexCount = -1;
      int indexAllele1 = -1;

      StringTokenizer st = new StringTokenizer(currentLine.trim());
      while (st.hasMoreTokens()) {
        String ts = st.nextToken().trim();
        if (ts.equals("chr") || ts.equals("Chromosome")) {
          indexCHROM = iCol;
        } else if (ts.equals("pos") || ts.equals("Start_Position")) {
          indexPosStart = iCol;
        } else if (ts.equals("pos") || ts.equals("End_Position")) {
          indexPosEnd = iCol;
        } else if (ts.equals("ref_allele") || ts.equals("Reference_Allele")) {
          indexREF = iCol;
        } else if (ts.equals("Tumor_Seq_Allele1") || ts.equals("Tumor_Allele1")) {
          indexAllele1 = iCol;
        } else if (ts.equals("newbase") || ts.equals("Tumor_Allele") || ts.equals("Tumor_Seq_Allele2") || ts.equals("Tumor_Allele2")) {
          indexAllele2 = iCol;
        } else if (ts.equals("classification") || ts.equals("Variant_Classification")) {
          indexType = iCol;
        } else if (ts.equals("count") || ts.equals("Count")) {
          indexCount = iCol;
        }
        iCol++;
      }

      int maxColNum = indexCHROM;
      maxColNum = Math.max(maxColNum, indexPosStart);
      maxColNum = Math.max(maxColNum, indexPosEnd);
      maxColNum = Math.max(maxColNum, indexREF);
      maxColNum = Math.max(maxColNum, indexAllele1);
      maxColNum = Math.max(maxColNum, indexAllele2);
      maxColNum = Math.max(maxColNum, indexType);
      maxColNum = Math.max(maxColNum, indexCount);

      currentLine = br.readLine();
      if (currentLine == null) {
        return null;
      }
      do {
        lineCounter++;
        if (needProgressionIndicator && lineCounter % 10000 == 0) {
          String prog = String.valueOf(lineCounter);
          System.out.print(prog);
          char[] backSpaces = new char[prog.length()];
          Arrays.fill(backSpaces, '\b');
          System.out.print(backSpaces);
        }

        st = new StringTokenizer(currentLine.trim(), "\t"); //, " \t"
        // System.out.println(currentLine);

        //initialize varaibles
        incomplete = true;
        currChr = null;
        makerPostionStart = -1;
        makerPostionEnd = -1;
        ref = null;
        alt = null;
        isIndel = false;
        comments = null;
        count = null;
        Arrays.fill(tumorAllele, null);
        /*
                 0	1	2	3	4	5	6	7	8	9	10
                 ttype	patient	gene	classification	type	chr	pos	ref_allele	newbase	context65	cons46
                 BRCA	BR-0001	Unknown	SNP	IGR	1	102094413	T	C	62	50
                 BRCA	BR-0001	Unknown	SNP	IGR	1	105351609	T	C	49	50
                 BRCA	BR-0001	Unknown	SNP	IGR	1	105803301	T	G	49	51
                 BRCA	BR-0001	Unknown	SNP	IGR	1	106065970	G	A	34	51
                 BRCA	BR-0001	Unknown	SNP	IGR	1	106147918	T	C	49	52
                 BRCA	BR-0001	Unknown	SNP	IGR	1	111047687	A	G	1	55
                 BRCA	BR-0001	Unknown	DEL	IGR	1	111460251	TTTTTGTTTTTTTG	-	64	27
                 BRCA	BR-0001	RSBN1	SNP	Intron	1	114350413	G	A	48	39
                 BRCA	BR-0001	DENND2C	DEL	Intron	1	115091329	A	-	16	50
                
         */
        for (iCol = 0; iCol <= maxColNum; iCol++) {
          if (st.hasMoreTokens()) {
            tmpBuffer.delete(0, tmpBuffer.length());
            tmpBuffer.append(st.nextToken().trim());
            if (iCol == indexCHROM) {
              currChr = tmpBuffer.toString();
            } else if (iCol == indexPosStart) {
              makerPostionStart = Util.parseInt(tmpBuffer.toString());

            } else if (iCol == indexPosEnd) {
              makerPostionEnd = Util.parseInt(tmpBuffer.toString());
            } else if (iCol == indexREF) {
              ref = tmpBuffer.toString();
            } else if (iCol == indexAllele1) {
              tumorAllele[0] = tmpBuffer.toString();
            } else if (iCol == indexAllele2) {
              tumorAllele[1] = tmpBuffer.toString();
            } else if (iCol == indexType) {
              comments = tmpBuffer.toString();
              if (!comments.equals("SNP")) {
                // break;
              }
            } else if (iCol == indexCount) {
              count = Integer.parseInt(tmpBuffer.toString());
            }

          } else {
            break;
          }
          if (iCol >= maxColNum) {
            incomplete = false;
          }
        }

        if (incomplete) {
          continue;
        }

        //format in KGG
        if (currChr.toLowerCase().startsWith("chr")) {
          currChr = currChr.substring(3);
        }
        if (currChr.equals("23")) {
          currChr = "X";
        } else if (currChr.equals("24")) {
          currChr = "Y";
        } else if (currChr.equals("25")) {
          currChr = "M";
        }

        if (tumorAllele[0] != null && !tumorAllele[0].equals(ref)) {
          alt = tumorAllele[0];
          String label = currChr + ":" + makerPostionStart + ":" + makerPostionEnd + ":" + ref + ":" + alt;
          Integer count1 = varCountMap.get(label);
          if (count1 == null) {
            if (count == null) {
              varCountMap.put(label, 1);
            } else {
              varCountMap.put(label, count);
            }
          } else {
            if (count == null) {
              varCountMap.put(label, count1 + 1);
            } else {
              varCountMap.put(label, count1 + count);
            }
          }
        }

        if (tumorAllele[1] != null && !tumorAllele[1].equals(ref)) {
          alt = tumorAllele[1];
          String label = currChr + ":" + makerPostionStart + ":" + makerPostionEnd + ":" + ref + ":" + alt;
          Integer count1 = varCountMap.get(label);
          if (count1 == null) {
            if (count == null) {
              varCountMap.put(label, 1);
            } else {
              varCountMap.put(label, count);
            }
          } else {
            if (count == null) {
              varCountMap.put(label, count1 + 1);
            } else {
              varCountMap.put(label, count + count1);
            }
          }
        }
        acceptVarNum++;
        // if (acceptVarNum==10000) break;
      } while ((currentLine = br.readLine()) != null);

    } catch (NumberFormatException nex) {
      String info = nex.toString() + " when parsing at line " + lineCounter + ": " + currentLine;
      // LOG.error(nex, info);
      throw new Exception(info);
    }
    br.close();

    StringBuilder message = new StringBuilder();
    message.append(lineCounter).append(" lines are scanned in ").append(vAFile).append("; and ").append(acceptVarNum).append(" variants (").append(indelNum).append(" indels) are retained.");
    LOG.info(message);
    if (acceptVarNum == 0) {
      System.exit(1);
    }

    Genome genome = new Genome("Simple", tmpGenomePath);
    genome.addVariantFeatureLabel("SomaticAltAllele");
    String altAllele;
    String[] altAllelesIndexes;
    StringBuilder tmpSB = new StringBuilder();
    int t = 0;
    boolean invalid;
    for (Map.Entry<String, Integer> item : varCountMap.entrySet()) {
      String[] varInfo = item.getKey().split(":");
      makerPostionStart = Util.parseInt(varInfo[1]);

      ref = varInfo[3];
      altAllele = varInfo[4];
      altAllelesIndexes = altAllele.split(",");

      invalid = false;
      isIndel = false;

      if (ref.equals("-")) {
        //insertion
        ref = ".";
        makerPostionStart--;
        for (int ss = 0; ss < altAllelesIndexes.length; ss++) {
          altAllelesIndexes[ss] = "+" + altAllelesIndexes[ss];
        }
        Variant var = new Variant(makerPostionStart, ref, altAllelesIndexes);
        var.setFeatureValue(avialbleFeatureIndex, item.getValue().toString());
        genome.addVariant(varInfo[0], var);
        continue;
      } else if (altAllele.equals("-")) {
        //deletion
        for (int ss = 0; ss < altAllelesIndexes.length; ss++) {
          altAllelesIndexes[ss] = "-" + ref;
        }
        ref = ".";
        Variant var = new Variant(makerPostionStart, ref, altAllelesIndexes);
        var.setFeatureValue(avialbleFeatureIndex, item.getValue().toString());
        genome.addVariant(varInfo[0], var);
        makerPostionStart--;
        continue;
      }

      for (int ss = 0; ss < altAllelesIndexes.length; ss++) {
        alt = altAllelesIndexes[ss];
        //only one alternative alleles; the most common  scenario
        if (ref.length() == alt.length()) {
          //substitution
          //now it can sonsider double polymorphsom
          altAllelesIndexes[ss] = alt;
        } else if (ref.length() < alt.length()) {
          //insertion
          /*examples 
                         insertion1
                         chr1 1900106 . TCT TCTCCT 217 . INDEL;DP=62;AF1=0.5;CI95=0.5,0.5;DP4=17,9,18,12;MQ=60;FQ=217;PV4=0.78,1,1,0.1 GT:PL:DP:SP:GQ 0/1:255,0,255:56:-991149567:99
                        
                         insertion2
                         chr1 109883576 . C CAT 214 . INDEL;DP=15;AF1=1;CI95=1,1;DP4=0,0,1,11;MQ=60;FQ=-70.5 GT:PL:DP:SP:GQ 1/1:255,36,0:12:-991149568:69
                         * 
           */
          //for Indel TTCC TT--
          //for Insertion T +TTTT
          tmpSB.delete(0, tmpSB.length());
          if (alt.startsWith(ref)) {
            for (t = ref.length(); t > 0; t--) {
              tmpSB.append('+');
            }
            tmpSB.append(alt.substring(ref.length()));
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (alt.endsWith(ref)) {
            tmpSB.append(alt.substring(0, alt.length() - ref.length()));
            for (t = ref.length(); t > 0; t--) {
              tmpSB.append('+');
            }
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (alt.charAt(0) == ref.charAt(0)) {
            int startI = 0;
            int len1 = Math.min(alt.length(), ref.length());
            while (startI < len1) {
              if (alt.charAt(startI) != ref.charAt(startI)) {
                break;
              }
              startI++;
            }
            for (t = startI; t > 0; t--) {
              tmpSB.append('+');
            }
            tmpSB.append(alt.substring(startI));
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (alt.charAt(alt.length() - 1) == ref.charAt(ref.length() - 1)) {
            int startI = 0;
            int len1 = Math.min(alt.length(), ref.length());
            int lenA = alt.length() - 1;
            int lenR = ref.length() - 1;
            while (startI < len1) {
              if (alt.charAt(lenA - startI) != ref.charAt(lenR - startI)) {
                break;
              }
              startI++;
            }
            tmpSB.append(alt.substring(0, alt.length() - startI));
            for (t = startI; t > 0; t--) {
              tmpSB.append('+');
            }
            altAllelesIndexes[ss] = tmpSB.toString();
          } else {
            invalid = true;
          }

          isIndel = true;
        } else if (ref.length() > alt.length()) {
          //deletion     
          /*examples
                         deletion1
                         chr1 113659065 . ACTCT ACT 214 . INDEL;DP=61;AF1=1;CI95=1,1;DP4=0,0,22,34;MQ=60;FQ=-204 GT:PL:DP:SP:GQ 1/1:255,169,0:56:-991149568:99
                         deletion2
                         chr1 1289367 . CTG C 101 . INDEL;DP=14;AF1=0.5;CI95=0.5,0.5;DP4=5,2,5,1;MQ=60;FQ=104;PV4=1,0.4,1,1 GT:PL:DP:SP:GQ 0/1:139,0,168:13:-991149568:99
           */
          //Note it can work for multiple deletion alleles like:chr1	158164305	.	TAA	TA,T

          //for Indel TTCC TT--
          //for Insertion T +TTTT
          tmpSB.delete(0, tmpSB.length());
          if (ref.startsWith(alt)) {
            tmpSB.append(alt);
            for (t = ref.length() - alt.length(); t > 0; t--) {
              tmpSB.append('-');
            }
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (ref.endsWith(alt)) {
            for (t = ref.length() - alt.length(); t > 0; t--) {
              tmpSB.append('-');
            }
            tmpSB.append(alt);
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (alt.charAt(0) == ref.charAt(0)) {
            tmpSB.append(alt);
            for (t = ref.length() - alt.length(); t > 0; t--) {
              tmpSB.append('-');
            }
            altAllelesIndexes[ss] = tmpSB.toString();
          } else if (alt.charAt(alt.length() - 1) == ref.charAt(ref.length() - 1)) {
            for (t = ref.length() - alt.length(); t > 0; t--) {
              tmpSB.append('-');
            }
            tmpSB.append(alt);
          } else {
            invalid = true;
          }
          isIndel = true;
        } else {
          StringBuilder info = new StringBuilder("Unexpected (REF	ALT) format when parsing line :" + currentLine);
          LOG.warn(info);
          // throw new Exception(info.toString());
        }
      }
      if (invalid) {
        //System.out.println(item.getKey());
        continue;
      }
      Variant var = new Variant(makerPostionStart, ref, altAllelesIndexes);
      var.setFeatureValue(avialbleFeatureIndex, item.getValue().toString());
      genome.addVariant(varInfo[0], var);
    }

    genome.buildVariantIndexMapOnChromosomes();
    genome.setVarNum(acceptVarNum);
    varCountMap.clear();
    genome.removeTempFileFromDisk();
    genome.writeChromsomeToDiskClean();
    return genome;
  }

}
