/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.controller;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.IntArrayList;
import cern.jet.random.engine.MersenneTwister64;
import java.io.BufferedWriter;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import org.apache.log4j.Logger;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.RefGene;
import org.cobi.kggseq.entity.SeqSegment;
import org.cobi.util.text.BGZFInputStream;
import org.cobi.util.thread.Task;

/**
 *
 * @author limx54
 */
public class SimuDoubleHitAllTask extends Task implements Callable<String> {

    private static final Logger LOG = Logger.getLogger(SimuDoubleHitAllTask.class);
    int datasetNum;
    int sampleSize;

    protected RefGene mgeneExons;
    String chromName;
    File scoreFile;
    int[] scoreIndexes;
    BGZFInputStream bfScoreIndexes;
    String[] varaintDBFilterFilesPathes;
    int[][] freqCols;
    BGZFInputStream[] bfMAFIndexes;
    boolean exclusionMode;
    double minExFreq;
    double minAF;
    double maxAF;
    boolean ignoreHomo = false;

    double actualGeneScore;
    RiskPredictionLogisticTask taskPredic;

    List<CombOrders> combOrderList;
    protected double empP;

    BufferedWriter bw;

    MersenneTwister64 mt54 = new cern.jet.random.engine.MersenneTwister64(new java.util.Date());

    public SimuDoubleHitAllTask(int datasetNum, int sampleSize, List<CombOrders> combOrderList, int bestModelNum,
            String chromName, File scoreFile, int[] scoreIndexes, BGZFInputStream bfScoreIndexes, String[] varaintDBFilterFilesPathes,
            int[][] freqCols, BGZFInputStream[] bfMAFIndexes, boolean exclusionMode, double minExFreq, double minAF, double maxAF, boolean ignoreHomo, BufferedWriter bw) {
        this.bw = bw;
        this.datasetNum = datasetNum;
        this.sampleSize = sampleSize;
        this.chromName = chromName;
        this.scoreFile = scoreFile;
        this.scoreIndexes = scoreIndexes;
        this.bfScoreIndexes = bfScoreIndexes;
        this.varaintDBFilterFilesPathes = varaintDBFilterFilesPathes;
        this.freqCols = freqCols;
        this.bfMAFIndexes = bfMAFIndexes;
        this.exclusionMode = exclusionMode;
        this.minExFreq = minExFreq;
        this.minAF = minAF;
        this.maxAF = maxAF;
        this.ignoreHomo = ignoreHomo;

        this.combOrderList = combOrderList;
        taskPredic = new RiskPredictionLogisticTask(combOrderList, bestModelNum);
    }

    public void updateParamters(double actualGeneScore, RefGene mgeneExons) {
        this.actualGeneScore = actualGeneScore;
        this.mgeneExons = mgeneExons;
    }

    @Override
    public String call() throws Exception {
        IntArrayList positions = new IntArrayList();
        List<char[]> alleleList = new ArrayList<char[]>();
        List<float[]> scoreList = new ArrayList<float[]>();
        DoubleArrayList frequnceList = new DoubleArrayList();

         
        

        retrieveVariants(mgeneExons, chromName, scoreFile.getCanonicalPath(), bfScoreIndexes, scoreIndexes, varaintDBFilterFilesPathes,
                bfMAFIndexes, freqCols, positions, alleleList, scoreList, frequnceList);

        removeVariantsByAlleleFreq(exclusionMode, minExFreq, minAF, maxAF, positions, alleleList, scoreList, frequnceList);

        //codes for testing
        StringBuilder sb = new StringBuilder();
        for (int t = 0; t < frequnceList.size(); t++) {
            if (frequnceList.getQuick(t) > 0) {
                sb.delete(0, sb.length());
                sb.append(frequnceList.getQuick(t));
                for (int k = 0; k < scoreList.get(t).length; k++) {
                    sb.append("\t");
                    sb.append(scoreList.get(t)[k]);
                }
                sb.append("\n");
                bw.write(sb.toString());
            }
        }

         

        double scoreSum = 0;
        double prob;
        double[] mutantCounts = new double[2];
        double score;
        double denovMutationRate = 1.3E-8;
        empP = 1;
        int varNum = frequnceList.size();
        //random simulation
        int ranSet = 0;
        int startI = 0, endI = 1;
        //at most three types altration
        double[] probs = new double[3];
        int[] scoreIndex = new int[3];
        boolean allNA = false;
        int nonNAIndex = 0;
        int tempLen;
        double minMutRate;
        Set<Integer> availVars = new HashSet<Integer>();
        int tmpI;
        int altTime = 0;
        double[] localMuteScore = new double[2];
        for (int k = 0; k < datasetNum; k++) {
            scoreSum = 0;
            ranSet++;
            for (int j = 0; j < sampleSize; j++) {
                Arrays.fill(mutantCounts, 0);
                startI = 0;
                endI = 1;
                do {
                    //all variants
                    while (endI < varNum && positions.getQuick(endI - 1) == positions.getQuick(endI)) {
                        endI++;
                    }
                    allNA = false;
                    nonNAIndex = 0;
                    //a variant may have different amino accid annotatins
                    availVars.clear();
                    Arrays.fill(scoreIndex, -1);
                    tempLen = 0;
                    for (int i = startI; i < endI; i++) {
                        tmpI = alleleList.get(i)[0] + alleleList.get(i)[1];
                        //filter out duplicated variant
                        if (availVars.contains(tmpI)) {
                            continue;
                        }
                        availVars.add(tmpI);

                        scoreIndex[tempLen] = i;
                        if (!Double.isNaN(frequnceList.getQuick(i)) && frequnceList.getQuick(i) != 0) {
                            if (nonNAIndex == 0) {
                                probs[nonNAIndex] = frequnceList.getQuick(i);
                            } else {
                                //accumulate the probablity
                                probs[nonNAIndex] = (probs[nonNAIndex - 1] + frequnceList.getQuick(i));
                            }
                            nonNAIndex++;
                        }
                        tempLen++;
                        if (tempLen >= 3) {
                            break;
                        }
                    }

                    if (nonNAIndex < tempLen) {
                        minMutRate = denovMutationRate / (tempLen);
                        while (nonNAIndex < tempLen) {
                            if (nonNAIndex == 0) {
                                probs[nonNAIndex] = minMutRate;
                            } else {
                                //accumulate the probablity
                                probs[nonNAIndex] = (probs[nonNAIndex - 1] + minMutRate);
                            }
                            nonNAIndex++;
                        }
                    }

                    //2 haplod transmitted
                    altTime = 0;
                    localMuteScore[0] = 0;
                    localMuteScore[1] = 0;
                    for (int t = 0; t < 2; t++) {
                        prob = mt54.nextDouble();
                        nonNAIndex = Arrays.binarySearch(probs, 0, tempLen, prob);
                        if (nonNAIndex < 0) {
                            nonNAIndex = -nonNAIndex - 1;
                            if (nonNAIndex < tempLen) {
                                altTime++;
                                score = taskPredic.predictByBestModels(combOrderList, scoreList.get(scoreIndex[nonNAIndex]));
                                localMuteScore[t] = score;
                            }
                        } else {
                            score = taskPredic.predictByBestModels(combOrderList, scoreList.get(scoreIndex[nonNAIndex]));
                            localMuteScore[t] = score;
                        }
                    }
                    if (altTime > 0) {
                        if (ignoreHomo) {
                            if (altTime != 2) {
                                for (int t = 0; t < 2; t++) {
                                    mutantCounts[t] += localMuteScore[t];
                                }
                            }
                        } else {
                            for (int t = 0; t < 2; t++) {
                                mutantCounts[t] += localMuteScore[t];
                            }
                        }
                    }

                    startI = endI;
                    endI++;
                } while (startI < varNum);

                //under double-hit model, assume mutations occur on both chromosomes
                scoreSum += (mutantCounts[0] * mutantCounts[1]);
            }

            if (scoreSum >= actualGeneScore) {
                empP++;
            }
            //Use the adaptive approach here     
            if (ranSet > 500000000) {
                if (empP / ranSet > 0.0000005) {
                    break;
                }
            } else if (ranSet > 50000000) {
                if (empP / ranSet > 0.000005) {
                    break;
                }
            } else if (ranSet > 5000000) {
                if (empP / ranSet > 0.00005) {
                    break;
                }
            } else if (ranSet > 500000) {
                if (empP / ranSet > 0.0005) {
                    break;
                }
            } else if (ranSet > 50000) {
                if (empP / ranSet > 0.005) {
                    break;
                }
            } else if (ranSet > 5000) {
                if (empP / ranSet > 0.01) {
                    break;
                }
            } else if (ranSet > 500) {
                if (empP / ranSet > 0.1) {
                    break;
                }
            } else if (ranSet > 100) {
                if (empP / ranSet > 0.3) {
                    break;
                }
            }
            if (ranSet % 500 == 0) {
                //  System.out.println("Running " + mgeneExons.getSymb());
            }
        }
        empP = empP / (ranSet + 1);
        fireTaskComplete();
        //threadsSignal.countDown();
        // LOG.info(mgeneExons.getSymb() + "\t" + empP);
        //System.out.println(Thread.currentThread().getName() + "结束. 还有" + threadsSignal.getCount() + " 个线程");
        return "";
    }

    public void retrieveVariants(RefGene mgeneExons, String chromName, String scorePath, BGZFInputStream bfScoreIndexes, int[] scoreIndexes,
            String[] varaintDBFilterFilesPathes, BGZFInputStream[] bfMAFIndexes, int[][] freqIndexes, IntArrayList positions,
            List<char[]> alleleList, List<float[]> scoreList, DoubleArrayList frequnceList) throws Exception {

        int boundNum = mgeneExons.getMergedSegments().size();
        if (boundNum == 0) {
            return;
        }
        IntArrayList exonBounders = new IntArrayList();
        List<SeqSegment> segs = mgeneExons.getMergedSegments();
        //it should be reversed
        if (segs.get(0).getStart() >= segs.get(boundNum - 1).getStart()) {
            for (int i = boundNum - 1; i >= 0; i--) {
                SeqSegment mgs = segs.get(i);
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        } else {
            for (SeqSegment mgs : segs) {
                exonBounders.add(mgs.getStart());
                exonBounders.add(mgs.getEnd());
            }
        }
        boundNum = exonBounders.size();

        long[] pos = bfScoreIndexes.findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
        if (pos[0] == pos[1]) {
            return;
        }

        File rsFile = new File(scorePath + chromName + ".gz");

        final BGZFInputStream bfScore = new BGZFInputStream(rsFile.getCanonicalPath(), 1, true);
        bfScore.adjustPos(pos[0], pos[1]);
        bfScore.creatSpider(pos[0] != 0);
        int indexCHROM = -1, indexPOS = 0;
        //after the spliting, the first cell store the number of columns
        //this indexPOS 
        VarAnnotTask varAnnoTask = new VarAnnotTask(bfScore.spider[0], indexCHROM, indexPOS, scoreIndexes);

        //skip the headline
        if (pos[0] == 0) {
            bfScore.spider[0].readLine();
        }

        int[] regions = new int[exonBounders.size()];
        for (int i = 0; i < regions.length; i++) {
            regions[i] = exonBounders.getQuick(i);

        }
//because dbNSFP only has resions of exons, it is safe to just use the first and last boundary 
        varAnnoTask.dbNSFPAnnotSimple(positions, alleleList, scoreList, regions);
        bfScore.spider[0].closeInputStream();

        for (int i = positions.size() - 1; i >= 0; i--) {
            frequnceList.add(Double.NaN);
        }

//should define the format of alleles and frequencies
        indexCHROM = 0;
        indexPOS = 1;

        if (varaintDBFilterFilesPathes != null) {
            for (int i = 0; i < varaintDBFilterFilesPathes.length; i++) {
                // varAnnoter.markByANNOVARefFormat(chromosomes[chromID], chromID, varaintDBFilterFiles6[i], options.needProgressionIndicator);               
                File mapfFile = new File(varaintDBFilterFilesPathes[i]);

                pos = bfMAFIndexes[i].findIndex(exonBounders.getQuick(0), exonBounders.getQuick(boundNum - 1));
                if (pos[0] == pos[1]) {
                    return;
                }
                final BGZFInputStream bfMAF = new BGZFInputStream(mapfFile.getCanonicalPath(), 1, true);
                bfMAF.adjustPos(pos[0], pos[1]);
                bfMAF.creatSpider(pos[0] != 0);

                varAnnoTask = new VarAnnotTask(bfMAF.spider[0], indexCHROM, indexPOS);

                if (varaintDBFilterFilesPathes[i].endsWith("vcf.gz")) {
                    varAnnoTask.markByVCFFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i]);
                } else {
                    varAnnoTask.markByANNOVARefFormatSimpleVar(chromName, positions, alleleList, frequnceList, freqIndexes[i][0]);
                }
                bfMAF.spider[0].closeInputStream();
            }
        }

    }

    public void removeVariantsByAlleleFreq(boolean exclusionMode, double minExFreq, double minAlleleFreq, double maxAlleleFreq, IntArrayList positions, List<char[]> alleleList,
            List<float[]> scoreList, DoubleArrayList frequnceList) {
        IntArrayList positionsTmp = new IntArrayList();
        List<char[]> alleleListTmp = new ArrayList<char[]>(alleleList);
        List<float[]> scoreListTmp = new ArrayList<float[]>(scoreList);
        DoubleArrayList frequnceListTmp = new DoubleArrayList();
        frequnceListTmp.addAllOf(frequnceList);
        positionsTmp.addAllOf(positions);

        positions.clear();
        alleleList.clear();
        scoreList.clear();
        frequnceList.clear();
        double altAF;
        int size = positionsTmp.size();
        boolean shouldAdd = false;
        for (int i = 0; i < size; i++) {
            altAF = frequnceListTmp.getQuick(i);
            shouldAdd = false;
            if (exclusionMode) {
                if (altAF == -1) {
                    //not exist in any database
                    //keep it anyhow
                    shouldAdd = true;
                } else if (Double.isNaN(altAF)) {
                    //exist in a database but have no frequence informaion
                    //not exist in any database
                    shouldAdd = true;

                } else //exist in a database and have freq infor
                if ((altAF >= minExFreq)) {
//                    leftVarNum--;

                } else {
                    shouldAdd = true;
                }
                if (shouldAdd) {
                    positions.add(positionsTmp.getQuick(i));
                    alleleList.add(alleleListTmp.get(i));
                    scoreList.add(scoreListTmp.get(i));
                    frequnceList.add(frequnceListTmp.getQuick(i));
                }

            } else {
                if (altAF == -1) {
                    //remove is anyhow
//                leftVarNum--;

                } else if (Double.isNaN(altAF)) {
                    // exist in a database but have no frequence informaion
                    //remove is anyhow
//                leftVarNum--;

                } else //exist in a database and have freq infor
                if ((altAF < minAlleleFreq || altAF > maxAlleleFreq)) {
//                    leftVarNum--;

                } else {
                    positions.add(positionsTmp.getQuick(i));
                    alleleList.add(alleleListTmp.get(i));
                    scoreList.add(scoreListTmp.get(i));
                    frequnceList.add(frequnceListTmp.getQuick(i));
                }
            }
        }
        positionsTmp.clear();
        alleleListTmp.clear();
        scoreListTmp.clear();
        frequnceListTmp.clear();
    }

}
