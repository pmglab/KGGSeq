/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.FloatArrayList;
import cern.colt.list.IntArrayList;
import cern.colt.map.OpenIntIntHashMap;
import htsjdk.samtools.util.BlockCompressedOutputStream;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPOutputStream;
import javax.swing.JFrame;

import org.apache.log4j.Logger;

import org.cobi.bayes.Bayes;
import static org.cobi.kggseq.GlobalManager.PLUGIN_PATH;
import org.cobi.kggseq.controller.GeneAnnotator;
import org.cobi.kggseq.controller.VariantAnnotator;
import org.cobi.kggseq.controller.VariantFilter;
import org.cobi.kggseq.dialog.PlotShowFrame;
import org.cobi.kggseq.entity.AnnotationSummarySet;
import org.cobi.kggseq.entity.CNVRegionParser;
import org.cobi.kggseq.entity.Chromosome;
import org.cobi.kggseq.entity.CombOrders;
import org.cobi.kggseq.entity.FiltrationSummarySet;
import org.cobi.kggseq.entity.Genome;
import org.cobi.kggseq.entity.Individual;
import org.cobi.kggseq.entity.PPIGraph;
import org.cobi.kggseq.entity.GeneSet;
import org.cobi.kggseq.entity.ReferenceGenome;
import org.cobi.kggseq.entity.Variant;
import org.cobi.kggseq.controller.Phenolyzer;
import org.cobi.kggseq.controller.SKAT;
import org.cobi.kggseq.controller.SequenceRetriever;
import org.cobi.kggseq.controller.VCFParserFast;
import org.cobi.kggseq.entity.RefGene;
import org.cobi.kggseq.Tuple.*;
import org.cobi.randomforests.MyRandomForest;
import org.cobi.util.file.LocalFileFunc;
import org.cobi.util.net.NetUtils;
import org.cobi.util.plot.HistogramPainter;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;

/**
 *
 * @author mxli
 */
public class NewCUIApp implements Constants {

    Options options;

    static final Logger LOG = Logger.getLogger(NewCUIApp.class);

    public NewCUIApp(Options options) throws Exception {
        this.options = options;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String headInfor = "@----------------------------------------------------------@\n" + "|        " + PREL + "        |     v" + PVERSION + "     |   " + PDATE + "     |\n"
                + "|----------------------------------------------------------|\n" + "|    (C) 2011 Miaoxin Li,  limx54@163.com                  |\n"
                + "|----------------------------------------------------------|\n" + "|  For documentation, citation & bug-report instructions:  |\n"
                + "|                http://pmglab.top/kggseq/                 |\n" + "@----------------------------------------------------------@";

        long time = System.nanoTime();

        Options option = new Options();
        try {
            if (args.length == 1 && !args[0].startsWith("--")) {
                option.readOptions(args[0]);
            } else if (args.length >= 1) {
                option.readOptions(args);
            } else {
                System.out.println("Usage: java -Xmx1g -jar kggseq.jar param.txt\n Or:  java -Xmx1g -jar kggseq.jar [options] ...");
                return;
            }

            String param = option.parseOptions();
            // System.out.println(headInfor);
            LOG.info("\n" + headInfor + "\nEffective settings :\n" + param);
            GlobalManager.detectOS();
            // final int INIT_PROBLEM = 0, WINDOWS = 1, UNIX = 2, POSIX_UNIX = 3, OTHER = 4;
            if (GlobalManager.osCode != 2) {
                if (option.rvtestGene || option.rvtestGeneset || option.rvtestVar) {
                    String infor = "Sorry, association analysis by RVTests can only run on Unix or Linux Or Mac OS!";
                    LOG.fatal(infor);
                    TimeUnit.SECONDS.sleep(1);
//                    System.exit(1);
                }

                if (option.phenolyzer) {
                    String infor = "Sorry, \'--phenolyzer-prediction\' can only run on Unix or Linux Or Mac OS!";
                    LOG.fatal(infor);
                    TimeUnit.SECONDS.sleep(1);
                    System.exit(1);
                }
            }

            GlobalManager.initiateVariables(option.refGenomeVersion, GlobalManager.osCode, option.resourceFolder, option.maxGtyAlleleNum);
            if (option.needRconnection) {
                RConnection rcon = null;
                try {
                    rcon = new RConnection(option.RHOST, option.RPORT);
                    rcon.voidEval("is.installed <- function(mypkg) is.element(mypkg, installed.packages()[,1])");
                    int is = rcon.eval("is.installed('countreg')").asInteger();
                    int totalInstallNum = 0;
                    if (is == 0) {
                        String[] packges = {"modeltools", "coin", "stabs", "nnls",
                            "quadprog", "party", "pbkrtest", "quantreg", "maptools",
                            "rio", "lme4"};

                        for (String pack : packges) {
                            is = rcon.eval("is.installed('" + pack + "')").asInteger();
                            if (is == 0) {
                                totalInstallNum++;
                                //,repos='http://cran.us.r-project.org'
                                System.out.println("install.packages('" + pack + "', dep=TRUE)");
                            }
                        }
                        totalInstallNum++;
                        System.out.println("install.packages('countreg', dep=TRUE,repos='http://R-Forge.R-project.org')");
                    }

                    //,"missForest"
                    String[] packges = {"MASS", "mvtnorm", "tmvtnorm", "SKAT", "snow"};

                    for (String pack : packges) {
                        is = rcon.eval("is.installed('" + pack + "')").asInteger();
                        if (is == 0) {
                            totalInstallNum++;
                            //,repos='http://cran.us.r-project.org'
                            System.out.println("install.packages('" + pack + "', dep=TRUE)");
                        }
                    }
                    if (totalInstallNum > 0) {
                        System.out.println("You may have to install the above R packages by the script in R interactive interface by your system administrators:");
                    }
                    //System.out.println("  install.packages(\"Rserve\", \"Rserve_1.8-6.tgz\", \"http://www.rforge.net/\")");
                    rcon.eval("library(MASS)");
                    rcon.eval("library(countreg)");
                } catch (RserveException | NoSuchMethodError ex) {
                    //RserveException
                    if (ex.getMessage().contains("Cannot connect") || ex.getMessage().contains("REngine")) {

                        // System.out.println(ex.getMessage() + "\t" +
                        // ex.getRequestReturnCode() + "\t" +
                        // ex.getRequestErrorDescription());
                        String infor = "Please open your R and type the following commands to allow kggseq to use it:\npack=\"Rserve\";\n"
                                + "if (!require(pack,character.only = TRUE, quietly = TRUE))   { install.packages(pack,\"Rserve_1.8-6.tgz\",repos=\'http://www.rforge.net/\');   if(!require(pack,character.only = TRUE)) stop(\"Package not found\")   }\n"
                                + "library(\"Rserve\");\nRserve(debug = FALSE, port = " + option.RPORT + ", args =\"--no-save\")"
                                + "\n OR\nType this command without openning your R: \nR CMD Rserve";

                        //,repos=\'http://cran.us.r-project.org\'
//                        String infor = "Please open your R and type the following commands to allow kggseq to use it:\npack=\"Rserve\";\n"
//                                + "if (!require(pack,character.only = TRUE, quietly = TRUE))   { install.packages(pack, dep=TRUE);  "
//                                + "if(!require(pack,character.only = TRUE)) stop(\"Package not found\")   }\n"
//                                + "library(\"Rserve\");\nRserve(debug = FALSE, port = " + option.RPORT + ", args =\"--no-save\")"
//                                + "\n OR\nType this command without openning your R: \nR CMD Rserve";
                        LOG.fatal(infor);
                        TimeUnit.SECONDS.sleep(1);
                    }
                    //ex.printStackTrace();
                    System.exit(1);
                } catch (Exception ex) {
                    ex.printStackTrace();

                } finally {
                    if (rcon != null) {
                        rcon.close();
                    }
                }
            }
            if (args.length == 1 && args[0].equals("--manual")) {
                File docPath = new File(NewCUIApp.class.getResource("/UserManual.html").getFile());
                NewCUIApp.browse(docPath.getCanonicalPath());
            }

            if (option.needInternetChecking) {
                GlobalManager.checkConnection();
                if (!option.noLibCheck) {
                    if (GlobalManager.isConnectInternet) {
                        if (NetUtils.checkLibFileVersion(option.libUpdate)) {
                            return;
                        } else if (args.length == 1 && args[0].equals("--lib-update")) {
                            String infor = "Your KGGSeq has already been the latest version!";
                            System.out.println(infor);
                            return;
                        }
                    } else if (args.length == 1 && args[0].equals("--lib-update")) {
                        String infor = "Failed to update KGGSeq because of network problem!";
                        System.out.println(infor);
                        return;
                    }
                }

                if (GlobalManager.isConnectInternet) {
                    if (option.phenolyzer) {
                        String strURL = "https://github.com/WGLab/phenolyzer/archive/master.zip";
                        NetUtils.checkInstallPhenolyzer(strURL, new File(PLUGIN_PATH + "phenolyzer-master.zip"), option.libUpdate);
                    }
                    if (option.uwrunnerGeneCoding || option.runnerGeneCoding || option.renerGeneNonCoding || option.wrenerGeneNonCoding || option.runnerDiGeneCoding || option.uwrunnerDiGeneCoding) {
                        //
                        String strURL = "http://pmglab.top/kggseq/download/lib/R/negtrunc.R";
                        NetUtils.checkrTruncatedNBGLMR(strURL, new File(PLUGIN_PATH + "R/negtrunc.R"), option.libUpdate);
                    }

                    if (option.rvtestGene || option.rvtestGeneset || option.rvtestVar) {
                        boolean needMake1 = false, needMake2 = false;
                        String strURL;
                        /*
                      strURL = "https://github.com/samtools/tabix/archive/master.zip";
                    needMake1 = NetUtils.checkInstallCpp(strURL, new File(PLUGIN_PATH + "tabix-master.zip"));
                         */

                        strURL = "https://github.com/zhanxw/rvtests/archive/master.zip";
                        needMake2 = NetUtils.checkInstallCpp(strURL, new File(PLUGIN_PATH + "rvtests-master.zip"), option.libUpdate);
                        if (needMake1 || needMake2) {
                            //  System.exit(1);
                        }
                    }
                }

                if (option.resCheck) {
                    if (GlobalManager.isConnectInternet) {
                        //    NetUtils.checkLatestResource(option);
                    }
                } else if (GlobalManager.isConnectInternet) {
                    // must check avaible resources
                    //NetUtils.checkResourceList(option);
                    NetUtils.checkOneDriveResourceList(option);

                }
            } else {
                if (option.mergeGtyDb != null) {
                    String piResource = option.PUBDB_URL_MAP.get(option.mergeGtyDb);
                    String url = "http://pmglab.top/genotypes/";

                    if (piResource != null) {
                        if (piResource.contains("_CHROM_")) {
                            option.mergeGtyDb = piResource.substring(0, piResource.indexOf(".chr_"));
                            option.mergeGtyDb = option.mergeGtyDb.substring(10);

                        } else {
                            String newLabel = "mergeddb";
                            option.PUBDB_URL_MAP.put(newLabel, url + piResource);

                            option.mergeGtyDb = piResource.substring(10);
                            option.PUBDB_FILE_MAP.put(newLabel, option.mergeGtyDb);
                            //remove the tar lable
                            option.mergeGtyDb = option.mergeGtyDb.substring(0, option.mergeGtyDb.lastIndexOf('.'));
                        }
                    }
                }
            }

            NewCUIApp main = new NewCUIApp(option);
            if (args.length != 1 && option.openManual) {
                File docPath = new File(NewCUIApp.class.getResource("/UserManual.html").getFile());
                main.browse(docPath.getCanonicalPath());
            }
            File tmpFloder = new File(option.outputFileName + "KGGSeqTMP");
            tmpFloder.mkdirs();
            System.setProperty("java.io.tmpdir", tmpFloder.getCanonicalPath());

            main.process();

            LocalFileFunc.delAll(tmpFloder);

            if (option.hasTmpPedFile) {
                File f = new File(option.pedFile);
                f.delete();
            }
            time = System.nanoTime() - time;
            time = time / 1000000000;
            long min = time / 60;
            long sec = time % 60;
            LOG.info("Elapsed time: " + min + " min. " + sec + " sec.");
            if (option.needLog) {
                String info = "The log information is saved in " + option.outputFileName + ".log" + "\n\n";
                LOG.info(info);
            }
//            LOG.info("\n\n");
            Toolkit.getDefaultToolkit().beep();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void showPlots(final File[] plotFiles) {
        if (!GraphicsEnvironment.isHeadless()) {
            java.awt.EventQueue.invokeLater(new Runnable() {

                @Override
                public void run() {
                    PlotShowFrame psf = new PlotShowFrame();
                    psf.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    for (final File file : plotFiles) {
                        if (file == null) {
                            continue;
                        }
                        psf.insertImage2PlottingPane(file);
                    }
                    psf.setVisible(true);
                }
            });
        } else {
            String info = "But no avaible graphics environment to present the figure(s) here!";
            LOG.info(info);
        }
    }

    private static void browse(String url) throws Exception {
        // 获取操作系统的名字
        String osName = System.getProperty("os.name", "");
        if (osName.startsWith("Mac OS")) {
            // 苹果的打开方式
            Class fileMgr = Class.forName("com.apple.eio.FileManager");
            Method openURL = fileMgr.getDeclaredMethod("openURL",
                    new Class[]{String.class});
            openURL.invoke(null, new Object[]{url});
        } else if (osName.startsWith("Windows")) {
            // windows的打开方式。
            Runtime.getRuntime().exec(
                    "rundll32 url.dll,FileProtocolHandler " + url);
        } else {
            // Unix or Linux的打开方式
            String[] browsers = {"firefox", "opera", "konqueror", "epiphany",
                "mozilla", "netscape"};
            String browser = null;
            for (int count = 0; count < browsers.length && browser == null; count++) // 执行代码，在brower有值后跳出，
            // 这里是如果进程创建成功了，==0是表示正常结束。
            {
                if (Runtime.getRuntime()
                        .exec(new String[]{"which", browsers[count]})
                        .waitFor() == 0) {
                    browser = browsers[count];
                }
            }
            if (browser == null) {
                throw new Exception("Could not find web browser");
            } else // 这个值在上面已经成功的得到了一个进程。
            {
                Runtime.getRuntime().exec(new String[]{browser, url});
            }
        }
    }

    public void process() throws Exception {
        OptionHandlerTools.optionHandlerToolsGenerator(options, LOG);

        Genome uniqueGenome = null;
        List<Individual> subjectList = new ArrayList<Individual>();
        int[] caeSetID = new int[0], controlSetID = new int[0];

        GeneAnnotator geneAnnotor = new GeneAnnotator();
        boolean hasControls = false;

        IntArrayList allEffectIndivIDs = new IntArrayList();
        VCFParserFast vsParser = new VCFParserFast();

        // OpenLongObjectHashMap wahBit = null;
        //OpenLongObjectHashMap wahBitGeneset = new OpenLongObjectHashMap();
        int maxEffectiveColVCF;
        boolean[] origionallySorted = new boolean[1];
        int[] maxThreadID = new int[1];
        boolean hasChrLabel;

        boolean useMinIDForGeneMapping = true;

        try {
            Map<String, GeneSet> dbPathwaySet = OptionHandlerTools.readGeneSets();
            OptionHandlerTools.indexdbNCFPHandler();

            Map<String, List<Variant>> genesetVars = new HashMap<String, List<Variant>>();
            //assigne variants into genes and pathways
            Map<String, List<Variant>> geneVars = new HashMap<String, List<Variant>>();
            Map<String, double[]> allDoubleHitGeneScoresMap = new HashMap<String, double[]>();
            Map<String, double[]> chromDoubleHitGeneScoresMap = null;
            TwoTuple<Boolean, Genome> tuple1 = OptionHandlerTools.makeVariantMAFFilterSet(uniqueGenome, vsParser, origionallySorted, maxThreadID);
            uniqueGenome = tuple1.getSecond();
            if (tuple1.getFirst()) {
                return;
            }

            uniqueGenome = OptionHandlerTools.autoGenerateVariantMAFFilterSet(uniqueGenome, vsParser, origionallySorted, maxThreadID, subjectList, allEffectIndivIDs);

            FiveTuple<Genome, int[], Boolean, int[], int[]> tuple2 = OptionHandlerTools.loadInputVariants(uniqueGenome, vsParser, subjectList, caeSetID, controlSetID, allEffectIndivIDs);
            uniqueGenome = tuple2.getFirst();
            int[] pedEncodeGytIDMap = tuple2.getSecond();
            boolean needGty = tuple2.getThird();
            caeSetID = tuple2.getFourth();
            controlSetID = tuple2.getFifth();

            maxEffectiveColVCF = vsParser.getMaxEffectiveColVCF();
            hasChrLabel = vsParser.isHasChrLabel();
            if (controlSetID.length > 0) {
                hasControls = true;
            }

            //for gene-based mutation rate test
            boolean[] useLocalGeneScore = new boolean[]{false};

            double[] scorePercentiles = new double[]{0.5, 0.8, 0.95, 0.99, 0.999};
            double[] scoreCutoffs = new double[scorePercentiles.length];
            boolean needRegionLen = true;
            //no need scores in the regression for up and downstream
            if (options.dependentGeneFeature.contains((byte) 12) || options.dependentGeneFeature.contains((byte) 13)) {
                needRegionLen = false;
            }

//,"hg19_gnomad.genomes.gene.var.freq.gz","hg19_gnomad.exomes.gene.var.freq.gz"  ,
            String[] geneVarFreqFiles = new String[]{"gadexome.gene.freq", "1kg.gene.freq"};

            if (options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                geneVarFreqFiles = new String[]{"gadgenome.gene.freq", "1kg.gene.freq"};
            }

            TwoTuple<String[], int[]> tuple8t = OptionHandlerTools.geneVarFreqFilePopuName(geneVarFreqFiles, useLocalGeneScore, hasControls);
            String[] popuNames = tuple8t.getFirst();
            int[] effecIndexVarFreq = tuple8t.getSecond();

            Set<String> genesWithMutationsAndScores = new HashSet<String>();
            Map<String, double[]> geneMutationPredictors = new HashMap<String, double[]>();
            Map<String, FloatArrayList[]> geneSampleMuts = new HashMap<String, FloatArrayList[]>();
            DoubleArrayList rareMutScores = new DoubleArrayList();
            Map<String, String[]> genePositions = new HashMap<String, String[]>();
            Map<String, DoubleArrayList> refGeneVarFreqScoreMap = new HashMap<String, DoubleArrayList>();

            //-----------------------Annotate variants on each chromsome-------------------------------
            VariantAnnotator varAnnoter = new VariantAnnotator();

            VariantFilter varFilter = new VariantFilter();
            FiltrationSummarySet minMissingQCFilter1 = new FiltrationSummarySet("missingQC", uniqueGenome.getVariantFeatureNum());
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of heterozygous genotypes <" + options.minHetA
                    + " or that of alternative homozygous genotypes <" + options.minHomA + " in cases.");

            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of heterozygous genotypes <" + options.minHetU
                    + " or that of alternative homozygous genotypes <" + options.minHomU + " in controls.");
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of non-null genotypes in cases <" + options.minOBSA + ".");
            minMissingQCFilter1.initiateAMessage(0, "variants are ignored due to the number of non-null genotypes in controls <" + options.minOBSU + ".");
            minMissingQCFilter1.initiateAMessage(0, "variant(s) are retained after filtration according to minimal successful genotype calling rates in patients and healthy individuals.");

            int filterNum = 6;
            boolean[] uniqueFilters = new boolean[2];
            boolean[] genotypeFilters = new boolean[filterNum];
            Arrays.fill(uniqueFilters, false);
            Arrays.fill(genotypeFilters, false);

            List<String> setSampleLabelList = new ArrayList<String>();

//            AnnotationSummarySet assLFF1=null;
//            if(altLocalFilterFiles!=null && !altLocalFilterFiles.isEmpty()){
//                assLFF1=new AnnotationSummarySet("LocalFileFilter",null,null,0,0,0,uniqueGenome.getVariantFeatureNum());
//            }
            FourTuple<List<int[]>, FiltrationSummarySet, FiltrationSummarySet, FiltrationSummarySet> tuple3 = OptionHandlerTools.setSampleGtyHardFilterModels(uniqueGenome, filterNum, genotypeFilters, setSampleLabelList, varFilter, subjectList);
            List<int[]> setSampleIDList = tuple3.getFirst();
            FiltrationSummarySet inheritanceModelFilter2 = tuple3.getSecond();
            FiltrationSummarySet denovoModelFilter3 = tuple3.getThird();
            FiltrationSummarySet somaticModelFilter4 = tuple3.getFourth();

            SixTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, DoubleArrayList[]> tuple4 = OptionHandlerTools.setCaseControlFilters(uniqueGenome, uniqueFilters);
            AnnotationSummarySet assCCUMFV = tuple4.getFirst();
            AnnotationSummarySet assHWD = tuple4.getSecond();
            AnnotationSummarySet assMAF = tuple4.getThird();
            AnnotationSummarySet ctTypeFilter = tuple4.getFourth();
            AnnotationSummarySet assSVHF = tuple4.getFifth();
            DoubleArrayList[] varPArray = tuple4.getSixth();

            SixTuple<AnnotationSummarySet[], AnnotationSummarySet[], String[], int[][], AnnotationSummarySet, AnnotationSummarySet> tuple5 = OptionHandlerTools.setVariantDBAlleleFreqFilters(uniqueGenome);
            AnnotationSummarySet[] varaintDBHardFilterFiles5 = tuple5.getFirst();
            AnnotationSummarySet[] varaintDBFilterFiles6 = tuple5.getSecond();
            String[] varaintDBFilterFiles = tuple5.getThird();
            int[][] freqColIndexes = tuple5.getFourth();
            AnnotationSummarySet assFBAFEM = tuple5.getFifth();
            AnnotationSummarySet assFBAFIM = tuple5.getSixth();
            ThreeTuple<AnnotationSummarySet, String, int[]> tuple51 = OptionHandlerTools.setExpressionVariantFilters(uniqueGenome);
            AnnotationSummarySet pextSumSet = tuple51.getFirst();
            String pextFileLocalPath = tuple51.getSecond();
            int[] varExpressionTissuesIndex = tuple51.getThird();

            SixTuple<AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[], AnnotationSummarySet[]> tuple6 = OptionHandlerTools.setVariantLocalAlleleFreqFilters(uniqueGenome);
            AnnotationSummarySet[] assLocalHardFilterFile5 = tuple6.getFifth();
            AnnotationSummarySet[] assLocalFilterFile6 = tuple6.getSecond();
            AnnotationSummarySet[] assLocalHardFilterVCFFile5 = tuple6.getThird();
            AnnotationSummarySet[] assLocalFilterVCFFile6 = tuple6.getFourth();
            AnnotationSummarySet[] assLocalHardFilterNoGtyVCFFile5 = tuple6.getFifth();
            AnnotationSummarySet[] assLocalFilterNoGtyVCFFile6 = tuple6.getSixth();

            FloatArrayList mafRefList = null;
            if (options.toMAFPlotRef) {
                mafRefList = new FloatArrayList();
            }
            FloatArrayList mafSampleList = null;
            if (options.toMAFPlotSample) {
                mafSampleList = new FloatArrayList();
            }

            AnnotationSummarySet ldPruningASS = null;
            if (options.ldPruning) {
                ldPruningASS = new AnnotationSummarySet("LDPruning", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            FourTuple<FiltrationSummarySet, int[], ReferenceGenome[], int[]> tuple7 = OptionHandlerTools.setGeneModelDBs(uniqueGenome);
            FiltrationSummarySet geneDBFilter7 = tuple7.getFirst();
            int[] variantsCounters = tuple7.getSecond();
            ReferenceGenome[] referenceGenomes = tuple7.getThird();
            int[] availableFeatureSizeForGeneDB = tuple7.getFourth();

            //to summarize
            List<String> featureLabels = uniqueGenome.getVariantFeatureLabels();
            TwoTuple<Integer, Integer> tuple8 = OptionHandlerTools.setFeaturesForGeneMutationRateTest(uniqueGenome, hasControls, featureLabels);
            int somatNumIndex = tuple8.getFirst();
            int readInfoIndex = tuple8.getSecond();

            Map genicMap = new HashMap<String, Integer>();
            Bayes bayesPredictor = new Bayes(GlobalManager.RESOURCE_PATH, options.refGenomeVersion);
            List<CombOrders> combOrderList = new ArrayList<CombOrders>();
            MyRandomForest[][] myRandomForestsCancer = new MyRandomForest[options.threadNum][];

            // dbNSFP3.0
            // int[] dbNSFP3ScoreIndexes = new int[]{5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18};
            // int[] dbNSFP3PredicIndex = new int[]{19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31};
            // dbNSFP3.5            
            int[] dbNSFP3ScoreIndexes = new int[]{5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23};
            int[] dbNSFP3PredicIndex = new int[]{24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41};
            if (options.dbnsfpVersion.equals("4.1")) {
                dbNSFP3ScoreIndexes = new int[]{26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70};
                dbNSFP3PredicIndex = new int[]{5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};
            }

            int writenVCFVarNum = 0;
            //String annNCFPPath = GlobalManager.RESOURCE_PATH + options.refGenomeVersion + "/hg19_all_SNV_dbNCFP.gz";

            /*
            final HashMap<String, Double> missingIndex = new HashMap<String, Double>() {
                {
                    put("CADD_cscore", (double) -0.0784622);
                    put("CADD_PHRED", (double) 3.68016);
                    put("DANN_score", (double) 0.291601);
                    put("FunSeq_score", (double) 1);
                    put("FunSeq2_score", (double) 0.287838);
                    put("GWAS3D_score", (double) 2.80186);
                    put("GWAVA_region_score", (double) 0.153309);
                    put("GWAVA_TSS_score", (double) 0.205698);
                    put("GWAVA_unmatched_score", (double) 0.33259);
                    put("SuRFR_score", (double) 9.44965);
                    put("Fathmm_MKL_score", (double) 0.00403947);
                }
            };
             */
            String[] nonCodingPredicLabels = new String[]{"GWAVA.matched", "GWAVA.tss", "GWAVA.unmatched", "CADD.CScore", "DANN", "fathmm-MKL", "FunSeq", "FunSeq2", "GWAS3D", "SuRFR"};
            double[] meanNonCodingPredic = new double[]{0.153309, 0.205698, 0.33259, -0.0784622, 0.291601, 0.00403947, 1, 0.287838, 2.80186, 9.44965};
            double[] baye1NonCodingPredic = new double[]{1.920773254522716, 1.4062755776550864, 8.931983960714861, 1.3731949333636428, 0.6465087024693027, 2.8994079489732445, 1.830225759450194, 0.4278010512234839, 1.3486363708941753, 8.010294623730767};
            double[] baye2NonCodingPredic = new double[]{0.6576249120154963, 0.5844200018958348, 0.8993151817446124, 0.5786271132044547, 0.39265428813083125, 0.743550812562889, 0.6466712958635984, 0.2996223114256015, 0.574221019314591, 0.8890158377988816};

            Map<String, Object> resultMap = OptionHandlerTools.addVarFuncScoreLabels(uniqueGenome, nonCodingPredicLabels, genicMap, bayesPredictor, dbNSFP3ScoreIndexes, dbNSFP3PredicIndex, combOrderList, myRandomForestsCancer);
            if ((boolean) resultMap.get("return") == true) {
                return;
            }
            String annNCFPPath = (String) resultMap.get("annNCFPPath");
            AnnotationSummarySet dbNoncodePred9d0 = (AnnotationSummarySet) resultMap.get("dbNoncodePred9d0");
            FiltrationSummarySet dbNoncodePred9d1 = (FiltrationSummarySet) resultMap.get("dbNoncodePred9d1");
            AnnotationSummarySet dbNoncodePred9d0Tmp = (AnnotationSummarySet) resultMap.get("dbNoncodePred9d0Tmp");
            FiltrationSummarySet dbNoncodePred9d1Tmp = (FiltrationSummarySet) resultMap.get("dbNoncodePred9d1Tmp");
            MyRandomForest[][] myRandomForestList = (MyRandomForest[][]) resultMap.get("myRandomForestList");
            String[] currentLineList = (String[]) resultMap.get("currentLineList");
            BufferedReader[] lineReaderList = (BufferedReader[]) resultMap.get("lineReaderList");
            Boolean[] isReigonList = (Boolean[]) resultMap.get("isReigonList");
            double[] iniScore = (double[]) resultMap.get("iniScore");
            int[] fixedPosition = (int[]) resultMap.get("fixedPosition");
            int scoreIndexNum = (int) resultMap.get("scoreIndexNum");
            FiltrationSummarySet dbNoncodePred9d2 = (FiltrationSummarySet) resultMap.get("dbNoncodePred9d2");
            FiltrationSummarySet dbNoncodePred9d2Tmp = (FiltrationSummarySet) resultMap.get("dbNoncodePred9d2Tmp");
            BufferedReader[] lineReaderList9d2 = (BufferedReader[]) resultMap.get("lineReaderList9d2");
            FiltrationSummarySet dbNSFPAnnot8 = (FiltrationSummarySet) resultMap.get("dbNSFPAnnot8");
            FiltrationSummarySet dbNSFPPred9 = (FiltrationSummarySet) resultMap.get("dbNSFPPred9");
            FiltrationSummarySet dbNSFPAnnot8Tmp = (FiltrationSummarySet) resultMap.get("dbNSFPAnnot8Tmp");
            FiltrationSummarySet dbNSFPPred9Tmp = (FiltrationSummarySet) resultMap.get("dbNSFPPred9Tmp");
            CombOrders fixedComb = (CombOrders) resultMap.get("fixedComb");

            AnnotationSummarySet assGVF10 = null;

            if (options.geneMaxVarFilter >= 0) {
                assGVF10 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            } else if (options.geneMinVarFilter >= 0) {
                assGVF10 = new AnnotationSummarySet("", null, null, 0, 0, 0, uniqueGenome.getVariantFeatureNum());
            }

            resultMap = OptionHandlerTools.prepareCandidateGeneSetFeatures(uniqueGenome);
            AnnotationSummarySet assG11 = (AnnotationSummarySet) resultMap.get("assG11");
            AnnotationSummarySet assV12 = (AnnotationSummarySet) resultMap.get("assV12");
            AnnotationSummarySet assPPIG13 = (AnnotationSummarySet) resultMap.get("assPPIG13");
            AnnotationSummarySet assPPIV14 = (AnnotationSummarySet) resultMap.get("assPPIV14");
            AnnotationSummarySet assPWG15 = (AnnotationSummarySet) resultMap.get("assPWG15");
            AnnotationSummarySet assPWV16 = (AnnotationSummarySet) resultMap.get("assPWV16");
            PPIGraph ppiTree = (PPIGraph) resultMap.get("ppiTree");
            Map<String, GeneSet> mappedPathes = (Map<String, GeneSet>) resultMap.get("mappedPathes");
            String ppiDBFile = (String) resultMap.get("ppiDBFile");

            TwoTuple<AnnotationSummarySet, AnnotationSummarySet> tuple9 = OptionHandlerTools.addHomoAndIBSFeatureNames(uniqueGenome);
            AnnotationSummarySet assIBS17d1 = tuple9.getFirst();
            AnnotationSummarySet assHRC17d2 = tuple9.getSecond();

            // as it is fast, giantID would prefer to read the lenght always.
            FourTuple<Map<String, Double>, AnnotationSummarySet, AnnotationSummarySet, Map<String, RefGene>> tuple10
                    = OptionHandlerTools.getGeneLength(uniqueGenome, needRegionLen, geneMutationPredictors);
            Map<String, Double> geneLengths = tuple10.getFirst();
            AnnotationSummarySet assGIS17d3 = tuple10.getSecond();
            AnnotationSummarySet assGOS17d4 = tuple10.getThird();
            Map<String, RefGene> mergedGeneCodingRegions = tuple10.getFourth();

            TwoTuple<List<String[]>, AnnotationSummarySet> tuple11 = OptionHandlerTools.ibdFileNameHandler(uniqueGenome);
            List<String[]> regionItems = tuple11.getFirst();
            AnnotationSummarySet assIBD17d5 = tuple11.getSecond();

            AnnotationSummarySet dbScSNV18 = OptionHandlerTools.setDBscSNVAnnoter(uniqueGenome);

            Map<String, String> genePubMedID = new HashMap<String, String>();
            String fileName = "HgncGene.txt";
            File resourceFile = new File(GlobalManager.RESOURCE_PATH + "/" + fileName);
            Map<String, String[]> geneNamesMap = varAnnoter.readGeneNames(resourceFile.getCanonicalPath());//time-consuming line.

            EightTuple<List<String[]>, List<String[]>, List<int[]>, IntArrayList, Set<String>, Set<String>, FiltrationSummarySet, Boolean> tuple12
                    = OptionHandlerTools.setDoubleHitGeneTriosFeatures(uniqueGenome, subjectList, varFilter, caeSetID, controlSetID);
            if (tuple12.getEighth()) {
                return;
            }
            List<String[]> hitDisCountsTriosGenes = tuple12.getFirst();
            List<String[]> hitDisCounTriosReads = tuple12.getSecond();
            List<int[]> triosIDList = tuple12.getThird();
            IntArrayList effectiveIndivIDsTrios = tuple12.getFourth();
            Set<String> caseDoubleHitTriosGenes = tuple12.getFifth();
            Set<String> controlDoubleHitTriosGenes = tuple12.getSixth();
            FiltrationSummarySet doubleHitGeneModelFilter19 = tuple12.getSeventh();

            SixTuple<FiltrationSummarySet, List<String[]>, List<String[]>, Set<String>, Set<String>, Integer> tuple13
                    = OptionHandlerTools.setDoubleHitGenePhasedGtyFeatures(uniqueGenome, featureLabels, subjectList, caeSetID, controlSetID);
            FiltrationSummarySet doubleHitGeneModelFilter19d1 = tuple13.getFirst();
            List<String[]> doubleHitGenePhasedGenes = tuple13.getSecond();
            List<String[]> doubleHitGenePhasedReads = tuple13.getThird();
            Set<String> caseDoubleHitPhasedGenes = tuple13.getFourth();
            Set<String> controlDoubleHitPhasedGenes = tuple13.getFifth();
            int pathogenicPredicIndex = tuple13.getSixth();

            FourTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet> tuple14 = OptionHandlerTools.setAnnotateGeneFeatures(uniqueGenome);
            AnnotationSummarySet assGene20 = tuple14.getFirst();
            AnnotationSummarySet assVariant20 = tuple14.getSecond();
            AnnotationSummarySet assOmimGene21 = tuple14.getThird();
            AnnotationSummarySet assOmimVar21 = tuple14.getFourth();

            ThreeTuple<AnnotationSummarySet, AnnotationSummarySet, Map<String, StringBuilder>> tuple15
                    = OptionHandlerTools.tissueSpecAnnotHandler(uniqueGenome, geneAnnotor);
            AnnotationSummarySet assTissueSpecGene21 = tuple15.getFirst();
            AnnotationSummarySet assTissueSpecVar21 = tuple15.getSecond();
            Map<String, StringBuilder> tissueSpecGeneMap = tuple15.getThird();

            FourTuple<AnnotationSummarySet, AnnotationSummarySet, CNVRegionParser, ReferenceGenome> tuple16 = OptionHandlerTools.setSuperdupFeatures(uniqueGenome);
            AnnotationSummarySet assSDA22 = tuple16.getFirst();
            AnnotationSummarySet assSDF22 = tuple16.getSecond();
            CNVRegionParser grpSD = tuple16.getThird();
            ReferenceGenome refGenomeSD = tuple16.getFourth();

            ThreeTuple<AnnotationSummarySet, CNVRegionParser, ReferenceGenome> tuple17 = OptionHandlerTools.setDgvCNVAnnotationFeatures(uniqueGenome);
            AnnotationSummarySet assDGV23 = tuple17.getFirst();
            CNVRegionParser grpDGV = tuple17.getSecond();
            ReferenceGenome refGenomeDGV = tuple17.getThird();

            IntArrayList caseSubIDs = new IntArrayList();
            IntArrayList controlSubIDs = new IntArrayList();
            ThreeTuple<AnnotationSummarySet, List<String>, Integer> tuple18 = OptionHandlerTools.setPredictedGeneLabels(uniqueGenome, featureLabels,
                    pathogenicPredicIndex, subjectList, caseSubIDs, controlSubIDs);
            AnnotationSummarySet assOLGF = tuple18.getFirst();
            featureLabels = tuple18.getSecond();
            pathogenicPredicIndex = tuple18.getThird();

            TwoTuple<AnnotationSummarySet, Map> tuple19 = OptionHandlerTools.setMousePhenoLabels(uniqueGenome, geneAnnotor);
            AnnotationSummarySet assMousePheno = tuple19.getFirst();
            Map g2MP = tuple19.getSecond();

            TwoTuple<AnnotationSummarySet, HashMap<String, String>> tuple20 = OptionHandlerTools.setZebraFishLabels(uniqueGenome, geneAnnotor);
            AnnotationSummarySet assZebra = tuple20.getFirst();
            HashMap<String, String> xebraP2Phe = tuple20.getSecond();

            File fisher = new File(GlobalManager.RESOURCE_PATH + "/DDG2P.csv.gz");
            TwoTuple<AnnotationSummarySet, HashMap<String, String>> tuple21 = OptionHandlerTools.setDddPhenotypeLabel(uniqueGenome, fisher);
            AnnotationSummarySet assDDD = tuple21.getFirst();
            HashMap<String, String> dddP2Phe = tuple21.getSecond();

            List<String[]> ideogramItemsGene = new ArrayList<String[]>();
            List<String[]> ideogramItemsVar = new ArrayList<String[]>();
            int driverPredicIndex = -1;
            SixTuple<AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, AnnotationSummarySet, Integer, Boolean> tuple22
                    = OptionHandlerTools.setPubMedSearchList(uniqueGenome, ideogramItemsGene, ideogramItemsVar, driverPredicIndex, featureLabels, pathogenicPredicIndex);
            if (tuple22.getSixth()) {
                return;
            }
            AnnotationSummarySet pubmedSearch24_Gene_Ideo = tuple22.getFirst();
            AnnotationSummarySet pubmedSearch24_Gene = tuple22.getSecond();
            AnnotationSummarySet pubmedSearch24_Var_Ideo = tuple22.getThird();
            AnnotationSummarySet pubmedSearch24_Var = tuple22.getFourth();
            pathogenicPredicIndex = tuple22.getFifth();

            TwoTuple<AnnotationSummarySet, OpenIntIntHashMap[]> tuple23 = OptionHandlerTools.setRSIDLabels(uniqueGenome, varAnnoter);
            AnnotationSummarySet assRSID25 = tuple23.getFirst();
            OpenIntIntHashMap[] altMapID = tuple23.getSecond();

            TwoTuple<AnnotationSummarySet, SequenceRetriever> tuple230 = OptionHandlerTools.setFlankingSeqLabels(uniqueGenome);
            AnnotationSummarySet assFS = tuple230.getFirst();
            SequenceRetriever seqRe = tuple230.getSecond();

            ThreeTuple<AnnotationSummarySet, Phenolyzer, HashMap<String, String>> tuple24 = OptionHandlerTools.setPhenolyzerLabels(uniqueGenome);
            AnnotationSummarySet assPhenolyzer26 = tuple24.getFirst();
            Phenolyzer phenolyzer = tuple24.getSecond();
            HashMap<String, String> hmpPhenolyzer = tuple24.getThird();

            TwoTuple<SKAT, DoubleArrayList[]> tuple25 = OptionHandlerTools.setSKATGeneLabel(subjectList);
            SKAT skat = tuple25.getFirst();
            DoubleArrayList[] genePVList = tuple25.getSecond();

            ThreeTuple<AnnotationSummarySet, HashMap<String, String[]>, Integer> tuple26 = OptionHandlerTools.mendelGenePathoHandler(uniqueGenome);
            AnnotationSummarySet assPatho27 = tuple26.getFirst();
            HashMap<String, String[]> hmpPatho = tuple26.getSecond();
            int intPatho = tuple26.getThird();

            IntArrayList[] chromRegions = OptionHandlerTools.readBEDRegions();

            ThreeTuple<Map<String, Map<String, Integer>>, AnnotationSummarySet, String> tuple27 = OptionHandlerTools.setCosmicLabels(uniqueGenome, fileName, geneAnnotor);
            Map<String, Map<String, Integer>> cosmicGeneMut = tuple27.getFirst();
            AnnotationSummarySet cosmicDBAnnot28 = tuple27.getSecond();
            fileName = tuple27.getThird();

            ThreeTuple<File, BufferedWriter, BufferedWriter> tuple28 = OptionHandlerTools.setANNOVAROutandisGeneVarGroupFileOut();
            File annovarFilteredInFile = tuple28.getFirst();
            BufferedWriter annovarFilteredInFileWriter = tuple28.getSecond();
            BufferedWriter bwGeneVarGroupFile = tuple28.getThird();

            int[] savedBinnaryBedVar = new int[2];
            savedBinnaryBedVar[0] = 0;
            savedBinnaryBedVar[1] = 0;
            int[] savedPedVar = new int[2];
            savedPedVar[0] = 0;
            savedPedVar[1] = 0;
            FourTuple<BufferedWriter, BufferedOutputStream, WritableByteChannel, BufferedWriter> tuple29 = OptionHandlerTools.setPlinkOut(subjectList, savedBinnaryBedVar, savedPedVar);
            BufferedWriter bwMapBed = tuple29.getFirst();
            BufferedOutputStream fileBedStream = tuple29.getSecond();
            WritableByteChannel wbcFileBed = tuple29.getThird();
            BufferedWriter bwMapPed = tuple29.getFourth();

            int[] savedBinnaryKedVar = new int[2];
            savedBinnaryKedVar[0] = 0;
            ThreeTuple<BufferedOutputStream, WritableByteChannel, BufferedWriter> tuple30 = OptionHandlerTools.setKEDGtyOut(uniqueGenome, subjectList, savedBinnaryKedVar);
            BufferedOutputStream filelKedStream = tuple30.getFirst();
            WritableByteChannel rafKed = tuple30.getSecond();
            BufferedWriter bwMapKed = tuple30.getThird();

            FourTuple<File, BlockCompressedOutputStream, File, BlockCompressedOutputStream> tuple31 = OptionHandlerTools.setVCFOut(vsParser, subjectList);
            File vcfFilteredInFile = tuple31.getFirst();
            BlockCompressedOutputStream vcfFilteredInFileWriter = tuple31.getSecond();
            File simpleVcfFilteredInFile = tuple31.getThird();
            BlockCompressedOutputStream simpleVcfFilteredInFileWriter = tuple31.getFourth();

            boolean needWriteTmp = false;
            BufferedWriter tmpWriter = null;
            if (needWriteTmp) {
                //tmpWriter = new BufferedWriter(new FileWriter(options.outputFileName + ".tmp.maf"));
                //tmpWriter.write("chr	pos	ref_allele	newbase	classification	count\n");
                GZIPOutputStream gzOut = new GZIPOutputStream(new FileOutputStream(options.outputFileName + ".tmp.maf.gz"));
                tmpWriter = new BufferedWriter(new OutputStreamWriter(gzOut));
            }

            TwoTuple<File, BufferedWriter> tuple32 = OptionHandlerTools.setMainOutFormat();
            File finalFilteredInFile = tuple32.getFirst();
            BufferedWriter finalExportWriter = tuple32.getSecond();

            Genome refhapGenome = null;
            int[] coutVar = new int[1];
            int[] intsSPV = new int[2];
            int[] intsIndiv = new int[1];

            FiveTuple<List<Individual>, BufferedWriter, BufferedOutputStream, WritableByteChannel, BlockCompressedOutputStream> tuple33
                    = OptionHandlerTools.setMergeGtyDb(uniqueGenome, vsParser, subjectList, coutVar, intsSPV, intsIndiv);
            List<Individual> refIndivList = tuple33.getFirst();
            BufferedWriter mergedBwMap = tuple33.getSecond();
            BufferedOutputStream mergedFileStream = tuple33.getThird();
            WritableByteChannel mergedFileChannel = tuple33.getFourth();
            BlockCompressedOutputStream outMergeVCFFile = tuple33.getFifth();

            BufferedWriter bwLD = OptionHandlerTools.setCalcLD();

            //*********************************************************************************************************************************************************************//
            //-------------------------------------------------------------------Start to filter or annotate
            Chromosome[] chromosomes = uniqueGenome.getChromosomes();

            int leftVar = -1;
            boolean needHead = true;
            List<Variant> chromosomeVarAll = new ArrayList<Variant>();
            int finalVarNum = 0;
            Map<String, String[]> geneAlleleCCMap = new HashMap<String, String[]>();
            //--------------------xc part start---------------------------------------------   
            // for (int chromID = 0; chromID < 1; chromID++){
            for (int chromID = 0; chromID < chromosomes.length; chromID++) {
                uniqueGenome.loadVariantFromDisk(chromID, needGty, origionallySorted, maxThreadID);//time-consuming part.
                if (chromosomes[chromID].variantList == null || chromosomes[chromID].variantList.isEmpty()) {
                    continue;
                }
                OptionHandlerTools.qualityControl(chromID, chromosomes, chromosomeVarAll, varFilter, varAnnoter, minMissingQCFilter1, mafSampleList, assHWD, assMAF, ctTypeFilter);
                if (options.superdupFilter) {
                    varFilter.superDupFilter(chromosomes[chromID], assSDF22, refGenomeSD);
                    if (uniqueGenome == null || uniqueGenome.getVarNum() == 0) {
                        LOG.info("0 sequence variant(s) are retained finally!");
                    }
                }

                //anotate by gene features 
                OptionHandlerTools.geneMappingAndFiltration(referenceGenomes, varAnnoter, chromosomes, chromID, availableFeatureSizeForGeneDB,
                        uniqueGenome, mergedGeneCodingRegions, pedEncodeGytIDMap, caeSetID, controlSetID,
                        varFilter, variantsCounters, geneDBFilter7, useMinIDForGeneMapping,
                        assGIS17d3, assGOS17d4);

                OptionHandlerTools.genetModelFiltration(inheritanceModelFilter2, varFilter, chromosomes, chromID, uniqueGenome, subjectList, pedEncodeGytIDMap, caeSetID, controlSetID,
                        genotypeFilters, denovoModelFilter3, setSampleIDList, needGty, setSampleLabelList, somaticModelFilter4, uniqueFilters, varAnnoter, assCCUMFV);

                leftVar = OptionHandlerTools.mafRefDBHardFilteration(varaintDBHardFilterFiles5, leftVar, varAnnoter, chromosomes, chromID);
                OptionHandlerTools.mafRefDBAnnotation(varaintDBFilterFiles6, varAnnoter, chromosomes, chromID, freqColIndexes);

                leftVar = OptionHandlerTools.mafANNOVARefDBHardFilteration(varAnnoter, chromosomes, leftVar, assLocalHardFilterFile5, chromID);
                OptionHandlerTools.mafANNOVARefDBAnnotation(assLocalFilterFile6, chromosomes, chromID, varAnnoter);

                leftVar = OptionHandlerTools.mafVCFRefDBHardFilteration(varAnnoter, chromosomes, leftVar, assLocalHardFilterVCFFile5, chromID);

                OptionHandlerTools.mafVCFRefDBAnnotation(varAnnoter, assLocalFilterVCFFile6, chromosomes, chromID);

                leftVar = OptionHandlerTools.mafNoGtyVCFRefDBHardFilteration(varAnnoter, chromosomes, leftVar, assLocalHardFilterNoGtyVCFFile5, chromID);

                OptionHandlerTools.mafVCFNoGtyRefDBAnnotation(varAnnoter, assLocalFilterNoGtyVCFFile6, chromosomes, chromID);

                OptionHandlerTools.mafRefDBSoftFiltration(varaintDBFilterFiles6, chromosomes, varFilter, chromID, assFBAFEM, assFBAFIM, mafRefList);

                OptionHandlerTools.pextAnnotation(pextSumSet, pextFileLocalPath, varAnnoter, chromosomes, chromID, varExpressionTissuesIndex);

                if (chromosomes[chromID].variantList.isEmpty()) {
                    continue;
                }

                OptionHandlerTools.varAssocTest(varAnnoter, chromosomes, varFilter, chromID, assSVHF, varPArray, uniqueGenome);

                //this function is almost obsolete
                if (options.varGenetScore) {//
                    varFilter.genetScoringVar(chromosomes[chromID], uniqueGenome.isIsPhasedGty(), subjectList, pedEncodeGytIDMap, caeSetID, controlSetID, genotypeFilters, inheritanceModelFilter2);
                }
                Chromosome tmpChrom = null;
                if (!useLocalGeneScore[0] && (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding || options.runnerDiGeneCoding
                        || options.uwrunnerDiGeneCoding)) {
                    tmpChrom = OptionHandlerTools.loadRefVariantRenerGene(chromID, geneVarFreqFiles, geneAnnotor, effecIndexVarFreq, useMinIDForGeneMapping);
                    if (dbNSFPAnnot8Tmp != null) {
                        dbNSFPAnnot8Tmp.setAvailableFeatureIndex(effecIndexVarFreq.length * 2);
                    }
                }

                int scoreIndex = -1;

                scoreIndex = OptionHandlerTools.dbNSFPAnnotPrediction(chromID, tmpChrom, varAnnoter, chromosomes, dbNSFP3ScoreIndexes, combOrderList, uniqueGenome, dbNSFPPred9,
                        fixedComb, myRandomForestsCancer, dbNSFPPred9Tmp, dbNSFP3PredicIndex, dbNSFPAnnot8, dbNSFPAnnot8Tmp);

                TwoTuple<String[], Integer> reTuple = OptionHandlerTools.noncodeVarDBAnnotPrediction(chromID, currentLineList, varAnnoter, chromosomes, isReigonList, iniScore, fixedPosition, lineReaderList, scoreIndexNum, myRandomForestList, genicMap,
                        dbNoncodePred9d1, tmpChrom, dbNoncodePred9d1Tmp, dbNoncodePred9d0, annNCFPPath, dbNoncodePred9d0Tmp, dbNoncodePred9d2, bayesPredictor, baye1NonCodingPredic, baye2NonCodingPredic,
                        dbNoncodePred9d2Tmp);
                currentLineList = reTuple.getFirst();
                //only use one types of score for the analysis.
                if (scoreIndex == -1) {
                    scoreIndex = reTuple.getSecond();
                }

                OptionHandlerTools.ldPurningFiltration(chromID, varAnnoter, chromosomes, subjectList, pedEncodeGytIDMap, uniqueGenome, ldPruningASS);
                OptionHandlerTools.geneVarNumFiltration(chromID, chromosomes, options.geneFeatureIn, varFilter, assGVF10);

                OptionHandlerTools.ppiAndPathwayAnnot(chromID, varAnnoter, chromosomes, uniqueGenome, assG11, assV12, assPPIG13, ppiTree, assPPIV14, assPWG15, mappedPathes, assPWV16);

                OptionHandlerTools.ibsHomoCheckInCase(chromID, varAnnoter, chromosomes, assIBS17d1, chromosomeVarAll, uniqueGenome,
                        subjectList, pedEncodeGytIDMap, caeSetID, controlSetID, assHRC17d2, assIBD17d5, regionItems);

                int predictionIDCol = -1;
                if (dbNSFPPred9 != null) {
                    predictionIDCol = dbNSFPPred9.getAvailableFeatureIndex();
                }
                //----------------------------xc part end-----------------------------------
                // System.out.println(chromID);
                chromDoubleHitGeneScoresMap = OptionHandlerTools.doubleHitGeneModelFilteration(doubleHitGeneModelFilter19, doubleHitGeneModelFilter19d1, chromDoubleHitGeneScoresMap, varFilter, chromosomes,
                        chromID, uniqueGenome, subjectList, pedEncodeGytIDMap, triosIDList, effectiveIndivIDsTrios, geneNamesMap, genePubMedID, hitDisCountsTriosGenes,
                        hitDisCounTriosReads, caseDoubleHitTriosGenes, controlDoubleHitTriosGenes, predictionIDCol, pathogenicPredicIndex, doubleHitGenePhasedGenes,
                        doubleHitGenePhasedReads, caseDoubleHitPhasedGenes, controlDoubleHitPhasedGenes, caeSetID, controlSetID);

                OptionHandlerTools.hgncGeneAnnot(uniqueGenome, varAnnoter, chromosomes, chromID, assGene20, assVariant20, assOmimGene21, assOmimVar21);

                if (OptionHandlerTools.otherAnnotationHandler(uniqueGenome, varAnnoter, chromosomes, chromID, assTissueSpecVar21, tissueSpecGeneMap, assSDA22, refGenomeSD, varFilter, assSDF22, dbScSNV18)) {
                    continue;
                }

                if (options.dgvcnvAnnotate) {
                    varAnnoter.cnvAnnotation(chromosomes[chromID], assDGV23, refGenomeDGV);
                }

                if (options.overlappedGeneFilter) {
                    varAnnoter.overlappedGeneExploreVar(chromosomes[chromID], assOLGF, subjectList, pedEncodeGytIDMap, options.filterNonDiseaseMut, caseSubIDs, controlSubIDs, pathogenicPredicIndex, uniqueGenome);
                }

                OptionHandlerTools.annotGenePheno(varAnnoter, chromosomes, chromID, assMousePheno, g2MP, assZebra, xebraP2Phe, assDDD, dddP2Phe, phenolyzer, assPhenolyzer26, hmpPhenolyzer);

                OptionHandlerTools.pubmedMining(uniqueGenome, varAnnoter, chromosomes, chromID, pubmedSearch24_Gene_Ideo, ideogramItemsGene, pubmedSearch24_Gene, geneNamesMap,
                        genePubMedID, pubmedSearch24_Var_Ideo, ideogramItemsVar, driverPredicIndex, pubmedSearch24_Var);

                if (OptionHandlerTools.variantListHandler(chromosomes, chromID, chromosomeVarAll)) {
                    continue;
                }

                OptionHandlerTools.rsIDFlankSeqAnnot(varAnnoter, chromosomes, chromID, assRSID25, altMapID, seqRe, assFS);
                geneVars.clear();

                OptionHandlerTools.assignVar2Gene(dbPathwaySet, varAnnoter, chromosomes, chromID, geneVars);
                //this is a more stringent QC for rare variants association test
                OptionHandlerTools.cleanGtyAtGeneWithTooManyVarInIndividual(varAnnoter, geneVars, uniqueGenome.isIsPhasedGty(), pedEncodeGytIDMap, caeSetID, controlSetID);

                //this should not be filttered by gene-feature; this will be used for gene-based analysis
                //ingore Y chromosome
                if (chromID <= 22) {
                    OptionHandlerTools.countGeneMutation(somatNumIndex, chromID, varAnnoter, chromosomes, tmpChrom, scoreIndex, useMinIDForGeneMapping, geneAnnotor, popuNames, refGeneVarFreqScoreMap,
                            genesWithMutationsAndScores, readInfoIndex, useLocalGeneScore[0], options.minCCFreqRatio);
                }

                // OptionHandlerTools.assignVar2GeneAndSKAT(dbPathwaySet, varAnnoter, chromosomes, chromID, geneVars, skat, subjectList, pedEncodeGytIDMap, uniqueGenome, genePVList);
                if (options.mendelGenePatho) {
                    varAnnoter.addPatho(chromosomes[chromID], assPatho27, hmpPatho, intPatho);
                }
                if (options.cosmicAnnotate) {
                    varAnnoter.cosmicGeneAnnotationVar(chromosomes[chromID], cosmicDBAnnot28, cosmicGeneMut);
                }

                OptionHandlerTools.exportHandler(subjectList, uniqueGenome, chromosomes, chromID, pedEncodeGytIDMap, fileBedStream, bwMapBed, savedBinnaryBedVar, filelKedStream, bwMapKed,
                        savedBinnaryKedVar, bwMapPed, savedPedVar, needWriteTmp, tmpWriter, annovarFilteredInFileWriter, bwGeneVarGroupFile, geneVars);
                //to release memory, release all lefte variants on this chromosome  and unused feature of variants
                uniqueGenome.outputVariant2FlatTextAndReleaseRAM(finalExportWriter, chromID, needHead, options.needRecordAltFreq, options.refGenomeVersion);//To write the result into a temp file.
                System.gc();

                writenVCFVarNum = OptionHandlerTools.vcfOutHandler(origionallySorted, writenVCFVarNum, uniqueGenome, vcfFilteredInFileWriter, chromosomes, chromID,
                        maxEffectiveColVCF, maxThreadID, simpleVcfFilteredInFileWriter, subjectList, pedEncodeGytIDMap, hasChrLabel);

                OptionHandlerTools.runSKAT(geneVars, skat, subjectList, pedEncodeGytIDMap, uniqueGenome, genePVList, scoreIndex);
                OptionHandlerTools.prepareFilesForRVTests(chromID, uniqueGenome, geneVars, options.rvtestMinVar, hasChrLabel, geneAlleleCCMap);

                if (options.calcLD) {
                    if (options.calcLDRegionFile != null) {
                        IntArrayList regions = chromRegions[chromID];
                        int regionNum = regions.size() / 2;
                        for (int i = 0; i < regionNum; i++) {
                            // System.out.print(chromosomes[chromID].getName() + "\t" + regions.getQuick(giantID * 2) + "\t" + regions.getQuick(giantID * 2 + 1));
                            double[] values = varAnnoter.calculateLDVarRegion(chromosomes[chromID], regions.getQuick(i * 2), regions.getQuick(i * 2 + 1), subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum);
                            bwLD.write(chromosomes[chromID].getName() + "\t" + regions.getQuick(i * 2) + "\t" + regions.getQuick(i * 2 + 1) + "\t" + values[0] + "\t" + values[1] + "\t" + values[2] + "\n");

                            // System.out.print("\t" + values[0] + "\t" + values[1] + "\t" + values[2] + "\n");
                        }

                    } else {
                        varAnnoter.calculateLDVar(chromosomes[chromID], subjectList, pedEncodeGytIDMap, uniqueGenome.isIsPhasedGty(), options.threadNum, options.ldPrunWindowSize, options.ldPrunR2, bwLD);
                    }
                }
                refhapGenome = OptionHandlerTools.mergeResourceHandler(chromosomes, chromID, refhapGenome, vsParser, origionallySorted, maxThreadID,
                        subjectList, refIndivList, uniqueGenome, pedEncodeGytIDMap, mergedFileStream, mergedBwMap, outMergeVCFFile, coutVar);

                finalVarNum += chromosomes[chromID].variantList.size();
                chromosomes[chromID].getPosIndexMap().clear();
                needHead = false;
                chromosomeVarAll.clear();
                chromosomes[chromID].variantList.clear();

                //set back genotypes
                if (!geneVars.isEmpty() && (dbPathwaySet != null && !dbPathwaySet.isEmpty())) {
                    varAnnoter.assignSelectedVar2Genesets(dbPathwaySet, geneVars, genesetVars, (byte) chromID, chromosomeVarAll);
                }

                if (options.digeneAssoc || options.uwrunnerDiGeneCoding || options.runnerDiGeneCoding
                        || options.geneCodingLogistAssoc) {
                    varAnnoter.extractGeneSampleMuationScores(geneVars, uniqueGenome.isIsPhasedGty(), pedEncodeGytIDMap, caeSetID, controlSetID,
                            scoreIndex, geneSampleMuts, rareMutScores, chromosomes[chromID].getName(), genePositions, 1);

                }

                geneVars.clear();
                System.gc();
            }

            //--------------------------------------------------The big circle has completed!------------------------------------------
            if (needWriteTmp) {
                tmpWriter.close();
            }

            if (options.isVCFOut) {
                vcfFilteredInFileWriter.close();
            }
            if (options.isSimpleVCFOut) {
                simpleVcfFilteredInFileWriter.close();
                //Note: this VCF tabix function is subject to be fixed
                //LocalFileFunc.tabixVCFFile(simpleVcfFilteredInFile.getCanonicalPath());
                //LOG.info("The index file " + simpleVcfFilteredInFile.getCanonicalPath() + ".tbi is created.");
            }

            TwoTuple<File, File> getSet_tuple = OptionHandlerTools.geneSetAssocTest(genesetVars, featureLabels, uniqueGenome, subjectList, pedEncodeGytIDMap, skat, genePVList, hasChrLabel);
            File rvTestGroupTestFile = getSet_tuple.getFirst();
            File simpleIndiviGenesetSumFile = getSet_tuple.getSecond();

            //************************************************************************************************************************************************************************//
            finalExportWriter.close();
            //Li -----------------------------------
            OptionHandlerTools.closeAnnovarWriter(annovarFilteredInFileWriter);
            OptionHandlerTools.printMinMissingQC(minMissingQCFilter1);
            OptionHandlerTools.closeReferenceGenomes(referenceGenomes);
            OptionHandlerTools.printGeneFeatureSummary(variantsCounters, geneDBFilter7);
            OptionHandlerTools.printGeneRangeFiltrationSummary(uniqueGenome, assGIS17d3, assGOS17d4);

            OptionHandlerTools.printInheritanceModelFiltrationSummary(inheritanceModelFilter2);
            OptionHandlerTools.printDenovoModelFiltrationSummary(denovoModelFilter3);

            OptionHandlerTools.printSomatMuatModelFiltrationSummary(somaticModelFilter4);
            uniqueGenome = OptionHandlerTools.printMAFSampleHardFiltrationSummary(uniqueFilters, uniqueGenome, assCCUMFV);
            OptionHandlerTools.printSampleHWDFiltrationSummary(assHWD);
            OptionHandlerTools.printCaseContrlMAFFiltrationSummary(assMAF);
            OptionHandlerTools.printCTTypeFiltrationSummary(ctTypeFilter);

            OptionHandlerTools.printPValueCutFiltrationSummary(assSVHF);
            String multiCorrMethodName = OptionHandlerTools.nameMultipleTestingMethod();
            OptionHandlerTools.printAsscPValueCutFiltrationSummary(multiCorrMethodName, varPArray);
            OptionHandlerTools.printDoubleHitPValueCutFiltrationSummary(allDoubleHitGeneScoresMap, multiCorrMethodName);
            OptionHandlerTools.printSKATPValueCutFiltrationSummary(multiCorrMethodName, genePVList);
            TwoTuple<double[][], HistogramPainter> kgg_fun15_tuple = OptionHandlerTools.printMAFBinSummary(mafSampleList);
            double[][] thresholds = kgg_fun15_tuple.getFirst();
            HistogramPainter pvPainter = kgg_fun15_tuple.getSecond();
            OptionHandlerTools.printMAFDBHardFiltrationSummary(varaintDBHardFilterFiles5);
            varaintDBFilterFiles6 = OptionHandlerTools.printMAFDBSoftFiltrationSummary(varaintDBFilterFiles6);
            OptionHandlerTools.printMAFLocalHardFiltrationSummary(assLocalHardFilterFile5);
            OptionHandlerTools.printMAFLocalSoftFiltrationSummary(assLocalFilterFile6);
            OptionHandlerTools.printMAFLocalVCFHardFiltrationSummary(assLocalHardFilterVCFFile5);
            OptionHandlerTools.printMAFLocalVCFSoftFiltrationSummary(assLocalFilterVCFFile6);
            OptionHandlerTools.printMAFLocalNoGtyVCFHardFiltrationSummary(assLocalHardFilterNoGtyVCFFile5);
            OptionHandlerTools.printMAFLocalNoGtyVCFSoftFiltrationSummary(assLocalFilterNoGtyVCFFile6);
            uniqueGenome = OptionHandlerTools.printMAFRangeFiltrationSummary(varaintDBFilterFiles6, uniqueGenome, thresholds, assFBAFEM, assFBAFIM, mafRefList, pvPainter);
            OptionHandlerTools.printPextSNVSummary(pextSumSet, options.minVarExpression);
            // 
            //chen ----------------------------------------------------            
            OptionHandlerTools.printVarFuncPredicFiltrationSummary(dbNSFPAnnot8, dbNSFPPred9, dbNoncodePred9d1);
            OptionHandlerTools.printVarLDPruningFiltrationSummary(ldPruningASS);
            OptionHandlerTools.printGeneVarCountFiltrationSummary(assGVF10, uniqueGenome);
            OptionHandlerTools.printVarPPIGeneSetSummary(uniqueGenome, assG11, assV12, assPPIG13, assPPIV14, assPWG15, assPWV16, mappedPathes);
            OptionHandlerTools.printIBSFiltrationSummary(uniqueGenome, assIBS17d1, assHRC17d2);
            OptionHandlerTools.printIBDFiltrationSummary(assIBD17d5);
            OptionHandlerTools.printScSNVSummary(dbScSNV18);
            OptionHandlerTools.printGeneDoubleHitFiltrationTriosOutput(doubleHitGeneModelFilter19, hitDisCountsTriosGenes, geneLengths, hitDisCounTriosReads, allDoubleHitGeneScoresMap, caseDoubleHitTriosGenes);
            OptionHandlerTools.printGeneDoubleHitPhasedGtyFiltrationOut(doubleHitGeneModelFilter19d1, doubleHitGenePhasedGenes, doubleHitGenePhasedReads, caseDoubleHitPhasedGenes);
            OptionHandlerTools.annoteGeneSummary(uniqueGenome, assGene20, assVariant20, assOmimGene21, assOmimVar21, assTissueSpecGene21, assTissueSpecVar21, assSDA22, assSDF22);
            OptionHandlerTools.annoteGenePhenoSummary(assDGV23, uniqueGenome, assOLGF, assMousePheno, assZebra, assDDD);
            OptionHandlerTools.printPubMedSearchSummary(uniqueGenome, pubmedSearch24_Gene, pubmedSearch24_Var);

            //yuan---------------------------------------------------------
//***********************************************Yuanyy part***********************************************************************************************************//
            if (options.rsid) {
                String info = assRSID25.getAnnotNum() + " variants are annotated with rsid.";
                LOG.info(info);
            }

            if (options.flankingSequence > 0) {
                String info = assFS.getAnnotNum() + " variants are annotated with flanking sequence.";
                LOG.info(info);
            }

            if (options.phenolyzer) {
                String info = assPhenolyzer26.getAnnotNum() + " variants are annotated by phenolyzer.";
                LOG.info(info);
            }
            LOG.info("------------------------------------------------------------");

            OptionHandlerTools.outputSKAT(skat);
            OptionHandlerTools.runRVTests(rvTestGroupTestFile, geneNamesMap, geneAlleleCCMap);
            OptionHandlerTools.isPlinkBedOutHandler(bwMapBed, fileBedStream, refhapGenome, mergedBwMap, mergedFileStream, savedBinnaryBedVar, subjectList, coutVar, intsIndiv);
            OptionHandlerTools.isSimpleVCFOutMergeHandler(refhapGenome, outMergeVCFFile, coutVar, intsIndiv);

            if (simpleIndiviGenesetSumFile != null) {
                String infor = "The summary statistics of variants in specified genesets for each individual are listed in " + simpleIndiviGenesetSumFile.getCanonicalPath();
                LOG.info(infor);
            }

            if (options.mendelGenePatho) {
                String info = assPatho27.getAnnotNum() + " variants are annotated by pathology gene prediction.";
                LOG.info(info);
            }

            if (options.cosmicAnnotate) {
                String info = cosmicDBAnnot28.getAnnotNum() + " variant(s) are annotated by genes in the COSMIC database!";
                LOG.info(info);
            }

            OptionHandlerTools.isGenVarGFOHandler(bwGeneVarGroupFile);

            OptionHandlerTools.calcLDHandler(bwLD, uniqueGenome);

            OptionHandlerTools.isPlinkPedOutHandler(bwMapPed, savedPedVar, subjectList);

            OptionHandlerTools.isBinaryGtyOutHandler(bwMapKed, filelKedStream, rafKed, savedBinnaryKedVar, subjectList);

            OptionHandlerTools.isVCFOutHandler(vcfFilteredInFile, writenVCFVarNum);

            OptionHandlerTools.isSimpleVCFOutHandler(simpleVcfFilteredInFile, finalVarNum);

            if (options.isANNOVAROut) {
                LOG.info("Finally, " + finalVarNum + " variants are saved in " + annovarFilteredInFile.getCanonicalPath() + " with ANNOVAR format.");
                annovarFilteredInFileWriter.close();
            }

            OptionHandlerTools.excelOutHandler(finalFilteredInFile, finalVarNum);

            //-----------------------Annotate genes and gene sets on whole genome-------------------------------
            String[] cells = null;
            String[] fixedColNames = null;
            List<String> scoreNames = new ArrayList<String>();
            String[] indexLabels = null;
            if (options.iterGeneCoding || options.witerGeneCoding) {
                ThreeTuple<String[], Map<String, double[]>, String[]> tuple99
                        = OptionHandlerTools.cancerDriverGeneMutationRateTestHandler(geneAnnotor, fixedColNames, geneMutationPredictors, scoreNames, uniqueGenome, indexLabels, cosmicGeneMut, geneNamesMap);
                fixedColNames = tuple99.getFirst();
                geneMutationPredictors = tuple99.getSecond();
                indexLabels = tuple99.getThird();
            }
            int anaType = 0;
            boolean usingLog = false;
            if (options.geneCodingLogistAssoc) {
                //this function was made to response a question of a reviewer
                OptionHandlerTools.simpleGeneBasedAssoc(geneSampleMuts, rareMutScores, caeSetID.length, controlSetID.length);

            }
            if (options.uwrunnerGeneCoding || options.runnerGeneCoding || options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                if (options.renerGeneNonCoding || options.wrenerGeneNonCoding) {
                    anaType = 1;
                }

                ThreeTuple<String[], List<String[]>, String[]> tuple99 = OptionHandlerTools.geneMutationRateTestChangeFreqHandler(options.RHOST, options.RPORT, geneAnnotor, fixedColNames, scoreNames, needRegionLen, popuNames, geneMutationPredictors,
                        genesWithMutationsAndScores, refGeneVarFreqScoreMap, options.minAlleleFreqExc, cosmicGeneMut, indexLabels, uniqueGenome, hasControls, useLocalGeneScore[0], options.needInteraction, dbPathwaySet, geneNamesMap,
                        true, usingLog, anaType, !options.genePhenoRelatedness);

                fixedColNames = tuple99.getFirst();
                List<String[]> caseResults = tuple99.getSecond();
                indexLabels = tuple99.getThird();

                OptionHandlerTools.phenoRunnerAnalysis(caseResults, geneNamesMap);

            } else if (options.uwrunnerDiGeneCoding || options.runnerDiGeneCoding) {
                // ThreeTuple<String[], List<String[]>, String[]> tuple99 = OptionHandlerTools.geneMutationRateTestChangeFreqHandler(RHOST, RPORT, geneAnnotor, fixedColNames, scoreNames, needRegionLen, popuNames, geneMutationPredictors,
                //    genesWithMutationsAndScores, refGeneVarFreqScoreMap, options.minAlleleFreqExc, cosmicGeneMut, indexLabels, uniqueGenome, hasControls, useLocalGeneScore[0], options.needInteraction, dbPathwaySet, geneNamesMap, false, anaType, !options.genePhenoRelatedness);
                //usingLog = true;

                ThreeTuple<String[], List<String[]>, String[]> tuple99 = OptionHandlerTools.digeneMutationRateTestChangeFreqHandler(options.RHOST, options.RPORT, options.genePairFile, options.digeneProb, geneAnnotor, fixedColNames, scoreNames, needRegionLen, popuNames, geneMutationPredictors,
                        geneSampleMuts, rareMutScores, caeSetID.length, controlSetID.length, genesWithMutationsAndScores, refGeneVarFreqScoreMap, options.minAlleleFreqExc, indexLabels, hasControls, useLocalGeneScore[0], options.needInteraction, geneNamesMap,
                        false, usingLog, anaType, !options.genePhenoRelatedness);

                fixedColNames = tuple99.getFirst();
                // geneMutationPredictors = tuple99.getSecond();
                indexLabels = tuple99.getThird();

            }
            if (options.digeneAssoc) {
                List<String[]> genePairList = OptionHandlerTools.digeneAssocAnalysis(geneSampleMuts, options.genePairFile, caeSetID.length, controlSetID.length,
                        options.digeneProb, options.threadNum, genePositions);

                geneAnnotor.annotateGenePairAndOutput(genePairList, options.outputFileName + ".digene",
                        options.pubmedMiningSigGene, options.pubmedMiningTopGene, options.searchList, geneNamesMap, options.genePCut, options.excelOut);
            }
        } finally {
            if (uniqueGenome != null) {
                uniqueGenome.removeTempFileFromDisk();
            }
        }
    }
}
