/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

import cern.colt.list.IntArrayList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;
import org.cobi.kggseq.GlobalManager;
import org.cobi.util.text.Util;

/**
 *
 * @author mxli
 */
public class RefmRNA extends SeqSegment {

  //private static final Log LOG = Log.getIninstance(RefmRNA.class);
  private static final Logger LOG = Logger.getLogger(RefmRNA.class);
  private char strand = '0';
  private String refID;
  private int length;
  private String mRnaSequence;
  private int mRnaSequenceStart;
  //Note: The end boundary of each exon is not included in refGene database
  private List<SeqSegment> exons;
  public int codingStart;
  //probably codingEnd is exclusive
  public int codingEnd;
  boolean noCodingExon = true;
  int exonNum = 0;
  int codingStartRelativeSiteInSequence = -1;
  int codingStartSiteExonID = 0;
  int codingEndSiteExonID = 0;

  IntArrayList intronLength = new IntArrayList();
  List<ProteinDomain> proteinDomainList = null;
  String uniprotID = null;
  String geneSymb = null;
  int[] delSites;
  int[] insSites;
  String delSeq;
  String insSeq;
  boolean multipleMapping = false;

  Set<Character> seqSet = new HashSet<Character>() {
    {
      add('A');
      add('T');
      add('G');
      add('C');
      add('a');
      add('t');
      add('g');
      add('c');
    }
  };

  public String getDelSeq() {
    return delSeq;
  }

  public void setDelSeq(String delSeq) {
    this.delSeq = delSeq;
  }

  public String getInsSeq() {
    return insSeq;
  }

  public void setInsSeq(String insSeq) {
    this.insSeq = insSeq;
  }

  public boolean isMultipleMapping() {
    return multipleMapping;
  }

  public void setMultipleMapping(boolean multipleMapping) {
    this.multipleMapping = multipleMapping;
  }

  public String getGeneSymb() {
    return geneSymb;
  }

  public int[] getDelSites() {
    return delSites;
  }

  public int[] getInsSites() {
    return insSites;
  }

  public void setInsSites(int[] insSites) {
    this.insSites = insSites;
  }

  public void setDelSites(int[] delSites) {
    this.delSites = delSites;
  }

  public int getExonNum() {
    return exonNum;
  }

  public void setExonNum(int exonNum) {
    this.exonNum = exonNum;
  }

  public List<SeqSegment> getExons() {
    return exons;
  }

  public void setExons(List<SeqSegment> exons) {
    this.exons = exons;
  }

  public void setGeneSymb(String geneSymb) {
    this.geneSymb = geneSymb;
  }

  public void setProteinDomainList(List<ProteinDomain> proteinDomainList) {
    this.proteinDomainList = proteinDomainList;
  }

  public void setUniprotID(String uniprotID) {
    this.uniprotID = uniprotID;
  }

  public int getCodingEnd() {
    return codingEnd;
  }

  public int getCodingStart() {
    return codingStart;
  }

  public void setmRnaSequenceStart(int mRnaSequenceStart) {
    this.mRnaSequenceStart = mRnaSequenceStart;
  }

  public void setmRnaSequence(String mRnaSequence) {
    this.mRnaSequence = mRnaSequence;
  }

  public RefmRNA(String refID, int start, int end) {
    super(start, end);
    this.refID = refID;
    this.exons = new ArrayList<SeqSegment>();
  }

  public String getRefID() {
    return refID;
  }

  public void setRefID(String refID) {
    this.refID = refID;
  }

  public RefmRNA(String refID, int start, int end, int codingStart, int codingEnd) {
    super(start, end);
     
    this.refID = refID;
    this.codingStart = codingStart;
    this.codingEnd = codingEnd;
    this.exons = new ArrayList<SeqSegment>();
    if (codingStart != codingEnd) {
      noCodingExon = false;
    }
  }

  public char getStrand() {
    return strand;
  }

  public void setStrand(char strand) {
    this.strand = strand;
  }

  public void addExon(SeqSegment exon) {
    exons.add(exon);
    exonNum++;
  }

  public void makeAccuIntronLength() throws Exception {
    if (exons == null || exons.isEmpty()) {
      return;
    }
    int accumIntronLen = 0;
    if (strand == '0') {
      throw new Exception("Unknown strand at " + refID + "; and cannot make AccuExonLength!");
    } else if (strand == '+') {
      SeqSegment exon = exons.get(0);
      //assume the boundary is not inclusive 
      if (codingStart >= exon.start && codingStart <= exon.end) {
        codingStartRelativeSiteInSequence = codingStart - exon.start;
        codingStartSiteExonID = 0;
      }
      if (codingEnd >= exon.start && codingEnd <= exon.end) {
        codingEndSiteExonID = 0;
      }

      accumIntronLen = 0;
      for (int i = 1; i < exonNum; i++) {
        exon = exons.get(i);
        //assume the boundary is not inclusive     
        intronLength.add(exons.get(i).start - exons.get(i - 1).end);
        accumIntronLen += intronLength.get(i - 1);
        if (codingStart >= exon.start && codingStart <= exon.end) {
          codingStartRelativeSiteInSequence = codingStart - exons.get(0).start - accumIntronLen;
          codingStartSiteExonID = i;
        }
        if (codingEnd >= exon.start && codingEnd <= exon.end) {
          codingEndSiteExonID = i;
        }
      }
    } else {
      SeqSegment exon = exons.get(exonNum - 1);
      //assume the boundary is not inclusive 
      if (codingEnd >= exon.start && codingEnd <= exon.end) {
        codingStartRelativeSiteInSequence = exon.end - codingEnd;
        codingStartSiteExonID = exonNum - 1;
      }
      //codingStart and codingEnd are defined by the orginal RefGene file
      if (codingStart >= exon.start && codingStart <= exon.end) {
        codingEndSiteExonID = exonNum - 1;
      }
      accumIntronLen = 0;
      for (int i = exonNum - 2; i >= 0; i--) {
        exon = exons.get(i);
        //assume the boundary is not inclusive              
        accumIntronLen += (exons.get(i + 1).start - exons.get(i).end);
        if (codingEnd >= exon.start && codingEnd <= exon.end) {
          codingStartRelativeSiteInSequence = exons.get(exonNum - 1).end - codingEnd - accumIntronLen;
          codingStartSiteExonID = i;
        }
        if (codingStart >= exon.start && codingStart <= exon.end) {
          codingEndSiteExonID = i;
        }
      }
      for (int i = 1; i < exonNum; i++) {
        intronLength.add(exons.get(i).start - exons.get(i - 1).end);
      }
      //intronLength.reverse();
    }

    /*
         if(this.refID.equals("NM_001128929")){
         int sss=0;
         } 
     */
    //We only need adjust for gaps after the codingStartRelativeSiteInSequence
    //Note the sequences in the kggseq file are cDNA sequence from 5' to 3'. So we ingnore the direction here 
//        delSites=null;//***********************************
    if (delSites != null) {
      IntArrayList effectiveSites = new IntArrayList();
      StringBuilder effectiveBase = new StringBuilder();
      for (int i = 0; i < delSites.length; i++) {
        if (strand == '+') {
          //it is very confusing whether to incoude the deletion at tail
          if (delSites[i] > codingStartRelativeSiteInSequence) {
            effectiveSites.add(delSites[i]);
            effectiveBase.append(delSeq.charAt(i));
          }
        } else if (delSites[i] > codingStartRelativeSiteInSequence) {
          effectiveSites.add(delSites[i]);
          effectiveBase.append(delSeq.charAt(i));
        }
      }
      if (effectiveSites.isEmpty()) {
        delSites = null;
        delSeq = null;
      } else if (delSites.length != effectiveSites.size()) {
        delSites = new int[effectiveSites.size()];
        for (int i = 0; i < delSites.length; i++) {
          delSites[i] = effectiveSites.getQuick(i);
        }
        delSeq = effectiveBase.toString();
      }
    }

    //  insSites=null;//**************************************************
    if (insSites != null) {
      IntArrayList effectiveSites = new IntArrayList();
      StringBuilder effectiveBase = new StringBuilder();
      for (int i = 0; i < insSites.length; i++) {
        if (strand == '+') {
          //it is very confusing whether to incoude the deletion at tail
          if (insSites[i] > codingStartRelativeSiteInSequence) {
            effectiveSites.add(insSites[i]);
            effectiveBase.append(insSeq.charAt(i));
          }
        } else if (insSites[i] > codingStartRelativeSiteInSequence) {
          effectiveSites.add(insSites[i]);
          effectiveBase.append(insSeq.charAt(i));
        }
      }
      if (effectiveSites.isEmpty()) {
        insSites = null;
        insSeq = null;
      } else if (insSites.length != effectiveSites.size()) {
        insSites = new int[effectiveSites.size()];
        for (int i = 0; i < insSites.length; i++) {
          insSites[i] = effectiveSites.getQuick(i);
        }

        insSeq = effectiveBase.toString();
      }
    }

  }

  /*
     The possible values of the finding is summarized below:
     Value 	Default precedence 	Explanation
     0	1	2	3	4	5	6
     frameshift	nonframeshift	stoploss	stopgain	missense	synonymous	splicing
     7	8	9	10	11	12	13
     ncRNA	5UTR	3UTR	intronic	upstream	downstream	intergenic
    
     * 
   */
  // this is a function get position in messanger rna in which the intronic regions are excluded    
  public GeneFeature findFeature(String chr, Variant var, boolean isForwardStrandInput, int upstreamDis, int downstreamDis, int splicingDis) throws Exception {
    int oldStartPos = var.refStartPosition;
    /*
        if (oldStartPos == 45369633) {
            if (this.geneSymb.startsWith("MT-ND1")) {
                int ssssss = 0;
            }
            int sss = 0;
        }
     */
    String ref = var.getRefAllele();

    String[] altAlleles = new String[var.getAltAlleles().length];
    //only use the values of alt alleles because it may be changed by other functions
    System.arraycopy(var.getAltAlleles(), 0, altAlleles, 0, altAlleles.length);

    if (strand == '0') {
      throw new Exception("Unknown strand at " + refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")"));
    }
    int exonicFeatureID = GlobalManager.VarFeatureIDMap.get("exonic");

    if (isForwardStrandInput) {
      if (strand == '-') {
        //assum the input allele are all in forward strand
        ref = Util.getReverseComplementalSquences(ref);
        for (int i = 0; i < altAlleles.length; i++) {
          altAlleles[i] = Util.getReverseComplementalSquences(altAlleles[i]);
        }

      }
    }

    int count = 0;
    int startPos = 0;
    byte[] errorCode = new byte[1];
    errorCode[0] = 0;
    int startAllele = 0;
    int index = 0;
    int exonIDStartPos;

    List<GeneFeature> gfList = new ArrayList<GeneFeature>();

    for (String allele : altAlleles) {
      if (allele.startsWith("+") || allele.endsWith("+")) {
        startPos = oldStartPos;

        //it is an insertion
        GeneFeature gf = findCrudeFeature(startPos, upstreamDis, downstreamDis, splicingDis, ref, allele);
        if (gf == null) {
          continue;
        }

        if (gf.id == exonicFeatureID) {
          int exonID = Util.parseInt(gf.name.substring(0, gf.name.indexOf(':')));
          int relativeCodingStartPos = Util.parseInt(gf.name.substring(gf.name.indexOf(':') + 1));
          //to do something about insertion  
          GeneFeature gf1 = calculateAminoAcidInsertion(relativeCodingStartPos, ref, allele, startPos);
          index = gf.name.indexOf(':');
          if (gf.name.indexOf(':') < 0) {
            exonIDStartPos = -1;
          } else {
            exonIDStartPos = Util.parseInt(gf.name.substring(0, index));
          }
          index = gf1.getName().lastIndexOf(':');
          if (index < 0) {
            gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos);
          } else {
            gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
          }

          gfList.add(gf1);
        } else {
          gfList.add(gf);
        }
      } else if (allele.startsWith("-") || allele.endsWith("-")) {
        startPos = oldStartPos;
        count = 0;
        int delLen = 0;

        for (int i = allele.length() - 1; i >= 0; i--) {
          if (allele.charAt(i) != '-') {
            count++;
          } else {
            delLen++;
          }
        }

        startPos = oldStartPos + count;

        GeneFeature gfStart = findCrudeFeature(startPos, upstreamDis, downstreamDis, splicingDis, ref, allele);
        int endPos = 0;

        if (strand == '-') {
          //twice reverse
          if (allele.charAt(0) == '-') {
            endPos = startPos + delLen;
          } else {
            endPos = startPos - delLen + 1;
          }
        } else {
          if (allele.charAt(0) == '-') {
            endPos = startPos - delLen + 1;
          } else {
            endPos = startPos + delLen;
          }
        }

        GeneFeature gfEnd = findCrudeFeature(endPos, upstreamDis, downstreamDis, splicingDis, ref, allele);
        if (gfStart == null && gfEnd == null) {
          continue;
        } else if (gfStart != null && gfEnd != null) {
          if (gfStart.id == gfEnd.id) {
            if (gfStart.id == exonicFeatureID) {
              index = gfStart.name.indexOf(':');
              if (gfStart.name.indexOf(':') < 0) {
                exonIDStartPos = -1;
              } else {
                exonIDStartPos = Util.parseInt(gfStart.name.substring(0, index));
              }

              int relativeCodingStartPos = Util.parseInt(gfStart.name.substring(gfStart.name.indexOf(':') + 1));
              //to do something about deletion  
              GeneFeature gf1 = calculateAminoAcidDeletion(relativeCodingStartPos, ref, allele, delLen);
              index = gf1.getName().lastIndexOf(':');
              if (index < 0) {
                gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos);
              } else {
                gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
              }
              gfList.add(gf1);
            } else {
              gfList.add(gfStart);
            }
          } else if (gfStart.id == exonicFeatureID) {
            index = gfStart.name.indexOf(':');
            if (gfStart.name.indexOf(':') < 0) {
              exonIDStartPos = -1;
            } else {
              exonIDStartPos = Util.parseInt(gfStart.name.substring(0, index));
            }

            int relativeCodingStartPos = Util.parseInt(gfStart.name.substring(gfStart.name.indexOf(':') + 1));
            GeneFeature gf1 = calculateAminoAcidDeletion(relativeCodingStartPos, ref, allele, delLen);
            index = gf1.getName().lastIndexOf(':');
            if (gfStart.id != gfEnd.id) {
              if (index < 0) {
                gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + +exonIDStartPos + "-" + GlobalManager.VAR_FEATURE_NAMES[gfStart.id]);
              } else {
                gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + "-" + GlobalManager.VAR_FEATURE_NAMES[gfStart.id] + ":" + gf1.getName().substring(index + 1));
              }

            } else if (index < 0) {
              gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos);
            } else {
              gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
            }
            gfList.add(gf1);
          } else if (gfEnd.id == exonicFeatureID) {
            index = gfEnd.name.indexOf(':');
            if (gfEnd.name.indexOf(':') < 0) {
              exonIDStartPos = -1;
            } else {
              exonIDStartPos = Util.parseInt(gfEnd.name.substring(0, index));
            }
            int relativeCodingStartPos = Util.parseInt(gfEnd.name.substring(gfEnd.name.indexOf(':') + 1));

            //note calculateAminoAcidDeletionAtRightTail has not finished yet and simple put is as unknonw
            //gfList.add(gfEnd);
            // System.out.println(oldStartPos);
            GeneFeature gf1 = calculateAminoAcidDeletionAtRightTail(relativeCodingStartPos, ref, allele, delLen);
            index = gf1.getName().lastIndexOf(':');
            if (gfStart.id != gfEnd.id) {
              if (index < 0) {
                gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":" + GlobalManager.VAR_FEATURE_NAMES[gfStart.id] + "-exon" + exonIDStartPos);
              } else {
                gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":" + GlobalManager.VAR_FEATURE_NAMES[gfStart.id] + "-exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
              }
            } else if (index < 0) {
              gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos);
            } else {
              gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
            }
            gfList.add(gf1);

          } else {
            //not sure this is correct or not
            gfList.add(gfStart);
          }
        } else if (gfStart != null) {
          if (gfStart.id == exonicFeatureID) {
            index = gfStart.name.indexOf(':');
            if (gfStart.name.indexOf(':') < 0) {
              exonIDStartPos = -1;
            } else {
              exonIDStartPos = Util.parseInt(gfStart.name.substring(0, index));
            }

            int relativeCodingStartPos = Util.parseInt(gfStart.name.substring(gfStart.name.indexOf(':') + 1));
            //to do something about deletion  
            GeneFeature gf1 = calculateAminoAcidDeletion(relativeCodingStartPos, ref, allele, startPos);

            index = gf1.getName().lastIndexOf(':');
            if (index < 0) {
              gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos);
            } else {
              gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonIDStartPos + ":" + gf1.getName().substring(index + 1));
            }
            gfList.add(gf1);
          } else {
            gfList.add(gfStart);
          }
        } else {
          gfList.add(gfEnd);
        }

      } else {
        startPos = oldStartPos;
        startAllele = 0;
        int effectiveLen = ref.length();
        if (ref == null) {
          return null; //I'm not sure what value should be returned, but the ref==null will give error. It may be the error of the resource file. 
        }

        if (ref.length() > 1 && ref.length() == allele.length()) {
//                    System.out.println(chr+":"+oldStartPos+":"+ref);
//On May 1, 2017, the alogrithm is modified to consider variants with multiple consecutive variants
          if (strand == '+') {
            while (startAllele < ref.length() && ref.charAt(startAllele) == allele.charAt(startAllele)) {
              startAllele++;
              effectiveLen--;
            }
            startPos = oldStartPos + startAllele;
          } else {
            /*
                        startAllele = ref.length() - 1;
                        while (startAllele >= 0 && ref.charAt(startAllele) == allele.charAt(startAllele)) {
                            startAllele--;
                            effectiveLen--;
                        }
                        
             */

            //the reverse sequences have been converted
            while (startAllele < ref.length() && ref.charAt(startAllele) == allele.charAt(startAllele)) {
              startAllele++;
              effectiveLen--;
            }
            //but the old pos are not converted
            startPos = oldStartPos + (ref.length() - 1 - startAllele);

          }
        }

        //it is an sustitution
        GeneFeature gf = findCrudeFeature(startPos, upstreamDis, downstreamDis, splicingDis, ref, allele);
        if (gf == null) {
          continue;
        }
        if (gf.id == exonicFeatureID) {
          //int exonID = gf.exonID; //Util.parseInt(gf.name.substring(0, gf.name.indexOf(':')));
          //int relativeCodingStartPos = gf.relativeCodingStartPos;// Util.parseInt(gf.name.substring(gf.name.indexOf(':') + 1));
          int exonID = Util.parseInt(gf.name.substring(0, gf.name.indexOf(':')));
          int relativeCodingStartPos = Util.parseInt(gf.name.substring(gf.name.indexOf(':') + 1));
          errorCode[0] = 0;
          //System.out.println(relativeCodingStartPos);
          GeneFeature gf1;

          if (effectiveLen > 1 && seqSet.contains(allele.charAt(startAllele))) {
            if (strand == '+') {
              gf1 = calculateAminoAcidChangeMulti(relativeCodingStartPos, true, ref.substring(startAllele), allele.substring(startAllele), startPos, gf.pos2CondingEnd, errorCode);
            } else {
              gf1 = calculateAminoAcidChangeMulti(relativeCodingStartPos, false, ref.substring(startAllele), allele.substring(startAllele), startPos, gf.pos2CondingEnd, errorCode);
            }
          } else {
            gf1 = calculateAminoAcidChange(relativeCodingStartPos, ref.charAt(startAllele), allele.charAt(startAllele), startPos, gf.pos2CondingEnd, errorCode);
          }
          switch (errorCode[0]) {
            case 1:
              LOG.warn("The RefmRNA " + refID + " has no sequence data for the variant at chr" + chr + ":" + oldStartPos);
              break;
            case 2:
              LOG.warn("The RefmRNA " + refID + " has no sequence data for the variant at chr" + chr + ":" + oldStartPos);
              break;
            case 3:
              LOG.warn("The reference allele " + ref + " of chr" + chr + ":" + oldStartPos + " in the sample data and database are not identical on " + refID + " of " + geneSymb);
              break;
            // LOG.warn("The variant chr" + chr + ":" + oldStartPos + " is mapped against problematic codon on " + refID + " of " + geneSym);
            case 4:
              break;
            default:
              break;
          }
          index = gf1.getName().lastIndexOf(':');
          if (index < 0) {
            gf1.setName(refID + ":" + gf1.getName() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonID);
          } else {
            gf1.setName(refID + ":" + gf1.getName().substring(0, index) + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + exonID + ":" + gf1.getName().substring(index + 1));
          }
          gfList.add(gf1);
        } else {
          gfList.add(gf);
        }
      }
    }

    if (gfList.isEmpty()) {
      return null;
    }
    if (gfList.size() == 1) {
      GeneFeature gf = gfList.get(0);
      if (gf != null) {
        gf.setName(geneSymb + ":" + gf.getName());
      }
      return gf;
    } else {
      Collections.sort(gfList, new GeneFeatureComparator());
      GeneFeature gf = gfList.get(0);
      if (gf.getInfor() == null) {
        gf.setInfor("");
      }
      for (int i = 1; i < gfList.size(); i++) {
        GeneFeature gf1 = gfList.get(i);
        gf.setName(gf.getName() + "&" + gf1.getName());
        gf.setInfor(gf.getInfor() + (gf1.getInfor() == null ? "" : "&" + gf1.getInfor()));
      }
      gf.setName(geneSymb + ":" + gf.getName());
      return gf;
    }

  }

  public GeneFeature findCrudeFeature(int pos, int upstreamDis, int downstreamDis, int splicingDis, String ref, String alt) throws Exception {
    if (strand == '0') {
      throw new Exception("Unknown strand at " + refID);
    }
    int relativeCodingStartPos = -1;
    int exonIndex = binarySearch(pos, 0, exonNum - 1);
    //  System.out.println(pos);
    //Very important: In UCSC refGene regardless of strand the exon start site is not included . eg. for example in 93615298-93620445, the acual coding region should be 93615299-93620445
    //all coordinates are 1-based
    //note in the refgene database
    //the leftside boundaries of exon region are inclusive and rightside boundaries are exclusive 
    //Since v0.8, we start to use the hgvs format to output the annotation http://www.hgvs.org/mutnomen/examplesDNA.html#sub
    switch (strand) {
      case '+':
        if (exonIndex < 0) {
          exonIndex = -exonIndex - 1;
          if (exonIndex == exonNum) {
            //after all exons
            if (pos > end + downstreamDis) {
              //intergenic
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
            } else {
              //downstream	12	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this)
              relativeCodingStartPos = 0;
              for (int i = codingEndSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingEnd - exons.get(codingEndSiteExonID).start);
              relativeCodingStartPos += (pos - exons.get(exonNum - 1).end);

              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (relativeCodingStartPos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
            }
          } else if (exonIndex == 0) {
            if (pos <= start - upstreamDis) {
              //intergenic
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
            } else if (pos <= start) {
              // upstream	11	variant overlaps 1-kb region upstream of transcription start site
              relativeCodingStartPos = 0;
              for (int i = 0; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos += (exons.get(0).start - pos);
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (relativeCodingStartPos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
            } else if (noCodingExon) {
              // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation)
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
            } else if (pos <= codingStart) {
              //5UTR	8	variant overlaps a 5' untranslated region
              //relativeCodingStartPos = codingStart - pos + 1;
              relativeCodingStartPos = 0;
              if (exonIndex < codingStartSiteExonID) {
                for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                  relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
                }
                relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
                relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
              } else {
                relativeCodingStartPos = codingStart - pos;
              }
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c." + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
            } else if (pos <= codingEnd) {
              //it must in the coiding region
              // exonic
              //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA
              relativeCodingStartPos = pos - codingStart - 1;
              //special coding for the exonic variantsl it will be parsed later on                            
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), "1:" + relativeCodingStartPos, (codingEnd - pos));
            } else {
              //it is ver unlikely
              // 3UTR	9	variant overlaps a 3' untranslated region
              relativeCodingStartPos = 0;
              if (codingEndSiteExonID < exonIndex) {
                for (int i = codingEndSiteExonID; i < exonIndex; i++) {
                  relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
                }
                relativeCodingStartPos -= (codingEnd - exons.get(codingEndSiteExonID).start);
                relativeCodingStartPos += (pos - exons.get(exonIndex).start);
              } else {
                relativeCodingStartPos = (pos - codingEnd);
              }

              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
            }
          } else //  the shiftBpDel must be between 1 and exonIndex-1
          if (noCodingExon) {
            // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation)
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
            //this is a donor
            relativeCodingStartPos = 0;
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
            } else {
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingStart - exons.get(codingStartSiteExonID).start);
            }

            /*
                            relativeCodingStartPos = pos - codingStart - 1;
                            for (int i = exonIndex - 1; i > codingStartSiteExonID; i--) {
                            relativeCodingStartPos -= intronLength.getQuick(i - 1);
                            }
             */
            //splicing	6	variant is within 2-bp of a splicing junction (use -splicing_threshold to change this)
            //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":splicingGTdonor" + (exonIndex) + "+" + Math.abs(exons.get(exonIndex - 1).end - pos + 1));
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeCodingStartPos + "+" + Math.abs(pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex + 1) + "GTdonor");

          } else if (pos <= exons.get(exonIndex).start - splicingDis) {
            //5UTR	8	variant overlaps a 5' untranslated region
            // System.out.println("----------------------\startAllele" + ( exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
            int offSet1 = exons.get(exonIndex).start - pos;
            int offSet2 = pos - exons.get(exonIndex - 1).end;
            relativeCodingStartPos = 0;
            StringBuilder sb = new StringBuilder(":c.");
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
            } else {
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingStart - exons.get(codingStartSiteExonID).start);
            }
            if (offSet1 < offSet2) {
              relativeCodingStartPos++;
              sb.append(relativeCodingStartPos);
              sb.append('-');
              sb.append(offSet1 + 1);
            } else {
              sb.append(relativeCodingStartPos);
              sb.append('+');
              sb.append(offSet2);
            }
            sb.append(ref).append(">").append(alt);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonIndex));
          } else if (pos <= exons.get(exonIndex).start) {
            //the 5' and 3' are relative to the closet exon
            relativeCodingStartPos = 0;
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
            } else {
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingStart - exons.get(codingStartSiteExonID).start);
            }
            /*
                            relativeCodingStartPos = pos - codingStart - 1;
                            for (int i = exonIndex; i > codingStartSiteExonID; i--) {
                            relativeCodingStartPos -= intronLength.getQuick(i - 1);
                            }
                            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos + exons.get(exonIndex).start - pos + 2) + "-" + (exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex) + "AGacceptor");
             */
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos) + "-" + (exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex) + "AGacceptor");

          } else if (pos <= codingStart) {
            //5UTR	8	variant overlaps a 5' untranslated region
            //relativeCodingStartPos = codingStart - pos + 1;
            relativeCodingStartPos = 0;
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
            } else {
              relativeCodingStartPos = codingStart - pos;
            }
            relativeCodingStartPos = -relativeCodingStartPos;
            relativeCodingStartPos--;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c." + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic
            //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA

            /*
                        relativeCodingStartPos = pos - codingStart - 1;
                        for (int i = exonIndex; i > codingStartSiteExonID; i--) {
                            relativeCodingStartPos -= intronLength.getQuick(i - 1);
                        }
                        int tmpI = relativeCodingStartPos;
             */
            relativeCodingStartPos = 0;
            if (exonIndex > codingStartSiteExonID) {
              for (int i = codingStartSiteExonID + 1; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (exons.get(codingStartSiteExonID).end - codingStart);
              relativeCodingStartPos += (pos - exons.get(exonIndex).start);
            } else {
              relativeCodingStartPos = pos - codingStart;
            }
            relativeCodingStartPos--;

            //special coding for the exonic variantsl it will be parsed later on
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1) + ":" + relativeCodingStartPos, (codingEnd - pos));
          } else {
            //relativeCodingStartPos = (pos - codingEnd);
            relativeCodingStartPos = 0;
            if (codingEndSiteExonID < exonIndex) {
              for (int i = codingEndSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingEnd - exons.get(codingEndSiteExonID).start);
              relativeCodingStartPos += (pos - exons.get(exonIndex).start);
            } else {
              relativeCodingStartPos = (pos - codingEnd);
            }
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          }
        } else //just at the  leftside boundary which is exclusive
        if (noCodingExon) {
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= codingStart) {
          //relativeCodingStartPos = (codingStart - pos + 1);
          relativeCodingStartPos = 0;
          if (exonIndex < codingStartSiteExonID) {
            for (int i = exonIndex; i < codingStartSiteExonID; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos += (codingStart - exons.get(codingStartSiteExonID).start);
            relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
          } else {
            relativeCodingStartPos = codingStart - pos;
          }
          relativeCodingStartPos = -relativeCodingStartPos;
          relativeCodingStartPos--;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c." + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        } else if (pos <= codingEnd) {
          /*
                    relativeCodingStartPos = pos - codingStart - 1;
                    for (int i = exonIndex; i > codingStartSiteExonID; i--) {
                        relativeCodingStartPos -= intronLength.getQuick(i - 1);
                    }
                    int tmpI = relativeCodingStartPos;
           */
          relativeCodingStartPos = 0;
          if (exonIndex > codingStartSiteExonID) {
            for (int i = codingStartSiteExonID + 1; i < exonIndex; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos += (exons.get(codingStartSiteExonID).end - codingStart);
            relativeCodingStartPos += (pos - exons.get(exonIndex).start);
          } else {
            relativeCodingStartPos = pos - codingStart;
          }
          relativeCodingStartPos--;

          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1) + ":" + relativeCodingStartPos, (codingEnd - pos));
          //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID+":("+exonNum+"Exons"  + (multipleMapping ? "MultiMap)" : ")") + ":3splicing" + (exonIndex + 1));
        } else {
          //relativeCodingStartPos = (pos - codingEnd);
          relativeCodingStartPos = 0;
          relativeCodingStartPos = 0;
          if (codingEndSiteExonID < exonIndex) {
            for (int i = codingEndSiteExonID; i < exonIndex; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos -= (codingEnd - exons.get(codingEndSiteExonID).start);
            relativeCodingStartPos += (pos - exons.get(exonIndex).start);
          } else {
            relativeCodingStartPos = (pos - codingEnd);
          }
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        }
      case '-':
        if (exonIndex < 0) {
          exonIndex = -exonIndex - 1;
          //after all exons
          if (exonIndex == exonNum) {
            if (pos <= end + upstreamDis) {
              relativeCodingStartPos = 0;
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingEnd - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos += (pos - exons.get(exonNum - 1).end);
              // upstream 	11 	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this)
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (relativeCodingStartPos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
            } else {
              //intergenic
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
            }
          } else if (exonIndex == 0) {
            //the  leftside boundary is exclusive
            if (pos <= start - downstreamDis) {
              //intergenic
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
            } else if (pos <= start) {
              relativeCodingStartPos = 0;
              for (int i = exonIndex; i < codingEndSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingEndSiteExonID).start);
              relativeCodingStartPos += (exons.get(0).start - pos);
              // upstream 	12 	variant overlaps 1-kb region upstream of transcription start site
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (relativeCodingStartPos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
            } else if (noCodingExon) {
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
            } else if (pos <= codingStart) {
              //relativeCodingStartPos = codingStart - pos + 1;
              relativeCodingStartPos = 0;
              if (exonIndex < codingEndSiteExonID) {
                for (int i = exonIndex; i < codingEndSiteExonID; i++) {
                  relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
                }
                relativeCodingStartPos += (codingStart - exons.get(codingEndSiteExonID).start);
                relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
              } else {
                relativeCodingStartPos = codingStart - pos;
              }
              relativeCodingStartPos++;

              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
            } else if (pos <= codingEnd) {
              //it must in the coiding region
              // exonic
              relativeCodingStartPos = codingEnd - pos;
              if (exonNum > 1) {
                for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                  relativeCodingStartPos -= intronLength.getQuick(i);
                }
              }

              //special coding for the exonic variantsl it will be parsed later on
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), exonNum + ":" + relativeCodingStartPos, (pos - codingStart));

            } else {
              //relativeCodingStartPos = (pos - codingEnd);
              relativeCodingStartPos = 0;
              if (codingStartSiteExonID < exonIndex) {
                for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                  relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
                }
                relativeCodingStartPos -= (codingEnd - exons.get(codingStartSiteExonID).start);
                relativeCodingStartPos += (pos - exons.get(exonIndex).start);
              } else {
                relativeCodingStartPos = (pos - codingEnd);
              }
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
            }
          } else //the shiftBpDel must be between 1 and exonIndex-1
          if (noCodingExon) {
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
            //the 5' and 3' are relative to the closet exon
            relativeCodingStartPos = 0;
            if (exonIndex > codingStartSiteExonID) {
              for (int i = exonIndex; i > codingStartSiteExonID; i--) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              //because it is reverse strand
              relativeCodingStartPos += (exons.get(codingStartSiteExonID).end - codingEnd);
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
            } else {
              for (int i = codingStartSiteExonID; i >= exonIndex; i--) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              //because it is reverse strand
              relativeCodingStartPos -= (exons.get(codingStartSiteExonID).end - codingEnd);
              relativeCodingStartPos++;
            }

            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos) + "-" + (pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex + 1) + "AGacceptor");

            /*
                            relativeCodingStartPos = codingEnd - pos;
                            for (int i = exonIndex - 1; i < codingStartSiteExonID; i++) {
                            relativeCodingStartPos -= intronLength.getQuick(i);
                            }
                            relativeCodingStartPos++;
                            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos + (pos - exons.get(exonIndex - 1).end)) + "-" + (pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex + 1) + "AGacceptor");
             */
          } else if (pos <= exons.get(exonIndex).start - splicingDis) {
            // intronic 	4 	variant overlaps an intron
            // System.out.println("----------------------\startAllele" + (exonNum - exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
            int offSet1 = exons.get(exonIndex).start - pos;
            int offSet2 = pos - exons.get(exonIndex - 1).end;

            relativeCodingStartPos = 0;
            StringBuilder sb = new StringBuilder(":c.");
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingEnd - exons.get(codingStartSiteExonID).start);

            } else {
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingEnd - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos = -relativeCodingStartPos;
              relativeCodingStartPos--;
            }

            if (offSet1 < offSet2) {
              sb.append(relativeCodingStartPos);
              sb.append('+');
              sb.append(offSet1 + 1);
            } else {
              relativeCodingStartPos++;
              sb.append(relativeCodingStartPos);
              sb.append('-');
              sb.append(offSet2);
            }
            sb.append(ref).append(">").append(alt);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonNum - exonIndex));
          } else if (pos <= exons.get(exonIndex).start) {
            //the 5' and 3' are relative to the closet exon
            relativeCodingStartPos = 0;
            if (exonIndex > codingStartSiteExonID) {
              for (int i = exonIndex; i > codingStartSiteExonID; i--) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              //because it is reverse strand
              relativeCodingStartPos += (exons.get(codingStartSiteExonID).end - codingEnd);
              relativeCodingStartPos = -relativeCodingStartPos;
              //relativeCodingStartPos--;
            } else {
              for (int i = codingStartSiteExonID; i >= exonIndex; i--) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              //because it is reverse strand
              relativeCodingStartPos -= (exons.get(codingStartSiteExonID).end - codingEnd);
              // relativeCodingStartPos++;
            }
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeCodingStartPos + "+" + Math.abs(exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex) + "GTdonor");
            /*
                            relativeCodingStartPos = codingEnd - pos;
                            for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                            relativeCodingStartPos -= intronLength.getQuick(i);
                            }
                            relativeCodingStartPos--;
                            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeCodingStartPos + "+" + Math.abs(exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex) + "GTdonor");
             */
          } else if (pos <= codingStart) {
            //relativeCodingStartPos = (codingStart - pos);
            relativeCodingStartPos = 0;
            if (exonIndex < codingEndSiteExonID) {
              for (int i = exonIndex; i < codingEndSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingStart - exons.get(codingEndSiteExonID).start);
              relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
            } else {
              relativeCodingStartPos = (codingStart - pos);
            }
            relativeCodingStartPos++;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic
            //probably because codingEnd is exclusive, no -1 needed as in the forward strand

            /*
                        relativeCodingStartPos = codingEnd - pos;
                        for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                            relativeCodingStartPos -= intronLength.getQuick(i);
                        }
                        int tmpI = relativeCodingStartPos;
             */
            relativeCodingStartPos = 0;
            if (exonIndex < codingStartSiteExonID) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos += (codingEnd - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos += (exons.get(exonIndex).start - pos);
            } else {
              relativeCodingStartPos = codingEnd - pos;
            }

            // exonic
            //very important: usaully what we have in sample are alleles in forward strand
            //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid
            //special coding for the exonic variantsl it will be parsed later on
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex) + ":" + relativeCodingStartPos, (pos - codingStart));

          } else {
            //relativeCodingStartPos = (pos - codingEnd);
            relativeCodingStartPos = 0;
            if (codingStartSiteExonID < exonIndex) {
              for (int i = codingStartSiteExonID; i < exonIndex; i++) {
                relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
              }
              relativeCodingStartPos -= (codingEnd - exons.get(codingStartSiteExonID).start);
              relativeCodingStartPos += (pos - exons.get(exonIndex).start);
            } else {
              relativeCodingStartPos = (pos - codingEnd);
            }

            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          }
        } else //just at the  rightside boundary which is inclusive for reverse strand mRAN
        if (noCodingExon) {
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= codingStart) {
          //relativeCodingStartPos = (codingStart - pos) + 1;
          relativeCodingStartPos = 0;
          if (exonIndex < codingEndSiteExonID) {
            for (int i = exonIndex; i < codingEndSiteExonID; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos += (codingStart - exons.get(codingEndSiteExonID).start);
            relativeCodingStartPos -= (pos - exons.get(exonIndex).start);
          } else {
            relativeCodingStartPos = (codingStart - pos);
          }
          relativeCodingStartPos++;

          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        } else if (pos <= codingEnd) {
          //it must in the coiding region
          // exonic    
          //probably because codingEnd is exclusive, no -1 needed as in the forward strand

          /*relativeCodingStartPos = codingEnd - pos;
                    for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                        relativeCodingStartPos -= intronLength.getQuick(i);
                    }
                    int tmpI = relativeCodingStartPos;
           */
          relativeCodingStartPos = 0;
          if (exonIndex < codingStartSiteExonID) {
            for (int i = exonIndex; i < codingStartSiteExonID; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos += (codingEnd - exons.get(codingStartSiteExonID).start);
            relativeCodingStartPos += (exons.get(exonIndex).start - pos);
          } else {
            relativeCodingStartPos = codingEnd - pos;
          }

          // exonic
          //very important: usaully what we have in sample are alleles in forward strand
          //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid
          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex) + ":" + relativeCodingStartPos, (pos - codingStart));
        } else {
          //relativeCodingStartPos = (pos - codingEnd);
          relativeCodingStartPos = 0;
          if (codingStartSiteExonID < exonIndex) {
            for (int i = codingStartSiteExonID; i < exonIndex; i++) {
              relativeCodingStartPos += (exons.get(i).end - exons.get(i).start);
            }
            relativeCodingStartPos -= (codingEnd - exons.get(codingStartSiteExonID).start);
            relativeCodingStartPos += (pos - exons.get(exonIndex).start);
          } else {
            relativeCodingStartPos = (pos - codingEnd);
          }
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        }
      default:
        //unrecognzed strand infor
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("unknown"), "unknown");
    }
  }

  public GeneFeature findCrudeFeature0(int pos, int upstreamDis, int downstreamDis, int splicingDis, String ref, String alt) throws Exception {
    if (strand == '0') {
      throw new Exception("Unknown strand at " + refID);
    }
    int relativeCodingStartPos = -1;
    int exonIndex = binarySearch(pos, 0, exonNum - 1);
    //  System.out.println(pos);

    //Very important: In UCSC refGene regardless of strand the exon start site is not included . eg. for example in 93615298-93620445, the acual coding region should be 93615299-93620445
    //all coordinates are 1-based
    //note in the refgene database
    //the leftside boundaries of exon region are inclusive and rightside boundaries are exclusive 
    //Since v0.8, we start to use the hgvs format to output the annotation http://www.hgvs.org/mutnomen/examplesDNA.html#sub
    if (strand == '+') {
      if (exonIndex < 0) {
        exonIndex = -exonIndex - 1;
        if (exonIndex == exonNum) {
          //after all exons                   
          if (pos > end + downstreamDis) {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else {
            //downstream	12	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this) 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (pos - end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
          }
        } else if (exonIndex == 0) {
          if (pos <= start - upstreamDis) {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else if (pos <= start) {
            // upstream	11	variant overlaps 1-kb region upstream of transcription start site 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (start - pos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
          } else if (noCodingExon) {
            // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation) 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= codingStart) {
            //5UTR	8	variant overlaps a 5' untranslated region 
            relativeCodingStartPos = codingStart - pos + 1;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic   
            //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA   

            relativeCodingStartPos = pos - codingStart - 1;
            //special coding for the exonic variantsl it will be parsed later on
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), "1:" + relativeCodingStartPos, (codingEnd - pos));
          } else {
            //it is ver unlikely
            // 3UTR	9	variant overlaps a 3' untranslated region 
            relativeCodingStartPos = (pos - codingEnd);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          }
        } else //  the shiftBpDel must be between 1 and exonIndex-1
        if (noCodingExon) {
          // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation) 
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
          //this is a donor                      
          relativeCodingStartPos = pos - codingStart - 1;

          for (int i = exonIndex - 1; i > codingStartSiteExonID; i--) {
            relativeCodingStartPos -= intronLength.getQuick(i - 1);
          }
          //splicing	6	variant is within 2-bp of a splicing junction (use -splicing_threshold to change this) 
          //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":splicingGTdonor" + (exonIndex) + "+" + Math.abs(exons.get(exonIndex - 1).end - pos + 1));
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeCodingStartPos + "+" + Math.abs(pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex + 1) + "GTdonor");

        } else if (pos <= exons.get(exonIndex).start - splicingDis) {
          //5UTR	8	variant overlaps a 5' untranslated region 
          // System.out.println("----------------------\startAllele" + ( exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
          int offSet1 = exons.get(exonIndex).start - pos;
          int offSet2 = pos - exons.get(exonIndex - 1).end;
          relativeCodingStartPos = pos - codingStart - 1;

          StringBuilder sb = new StringBuilder(":c.");
          if (offSet1 < offSet2) {
            for (int i = exonIndex; i > codingStartSiteExonID; i--) {
              relativeCodingStartPos -= intronLength.getQuick(i - 1);
            }
            sb.append(relativeCodingStartPos + offSet1 + 2);
            sb.append('-');
            sb.append(offSet1 + 1);
          } else {
            for (int i = exonIndex - 1; i > codingStartSiteExonID; i--) {
              relativeCodingStartPos -= intronLength.getQuick(i - 1);
            }
            sb.append(relativeCodingStartPos - offSet2 + 1);
            sb.append('+');
            sb.append(offSet2);
          }
          sb.append(ref).append(">").append(alt);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonIndex));
        } else if (pos <= exons.get(exonIndex).start) {
          //the 5' and 3' are relative to the closet exon   
          relativeCodingStartPos = pos - codingStart - 1;
          for (int i = exonIndex; i > codingStartSiteExonID; i--) {
            relativeCodingStartPos -= intronLength.getQuick(i - 1);
          }
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos + exons.get(exonIndex).start - pos + 2) + "-" + (exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex) + "AGacceptor");
        } else if (pos <= codingStart) {
          //5UTR	8	variant overlaps a 5' untranslated region 
          relativeCodingStartPos = codingStart - pos + 1;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        } else if (pos <= codingEnd) {
          //it must in the coiding region
          // exonic   
          //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA      
          relativeCodingStartPos = pos - codingStart - 1;
          for (int i = exonIndex; i > codingStartSiteExonID; i--) {
            relativeCodingStartPos -= intronLength.getQuick(i - 1);
          }
          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1) + ":" + relativeCodingStartPos, (codingEnd - pos));
        } else {
          relativeCodingStartPos = (pos - codingEnd);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        }
      } else //just at the  leftside boundary which is exclusive
      if (noCodingExon) {
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
      } else if (pos <= codingStart) {
        relativeCodingStartPos = (codingStart - pos + 1);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
      } else if (pos <= codingEnd) {
        relativeCodingStartPos = pos - codingStart - 1;
        for (int i = exonIndex; i > codingStartSiteExonID; i--) {
          relativeCodingStartPos -= intronLength.getQuick(i - 1);
        }
        //special coding for the exonic variantsl it will be parsed later on
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1) + ":" + relativeCodingStartPos, (codingEnd - pos));
        //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID+":("+exonNum+"Exons"  + (multipleMapping ? "MultiMap)" : ")") + ":3splicing" + (exonIndex + 1));
      } else {
        relativeCodingStartPos = (pos - codingEnd);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
      }
    } else if (strand == '-') {
      if (exonIndex < 0) {
        exonIndex = -exonIndex - 1;

        //after all exons
        if (exonIndex == exonNum) {
          if (pos <= end + upstreamDis) {
            // upstream 	11 	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this)
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (pos - end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
          } else {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          }
        } else if (exonIndex == 0) {
          //the  leftside boundary is exclusive
          if (pos <= start - downstreamDis) {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else if (pos <= start) {
            // upstream 	12 	variant overlaps 1-kb region upstream of transcription start site
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (start - pos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
          } else if (noCodingExon) {
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= codingStart) {
            relativeCodingStartPos = codingStart - pos + 1;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic    
            relativeCodingStartPos = codingEnd - pos;
            if (exonNum > 1) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos -= intronLength.getQuick(i);
              }
            }

            //special coding for the exonic variantsl it will be parsed later on
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), exonNum + ":" + relativeCodingStartPos, (pos - codingStart));

          } else {
            relativeCodingStartPos = (pos - codingEnd);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          }
        } else //the shiftBpDel must be between 1 and exonIndex-1
        if (noCodingExon) {
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
          //the 5' and 3' are relative to the closet exon
          relativeCodingStartPos = codingEnd - pos;
          for (int i = exonIndex - 1; i < codingStartSiteExonID; i++) {
            relativeCodingStartPos -= intronLength.getQuick(i);
          }
          relativeCodingStartPos++;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeCodingStartPos + (pos - exons.get(exonIndex - 1).end)) + "-" + (pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex + 1) + "AGacceptor");
        } else if (pos <= exons.get(exonIndex).start - splicingDis) {
          // intronic 	4 	variant overlaps an intron 
          // System.out.println("----------------------\startAllele" + (exonNum - exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
          int offSet1 = exons.get(exonIndex).start - pos;
          int offSet2 = pos - exons.get(exonIndex - 1).end;
          relativeCodingStartPos = codingEnd - pos;

          StringBuilder sb = new StringBuilder(":c.");
          if (offSet1 < offSet2) {
            for (int i = exonIndex; i < codingStartSiteExonID; i++) {
              relativeCodingStartPos -= intronLength.getQuick(i);
            }
            sb.append(relativeCodingStartPos - offSet1);
            sb.append('+');
            sb.append(offSet1 + 1);
          } else {
            for (int i = exonIndex - 1; i < codingStartSiteExonID; i++) {
              relativeCodingStartPos -= intronLength.getQuick(i);
            }
            sb.append(relativeCodingStartPos + offSet2 + 1);
            sb.append('-');
            sb.append(offSet2);
          }
          sb.append(ref).append(">").append(alt);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonNum - exonIndex));
        } else if (pos <= exons.get(exonIndex).start) {
          //the 5' and 3' are relative to the closet exon
          relativeCodingStartPos = codingEnd - pos;
          for (int i = exonIndex; i < codingStartSiteExonID; i++) {
            relativeCodingStartPos -= intronLength.getQuick(i);
          }
          relativeCodingStartPos--;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeCodingStartPos + "+" + Math.abs(exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex) + "GTdonor");
        } else if (pos <= codingStart) {
          relativeCodingStartPos = (codingStart - pos);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        } else if (pos <= codingEnd) {
          //it must in the coiding region
          // exonic   
          //probably because codingEnd is exclusive, no -1 needed as in the forward strand

          relativeCodingStartPos = codingEnd - pos;
          for (int i = exonIndex; i < codingStartSiteExonID; i++) {
            relativeCodingStartPos -= intronLength.getQuick(i);
          }
          // exonic  
          //very important: usaully what we have in sample are alleles in forward strand
          //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid

          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex) + ":" + relativeCodingStartPos, (pos - codingStart));

        } else {
          relativeCodingStartPos = (pos - codingEnd);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        }
      } else //just at the  rightside boundary which is inclusive for reverse strand mRAN
      if (noCodingExon) {
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
      } else if (pos <= codingStart) {
        relativeCodingStartPos = (codingStart - pos) + 1;
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
      } else if (pos <= codingEnd) {
        //it must in the coiding region
        // exonic   
        //probably because codingEnd is exclusive, no -1 needed as in the forward strand
        relativeCodingStartPos = codingEnd - pos;
        for (int i = exonIndex; i < codingStartSiteExonID; i++) {
          relativeCodingStartPos -= intronLength.getQuick(i);
        }
        // exonic  
        //very important: usaully what we have in sample are alleles in forward strand
        //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid 

        //special coding for the exonic variantsl it will be parsed later on
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex) + ":" + relativeCodingStartPos, (pos - codingStart));
      } else {
        relativeCodingStartPos = (pos - codingEnd);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
      }
    } else {
      //unrecognzed strand infor
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("unknown"), "unknown");
    }
  }

  //later I found we should calculate the relative distance from the coding positions
  public GeneFeature findCrudeFeature1(int pos, int upstreamDis, int downstreamDis, int splicingDis, String ref, String alt) throws Exception {
    if (strand == '0') {
      throw new Exception("Unknown strand at " + refID);
    }
    int relativeCodingStartPos = -1;
    int relativeExonStartPos = -1;
    int exonIndex = binarySearch(pos, 0, exonNum - 1);
    //  System.out.println(pos);

    //Very important: In UCSC refGene regardless of strand the exon start site is not included . eg. for example in 93615298-93620445, the acual coding region should be 93615299-93620445
    //all coordinates are 1-based
    //note in the refgene database
    //the leftside boundaries of exon region are inclusive and rightside boundaries are exclusive 
    //Since v0.8, we start to use the hgvs format to output the annotation http://www.hgvs.org/mutnomen/examplesDNA.html#sub
    if (strand == '+') {
      if (exonIndex < 0) {
        exonIndex = -exonIndex - 1;
        if (exonIndex == exonNum) {
          //after all exons                   
          if (pos > end + downstreamDis) {
            //intergenicrelativeCodingStartPos
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else {
            //downstream	12	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this) 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (pos - end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
          }
        } else if (exonIndex == 0) {
          if (pos <= start - upstreamDis) {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else if (pos <= start) {
            // upstream	11	variant overlaps 1-kb region upstream of transcription start site 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (start - pos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
          } else if (noCodingExon) {
            // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation) 
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= codingStart) {
            //5UTR	8	variant overlaps a 5' untranslated region 
            //relativeCodingStartPos = codingStart - pos + 1;
            relativeExonStartPos = exons.get(0).start - pos + 1;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic   
            //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA   
            relativeCodingStartPos = pos - codingStart - 1;
            relativeExonStartPos = pos - exons.get(0).start - 1;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), 1, relativeExonStartPos, relativeCodingStartPos, (codingEnd - pos));
          } else {
            //it is ver unlikely
            // 3UTR	9	variant overlaps a 3' untranslated region 
            relativeCodingStartPos = (pos - codingEnd);
            relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          }
        } else //  the shiftBpDel must be between 1 and exonIndex-1
        if (noCodingExon) {
          // ncRNA	7	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation) 
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
          //this is a donor                      
          //relativeCodingStartPos = pos - codingStart - 1;
          relativeExonStartPos = pos - exons.get(0).start - 1;

          for (int i = exonIndex - 1; i > intronLength.size(); i--) {
            relativeExonStartPos -= intronLength.getQuick(i - 1);
          }
          //splicing	6	variant is within 2-bp of a splicing junction (use -splicing_threshold to change this) 
          //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":splicingGTdonor" + (exonIndex) + "+" + Math.abs(exons.get(exonIndex - 1).end - pos + 1));
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeExonStartPos + "+" + Math.abs(pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex + 1) + "GTdonor");

        } else if (pos <= exons.get(exonIndex).start - splicingDis) {
          //5UTR	8	variant overlaps a 5' untranslated region 
          // System.out.println("----------------------\startAllele" + ( exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
          int offSet1 = exons.get(exonIndex).start - pos;
          int offSet2 = pos - exons.get(exonIndex - 1).end;
          relativeCodingStartPos = pos - codingStart - 1;
          relativeExonStartPos = pos - exons.get(0).start - 1;
          StringBuilder sb = new StringBuilder(":c.");
          if (offSet1 < offSet2) {
            for (int i = exonIndex; i > 0; i--) {
              relativeExonStartPos -= intronLength.getQuick(i - 1);
            }
            sb.append(relativeExonStartPos + offSet1 + 2);
            sb.append('-');
            sb.append(offSet1 + 1);
          } else {
            for (int i = exonIndex - 1; i > 0; i--) {
              relativeExonStartPos -= intronLength.getQuick(i - 1);
            }
            sb.append(relativeExonStartPos - offSet2 + 1);
            sb.append('+');
            sb.append(offSet2);
          }
          sb.append(ref).append(">").append(alt);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonIndex));
        } else if (pos <= exons.get(exonIndex).start) {
          //the 5' and 3' are relative to the closet exon   
          //relativeCodingStartPos = pos - codingStart - 1;
          relativeExonStartPos = pos - exons.get(0).start - 1;

          for (int i = exonIndex; i > 0; i--) {
            relativeExonStartPos -= intronLength.getQuick(i - 1);
          }
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeExonStartPos + exons.get(exonIndex).start - pos + 2) + "-" + (exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonIndex) + "AGacceptor");
        } else if (pos <= codingStart) {
          //5UTR	8	variant overlaps a 5' untranslated region 
          relativeCodingStartPos = codingStart - pos + 1;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeCodingStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        } else if (pos <= codingEnd) {
          //it must in the coiding region
          // exonic   
          //do not know why my input sample always have 1-base shift compared to the refGene coordinates on forward RefmRNA      
          relativeCodingStartPos = pos - codingStart - 1;
          for (int i = exonIndex; i > codingStartSiteExonID; i--) {
            relativeCodingStartPos -= intronLength.getQuick(i - 1);
          }
          relativeExonStartPos = pos - exons.get(0).start - 1;
          for (int i = exonIndex; i > 0; i--) {
            relativeExonStartPos -= intronLength.getQuick(i - 1);
          }
          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1), relativeExonStartPos, relativeCodingStartPos, (codingEnd - pos));
        } else {
          //relativeCodingStartPos = (pos - codingEnd);
          relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        }
      } else //just at the  leftside boundary which is exclusive
      if (noCodingExon) {
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
      } else if (pos <= codingStart) {
        //relativeCodingStartPos = (codingStart - pos + 1);
        relativeExonStartPos = (exons.get(0).start - pos + 1);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
      } else if (pos <= codingEnd) {
        relativeCodingStartPos = pos - codingStart - 1;
        for (int i = exonIndex; i > codingStartSiteExonID; i--) {
          relativeCodingStartPos -= intronLength.getQuick(i - 1);
        }
        relativeExonStartPos = pos - exons.get(0).start - 1;
        for (int i = exonIndex; i > 0; i--) {
          relativeExonStartPos -= intronLength.getQuick(i - 1);
        }
        //special coding for the exonic variantsl it will be parsed later on
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonIndex + 1), relativeExonStartPos, relativeCodingStartPos, (codingEnd - pos));
        //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID+":("+exonNum+"Exons"  + (multipleMapping ? "MultiMap)" : ")") + ":3splicing" + (exonIndex + 1));
      } else {
        //relativeCodingStartPos = (pos - codingEnd);
        relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
      }
    } else if (strand == '-') {
      if (exonIndex < 0) {
        exonIndex = -exonIndex - 1;

        //after all exons
        if (exonIndex == exonNum) {
          if (pos <= end + upstreamDis) {
            // upstream 	11 	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this)
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("upstream"), refID + ":c.-" + (pos - end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":upstream");
          } else {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          }
        } else if (exonIndex == 0) {
          //the  leftside boundary is exclusive
          if (pos <= start - downstreamDis) {
            //intergenic
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intergenic"), "intergenic");
          } else if (pos <= start) {
            // upstream 	12 	variant overlaps 1-kb region upstream of transcription start site
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("downstream"), refID + ":c.*" + (start - pos) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":downstream");
          } else if (noCodingExon) {
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
          } else if (pos <= codingStart) {
            //relativeCodingStartPos = codingStart - pos + 1;
            relativeExonStartPos = exons.get(0).start - pos + 1;
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
          } else if (pos <= codingEnd) {
            //it must in the coiding region
            // exonic    
            relativeCodingStartPos = codingEnd - pos;
            if (exonNum > 1) {
              for (int i = exonIndex; i < codingStartSiteExonID; i++) {
                relativeCodingStartPos -= intronLength.getQuick(i);
              }
            }

            relativeExonStartPos = exons.get(exons.size() - 1).end - pos;
            if (exonNum > 1) {
              for (int i = exonIndex; i < intronLength.size(); i++) {
                relativeExonStartPos -= intronLength.getQuick(i);
              }
            }

            //special coding for the exonic variantsl it will be parsed later on
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), exonNum, relativeExonStartPos, relativeCodingStartPos, (pos - codingStart));

          } else {
            //relativeCodingStartPos = (pos - codingEnd);
            relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
          }
        } else //the shiftBpDel must be between 1 and exonIndex-1
        if (noCodingExon) {
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
        } else if (pos <= exons.get(exonIndex - 1).end + splicingDis) {
          //the 5' and 3' are relative to the closet exon
          //relativeCodingStartPos = codingEnd - pos;
          relativeExonStartPos = exons.get(exons.size() - 1).end - pos;
          for (int i = exonIndex - 1; i < intronLength.size(); i++) {
            relativeExonStartPos -= intronLength.getQuick(i);
          }
          relativeExonStartPos++;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + (relativeExonStartPos + (pos - exons.get(exonIndex - 1).end)) + "-" + (pos - exons.get(exonIndex - 1).end) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex + 1) + "AGacceptor");
        } else if (pos <= exons.get(exonIndex).start - splicingDis) {
          // intronic 	4 	variant overlaps an intron 
          // System.out.println("----------------------\startAllele" + (exonNum - exonIndex) + "\startAllele" + (exons.get(exonIndex).start - pos));
          int offSet1 = exons.get(exonIndex).start - pos;
          int offSet2 = pos - exons.get(exonIndex - 1).end;

          // relativeCodingStartPos = codingEnd - pos;
          relativeExonStartPos = exons.get(exons.size() - 1).end - pos;
          StringBuilder sb = new StringBuilder(":c.");
          if (offSet1 < offSet2) {
            for (int i = exonIndex; i < intronLength.size(); i++) {
              relativeExonStartPos -= intronLength.getQuick(i);
            }
            sb.append(relativeExonStartPos - offSet1);
            sb.append('+');
            sb.append(offSet1 + 1);
          } else {
            for (int i = exonIndex - 1; i < intronLength.size(); i++) {
              relativeExonStartPos -= intronLength.getQuick(i);
            }
            sb.append(relativeExonStartPos + offSet2 + 1);
            sb.append('-');
            sb.append(offSet2);
          }
          sb.append(ref).append(">").append(alt);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("intronic"), refID + sb.toString() + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":intron" + (exonNum - exonIndex));
        } else if (pos <= exons.get(exonIndex).start) {
          //the 5' and 3' are relative to the closet exon
          //relativeCodingStartPos = codingEnd - pos;
          relativeExonStartPos = exons.get(exons.size() - 1).end - pos;
          for (int i = exonIndex; i < intronLength.size(); i++) {
            relativeExonStartPos -= intronLength.getQuick(i);
          }
          relativeExonStartPos--;
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("splicing"), refID + ":c." + relativeExonStartPos + "+" + Math.abs(exons.get(exonIndex).start - pos + 1) + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":exon" + (exonNum - exonIndex) + "GTdonor");
        } else if (pos <= codingStart) {
          //relativeCodingStartPos = (codingStart - pos);
          relativeExonStartPos = (exons.get(0).start - pos);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
        } else if (pos <= codingEnd) {
          //it must in the coiding region
          // exonic   
          //probably because codingEnd is exclusive, no -1 needed as in the forward strand

          relativeCodingStartPos = codingEnd - pos;
          for (int i = exonIndex; i < codingStartSiteExonID; i++) {
            relativeCodingStartPos -= intronLength.getQuick(i);
          }

          relativeExonStartPos = exons.get(exons.size() - 1).end - pos;
          for (int i = exonIndex; i < intronLength.size(); i++) {
            relativeExonStartPos -= intronLength.getQuick(i);
          }
          // exonic  
          //very important: usaully what we have in sample are alleles in forward strand
          //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid

          //special coding for the exonic variantsl it will be parsed later on
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex), relativeExonStartPos, relativeCodingStartPos, (pos - codingStart));

        } else {
          //relativeCodingStartPos = (pos - codingEnd);
          relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
        }
      } else //just at the  rightside boundary which is inclusive for reverse strand mRAN
      if (noCodingExon) {
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("ncRNA"), refID + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":ncRNA");
      } else if (pos <= codingStart) {
        //relativeCodingStartPos = (codingStart - pos) + 1;
        relativeExonStartPos = (exons.get(0).start - pos) + 1;
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("3UTR"), refID + ":c.*" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":3UTR");
      } else if (pos <= codingEnd) {
        //it must in the coiding region
        // exonic   
        //probably because codingEnd is exclusive, no -1 needed as in the forward strand
        relativeCodingStartPos = codingEnd - pos;
        for (int i = exonIndex; i < codingStartSiteExonID; i++) {
          relativeCodingStartPos -= intronLength.getQuick(i);
        }
        relativeExonStartPos = exons.get(exons.size() - 1).end - pos;

        for (int i = exonIndex; i < intronLength.size(); i++) {
          relativeExonStartPos -= intronLength.getQuick(i);
        }
        // exonic  
        //very important: usaully what we have in sample are alleles in forward strand
        //but in the database RefmRNA on reverse strand will be on reverse strand before translated to amino accid 

        //special coding for the exonic variantsl it will be parsed later on
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), (exonNum - exonIndex), relativeExonStartPos, relativeCodingStartPos, (pos - codingStart));
      } else {
        //relativeCodingStartPos = (pos - codingEnd);
        relativeExonStartPos = (pos - exons.get(exons.size() - 1).end);
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("5UTR"), refID + ":c.-" + relativeExonStartPos + ref + ">" + alt + ":(" + exonNum + "Exons" + (multipleMapping ? "MultiMap)" : ")") + ":5UTR");
      }
    } else {
      //unrecognzed strand infor
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("unknown"), "unknown");
    }
  }

  /*
     nonsynonymous	0	Variants result in a codon coding for a different amino acid (missense) and an amino acid codon to a stop codon (stopgain) and a stop codon to an amino acid codon (stoplos)
     synonymous	1	
     splicing	2	variant is within 2-bp of a splicing junction (use -splicing_threshold to change this) 
     ncRNA	3	variant overlaps a transcript without coding annotation in the gene definition (see Notes below for more explanation) 
     5UTR	4	variant overlaps a 5' untranslated region 
     3UTR	5	variant overlaps a 3' untranslated region 
     intronic	6	variant overlaps an intron 
     upstream	7	variant overlaps 1-kb region upstream of transcription start site 
     downstream	8	variant overlaps 1-kb region downtream of transcription end site (use -neargene to change this) 
     intergenic	9	variant is in intergenic region     
     * 
   */
  public GeneFeature calculateAminoAcidChange(int relativeCodingStartPosInRef, char ref, char alt, int absPos, int pos2CondingEnd, byte[] errorCode) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;
    StringBuilder info = new StringBuilder("c.");

    if (delSites != null) {
      /*
             if (delSites[0] == 0) {
             //when a deletion starts at 0 position, it is often problematic. So I prefer not to annoate it clearly
             info.append(relativeCodingStartPosIncDNA + 1);
             info.append(ref);
             info.append('>');
             info.append(alt);
             errorCode[0] = 0;
             info.append(":exonic");
             return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
             }
       */
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;
    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }

    //start with 0
    info.append(relativeCodingStartPosIncDNA + 1);
    info.append(ref);
    info.append('>');
    info.append(alt);
    if (mRnaSequence == null) {
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      errorCode[0] = 1;
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    /* //Strange! When I enable the following code, I met a lot of reference allele mistached variants 
         if (delSites != null) {
         shiftBpDel = Arrays.binarySearch(delSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpDel < 0) {
         shiftBpDel = -shiftBpDel - 1;
         }
         //because the referenc genome has deletions, we should shif the relative CDNA positions
         }

         if (insSites != null) {
         shiftBpIns = Arrays.binarySearch(insSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpIns < 0) {
         shiftBpIns = -shiftBpIns - 1;
         } 
         }
     */
    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    //warning: by default it is 4. but this mixed the synonymous and unmapped varaint      
    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      //mRnaSequence acually saved the cDNA sequence
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      errorCode[0] = 2;
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    //similar format c.G807A:p.Q269Q
    if (codon.charAt(incodonIndex) != ref) {
      //LOG.warn("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      errorCode[0] = 3;
      //System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      //Warning. not sure this is opproperate or not
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    } else {
      char refP = '?';
      char altP = '?';

      if (GlobalManager.codonTable.containsKey(codon)) {
        refP = GlobalManager.codonTable.get(codon);
        if (refP == '*') {
          //an impossible stoploss
          if (pos2CondingEnd > 3) {
            errorCode[0] = 4;
            //Warning. not sure this is opproperate or not
            info.append(":exonic");
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
          }
        }
      }
      info.append(':');
      info.append("p.");
      info.append(refP);
      int codonIndex = (relativeCodingStartPosInRef) / 3 + 1;
      StringBuilder sb = new StringBuilder(codon);
      sb.setCharAt(incodonIndex, alt);

      info.append(codonIndex);
      codon = sb.toString().toUpperCase();
      if (GlobalManager.codonTable.containsKey(codon)) {
        altP = GlobalManager.codonTable.get(codon);
        info.append(altP);
      } else {
        //Unspecified or unknown amino acid
        info.append('?');
      }

      GeneFeature gf = new GeneFeature();
      if (proteinDomainList != null) {
        for (ProteinDomain pd : proteinDomainList) {
          if (codonIndex >= pd.start && codonIndex <= pd.end) {
            gf.infor = uniprotID + '|' + pd.toString();
          }
        }
      }

      if (refP == altP) {
        info.append(":");
        info.append("synonymous");

        gf.id = GlobalManager.VarFeatureIDMap.get("synonymous");
        gf.name = info.toString();
        return gf;
        // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("synonymous"), info.toString());
      } else {
        info.append(":");
        if (codonIndex == 1 && refP == 'M') {
          info.append("startloss");
          gf.id = GlobalManager.VarFeatureIDMap.get("startloss");
          gf.name = info.toString();
          return gf;
        } else if (refP != '*' && altP != '*') {
          info.append("missense");

          gf.id = GlobalManager.VarFeatureIDMap.get("missense");
          gf.name = info.toString();
          return gf;
          //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("missense"), info.toString());
        } else if (refP != '*') {
          info.append("stopgain");

          gf.id = GlobalManager.VarFeatureIDMap.get("stopgain");
          gf.name = info.toString();
          return gf;
          // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stopgain"), info.toString());
        } else {
          info.append("stoploss");

          gf.id = GlobalManager.VarFeatureIDMap.get("stoploss");
          gf.name = info.toString();
          return gf;
          //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
        }
      }
    }
  }

  public GeneFeature calculateAminoAcidChangeMulti(int relativeCodingStartPosInRef, boolean isforward, String ref, String alt, int startPos, int pos2CondingEnd, byte[] errorCode) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;
    //System.out.println(startPos);

    StringBuilder annot = new StringBuilder();
    StringBuilder info = new StringBuilder();

    if (delSites != null) {
      /*
             if (delSites[0] == 0) {
             //when a deletion starts at 0 position, it is often problematic. So I prefer not to annoate it clearly
             info.append(relativeCodingStartPosIncDNA + 1);
             info.append(ref);
             info.append('>');
             info.append(alt);
             errorCode[0] = 0;
             info.append(":exonic");
             return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
             }
       */
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;

    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonStart = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonStart;

    while (incodonStart < 0) {
      incodonStart += 3;
    }

    //start with 0
    annot.append(relativeCodingStartPosIncDNA + 1);

    if (mRnaSequence == null) {
      annot.append(ref);
      annot.append('>');
      annot.append(alt);
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      errorCode[0] = 1;
      annot.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), annot.toString());
    }

    /* //Strange! When I enable the following code, I met a lot of reference allele mistached variants 
         if (delSites != null) {
         shiftBpDel = Arrays.binarySearch(delSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpDel < 0) {
         shiftBpDel = -shiftBpDel - 1;
         }
         //because the referenc genome has deletions, we should shif the relative CDNA positions
         }

         if (insSites != null) {
         shiftBpIns = Arrays.binarySearch(insSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpIns < 0) {
         shiftBpIns = -shiftBpIns - 1;
         } 
         }
     */
    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    //warning: by default it is 4. but this mixed the synonymous and unmapped varaint      
    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      annot.append(ref);
      annot.append('>');
      annot.append(alt);
      annot.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), annot.toString());
    }

    String codon;

    String changedSeq1;
    StringBuilder sb = new StringBuilder();

    int accumlateSizeNum = 0, totalLen = ref.length();
    int totalEnd = incodonStart + totalLen;
    int incodonEnd = totalEnd > 3 ? 3 : totalEnd;
    byte minID = Byte.MAX_VALUE;
    String tmpRef, tmpAlt;
    curCodonStart += 3;
    while (accumlateSizeNum < totalLen) {
      annot.append("c.");
      if (curCodonStart <= mRnaSequence.length()) {
        //mRnaSequence acually saved the cDNA sequence
        codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
      } else {
        errorCode[0] = 2;
        //warning: this mixed the synonymous and unmapped varaint
        annot.append(ref);
        annot.append('>');
        annot.append(alt);
        annot.append(":exonic");
        minID = GlobalManager.VarFeatureIDMap.get("exonic");
        annot.append('&');
        break;
      }
      changedSeq1 = codon.substring(incodonStart, incodonEnd);

      sb.delete(0, sb.length());
      //fill the unknown sequence variants
      for (int t = 0; t < (incodonEnd - incodonStart); t++) {
        if (ref.charAt(t + accumlateSizeNum) == '.') {
          sb.append(changedSeq1.charAt(t));
        } else {
          sb.append(ref.charAt(t + accumlateSizeNum));
        }
      }
      tmpRef = sb.toString();

      sb.delete(0, sb.length());
      int len = alt.length();
      for (int t = 0; t < (incodonEnd - incodonStart); t++) {
        if (t + accumlateSizeNum >= len) {
          break;
        }
        if (alt.charAt(t + accumlateSizeNum) == '.') {
          sb.append(changedSeq1.charAt(t));
        } else {
          sb.append(alt.charAt(t + accumlateSizeNum));
        }
      }
      tmpAlt = sb.toString();

      annot.append(tmpRef);
      annot.append('>');
      annot.append(tmpAlt);
      //similar format c.G807A:p.Q269Q
      if (!changedSeq1.equals(tmpRef)) {
        //LOG.warn("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
        errorCode[0] = 3;
        //System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
        //Warning. not sure this is opproperate or not

        annot.append(":exonic");
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), annot.toString());
      } else {
        char refP = '?';
        char altP = '?';

        if (GlobalManager.codonTable.containsKey(codon)) {
          refP = GlobalManager.codonTable.get(codon);
          if (refP == '*') {
            //an impossible stoploss
            if (pos2CondingEnd > 3) {
              errorCode[0] = 4;
              //Warning. not sure this is opproperate or not
              annot.append(":exonic");
              return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), annot.toString());
            }
          }
        }
        annot.append(':');
        annot.append("p.");
        annot.append(refP);
        int codonIndex = (relativeCodingStartPosInRef) / 3 + 1;
        sb.delete(0, sb.length());
        sb.append(codon);
        //at most three SNV

        for (int t = 0; t < tmpAlt.length(); t++) {
          sb.setCharAt(incodonStart + t, tmpAlt.charAt(t));
        }
        annot.append(codonIndex);
        codon = sb.toString().toUpperCase();
        if (GlobalManager.codonTable.containsKey(codon)) {
          altP = GlobalManager.codonTable.get(codon);
          annot.append(altP);
        } else {
          //Unspecified or unknown amino acid
          annot.append('?');
        }
        if (proteinDomainList != null) {
          for (ProteinDomain pd : proteinDomainList) {
            if (codonIndex >= pd.start && codonIndex <= pd.end) {
              info.append(uniprotID + '|' + pd.toString());
            }
          }
        }

        if (refP == altP) {
          annot.append(":");
          annot.append("synonymous");
          minID = GlobalManager.VarFeatureIDMap.get("synonymous");

          // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("synonymous"), info.toString());
        } else {
          annot.append(":");
          if (codonIndex == 1 && refP == 'M') {
            annot.append("startloss");
            minID = GlobalManager.VarFeatureIDMap.get("startloss");

          } else if (refP != '*' && altP != '*') {
            annot.append("missense");

            minID = GlobalManager.VarFeatureIDMap.get("missense");

            //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("missense"), info.toString());
          } else if (refP != '*') {
            annot.append("stopgain");

            minID = GlobalManager.VarFeatureIDMap.get("stopgain");

            // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stopgain"), info.toString());
          } else {
            annot.append("stoploss");
            minID = GlobalManager.VarFeatureIDMap.get("stoploss");
            //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
          }
        }
      }
      //next run            
      curCodonStart += 3;
      accumlateSizeNum += (incodonEnd - incodonStart);
      //must start at o
      incodonStart = 0;
      incodonEnd = totalLen - accumlateSizeNum;
      incodonEnd = incodonEnd > 3 ? 3 : incodonEnd;
      annot.append('&');
      info.append('&');
    }

    GeneFeature gf = new GeneFeature();
    gf.id = minID;
    gf.name = annot.substring(0, annot.length() - 1);
    if (info.length() > 0) {
      gf.infor = info.substring(0, info.length() - 1);
    }

    return gf;

  }

  public GeneFeature calculateAminoAcidChangeMulti0(int relativeCodingStartPosInRef, boolean isforward, String ref, String alt, int absPos, int pos2CondingEnd, byte[] errorCode) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;
    StringBuilder info = new StringBuilder("c.");

    if (delSites != null) {
      /*
             if (delSites[0] == 0) {
             //when a deletion starts at 0 position, it is often problematic. So I prefer not to annoate it clearly
             info.append(relativeCodingStartPosIncDNA + 1);
             info.append(ref);
             info.append('>');
             info.append(alt);
             errorCode[0] = 0;
             info.append(":exonic");
             return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
             }
       */
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;

    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }

    //start with 0
    info.append(relativeCodingStartPosIncDNA + 1);

    if (mRnaSequence == null) {
      info.append(ref);
      info.append('>');
      info.append(alt);
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      errorCode[0] = 1;
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    /* //Strange! When I enable the following code, I met a lot of reference allele mistached variants 
         if (delSites != null) {
         shiftBpDel = Arrays.binarySearch(delSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpDel < 0) {
         shiftBpDel = -shiftBpDel - 1;
         }
         //because the referenc genome has deletions, we should shif the relative CDNA positions
         }

         if (insSites != null) {
         shiftBpIns = Arrays.binarySearch(insSites, curCodonStart + codingStartRelativeSiteInSequence);
         if (shiftBpIns < 0) {
         shiftBpIns = -shiftBpIns - 1;
         } 
         }
     */
    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    //warning: by default it is 4. but this mixed the synonymous and unmapped varaint      
    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(ref);
      info.append('>');
      info.append(alt);
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      //mRnaSequence acually saved the cDNA sequence
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      errorCode[0] = 2;
      //warning: this mixed the synonymous and unmapped varaint
      info.append(ref);
      info.append('>');
      info.append(alt);
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    String changedSeq1;
    StringBuilder sb = new StringBuilder();

    int totalEnd = incodonIndex + ref.length();
    int tmpStart, tmpEnd;
    if (totalEnd > 3) {
      totalEnd = 3;
    }
    changedSeq1 = codon.substring(incodonIndex, totalEnd);

    if (changedSeq1.length() < ref.length()) {
      errorCode[0] = 3;
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(ref);
      info.append('>');
      info.append(alt);
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    //fill the unknown sequence variants
    for (int t = 0; t < ref.length(); t++) {
      if (ref.charAt(t) == '.') {
        sb.append(changedSeq1.charAt(t));
      } else {
        sb.append(ref.charAt(t));
      }
    }
    ref = sb.toString();

    sb.delete(0, sb.length());
    for (int t = 0; t < alt.length(); t++) {
      if (alt.charAt(t) == '.') {
        sb.append(changedSeq1.charAt(t));
      } else {
        sb.append(alt.charAt(t));
      }
    }
    alt = sb.toString();

    info.append(ref);
    info.append('>');
    info.append(alt);
    //similar format c.G807A:p.Q269Q
    if (!changedSeq1.equals(ref)) {
      //LOG.warn("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      errorCode[0] = 3;
      //System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      //Warning. not sure this is opproperate or not

      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    } else {
      char refP = '?';
      char altP = '?';

      if (GlobalManager.codonTable.containsKey(codon)) {
        refP = GlobalManager.codonTable.get(codon);
        if (refP == '*') {
          //an impossible stoploss
          if (pos2CondingEnd > 3) {
            errorCode[0] = 4;
            //Warning. not sure this is opproperate or not
            info.append(":exonic");
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
          }
        }
      }
      info.append(':');
      info.append("p.");
      info.append(refP);
      int codonIndex = (relativeCodingStartPosInRef) / 3 + 1;
      sb.delete(0, sb.length());
      sb.append(codon);
      //at most three SNV

      for (int t = 0; t < alt.length(); t++) {
        sb.setCharAt(incodonIndex + t, alt.charAt(t));
      }
      info.append(codonIndex);
      codon = sb.toString().toUpperCase();
      if (GlobalManager.codonTable.containsKey(codon)) {
        altP = GlobalManager.codonTable.get(codon);
        info.append(altP);
      } else {
        //Unspecified or unknown amino acid
        info.append('?');
      }

      GeneFeature gf = new GeneFeature();
      if (proteinDomainList != null) {
        for (ProteinDomain pd : proteinDomainList) {
          if (codonIndex >= pd.start && codonIndex <= pd.end) {
            gf.infor = uniprotID + '|' + pd.toString();
          }
        }
      }

      if (refP == altP) {
        info.append(":");
        info.append("synonymous");

        gf.id = GlobalManager.VarFeatureIDMap.get("synonymous");
        gf.name = info.toString();
        return gf;
        // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("synonymous"), info.toString());
      } else {
        info.append(":");
        if (codonIndex == 1 && refP == 'M') {
          info.append("startloss");
          gf.id = GlobalManager.VarFeatureIDMap.get("startloss");
          gf.name = info.toString();
          return gf;
        } else if (refP != '*' && altP != '*') {
          info.append("missense");

          gf.id = GlobalManager.VarFeatureIDMap.get("missense");
          gf.name = info.toString();
          return gf;
          //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("missense"), info.toString());
        } else if (refP != '*') {
          info.append("stopgain");

          gf.id = GlobalManager.VarFeatureIDMap.get("stopgain");
          gf.name = info.toString();
          return gf;
          // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stopgain"), info.toString());
        } else {
          info.append("stoploss");

          gf.id = GlobalManager.VarFeatureIDMap.get("stoploss");
          gf.name = info.toString();
          return gf;
          //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
        }
      }
    }
  }

  public GeneFeature calculateAminoAcidChangeMulit1(int relativeCodingStartPosInRef, String ref, String alt, int absPos, int pos2CondingEnd, byte[] errorCode) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;
    StringBuilder info = new StringBuilder("c.");
    int seqLen = ref.length();
    if (delSites != null) {
      /*
             if (delSites[0] == 0) {
             //when a deletion starts at 0 position, it is often problematic. So I prefer not to annoate it clearly
             info.append(relativeCodingStartPosIncDNA + 1);
             info.append(ref);
             info.append('>');
             info.append(alt);
             errorCode[0] = 0;
             info.append(":exonic");
             return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
             }
       */
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;

    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }

    //start with 0
    info.append(relativeCodingStartPosIncDNA + 1);
    info.append(ref);
    info.append('>');
    info.append(alt);
    if (mRnaSequence == null) {
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      errorCode[0] = 1;
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    //warning: by default it is 4. but this mixed the synonymous and unmapped varaint      
    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      //mRnaSequence acually saved the cDNA sequence
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      errorCode[0] = 2;
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }  //similar format c.G807A:p.Q269Q

    if (!codon.substring(incodonIndex, seqLen + incodonIndex).equals(ref)) {
      //LOG.warn("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      errorCode[0] = 3;
      //System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
      //Warning. not sure this is opproperate or not
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    } else {
      char refP = '?';
      char altP = '?';

      if (GlobalManager.codonTable.containsKey(codon)) {
        refP = GlobalManager.codonTable.get(codon);
        if (refP == '*') {
          //an impossible stoploss
          if (pos2CondingEnd > 3) {
            errorCode[0] = 4;
            //Warning. not sure this is opproperate or not
            info.append(":exonic");
            return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
          }
        }
      }
      info.append(':');
      info.append("p.");
      info.append(refP);
      int codonIndex = (relativeCodingStartPosInRef) / 3 + 1;
      StringBuilder sb = new StringBuilder(codon);
      for (int i = 0; i < seqLen; i++) {
        sb.setCharAt(incodonIndex + i, alt.charAt(i));
      }

      info.append(codonIndex);
      codon = sb.toString().toUpperCase();
      if (GlobalManager.codonTable.containsKey(codon)) {
        altP = GlobalManager.codonTable.get(codon);
        info.append(altP);
      } else {
        //Unspecified or unknown amino acid
        info.append('?');
      }

      GeneFeature gf = new GeneFeature();
      if (proteinDomainList != null) {
        for (ProteinDomain pd : proteinDomainList) {
          if (codonIndex >= pd.start && codonIndex <= pd.end) {
            gf.infor = uniprotID + '|' + pd.toString();
          }
        }
      }

      if (refP == altP) {
        info.append(":");
        info.append("synonymous");

        gf.id = GlobalManager.VarFeatureIDMap.get("synonymous");
        gf.name = info.toString();
        return gf;
        // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("synonymous"), info.toString());
      } else {
        info.append(":");
        if (codonIndex == 1 && refP == 'M') {
          info.append("startloss");
          gf.id = GlobalManager.VarFeatureIDMap.get("startloss");
          gf.name = info.toString();
          return gf;
        } else if (refP != '*' && altP != '*') {
          info.append("missense");

          gf.id = GlobalManager.VarFeatureIDMap.get("missense");
          gf.name = info.toString();
          return gf;
          //return new GeneFeature(GlobalManager.VarFeatureIDMap.get("missense"), info.toString());
        } else if (refP != '*') {
          info.append("stopgain");

          gf.id = GlobalManager.VarFeatureIDMap.get("stopgain");
          gf.name = info.toString();
          return gf;
          // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stopgain"), info.toString());
        } else {
          info.append("stoploss");

          gf.id = GlobalManager.VarFeatureIDMap.get("stoploss");
          gf.name = info.toString();
          return gf;
          //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
        }
      }
    }
  }

  public int calculateAminoAcidIndex(int relativeCodingStartPosInRef) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;

    if (delSites != null) {
      /*
             if (delSites[0] == 0) {
             //when a deletion starts at 0 position, it is often problematic. So I prefer not to annoate it clearly
             info.append(relativeCodingStartPosIncDNA + 1);
             info.append(ref);
             info.append('>');
             info.append(alt);
             errorCode[0] = 0;
             info.append(":exonic");
             return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
             }
       */
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;

    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }
    return incodonIndex;
  }

  //Nameing regulation
//http://varnomen.hgvs.org/recommendations/DNA/variant/deletion/
  public GeneFeature calculateAminoAcidDeletion(int relativeCodingStartPosInRef, String ref, String alt, int delSeqLen) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;

    if (delSites != null) {
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;
    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }

    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }

    StringBuilder info = new StringBuilder("c.");

    if (alt.endsWith("-")) {
      //forward sequence
      int s = ref.length() - delSeqLen - 1;
      if (s >= 0) {
        info.append(ref.charAt(s));
      }

      info.append(relativeCodingStartPosIncDNA + (ref.length() - delSeqLen));
      info.append("del-");
      info.append(ref.substring(ref.length() - delSeqLen));
    } else {
      //reverse sequence
      //info.append('?');
      //use the last char
      info.append(ref.charAt(0));
      info.append(relativeCodingStartPosIncDNA - (ref.length() - delSeqLen));

      info.append("del");
      info.append(ref.substring(0, delSeqLen));
      info.append("-");
    }

    if (mRnaSequence == null) {
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    /*
         //ignore this, sometimes ref is not avaible for indels         
         if (codon.charAt(incodonIndex) != ref) {
         System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
         //Warning. not sure this is opproperate or not
         return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
         }
         * 
     */
    Character refP = '?';
    info.append(':');
    info.append("p.");
    if (GlobalManager.codonTable.containsKey(codon)) {
      refP = GlobalManager.codonTable.get(codon);
      if (refP == null) {
        System.err.println("Unknown code for " + codon);
        refP = '?';
      }
      info.append(refP);
    } else {
      //Unspecified or unknown amino acid
      info.append('?');
    }

    int codonIndex = (relativeCodingStartPosIncDNA) / 3 + 1;

    info.append(codonIndex);
    GeneFeature gf = new GeneFeature();

    if (proteinDomainList != null) {
      for (ProteinDomain pd : proteinDomainList) {
        if (codonIndex >= pd.start && codonIndex <= pd.end) {
          gf.infor = uniprotID + '|' + pd.toString();
        }
      }
    }

    if (delSeqLen % 3 == 0) {
      info.append(":nonframeshift");
      gf.id = GlobalManager.VarFeatureIDMap.get("nonframeshift");
      gf.name = info.toString();
      return gf;

      /*
             boolean hasStopCoden = false;
             int startCheckSite = 0;
            
             StringBuilder altSB = new StringBuilder();
             if (alt.endsWith("-")) {
             //if this is a forward strand
             //but it looks like the same as the reverse
             if (incodonIndex == 2) {
             startCheckSite = 1;
             } else if (incodonIndex == 1) {
             info.append('?');
             startCheckSite = 2;
             } else if (incodonIndex == 0) {
             startCheckSite = 0;
             }
             altSB.append(ref.substring(ref.length() - delSeqLen));
             } else {
             if (incodonIndex == 2) {
             startCheckSite = 1;
             } else if (incodonIndex == 1) {
             info.append('?');
             startCheckSite = 2;
             } else if (incodonIndex == 0) {
             startCheckSite = 0;
             }
             altSB.append(ref.substring(0, delSeqLen));
             }
            
             for (int i = startCheckSite; i < delSeqLen; i += 3) {
             if (i + 3 > altSB.length()) {
             //Unspecified or unknown amino acid
             info.append('?');
             break;
             }
             codon = altSB.substring(i, i + 3).toUpperCase();
             if (GlobalManager.codonTable.containsKey(codon)) {
             char altP = GlobalManager.codonTable.get(codon);
             if (altP == '*') {
             hasStopCoden = true;
             }
             info.append(altP);
             } else {
             //Unspecified or unknown amino acid
             info.append('?');
             }
             }
             if (hasStopCoden) {
             gf.id = GlobalManager.VarFeatureIDMap.get("stopgain");
             gf.name = info.toString();
             return gf;
             // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
             } else {
             gf.id = GlobalManager.VarFeatureIDMap.get("frameshift");
             gf.name = info.toString();
             return gf;
             //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("nonframeshift"), info.toString());
             }
       */
    } else {
      //for the forward strand the start positions is before the deletion from the second nucleotide
      info.append("del");
      StringBuilder altSB = new StringBuilder();

      boolean hasStopLoss = false;
      int startCheckSite = 0;
      if (alt.endsWith("-")) {
        //if this is a forward strand
        //but it looks like the same as the reverse
        switch (incodonIndex) {
          case 2:
            startCheckSite = 1;
            break;
          case 1:
            info.append('?');
            startCheckSite = 2;
            break;
          case 0:
            startCheckSite = 0;
            break;
          default:
            break;
        }
        altSB.append(ref.substring(ref.length() - delSeqLen));
      } else {
        switch (incodonIndex) {
          case 2:
            startCheckSite = 1;
            break;
          case 1:
            info.append('?');
            startCheckSite = 2;
            break;
          case 0:
            startCheckSite = 0;
            break;
          default:
            break;
        }
        altSB.append(ref.substring(0, delSeqLen));
      }

      for (int i = startCheckSite; i < delSeqLen; i += 3) {
        if (i + 3 > altSB.length()) {
          //Unspecified or unknown amino acid
          info.append('?');
          break;
        }
        codon = altSB.substring(i, i + 3).toUpperCase();
        if (GlobalManager.codonTable.containsKey(codon)) {
          char altP = GlobalManager.codonTable.get(codon);
          if (altP == '*') {
            hasStopLoss = true;
          }
          info.append(altP);
        } else {
          //Unspecified or unknown amino acid
          info.append('?');
        }
      }
      if (hasStopLoss) {
        gf.id = GlobalManager.VarFeatureIDMap.get("stoploss");
        info.append(":stoploss");
        gf.name = info.toString();
        return gf;
        // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
      } else {
        gf.id = GlobalManager.VarFeatureIDMap.get("frameshift");
        info.append(":frameshift");
        gf.name = info.toString();
        return gf;
        //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("nonframeshift"), info.toString());
      }
    }

  }

//note:     relativeCodingStartPos is also deleted
  public GeneFeature calculateAminoAcidDeletionAtRightTail(int relativeCodingStartPosInRef, String ref, String alt, int delSeqLen) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;

    if (delSites != null) {
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;
    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }
    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }

    StringBuilder info = new StringBuilder("c.");

    if (alt.endsWith("-")) {
      //forward sequence
      int s = ref.length() - delSeqLen - 1;
      if (s >= 0) {
        info.append(ref.charAt(s));
      }
      info.append(relativeCodingStartPosIncDNA + (ref.length() - delSeqLen));
      info.append("del-");
      info.append(ref.substring(ref.length() - delSeqLen));
    } else {
      //reverse sequence
      //info.append('?');
      info.append(ref.charAt(0));
      info.append(relativeCodingStartPosIncDNA - (ref.length() - delSeqLen));
      info.append("del");
      info.append(ref.substring(0, delSeqLen));
      info.append("-");
    }

    if (mRnaSequence == null) {
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }

    /*
         if (codingStartRelativeSiteInSequence >= 0&&geneSym.equals("KIF1B")) {
         StringBuilder protSeq = new StringBuilder();
         for (int i = codingStartRelativeSiteInSequence; i < mRnaSequence.length(); i += 3) {
         String codon1 = mRnaSequence.substring(i, i + 3);
         protSeq.append(GlobalManager.codonTable.get(codon1));
         }
         System.out.println(protSeq.toString());
         }
         * 
     */
    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      //warning: this mixed the synonymous and unmapped varaint 
      info.append(":exonic");
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    /*
         //similar format c.G807A:p.Q269Q
         if (codon.charAt(incodonIndex) != ref) {
         System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
         //Warning. not sure this is opproperate or not
         return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
         } else*/
    {
      char refP = '?';
      int codonIndex = (relativeCodingStartPosIncDNA) / 3 + 1;

      if (GlobalManager.codonTable.containsKey(codon)) {
        refP = GlobalManager.codonTable.get(codon);
      }
      info.append(':');
      info.append("p.");
      info.append(refP);
      info.append(codonIndex);

      if (delSeqLen % 3 == 0) {
        info.append(":nonframeshift");
        return new GeneFeature(GlobalManager.VarFeatureIDMap.get("nonframeshift"), info.toString());
      } else {
        //if (alt.startsWith("-"))
        info.append("del");
        boolean hasStopLoss = false;
        int startCheckSite = 0;
        StringBuilder altSB = new StringBuilder();
        if (alt.endsWith("-")) {
          //if this is a forward strand
          //but it looks like the same as the reverse
          switch (incodonIndex) {
            case 2:
              startCheckSite = 1;
              break;
            case 1:
              info.append('?');
              startCheckSite = 2;
              break;
            case 0:
              startCheckSite = 0;
              break;
            default:
              break;
          }
          altSB.append(ref.substring(ref.length() - delSeqLen));
        } else {
          switch (incodonIndex) {
            case 2:
              startCheckSite = 1;
              break;
            case 1:
              info.append('?');
              startCheckSite = 2;
              break;
            case 0:
              startCheckSite = 0;
              break;
            default:
              break;
          }
          altSB.append(ref.substring(0, delSeqLen));
        }

        for (int i = startCheckSite; i < delSeqLen; i += 3) {
          if (i + 3 > altSB.length()) {
            //Unspecified or unknown amino acid
            info.append('?');
            break;
          }
          codon = altSB.substring(i, i + 3).toUpperCase();
          if (GlobalManager.codonTable.containsKey(codon)) {
            char altP = GlobalManager.codonTable.get(codon);
            if (altP == '*') {
              hasStopLoss = true;
            }
            info.append(altP);
          }
        }
        if (hasStopLoss) {
          info.append(":stoploss");
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stoploss"), info.toString());
        } else {
          info.append(":frameshift");
          return new GeneFeature(GlobalManager.VarFeatureIDMap.get("frameshift"), info.toString());
        }

      }
    }
  }

  public GeneFeature calculateAminoAcidInsertion(int relativeCodingStartPosInRef, String ref, String alt, int absPos) {
    int shiftBpDel = 0;
    int relativeCodingStartPosIncDNA = relativeCodingStartPosInRef;

    if (delSites != null) {
      shiftBpDel = Arrays.binarySearch(delSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpDel < 0) {
        shiftBpDel = -shiftBpDel - 1;
      }
      //because the referenc genome has deletions, we should shif the relative CDNA positions
      relativeCodingStartPosIncDNA += shiftBpDel;
    }

    int shiftBpIns = 0;
    if (insSites != null) {
      shiftBpIns = Arrays.binarySearch(insSites, relativeCodingStartPosIncDNA + codingStartRelativeSiteInSequence);
      if (shiftBpIns < 0) {
        shiftBpIns = -shiftBpIns - 1;
      }
      relativeCodingStartPosIncDNA -= shiftBpIns;
    }
    int incodonIndex = (relativeCodingStartPosIncDNA) % 3;
    int curCodonStart = relativeCodingStartPosIncDNA - incodonIndex;

    if (incodonIndex < 0) {
      incodonIndex += 3;
    }
    int insSeqLen = alt.length() - ref.length();
    StringBuilder info = new StringBuilder("c.");

    if (alt.endsWith("+")) {
      //the format will be like TC/AGC++
      //reverse sequence
      //unknown sequence
      //info.append('?');
      //use the reverse
      info.append(ref.charAt(0));
      info.append(relativeCodingStartPosIncDNA + 1);
      info.append("ins");
      info.append(alt.substring(0, alt.length() - (ref.length() - 1)));

    } else {
      //the format will be like CT/++CGA
      info.append(ref.charAt(ref.length() - 1));
      info.append(relativeCodingStartPosIncDNA + 1);
      info.append("ins");
      info.append(alt.substring(ref.length() - 1));
    }

    if (mRnaSequence == null) {
      // System.out.println("The RefmRNA " + refID + " has no sequence data so the variant at site "+absPos+ " have no detailed coding change information");
      //Warning. not sure this is opproperate or not
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }


    /*
         if (this.refID.equals("NM_133497") && absPos == 2707921) {
         int sss = 0;
         }
     */
    curCodonStart += codingStartRelativeSiteInSequence;
    //because what we will obtain is the reference DNA so we need go back to the posistions of referce genome to get the correct referecne DNA
    curCodonStart -= shiftBpDel;
    curCodonStart += shiftBpIns;

    if (curCodonStart < 0) {
      //warning: this mixed the synonymous and unmapped varaint 
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    String codon;
    curCodonStart += 3;
    if (curCodonStart <= mRnaSequence.length()) {
      codon = mRnaSequence.substring(curCodonStart - 3, curCodonStart).toUpperCase();
    } else {
      //warning: this mixed the synonymous and unmapped varaint 
      return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
    }
    /*
         //ignore this, sometimes ref is not avaible for indels
         if (codon.charAt(incodonIndex) != ref) {
         System.out.println("The reference alleles in the sample data and database are not identical at site " + absPos + " on " + refID + " of " + geneSym);
         //Warning. not sure this is opproperate or not
         return new GeneFeature(GlobalManager.VarFeatureIDMap.get("exonic"), info.toString());
         }
     */
    Character refP = '?';
    if (GlobalManager.codonTable.containsKey(codon)) {
      refP = GlobalManager.codonTable.get(codon);
      if (refP == null) {
        System.err.println("Unknown code for " + codon);
      }
    }

    int codonIndex = (relativeCodingStartPosIncDNA) / 3 + 1;

    info.append(':');
    info.append("p.");
    info.append(refP);
    info.append(codonIndex);
    GeneFeature gf = new GeneFeature();

    if (proteinDomainList != null) {
      for (ProteinDomain pd : proteinDomainList) {
        if (codonIndex >= pd.start && codonIndex <= pd.end) {
          gf.infor = uniprotID + '|' + pd.toString();
        }
      }
    }

    if (insSeqLen % 3 == 0) {
      info.append(":nonframeshift");
      gf.id = GlobalManager.VarFeatureIDMap.get("nonframeshift");
      gf.name = info.toString();
      return gf;
      //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("frameshift"), info.toString());
    } else {
      boolean hasStopGain = false;
      int startCheckSite = 0;

      info.append("ins");
      StringBuilder altSB = new StringBuilder();
      if (alt.endsWith("+")) {
        //for the revsers stand the start position is the one after the insertion
        switch (incodonIndex) {
          case 2:
            startCheckSite = 1;
            break;
          case 1:
            info.append('?');
            startCheckSite = 2;
            break;
          case 0:
            startCheckSite = 0;
            break;
          default:
            break;
        }
        altSB.append(alt.substring(0, alt.length() - ref.length()));
      } else {
        //for the forward stand the start position is the one before the insertion
        switch (incodonIndex) {
          case 2:
            startCheckSite = 1;
            break;
          case 1:
            info.append('?');
            startCheckSite = 2;
            break;
          case 0:
            startCheckSite = 0;
            break;
          default:
            break;
        }
        altSB.append(alt.substring(ref.length()));
      }
      for (int i = startCheckSite; i < insSeqLen; i += 3) {
        if (i + 3 > alt.length()) {
          //Unspecified or unknown amino acid
          info.append('?');
          break;
        }

        codon = alt.substring(i, i + 3).toUpperCase();
        if (GlobalManager.codonTable.containsKey(codon)) {
          char altP = GlobalManager.codonTable.get(codon);
          if (altP == '*') {
            hasStopGain = true;
          }
          info.append(altP);
        } else {
          //Unspecified or unknown amino acid
          info.append('?');
        }
      }
      if (hasStopGain) {
        gf.id = GlobalManager.VarFeatureIDMap.get("stopgain");
        info.append(":stoploss");
        gf.name = info.toString();
        return gf;
        // return new GeneFeature(GlobalManager.VarFeatureIDMap.get("stopgain"), info.toString());
      } else {
        gf.id = GlobalManager.VarFeatureIDMap.get("frameshift");

        info.append(":frameshift");
        gf.name = info.toString();
        return gf;
        //  return new GeneFeature(GlobalManager.VarFeatureIDMap.get("nonframeshift"), info.toString());
      }
    }

  }

//we know that the exons are not overlapped and sorted . otherwise it is risk
  private int binarySearch(int pos, int left, int right) {
    if (left > right) {
      return -left - 1;
    }
    int middle = (left + right) / 2;

    if (exons.get(middle).end == pos) {
      return middle;
    } else if (exons.get(middle).end > pos) {
      return binarySearch(pos, left, middle - 1);
    } else {
      return binarySearch(pos, middle + 1, right);
    }
  }
}
