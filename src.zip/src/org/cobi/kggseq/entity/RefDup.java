/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
public class RefDup extends SeqSegment {

 
   
    double jcKScore = -1;
    double k2KScore = -1;

    public RefDup(String refID, int start, int end) {
        super(refID, start, end);
    }

    public RefDup(String refID, int start, int end,  double jcKScore, double k2KScore) {
        super(refID, start, end);       
        this.jcKScore = jcKScore;
        this.k2KScore = k2KScore;
    }

    public double getJcKScore() {
        return jcKScore;
    }

    public void setJcKScore(double jcKScore) {
        this.jcKScore = jcKScore;
    }

    public double getK2KScore() {
        return k2KScore;
    }

    public void setK2KScore(double k2KScore) {
        this.k2KScore = k2KScore;
    }

 
}
