/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.kggseq.entity;

/**
 *
 * @author mxli
 */
public class GeneFeature {

    byte id;
    String name;
    String infor;
    //to confirm whether a stoploss annoation is right
    public int pos2CondingEnd = -1;
    //for detailed annoation
    public int exonID;
    public int relativeCodingStartPos = -1;
    public int relativeExonStartPos = -1;

    public GeneFeature() {
    }

    public GeneFeature(byte id, String name) {
        this.id = id;
        this.name = name;
    }

    public GeneFeature(byte id, int exonID, int relativeExonStartPos, int relativeCodingStartPos, int dis) {
        this.id = id;
        pos2CondingEnd = dis;
        this.relativeExonStartPos = relativeExonStartPos;
        this.relativeCodingStartPos = relativeCodingStartPos;
        this.exonID = exonID;
    }

    public GeneFeature(byte id, String name, int dis) {
        this.id = id;
        pos2CondingEnd = dis;
        this.name = name;        
    }

    public byte getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfor() {
        return infor;
    }

    public void setInfor(String infor) {
        this.infor = infor;
    }

}
