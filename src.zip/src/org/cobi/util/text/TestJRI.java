/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.text;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat.Field;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author mxli
 */
public class TestJRI {
    
    /**
     * @param args the command line arguments
     */
    public static void main (String[] args) throws IOException {//in the folder /etc/ld.so.conf.d I created a file called libR.conf with the single line "/usr/lib64/R/lib/"  in it (without the quotes).
        //In the same folder I created a file called rJava.conf with the single line "/usr/lib/jvm/java-6-openjdk/jre/lib/amd64/server/" in it (without the quotes).
        //I then ran ldconfig to force these changes.

    //To get R_HOME set, I had to modify netbeans.conf adding the line "export R_HOME=/usr/lib64/R" 
        System.out.println("R_HOME: " + System.getenv("R_HOME"));
        try {//This next line is a trick to force a change to java.library.path at runtime
            addLibraryPath("/usr/lib64/R/site-library/rJava/jri/");
            // I copied libR.so to the jri folder so I am not sure if the next line does  anything
            addLibraryPath("/usr/lib64/R/lib/");
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        System.out.println("java.library.path: " + java.lang.System.getProperty("java.library.path"));
//Set some labels for the plot
        String title = "R Plot in JFrame";
        String xlab = "X Label";
        String ylab = "Y Label";
//Start R
        String newargs[] = {"--no-save"};

        /*
        Rengine r = new Rengine(newargs, false, null);
//Do some calcs and plot the chart but save as a png in the working folder
        r.eval("a<-c(1,2,3,4,5,6,7,8,9,10)");
        r.eval("b<-c(1,3,2,4,5,6,7,8,9,10)");
        r.eval("png(file=\"graph2.png\",width=1600,height=1600,res=400)");
        r.eval("plot(a,b,type='o',col=\"Blue\",main=\"" + title + "\",xlab=\""
                + xlab + "\",ylab=\"" + ylab + "\")");
        r.eval("dev.off()");
        */
//It took me a search to find where R stuck the image. I found it in /proc/29285/cwd.
//I will have to learn how to control the working folder for R from java.
//get the image and create a new imagepanel
        File file = new File("/proc/29285/cwd/graph2.png");
        Image image = ImageIO.read(file);
        imagePanel myPanel = new imagePanel(image);
//Create a new frame and add the imagepanel
        JFrame aFrame = new JFrame();
        aFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        aFrame.getContentPane().add(myPanel, BorderLayout.CENTER);
        aFrame.pack();
        aFrame.setVisible(true);
        aFrame.setSize(new Dimension(600, 600));
    }

    static class imagePanel extends JPanel {

        Image image = null;

        public imagePanel(Image image) {
            this.image = image;
        }

        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            //there is a picture: draw it
            if (image != null) {
                int height = this.getSize().height;
                int width = this.getSize().width;
                g.drawImage(image, 0, 0, width, height, this);
            }
        }
    }

    /**
     * Adds the specified path to the java library path
     *
     * @param path the new library path to add
     * @throws Exception
     */
    public static void addLibraryPath(String path) throws Exception {
        String oldPath = System.getProperty("java.library.path");
        if (oldPath.length() > 0) {
            path = path + ":" + oldPath;
        }
        System.setProperty("java.library.path", path);

        //set sys_paths to null
       // final Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
       // sysPathsField.setAccessible(true);
      //  sysPathsField.set(null, null);
    }

}
