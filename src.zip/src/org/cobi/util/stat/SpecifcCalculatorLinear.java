/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.stat;

import cern.jet.stat.Probability;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import org.cobi.kggseq.entity.DoubleArrayListComparator;

/**
 *
 * @author limx54
 */
public class SpecifcCalculatorLinear {

    List<double[]> indexY = new ArrayList<double[]>();
    DoubleArrayListComparator cp = new DoubleArrayListComparator(0);

    public boolean iterativeWeighter(double[] data, double[] finalWeights, double[] residues, int maxIterN) {
        int tissueSizeOrg = data.length;
        int tissueSize;
       
        double[][] x;
        double[] y;
        LinearRegression linReg = new LinearRegression();
        double median, sd;
        boolean success = false;
        indexY.clear();
        double[] coef = new double[2];
        double diff, maxDiff, MINDIFF = 1e-8;

        Arrays.fill(coef, 0);
        for (int j = 0; j < tissueSizeOrg; j++) {
            if (!Double.isNaN(data[j])) {
                indexY.add(new double[]{data[j], j});
            }
        }

        //because of missing values the tissue number may be diffrent
        tissueSize = indexY.size();
        if (tissueSize < 2) {
            
            return success;
        }
        Collections.sort(indexY, cp);
        x = new double[tissueSize][2];
        y = new double[tissueSize];
        double[] weights0 = new double[tissueSize];
        double[] weights1 = new double[tissueSize];
        Arrays.fill(weights0, 1);

        for (int j = 0; j < tissueSize; j++) {
            y[j] = indexY.get(j)[0];
            x[j][0] = 1;
            x[j][1] = j + 1;
        }
        int iter = 0;
        do {
            for (int j = 0; j < tissueSize; j++) {
                y[j] = indexY.get(j)[0];
            }
            //iteratively standize the expression values untile the coefficients are converged
            median = StdStats.mean(y, weights0, true);
            //sd = StdStats.stddev(residual);
            sd = StdStats.stddev(y, weights0);
            for (int j = 0; j < tissueSize; j++) {
                y[j] = (y[j] - median) / sd;
                //convert to uniform distribution
                if (y[j] <= 0) {
                    // y[j] = Probability.normal(y[j]);
                } else {
                    // y[j] = 1 - Probability.normal(-y[j]);
                }
            }

            success = linReg.robustLinearRegression(y, x, 100, 1);
            if (!success) {
                System.out.println(success);
            }
            //System.arraycopy(linReg.coef, 0, coef, 0, coef.length);
            System.arraycopy(linReg.getWeight(), 0, weights1, 0, weights1.length);
            StdStats.standWeight(weights1);
            maxDiff = Math.abs(weights0[0] - weights1[0]);
            for (int i = 1; i < weights0.length; i++) {
                diff = Math.abs(weights0[i] - weights1[i]);
                if (diff > maxDiff) {
                    maxDiff = diff;
                }
            }
            if (maxDiff < MINDIFF) {
                break;
            }
            System.arraycopy(weights1, 0, weights0, 0, weights0.length);
            iter++;
        } while (iter < maxIterN);
        if (iter >= maxIterN) {
            System.out.println("Over");
        }
        System.arraycopy(linReg.getWeight(), 0, weights0, 0, weights0.length);
        double[] residual = linReg.getResidual();
        for (int j = 0; j < tissueSize; j++) {
            residues[(int) (indexY.get(j)[1])] = -residual[j];
            finalWeights[(int) (indexY.get(j)[1])] = weights0[j];
            //data[(int) (indexY.get(j)[1])] = y[j];
        }

        return success;
    }

    public static void main(String[] args) {
        SpecifcCalculatorLinear linReg = new SpecifcCalculatorLinear();
        try {
            double[] values = new double[]{199.31, 199.53, 200.19, 200.82, 201.92, 201.95, 202.18, 245.57};
            double[] finalWeights = new double[values.length];
            double[] residues = new double[values.length];
            linReg.iterativeWeighter(values, finalWeights, residues, 100);
            double mean = StdStats.mean(values, finalWeights, true);
            double sd = StdStats.stddev(values, finalWeights);
            //mean = StdStats.mean(values);
            //sd = StdStats.stddev(residueCounter);
            double p;
            for (int i = 0; i < values.length; i++) {
                values[i] = (values[i] - mean) / sd;
                p = values[i];
                if (p > 0) {
                    p = Probability.normal(-p);
                } else {
                    p = 1 - Probability.normal(p);
                }
                System.out.println(values[i] + " " + p);
            }
        } catch (Exception nex) {
            nex.printStackTrace();
            //throw new Exception(info);
        }
    }

}
