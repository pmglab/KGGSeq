/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.graph;

import cern.colt.list.DoubleArrayList;
import cern.colt.list.ShortArrayList;
import cern.jet.random.Uniform;
import cern.jet.random.engine.RandomEngine;
import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.Callable;
import org.cobi.util.thread.Task;

/**
 *
 * @author mxli
 */
public class NetShortSimulationTask extends Task implements Callable<String> {

    int sampleSize;
    int maxSimuTimes;
    int geneNum;
    int obsNums;
    String[] geneList;

    double[] counts = new double[4];
    int[] containIds;
    short[] list2;
    boolean[] isSelGenes = new boolean[Short.MAX_VALUE * 2];
    //it is much faster than OpenIntIntHashMap

    DoubleArrayList randomCounts;
    //also very slow

    public NetShortSimulationTask(int simuTimes, int obsNums, Set<Short> selectedGenes, int[] containIds, short[] list2) {
        this.maxSimuTimes = simuTimes;
        this.obsNums = obsNums;
        this.containIds = containIds;
        this.list2 = list2;

        this.randomCounts = new DoubleArrayList();
        Arrays.fill(isSelGenes, false);
        int index;
        for (Short s : selectedGenes) {
            index = s + Short.MAX_VALUE;
            isSelGenes[index] = true;
        }
    }

    public DoubleArrayList getRandomCounts() {
        return randomCounts;
    }

    public double[] getOverCounts() {
        return counts;
    }

    @Override
    public String call() throws Exception {
        shuffleInteractionPairs();

        //  GlobalManager.logger.info(info);
        fireTaskComplete();
        String info = "  Varaince vas estimated on block  seconds.";
        //  System.out.println(info);
        //return info;
        return info;
        // 

    }

    public void shuffleInteractionPairs() throws Exception {
        RandomEngine tm = new cern.jet.random.engine.MersenneTwister(new java.util.Date());
        Uniform um = new Uniform(tm);
        int len = list2.length;
        int index = 0;
        short tmpS;

        int count0 = 0;
        counts[0] = 0;
        counts[1] = 0;
        int ringNum = -1;
        double prob;

        int j;
        int containIdsLen = containIds.length;

        int index0, index1;

        ShortArrayList sa = new ShortArrayList(list2);
        sa.shuffle();
        for (int t = 0; t < maxSimuTimes; t++) {
            //Collections.shuffle(Arrays.asList(list2));

            ringNum = um.nextIntFromTo(0, len - 1);
            if (ringNum > len) {
                ringNum = ringNum % len;
            }

            if (ringNum == 0) {
                //System.out.println("Running shuffle!");
                //shuffle the connection     Fisher–Yates shuffle Algorithm
/*
                for (int i = len - 1; i > 0; i--) {
                    // Pick a random index from 0 to i 
                    j = um.nextIntFromTo(0, i);

                    // Swap arr[i] with the element at random index 
                    tmpS = list2[i];
                    list2[i] = list2[j];
                    list2[j] = tmpS;
                }
                 */
                ///it does not shuffle it
                //Collections.shuffle(Arrays.asList(list2));

                //it seems the fastest
                sa = new ShortArrayList(list2);
                sa.shuffle();
                // list2=sa.elements();
            }
            //check the connection
            count0 = 0;

           // long time = System.nanoTime();

            for (int i = 0; i < containIdsLen; i++) {
                index1 = (containIds[i] + ringNum);
                if (index1 >= len) {
                    index1 = index1 % len;
                }

//it faster than OpenIntIntHashMap
/*
                if (geneIDSet.contains(list2[index1])) {
                    count0++;
                }
                 */
                index = list2[index1] + Short.MAX_VALUE;
                if (isSelGenes[index]) {
                    count0++;
                }
            }


            /*
            time = System.nanoTime() - time;
            time = time / 10000;
            System.out.println("2 " + time);
             */
            //very slow
            // Arrays.parallelSort(sortedGeneIDShuffle);
            randomCounts.add(count0);
            //System.out.println(count0);
            if (obsNums <= count0) {
                counts[0] += 1;
            }

            //total counts 
            counts[1]++;

            /*
      if (t % 1000 == 0) {
        double mean = Descriptive.mean(randomCounts);
        double sd = Descriptive.sampleVariance(randomCounts, mean);
        System.out.println(mean + "\t" + sd);
      }
             */
            if (t > 1000) {
                prob = counts[0] / counts[1];
                if (prob > 0.1) {
                    break;
                } else if (prob > 0.01 && t > 1000) {
                    break;
                } else if (prob > 0.001 && t > 10000) {
                    break;
                } else if (prob > 0.0001 && t > 100000) {
                    break;
                } else if (prob > 0.00001 && t > 1000000) {
                    break;
                } else if (prob > 0.000001 && t > 10000000) {
                    break;
                } else if (prob > 0.0000001 && t > 100000000) {
                    break;
                } else if (prob > 0.00000001 && t > 1000000000) {
                    break;
                } else if (prob > 0.000000001 && t > 2000000000) {
                    break;
                }
            }
        }
    }

}
