/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.graph;

import java.util.Comparator;

/**
 *
 * @author Miaoxin Li
 */
public class ShortArrayShortComparator implements Comparator<short[]> {

  private int index = 0;

  public ShortArrayShortComparator(int ind) {
    this.index = ind;
  }

  @Override
  public int compare(short[] o1, short[] o2) {
    return Short.compare(o1[index], o2[index]);
  }
}
