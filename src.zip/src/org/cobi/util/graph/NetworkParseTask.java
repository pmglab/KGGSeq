/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cobi.util.graph;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import org.cobi.util.text.BZPartReader;

import org.cobi.util.thread.Task;

/**
 *
 * @author mxli
 */
public class NetworkParseTask extends Task implements Callable<String> {

    BZPartReader br;
    int scoreBase = 10000;
    Map<Integer, String> geneEntryIDMap;
    double minScore;
    final List<int[]> itemList = new ArrayList<int[]>();
    Set<Integer> geneIDs = new HashSet<Integer>();

    public NetworkParseTask(BZPartReader br, Map<Integer, String> geneEntryIDMap, double minScore, int scoreBase) {
        this.br = br;
        this.geneEntryIDMap = geneEntryIDMap;
        this.minScore = minScore;
        this.scoreBase = scoreBase;
    }

    final public List<int[]> getItemList() {
        return itemList;
    }

    public Set<Integer> getGeneIDs() {
        return geneIDs;
    }

    private boolean isDiffSeq(String seq, int startI) {
        int len = seq.length();
        if (startI >= len) {
            return false;
        }
        char l = seq.charAt(startI);
        for (int i = startI + 1; i < len; i++) {
            if (l != seq.charAt(i)) {
                return true;
            }
        }
        return false;
    }

    private String findTandemSeqFromEnd(String seq1) {
        int len = seq1.length();
        if (seq1.length() == 0) {
            return null;
        }

        String seq2;
        int index = 0;
        int t = 0, len2, len3;
        int startIndex = 1;
        len = len - startIndex;
        int repeatCount = 0;
        String maxRepeatStr = null;
        int maxRepeatCount = -1;
        for (int i = 1; i < len; i++) {
            seq2 = seq1.substring(len - i + startIndex);
            len2 = seq2.length();
            len3 = len - len2 + startIndex;
            repeatCount = 0;
            for (t = len3; t > 0; t -= len2) {
                if (!seq2.equals(seq1.substring(t, t + len2))) {
                    break;
                }
                repeatCount++;
            }
            if (repeatCount > 1) {
                if (maxRepeatCount <= repeatCount) {
                    maxRepeatCount = repeatCount;
                    maxRepeatStr = seq2;
                }

            }
        }
        return maxRepeatStr;
    }

    private int isTandemSeq(String seq1, String seq2) {
        int len = seq1.length();
        if (seq2.length() == 0) {
            return -1;
        }

        int t;
        int len2 = seq2.length();
        int len3 = len - len2;
        for (t = len3; t > 0; t -= len2) {
            if (!seq2.equals(seq1.substring(t, t + len2))) {
                break;
            }
        }

        return t + len2;
    }

    //assume one file one frequency
    public void readGAINTNetworkFile() {

        int index1 = 0;
        int index2 = 1;
        int indexScore = 2;
        int id1, id2;
        float scoreF;
        int lineCounter = 0;
        byte[] currentLine = null;
        try {
            int maxColNum = index1;
            maxColNum = Math.max(maxColNum, index2);
            maxColNum = Math.max(maxColNum, indexScore);

            int[] cellDelimts = new int[maxColNum + 2];
            int shouldbeLen = maxColNum + 1;
            

            while ((currentLine = br.readLine(cellDelimts)) != null) {
                lineCounter++;
                // System.err.println(new String(currentLine));

                //this line may be trancated
                if (cellDelimts[0] < shouldbeLen) {
                    continue;
                }

                //indexREF=3
                scoreF = parseFloat(currentLine, cellDelimts[indexScore] + 1, cellDelimts[indexScore + 1]);
                if (scoreF < minScore) {
                    continue;
                }

                //indexPOS=1;
                id1 = parseInt(currentLine, index1 == 0 ? 0 : cellDelimts[index1] + 1, cellDelimts[index1 + 1]);

                if (!geneEntryIDMap.containsKey(id1)) {
                  continue;
                }
                id2 = parseInt(currentLine, cellDelimts[index2] + 1, cellDelimts[index2 + 1]);
                if (!geneEntryIDMap.containsKey(id2)) {
                   continue;
                }

                geneIDs.add(id1);
                geneIDs.add(id2);
                int[] item = new int[]{id1, id2, (short) (scoreF * scoreBase)};
                itemList.add(item);
            }

        } catch (Exception ex) {
            if (currentLine != null) {
                String ssss = new String(currentLine);
                System.err.println("Errors in a row: " + ssss);
            }
            ex.printStackTrace();
        }

      //  System.out.println(lineCounter + " rows are parsed. " +itemList.size());
    }

    @Override
    public String call() throws Exception {
        readGAINTNetworkFile();
        fireTaskComplete();
        return "";
    }

    private int parseInt(final byte[] s, int start, int end) {
        // Check for a sign.
        int num = 0;
        int sign = -1;
        int i = start;
        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        //' ': 32
        while (s[i] == 32) {
            i++;
        }

        final byte ch = s[i++];
        if (ch == 45) {
            sign = 1;
        } else {
            num = 48 - ch;
        }

        // Build the number. 
        while (i < end) {
            if (s[i] == 46) {
                return sign * num;
            } else if (s[i] < 48 || s[i] > 57) {
                i++;
            } else {
                num = num * 10 + 48 - s[i++];
            }
        }
        return sign * num;
    }

    private boolean equal(byte[] src, int start, int end, byte[] tar) {
        if (end - start != tar.length) {
            return false;
        }
        for (int i = start; i < end; i++) {
            if (src[i] != tar[i - start]) {
                return false;
            }
        }
        return true;
    }

    private int indexof(byte[] src, int start, int end, byte tar) {
        if (end - start < 1) {
            return -1;
        }
        for (int i = start; i < end; i++) {
            if (tar == src[i]) {
                return i;
            }
        }
        return -1;
    }

    private float parseFloat(byte[] f, int start, int end) {
        double ret = 0f;         // return value
        int pos = start;          // read pointer position
        int part = 0;          // the current part (int, float and sci parts of the number)
        boolean neg = false;      // true if part is a negative number
        // the max long is 2147483647
        final int MAX_INT_BIT = 9;

        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        while (f[pos] == ' ') {
            pos++;
        }
        // find start
        while (pos < end && (f[pos] < 48 || f[pos] > 57) && f[pos] != 45 && f[pos] != 46) {
            pos++;
        }

        // sign
        if (f[pos] == 45) {
            neg = true;
            pos++;
        }

        // integer part
        while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
            part = part * 10 + (f[pos++] - 48);
        }
        ret = neg ? (double) (part * -1) : (double) part;

        // float part
        if (pos < end && f[pos] == 46) {
            pos++;
            int mul = 1;
            part = 0;
            int num = 0;
            while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                num++;
                if (num <= MAX_INT_BIT) {
                    part = part * 10 + (f[pos] - 48);
                    mul *= 10;
                }
                pos++;
            }
            ret = neg ? ret - (double) part / (double) mul : ret + (double) part / (double) mul;
        }

        // scientific part
        if (pos < end && (f[pos] == 101 || f[pos] == 69)) {
            pos++;
            if (pos < end) {
                neg = (f[pos] == 45);
                pos++;
                part = 0;
                while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                    part = part * 10 + (f[pos++] - 48);
                }
                if (neg) {
                    ret = ret / Math.pow(10, part);
                } else {
                    ret = ret * Math.pow(10, part);
                }
            }
        }
        return (float) ret;
    }

    private float parseFloat(byte[] f, int start, int end, boolean takeLog) {
        double ret = 0f;         // return value
        int pos = start;          // read pointer position
        int part = 0;          // the current part (int, float and sci parts of the number)
        boolean neg = false;      // true if part is a negative number
        // the max long is 2147483647
        final int MAX_INT_BIT = 9;

        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        while (f[pos] == ' ') {
            pos++;
        }
        // find start
        while (pos < end && (f[pos] < 48 || f[pos] > 57) && f[pos] != 45 && f[pos] != 46) {
            pos++;
        }

        // sign
        if (f[pos] == 45) {
            neg = true;
            pos++;
        }

        // integer part
        while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
            part = part * 10 + (f[pos++] - 48);
        }
        ret = neg ? (double) (part * -1) : (double) part;

        // float part
        if (pos < end && f[pos] == 46) {
            pos++;
            int mul = 1;
            part = 0;
            int num = 0;
            while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                num++;
                if (num <= MAX_INT_BIT) {
                    part = part * 10 + (f[pos] - 48);
                    mul *= 10;
                }
                pos++;
            }
            ret = neg ? ret - (double) part / (double) mul : ret + (double) part / (double) mul;
        }

        // scientific part
        if (pos < end && (f[pos] == 101 || f[pos] == 69)) {
            pos++;
            if (pos < end) {
                neg = (f[pos] == 45);
                pos++;
                part = 0;
                while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                    part = part * 10 + (f[pos++] - 48);
                }
                if (neg) {
                    ret = ret / Math.pow(10, part);
                } else {
                    ret = ret * Math.pow(10, part);
                }
            }
        }
        if (takeLog) {
            if (ret == 0) {
                //the minimal value for log10
                ret = -240;
            } else {
                ret = Math.log10(ret);
            }
        }
        return (float) ret;
    }

    private double parseDouble(byte[] f, int start, int end) {
        double ret = 0f;         // return value
        int pos = start;          // read pointer position
        int part = 0;          // the current part (int, float and sci parts of the number)
        boolean neg = false;      // true if part is a negative number
        // the max long is 2147483647
        final int MAX_INT_BIT = 9;

        //ACSII
        //'0' : 48 
        //'9': 57
        //'-' 45
        //'.' 46
        //'e':101
        //'E':69
        while (f[pos] == ' ') {
            pos++;
        }
        // find start
        while (pos < end && (f[pos] < 48 || f[pos] > 57) && f[pos] != 45 && f[pos] != 46) {
            pos++;
        }

        // sign
        if (f[pos] == 45) {
            neg = true;
            pos++;
        }

        // integer part
        while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
            part = part * 10 + (f[pos++] - 48);
        }
        ret = neg ? (double) (part * -1) : (double) part;

        // float part
        if (pos < end && f[pos] == 46) {
            pos++;
            int mul = 1;
            part = 0;
            int num = 0;
            while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                num++;
                if (num <= MAX_INT_BIT) {
                    part = part * 10 + (f[pos] - 48);
                    mul *= 10;
                }
                pos++;
            }
            ret = neg ? ret - (double) part / (double) mul : ret + (double) part / (double) mul;
        }

        // scientific part
        if (pos < end && (f[pos] == 101 || f[pos] == 69)) {
            pos++;
            if (pos < end) {
                neg = (f[pos] == 45);
                pos++;
                part = 0;
                while (pos < end && !(f[pos] > 57 || f[pos] < 48)) {
                    part = part * 10 + (f[pos++] - 48);
                }
                if (neg) {
                    ret = ret / Math.pow(10, part);
                } else {
                    ret = ret * Math.pow(10, part);
                }
            }
        }
        return ret;
    }
    private int[] tempInt;

    private int[] tokenizeDelimiter(byte[] string, int startI, int endI, byte delimiter) {
        int tempLength = ((endI - startI) / 2) + 2;
        if (tempInt == null || tempInt.length < tempLength) {
            tempInt = new int[tempLength];
        }

        int i = startI;
        int j = 0;

        int wordCount = 0;
        int tt = startI;
        tempInt[wordCount] = startI;
        wordCount++;
        if (endI > string.length) {
            endI = string.length;
        }
        j = -1;
        for (; tt < endI; tt++) {
            if (string[tt] == delimiter) {
                j = tt;
                break;
            }
        }

        while (j >= 0 && j <= endI) {
            tempInt[wordCount] = j;
            wordCount++;
            i = j + 1;
            j = -1;
            for (tt = i; tt < endI; tt++) {
                if (string[tt] == delimiter) {
                    j = tt;
                    break;
                }
            }
        }

        if (i <= endI) {
            // tempInt[wordCount++] = i;
            tempInt[wordCount] = endI;
            wordCount++;
        }

        int[] result = new int[wordCount];
        System.arraycopy(tempInt, 0, result, 0, wordCount);
        return result;
    }

    private int tokenizeDelimiter(byte[] string, int startI, int endI, byte delimiter, int[] indexes) {
        int i = startI;
        int j = 0;
        int wordCount = 0;
        int tt = startI;
        j = -1;
        indexes[wordCount] = startI;
        wordCount++;
        if (endI > string.length) {
            endI = string.length;
        }
        for (; tt < endI; tt++) {
            if (string[tt] == delimiter) {
                j = tt;
                break;
            }
        }

        while (j >= 0 && j <= endI) {
            indexes[wordCount] = j;
            wordCount++;
            if (wordCount >= indexes.length) {
                break;
            }
            i = j + 1;
            j = -1;
            for (tt = i; tt < endI; tt++) {
                if (string[tt] == delimiter) {
                    j = tt;
                    break;
                }
            }
        }

        if (i <= endI) {
            // tempInt[wordCount++] = i;
            if (wordCount >= indexes.length) {
                wordCount = indexes.length - 1;
            }
            indexes[wordCount] = endI;
        }
        return wordCount + 1;
    }

}
